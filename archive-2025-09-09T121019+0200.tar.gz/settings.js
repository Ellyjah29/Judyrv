exports.bots = [
  {
    "botName": "SEPTORCH",
    "themeemoji": "🦄",
    "ownerNumber": "2349131037140",
    "phoneNumber": "",
    "expiry": "2025-09-19",
    "authKey": "IbqsCN2rorMfTtj6",
    "telegramUserId": 7738315673,
    "expiryTimestamp": 1753786696977,
    "createdAt": "2025-08-20T17:03:03.908Z",
    "expiredAt": "2025-08-20",
    "SESSION_ID": "CN5jUZ7Y#T951Eg7DAxtuafPvx2JnKbXlKX2_8hpBKW7wEkGgy-k"
  },
  {
    "botName": "TYR2zJaY#XSuANX-Mne0ZjxY6LsPnSN_F9Yg_0UGLvJvwVl3eQe4",
    "themeemoji": "🤖",
    "ownerNumber": "2349131037140",
    "phoneNumber": "",
    "expiry": "2025-10-19",
    "authKey": "SLuEfO0lJAg0vqbe",
    "telegramUserId": null,
    "expiryTimestamp": 1753810236437,
    "createdAt": "2025-08-20T17:03:03.911Z"
  },
  {
    "botName": "Joker is evil",
    "themeemoji": "⚡",
    "ownerNumber": "2349051799728",
    "phoneNumber": "",
    "expiry": "2025-09-19",
    "authKey": "kIn0Bv0rVmyyUuAw",
    "telegramUserId": 6817161756,
    "expiryTimestamp": 1751324399000,
    "createdAt": "2025-08-20T17:03:03.911Z",
    "expiredAt": "2025-08-20",
    "SESSION_ID": "aBIwVJZA#sfcClCkMdAysKFeoi9x1oBH-Zso6WwYECOwtsAu7g18"
  },
  {
    "botName": "Big nuru",
    "themeemoji": "⚡",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-09-19",
    "authKey": "HaelK5QqX9pWqXG6",
    "telegramUserId": 7931848854,
    "expiryTimestamp": 1752188399000,
    "createdAt": "2025-08-20T17:03:03.911Z",
    "SESSION_ID": "2J5g0AYL#_Wuv1QWqFB-O6jQtUVOzvjkOph_u0P3X1uYte0lxFdY"
  },
  {
    "botName": "My choice",
    "themeemoji": "👑",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-09-19",
    "authKey": "0ClXikkuyILO4qKH",
    "telegramUserId": 7021106990,
    "expiryTimestamp": 1752361199000,
    "createdAt": "2025-08-20T17:03:03.911Z",
    "SESSION_ID": "WI5XUIZT#MpyBuqHYZBvHrMpztRVzeJNg4qiE4XHgxFYTYsfQFGw"
  },
  {
    "botName": "ϻΘ尸卄เ乇乇",
    "themeemoji": "🎯",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-09-19",
    "authKey": "EHazyItl2xwUU7lV",
    "telegramUserId": 8120979984,
    "expiryTimestamp": 1752361199000,
    "createdAt": "2025-08-20T17:03:03.911Z",
    "SESSION_ID": "Dcw0RBoQ#b4G5LShZeeFAqGF8gqHdbS_FTV9bIaz98wgLN3ildGc"
  },
  {
    "botName": "New Bot",
    "themeemoji": "💫",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "pbaVIl7UKcnKCfvG",
    "telegramUserId": null,
    "expiryTimestamp": 1753788399409,
    "createdAt": "2025-08-20T17:03:03.911Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🌟",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "wFypRb8dD9SezjN7",
    "telegramUserId": null,
    "expiryTimestamp": 1754175599000,
    "createdAt": "2025-08-20T17:03:03.911Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🔥",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "Vd6VNvpEreeqUVtl",
    "telegramUserId": null,
    "expiryTimestamp": 1753796135547,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🛡️",
    "ownerNumber": "2349072231689",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "xjE3q7ZGn2c0RZCv",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🚀",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "hsSVxw4sJp3R8zRc",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "⚙️",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "MuJvMWGKVSOPPUVW",
    "telegramUserId": null,
    "expiryTimestamp": 1753869068620,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "💎",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "hB4qaMzwL35Qu2Vr",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "OM23C5VIq5TkHXAq",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "uTTJ3nJURS8zGfaU",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "SfPy98dJuIVCOmcf",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "SHnku9uHgDawU4za",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "2347087008930",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "MqLxRApmjYdAJGcy",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "FpqUayiVLJq89dZY",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "b02ZPeSIIIBClajo",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-20T17:03:03.912Z"
  },
  {
    "authKey": "wYCIV2m0mwq45OQJ",
    "createdAt": "2025-09-06T21:19:45.988Z",
    "botName": "『Ṧℌᵢᵲǒ ★』",
    "telegramUserId": 1414604371,
    "SESSION_ID": "qRRTkaaD#_rwVzrD-c3cSFufK__t-H-oQ0TKixGhQyAPLuNtBQIo",
    "expiry": "2025-10-06"
  }
];
exports.userStates = {
  "1208243019": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9603
  },
  "1865366611": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11913
  },
  "1974108270": {
    "step": "awaiting_session_id",
    "authKey": "7MgMCN9SUwNJSUA1",
    "promptMessageId": 9067
  },
  "1984959557": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3602
  },
  "2005128327": {
    "step": "awaiting_session_id",
    "authKey": "SLuEfO0lJAg0vqbe",
    "promptMessageId": 12429
  },
  "2046598405": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8170
  },
  "6834525619": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7904
  },
  "6178610094": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8106
  },
  "6582804562": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8122
  },
  "7179979536": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "lastRestart": 1753722572914,
    "promptMessageId": 8165
  },
  "7569969378": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8197
  },
  "5603889826": {
    "step": "awaiting_session_id",
    "authKey": "lNNXjvoQoMHUEFMz",
    "promptMessageId": 8265
  },
  "5613886154": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8335
  },
  "8454766080": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8372
  },
  "6318304090": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8454
  },
  "7698997438": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7584
  },
  "7561987171": {
    "step": "awaiting_session_id",
    "authKey": "JNm14SnK3sYlk6JS",
    "promptMessageId": 11281
  },
  "7262422290": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8504
  },
  "6952558480": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8547
  },
  "7705270175": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8039
  },
  "6533592280": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7348
  },
  "7489934782": {
    "step": "awaiting_session_id",
    "authKey": "jNIabtkeCERNjf6f",
    "promptMessageId": 8922
  },
  "7651849479": {
    "step": "awaiting_session_id",
    "authKey": "h9xCz2VdscUlRWt4",
    "promptMessageId": 8942
  },
  "6446529359": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9117
  },
  "7995698204": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9319
  },
  "8230335047": {
    "step": "awaiting_session_id",
    "authKey": "TKfoNBe71Z3OnTJY",
    "promptMessageId": 9332
  },
  "7543401844": {
    "step": "awaiting_session_id",
    "authKey": "TKfoNBe71Z3OnTJY",
    "promptMessageId": 9330
  },
  "7640425412": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9374
  },
  "7210517032": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9518
  },
  "5920552777": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9520
  },
  "7567588756": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9545
  },
  "7705529700": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9573
  },
  "5445162970": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9578
  },
  "6468630089": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9584
  },
  "5032528012": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9607
  },
  "6743991616": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9617
  },
  "7490089479": {
    "step": "awaiting_auth_key",
    "promptMessageId": 6790
  },
  "6914462600": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9660
  },
  "7467159978": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9297
  },
  "7169588332": {
    "step": "awaiting_auth_key",
    "promptMessageId": 5879
  },
  "7821198502": {
    "step": "awaiting_stop_auth_key",
    "promptMessageId": 11106
  },
  "6777244790": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9822
  },
  "6127139212": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11088
  },
  "6505939301": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11091
  },
  "7270537170": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11094
  },
  "6072756403": {
    "step": "awaiting_session_id",
    "authKey": "lV7rYXrJv5qdBMA2",
    "promptMessageId": 11228
  },
  "7664278052": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11396
  },
  "7685257379": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11571
  },
  "6411182624": {
    "step": "awaiting_session_id",
    "authKey": "4Qhyt6lH3eejUUd2",
    "promptMessageId": 11671
  },
  "7358203263": {
    "step": "awaiting_session_id",
    "authKey": "RzB7jXSDHiFrwM8f",
    "promptMessageId": 11681
  },
  "6934593882": {
    "step": "awaiting_auth_key",
    "promptMessageId": 10898
  },
  "7894470833": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12058
  },
  "7880561946": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12061
  },
  "7980642394": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12116
  },
  "6661104825": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12143
  },
  "8389072721": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12153
  },
  "7486768415": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12190
  },
  "7021571970": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12213
  },
  "7405226005": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12224
  },
  "7043011281": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12226
  },
  "6482559021": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12231
  },
  "7910332392": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12248
  },
  "7187358479": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12256
  },
  "7288391514": {
    "step": "awaiting_stop_auth_key",
    "promptMessageId": 12268
  },
  "8292514675": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12290
  },
  "6550062103": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12354
  },
  "7845636719": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12371
  },
  "7013483934": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12378
  },
  "6339309206": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12383
  },
  "7769985707": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12400
  },
  "7391534860": {
    "step": "awaiting_session_id",
    "authKey": "SLuEfO0lJAg0vqbe",
    "lastRestart": 1755857184710,
    "promptMessageId": 12435
  },
  "5520343572": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12469
  },
  "7417554225": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12486
  },
  "8135871264": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12534
  },
  "8305013620": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12538
  },
  "7298759934": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12548
  },
  "7866376666": {
    "step": "awaiting_auth_key",
    "promptMessageId": 10919
  },
  "8096124310": {
    "step": "awaiting_auth_key",
    "promptMessageId": 12741
  }
};
exports.blacklistedUsers = [];