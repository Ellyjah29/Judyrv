const axios = require('axios');

async function urlShortCommand(sock, chatId, message, botId) {
    const args = message.trim().split(' ').slice(1).join(' ');

    if (!args && !message.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
        return sock.sendMessage(chatId, {
            text: '❌ Please provide a URL to shorten or reply to a message with a link.',
        });
    }

    let urlToShorten = args;

    // If no URL provided, check quoted message
    if (!urlToShorten) {
        const quotedMsg = message.message.extendedTextMessage.contextInfo.quotedMessage;
        const quotedText = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text || '';
        urlToShorten = quotedText.trim();
    }

    // Basic URL validation
    const urlPattern = /^(https?:\/\/)?([\w.-]+)\.([a-z]{2,})(\/\S*)?$/i;
    if (!urlPattern.test(urlToShorten)) {
        return sock.sendMessage(chatId, {
            text: '❌ Invalid URL. Please provide a valid web address starting with http:// or https://',
        });
    }

    try {
        const response = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(urlToShorten)}`);
        const shortUrl = response.data;

        await sock.sendMessage(chatId, {
            text: `🔗 Shortened URL:\n${shortUrl}`,
        });
    } catch (error) {
        console.error('Error shortening URL:', error);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to shorten the URL. Please try again later.',
        });
    }
}

module.exports = { urlShortCommand };