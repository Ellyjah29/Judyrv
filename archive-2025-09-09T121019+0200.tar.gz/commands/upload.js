const fs = require('fs');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { downloadMediaMessage } = require('baileys');

// Ensure tmp directory exists
function ensureTmpDir() {
    const tmpDir = path.join(__dirname, '../tmp');
    if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
    }
    return tmpDir;
}

async function uploadCommand(sock, chatId, message, botId) {
    try {
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const contextInfo = message.message?.extendedTextMessage?.contextInfo;

        if (!quoted) {
            return await sock.sendMessage(chatId, {
                text: '❌ Please reply to an image or video to upload.'
            });
        }

        // Supported media types
        const mediaTypes = ['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage'];
        const mediaType = Object.keys(quoted).find(type => mediaTypes.includes(type));

        if (!mediaType) {
            return await sock.sendMessage(chatId, {
                text: '❌ Unsupported media type.'
            });
        }

        const mediaMsg = {
            key: {
                remoteJid: chatId,
                id: contextInfo?.stanzaId,
                fromMe: false,
                participant: contextInfo?.participant
            },
            message: quoted
        };

        const mediaBuffer = await downloadMediaMessage(mediaMsg, 'buffer', {}, { reuploadRequest: sock });

        const mimeType = quoted[mediaType]?.mimetype || 'application/octet-stream';
        const ext = mimeType.split('/')[1]?.split(';')[0] || 'bin';

        const tmpDir = ensureTmpDir();
        const filePath = path.join(tmpDir, `upload_${Date.now()}.${ext}`);
        fs.writeFileSync(filePath, mediaBuffer);

        // Upload to Pixeldrain
        const form = new FormData();
        form.append('file', fs.createReadStream(filePath));

        const response = await axios.post('https://pixeldrain.com/api/file', form, {
            headers: form.getHeaders()
        });

        fs.unlinkSync(filePath); // Clean up

        const fileId = response.data?.id;

        if (!fileId) {
            throw new Error('Unexpected Pixeldrain response: ' + JSON.stringify(response.data));
        }

        const link = `https://pixeldrain.com/u/${fileId}`;

        await sock.sendMessage(chatId, {
            text: `✅ File uploaded successfully!\n\n🔗 Link: ${link}`
        });

    } catch (error) {
        console.error('❌ Pixeldrain Upload Error:', error.stack || error.message);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to upload file. Try again later.'
        });
    }
}

module.exports = { uploadCommand };