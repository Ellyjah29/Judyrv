const yts = require('yt-search');
const ytdl = require('@distube/ytdl-core');
const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');

// Load environment variables
require('dotenv').config();

async function videoCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        if (!text) {
            return await sock.sendMessage(chatId, { text: "Please provide a video name or YouTube link." });
        }

        // Parse quality from the command
        let quality = '720'; // Default to 720p for HD
        let searchQuery = text.split(' ').slice(1).join(' ').trim();

        // Extract quality if provided
        const qualityMatch = searchQuery.match(/quality:(\w+)/);
        if (qualityMatch) {
            quality = qualityMatch[1];
            searchQuery = searchQuery.replace(/quality:\w+/, '').trim();
        }

        // Validate quality
        const supportedQualities = ['144', '240', '360', '480', '720'];
        if (!supportedQualities.includes(quality)) {
            return await sock.sendMessage(chatId, {
                text: `Invalid quality. Please choose one of: ${supportedQualities.join(', ')}.`
            });
        }

        // Determine if input is a YouTube link or search query
        let videoUrl = '';
        let videoTitle = 'Unknown Title';
        let videoThumbnail = '';
        let duration = 0;
        if (searchQuery.startsWith('http://') || searchQuery.startsWith('https://')) {
            videoUrl = searchQuery;
            try {
                const cookies = fs.existsSync('cookies.json') ? JSON.parse(fs.readFileSync('cookies.json')) : [];
                const agent = cookies.length ? ytdl.createAgent(cookies) : undefined;
                const info = await ytdl.getInfo(videoUrl, { agent });
                videoTitle = info.videoDetails.title;
                videoThumbnail = info.videoDetails.thumbnails[0]?.url || `https://i.ytimg.com/vi/${info.videoDetails.videoId}/0.jpg`;
                duration = parseInt(info.videoDetails.lengthSeconds);
                if (duration > 300) { // 5 minutes
                    return await sock.sendMessage(chatId, { text: "Video is too long (>5 minutes). Try a shorter video." });
                }
            } catch (e) {
                console.error(`Failed to get video info for ${videoUrl}: ${e.message}`);
            }
        } else {
            // Search YouTube for the video
            const { videos } = await yts(searchQuery);
            if (!videos || videos.length === 0) {
                return await sock.sendMessage(chatId, { text: "No videos found! Try a different query." });
            }
            // Filter out live streams, Shorts, and prefer videos with audio
            const suitableVideo = videos.find(v => 
                !v.live && 
                !v.url.includes('/shorts/') && 
                v.duration.seconds > 30 && 
                v.duration.seconds <= 300 && // 5 minutes max
                (v.title.toLowerCase().includes('official') || v.title.toLowerCase().includes('video') || v.title.toLowerCase().includes('music'))
            );
            if (!suitableVideo) {
                return await sock.sendMessage(chatId, { text: "No suitable videos found (must be 30s-5min). Try a direct YouTube link or different query." });
            }
            videoUrl = suitableVideo.url;
            videoTitle = suitableVideo.title;
            videoThumbnail = suitableVideo.thumbnail;
            duration = suitableVideo.duration.seconds;
            console.log(`Selected video: ${videoTitle} (${videoUrl})`);
        }

        // Calculate target bitrate based on duration to stay under 15MB
        const maxFileSizeBits = 15 * 8 * 1024 * 1024; // 15MB in bits
        const audioBitrate = 128; // 128kbps for audio
        const audioBits = audioBitrate * 1000 * duration; // Total audio bits
        const maxVideoBits = maxFileSizeBits - audioBits; // Remaining bits for video
        let videoBitrate = Math.floor(maxVideoBits / (duration * 1000)); // Video bitrate in kbps
        if (videoBitrate > 7000) videoBitrate = 7000; // Cap at 7000kbps for quality
        if (videoBitrate < 250) videoBitrate = 250; // Minimum 250kbps to avoid extreme compression
        console.log(`Calculated video bitrate: ${videoBitrate}kbps for ${duration}s`);

        // Download video with audio using ytdl-core
        let tempFile;
        let outputFile;
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
        const fileExtension = 'mp4';
        tempFile = path.join(tempDir, `${Date.now()}_raw.${fileExtension}`);
        outputFile = path.join(tempDir, `${Date.now()}_processed.${fileExtension}`);

        try {
            console.log(`Attempting download with quality: ${quality}p using ytdl-core`);
            const cookies = fs.existsSync('cookies.json') ? JSON.parse(fs.readFileSync('cookies.json')) : [];
            const agent = cookies.length ? ytdl.createAgent(cookies) : undefined;
            const info = await ytdl.getInfo(videoUrl, { agent });

            // Select format with both video and audio
            let format;
            try {
                format = ytdl.chooseFormat(info.formats, {
                    filter: format => format.container === 'mp4' && format.hasVideo && format.hasAudio && format.qualityLabel === `${quality}p`
                });
            } catch (error) {
                console.warn(`No format found for quality ${quality}p with audio and video. Falling back to 360p.`);
                quality = '360';
                format = ytdl.chooseFormat(info.formats, {
                    filter: format => format.container === 'mp4' && format.hasVideo && format.hasAudio && format.qualityLabel === '360p'
                });
            }

            if (!format) {
                throw new Error(`No suitable format found with video and audio at ${quality}p`);
            }

            const stream = ytdl(videoUrl, { format, agent });
            const writer = fs.createWriteStream(tempFile);
            stream.pipe(writer);
            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });

            // Check file size
            const stats = fs.statSync(tempFile);
            if (stats.size < 100000) {
                throw new Error(`Downloaded file too small (${stats.size} bytes)`);
            }
        } catch (error) {
            console.error(`ytdl-core failed for ${videoUrl} at ${quality}p: ${error.message}`);
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            return await sock.sendMessage(chatId, {
                text: `Download failed: ${error.message}. Try a different video or lower quality.`
            });
        }

        // Check if the downloaded video is already compatible
        try {
            const metadata = await new Promise((resolve, reject) => {
                ffmpeg.ffprobe(tempFile, (err, metadata) => {
                    if (err) reject(err);
                    else resolve(metadata);
                });
            });

            const videoStream = metadata.streams.find(s => s.codec_type === 'video');
            const audioStream = metadata.streams.find(s => s.codec_type === 'audio');
            const fileSize = fs.statSync(tempFile).size;

            if (fileSize < 15000000 && 
                videoStream && audioStream && 
                videoStream.codec_name === 'h264' && 
                audioStream.codec_name === 'aac' && 
                metadata.format.format_name === 'mp4') {
                // Already compatible, send directly
                console.log(`Video is already compatible. Sending directly.`);
                await sock.sendMessage(chatId, {
                    video: { url: tempFile },
                    caption: `🎥 *${videoTitle}* (${quality}p)\nThumbnail: ${videoThumbnail}`,
                    mimetype: 'video/mp4'
                });
                if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
                return;
            }
        } catch (error) {
            console.error(`ffprobe failed: ${error.message}`);
        }

        // Re-encode video for WhatsApp compatibility
        try {
            console.log(`Re-encoding video for WhatsApp compatibility...`);
            await new Promise((resolve, reject) => {
                const ffmpegCmd = ffmpeg(tempFile)
                    .videoCodec('libx264')
                    .audioCodec('aac')
                    .videoBitrate(`${videoBitrate}k`)
                    .audioBitrate('128k')
                    .outputOptions([
                        '-preset ultrafast', // Fast encoding
                        '-movflags +faststart',
                        '-max_muxing_queue_size 1024',
                        '-map 0:v:0', // Map first video stream
                        '-map 0:a:0?', // Map first audio stream if present
                        '-c:a aac', // Ensure AAC audio
                        '-ar 44100', // Audio sample rate
                        '-ac 2' // Stereo audio
                    ]);

                // Set resolution based on quality
                if (quality === '720') {
                    ffmpegCmd.size('1280x720');
                } else if (quality === '480') {
                    ffmpegCmd.size('854x480');
                } else if (quality === '360') {
                    ffmpegCmd.size('640x360');
                } else if (quality === '240') {
                    ffmpegCmd.size('426x240');
                } else if (quality === '144') {
                    ffmpegCmd.size('256x144');
                }

                ffmpegCmd
                    .output(outputFile)
                    .on('end', resolve)
                    .on('error', err => {
                        console.error(`FFmpeg error: ${err.message}`);
                        reject(new Error(`Re-encoding failed: ${err.message}`));
                    })
                    .run();
            });

            // Verify re-encoded file
            let stats = fs.statSync(outputFile);
            console.log(`Re-encoded file size: ${stats.size} bytes`);
            if (stats.size < 100000) {
                throw new Error(`Re-encoded file too small (${stats.size} bytes)`);
            }
            if (stats.size > 15000000) {
                console.warn(`File size (${stats.size} bytes) exceeds WhatsApp limit. Attempting compression...`);
                const compressedFile = path.join(tempDir, `${Date.now()}_compressed.${fileExtension}`);
                await new Promise((resolve, reject) => {
                    ffmpeg(outputFile)
                        .size('640x360') // Set to 360p
                        .videoCodec('libx264')
                        .audioCodec('aac')
                        .videoBitrate('250k')
                        .audioBitrate('64k')
                        .outputOptions([
                            '-preset ultrafast', // Faster encoding
                            '-movflags +faststart',
                            '-max_muxing_queue_size 1024',
                            '-map 0:v:0', // Map first video stream
                            '-map 0:a:0?', // Map first audio stream if present
                            '-c:a aac', // Ensure AAC audio
                            '-ar 44100', // Audio sample rate
                            '-ac 2' // Stereo audio
                        ])
                        .output(compressedFile)
                        .on('end', () => {
                            fs.unlinkSync(outputFile);
                            fs.renameSync(compressedFile, outputFile);
                            resolve();
                        })
                        .on('error', err => {
                            console.error(`FFmpeg compression error: ${err.message}`);
                            reject(new Error(`Compression failed: ${err.message}`));
                        })
                        .run();
                });
            }

            // Send video to WhatsApp
            await sock.sendMessage(chatId, {
                video: { url: outputFile },
                caption: `🎥 *${videoTitle}* (${quality}p)\nThumbnail: ${videoThumbnail}`,
                mimetype: 'video/mp4'
            });

            // Clean up
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
        } catch (error) {
            console.error(`Processing failed: ${error.message}`);
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
            return await sock.sendMessage(chatId, {
                text: `Processing failed: ${error.message}. Try a shorter video or lower quality.`
            });
        }
    } catch (error) {
        console.error(`Error in videoCommand: ${error.message}`);
        return await sock.sendMessage(chatId, {
            text: `An error occurred: ${error.message}. Please try again.`
        });
    }
}

module.exports = videoCommand;