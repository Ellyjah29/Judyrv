/**
 * WhatsApp Bot - STABLE PRODUCTION EDITION (Hybrid: MongoDB + Telegram + File Sync)
 * Features: Auto-Reconnect, Hot-Reload, Video Startup, Advanced Links, LID Support, MongoDB Sync
 * Library: @whiskeysockets/baileys (Stable)
 * Copyright (c) 2025 Septorch
 */

require('dotenv').config(); // 🟢 Loads variables from .env file

const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const telegramBot = require('./telegrambot.js').bot; 
const { MongoClient } = require('mongodb'); // 🟢 MongoDB Added
const { promises: fsp } = fs;
const { Boom } = require('@hapi/boom');
const PhoneNumber = require('awesome-phonenumber');
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, await, sleep, reSize, delay } = require('./lib/myfunc');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  jidDecode,
  proto,
  jidNormalizedUser,
  makeCacheableSignalKeyStore
} = require("@whiskeysockets/baileys"); 
const NodeCache = require("node-cache");
const pino = require("pino");
const chokidar = require('chokidar');
const WebSocket = require('ws');
const { File } = require('megajs'); 
const yauzl = require('yauzl');      

// --- [ 🟢 MONGODB CONFIGURATION ] ---
const MONGO_URI = process.env.MONGO_URI; 
const DB_NAME = "SeptorchBot";
const COLLECTION_NAME = "bots";
let db, botsCollection;

// 🟢 GLOBAL BOOT TIME (Process Start)
global.bootTime = Math.floor(Date.now() / 1000);

// Load handlers
let handlers = require('./main');
let handleMessages = handlers.handleMessages;
let handleGroupParticipantUpdate = handlers.handleGroupParticipantUpdate;
let handleStatus = handlers.handleStatus;

// Global store for bots
global.botInstances = {};
global.settings = require('./settings');
global.isReloading = false; 
global.lastInternalSave = 0; 
global.isInternalUpdate = false; // 🔒 Prevents sync loops

// Deduplication Cache
const processedMsgCache = new NodeCache({ stdTTL: 120, checkperiod: 150 });

const store = {
  messages: {},
  contacts: {},
  chats: {},
  groupMetadata: async (jid) => { return {}; },
  bind: function (ev) {
    ev.on('messages.upsert', ({ messages }) => {
      messages.forEach(msg => {
        if (msg.key && msg.key.remoteJid) {
          this.messages[msg.key.remoteJid] = this.messages[msg.key.remoteJid] || {};
          this.messages[msg.key.remoteJid][msg.key.id] = msg;
        }
      });
    });

    // 🟢 Handle Initial Contact Sync (Upsert)
    ev.on('contacts.upsert', (contacts) => {
        const contactsList = Array.isArray(contacts) ? contacts : contacts.contacts;
        if (contactsList) {
            contactsList.forEach(contact => {
                if (contact.id) {
                    this.contacts[contact.id] = { ...(this.contacts[contact.id] || {}), ...contact };
                }
            });
        }
    });

    // Handle Contact Updates
    ev.on('contacts.update', (contacts) => {
      contacts.forEach(contact => {
        if (contact.id) {
            this.contacts[contact.id] = { ...(this.contacts[contact.id] || {}), ...contact };
        }
      });
    });
    
    ev.on('chats.set', (chats) => { this.chats = chats; });
  },
  loadMessage: async (jid, id) => { return this.messages[jid]?.[id] || null; }
};

// 🟢 CRITICAL: Expose store globally for isOwner.js
global.store = store;

// --- [HELPER FUNCTIONS] ---

function getLidFromJid(jid) {
    if (!jid) return null;
    const normalizedJid = jid.split(':')[0] + '@s.whatsapp.net';
    if (store.contacts[normalizedJid] && store.contacts[normalizedJid].lid) {
        return store.contacts[normalizedJid].lid;
    }
    return null;
}

// 🟢 NEW: Helper to Nuking Session Folders
function deleteSessionFolder(botId) {
    const sessionPath = path.join(__dirname, 'session', botId);
    try {
        if (fs.existsSync(sessionPath)) {
            fs.rmSync(sessionPath, { recursive: true, force: true });
            console.log(chalk.red(`🗑️  Session Deleted for ${botId} (Cleanup/Expired)`));
        }
    } catch (e) {
        console.error(chalk.red(`Failed to delete session ${botId}:`), e.message);
    }
}

async function downloadSession(sessionPath, sessionId) {
  const zipPath = path.join(sessionPath, 'session.zip');
  if (fs.existsSync(path.join(sessionPath, 'creds.json'))) {
    console.log(chalk.gray(`📁 Session exists in ${sessionPath} — skipping download.`));
    return;
  }
  if (!sessionId) {
    console.log(chalk.yellow(`⚠️ SESSION_ID not provided for ${sessionPath}`));
    return;
  }
  try {
    console.log(chalk.blue(`📥 Downloading session ZIP...`));
    await fs.promises.mkdir(sessionPath, { recursive: true });
    const file = File.fromURL(`https://mega.nz/file/${sessionId}`);
    const buffer = await new Promise((resolve, reject) => {
      file.download((err, data) => err ? reject(err) : resolve(data));
    });
    fs.writeFileSync(zipPath, buffer);
    await new Promise((resolve, reject) => {
      yauzl.open(zipPath, { lazyEntries: true }, (err, zipfile) => {
        if (err) return reject(err);
        zipfile.readEntry();
        zipfile.on('entry', (entry) => {
          if (/\/$/.test(entry.fileName)) {
            fs.mkdirSync(path.join(sessionPath, entry.fileName), { recursive: true });
            zipfile.readEntry();
          } else {
            zipfile.openReadStream(entry, (err, readStream) => {
              if (err) return reject(err);
              const filePath = path.join(sessionPath, entry.fileName);
              fs.mkdirSync(path.dirname(filePath), { recursive: true });
              readStream.pipe(fs.createWriteStream(filePath)).on('close', () => zipfile.readEntry());
            });
          }
        });
        zipfile.once('end', () => {
          if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);
          console.log(chalk.green(`✅ Session unzipped successfully.`));
          resolve();
        });
      });
    });
  } catch (error) {
    console.error(chalk.red(`❌ Download failed:`), error.message);
    if (fs.existsSync(sessionPath)) fs.rmSync(sessionPath, { recursive: true, force: true });
  }
}

function getExpiryTimestamp(expiryDateStr) {
  const date = new Date(expiryDateStr);
  return isNaN(date.getTime()) ? null : date.setHours(23, 59, 59, 999);
}

// --- [ 🟢 MONGODB SYNC FUNCTIONS ] ---

// 1. DB -> File (UPDATED: Only writes file, does NOT update global state directly)
async function backupToSettingsJS(newBotsList = null) {
    try {
        const allBotsRaw = newBotsList || await botsCollection.find({}).toArray();
        
        // 🟢 FIX: Deduplicate bots based on authKey/ownerNumber before writing
        const uniqueBotsMap = new Map();
        
        allBotsRaw.forEach(bot => {
            const uniqueKey = bot.ownerNumber || bot.authKey; 
            if (!uniqueKey) return;

            if (!uniqueBotsMap.has(uniqueKey) || (bot.SESSION_ID && !uniqueBotsMap.get(uniqueKey).SESSION_ID)) {
                // 🟢 REMOVE DB FIELDS: Strip botId and _id so they don't get locked in settings.js
                const { _id, botId, ...rest } = bot; 
                uniqueBotsMap.set(uniqueKey, rest);
            }
        });

        const cleanBots = Array.from(uniqueBotsMap.values());
        let currentFile = {};
        try { currentFile = require('./settings'); } catch (e) {}
        
        const settingsContent = `/**
 * ⚠️ AUTOMATICALLY GENERATED (Synced with MongoDB)
 * Edit this file to push changes to DB, or edit DB to push changes here.
 * Last Update: ${new Date().toLocaleString()}
 */

exports.bots = ${JSON.stringify(cleanBots, null, 4)};
exports.userStates = ${JSON.stringify(currentFile.userStates || {}, null, 2)};
exports.blacklistedUsers = ${JSON.stringify(currentFile.blacklistedUsers || [], null, 2)};
`;
        fs.writeFileSync('./settings.js', settingsContent);
        
        // Mark that we just saved, so Chokidar knows it was us
        global.lastInternalSave = Date.now();
        
        return cleanBots; // Return the new list for immediate use
    } catch (err) {
        console.error(chalk.red("❌ Sync Failed (DB->File):"), err.message);
        return [];
    }
}

// 2. File -> DB (Push changes from file to DB)
async function importFromSettings() {
    console.log(chalk.yellow('📂 Settings.js changed. Syncing to MongoDB...'));
    try {
        const settingsPath = require.resolve('./settings.js');
        delete require.cache[settingsPath];
        const localSettings = require('./settings.js');
        
        if (!localSettings || !localSettings.bots) return;

        for (const bot of localSettings.bots) {
            // 🟢 NEW ID LOGIC: Ensure Bot ID exists (bot_OWNERNUMBER)
            if (!bot.botId) bot.botId = `bot_${bot.ownerNumber}`;
            
            if (bot.SESSION_ID) console.log(chalk.green(`   ✅ Syncing Session for ${bot.botId}`));

            await botsCollection.updateOne(
                { botId: bot.botId },
                { $set: bot },
                { upsert: true }
            );
        }
        console.log(chalk.green('✅ Synced (File->DB)'));
    } catch (err) {
        console.error(chalk.red('❌ Sync Failed (File->DB):'), err.message);
    }
}

// --- [CORE BOT LOGIC] ---

async function startBot(botConfig, botId) {
  // 🟢 NEW ID LOGIC: Fallback to ownerNumber if botId is missing
  const safeBotId = botId || botConfig.botId || `bot_${botConfig.ownerNumber || 'undefined'}`;

  console.log(chalk.cyan(`🚀 Starting ${safeBotId}...`));
  await safeStopBot(safeBotId);
  const sessionPath = path.join(__dirname, 'session', safeBotId);
  if (botConfig.expiry) botConfig.expiryTimestamp = getExpiryTimestamp(botConfig.expiry);
  
  await downloadSession(sessionPath, botConfig.SESSION_ID);
  let { version } = await fetchLatestBaileysVersion();
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
  
  const XeonBotInc = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'fatal' }))
    },
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    getMessage: async key => {
      let jid = jidNormalizedUser(key.remoteJid);
      let msg = await store.loadMessage(jid, key.id);
      return msg?.message || '';
    },
    defaultQueryTimeoutMs: undefined,
    connectTimeoutMs: 20000, 
    keepAliveIntervalMs: 10000,
    syncFullHistory: true, 
    emitOwnEvents: true, 
    retryRequestDelayMs: 2000 
  });

  if (!global.botInstances) global.botInstances = {};
  global.botInstances[safeBotId] = XeonBotInc;
  global.botInstances[safeBotId].launchTime = Math.floor(Date.now() / 1000);

  const originalSendMessage = XeonBotInc.sendMessage;
  
  XeonBotInc.sendMessage = async (jid, content, options = {}) => {
    if (options.skipHumanize) return await originalSendMessage(jid, content, options);
    try {
      await XeonBotInc.sendPresenceUpdate('composing', jid);
      await delay(500); 
      const result = await originalSendMessage(jid, content, options);
      if (jid.endsWith('@s.whatsapp.net') || jid.endsWith('@g.us')) {
        await XeonBotInc.readMessages([{
          remoteJid: jid,
          id: result.key.id,
          participant: result.key.participant || jid
        }]);
      }
      return result;
    } catch (error) {
      return await originalSendMessage(jid, content, options);
    }
  };

  XeonBotInc.sendLidMessage = async (jid, content, options = {}) => {
    let targetJid = jid;
    if (jid.endsWith('@g.us')) {
        return await XeonBotInc.sendMessage(jid, content, options);
    }
    const lid = getLidFromJid(jid);
    if (lid) targetJid = lid;
    
    return await XeonBotInc.sendMessage(targetJid, content, options);
  };

  global.owner = [botConfig.ownerNumber];
  store.bind(XeonBotInc.ev);
  
  setupEventHandlers(XeonBotInc, safeBotId, botConfig);
  
  XeonBotInc.ev.on('connection.update', async (update) => {
    await handleConnectionUpdate(XeonBotInc, update, botConfig, safeBotId);
  });
  
  XeonBotInc.ev.on('creds.update', saveCreds);
  return XeonBotInc;
}

// --- [CONNECTION HANDLER WITH SELF-REPAIR] ---

async function handleConnectionUpdate(sock, update, initialBotConfig, botId) {
  const { connection, lastDisconnect } = update;
  const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
  const botIndex = parseInt(botId.replace('bot', '')) - 1;
  
  if (connection === 'open') {
    // 🟢 REFRESH CONFIGURATION
    const botConfig = global.settings.bots[botIndex] || initialBotConfig;

    // 1. Extract IDs
    const rawUserJid = sock.user.id;
    const rawUserLid = sock.user.lid;

    const userPhone = rawUserJid.split(':')[0]; // 9231...
    const userLid   = rawUserLid ? rawUserLid.split(':')[0] : 'N/A'; // 2647...

    console.log(chalk.green(`✅ ${botId} Connected!`));
    console.log(chalk.green(`   📱 JID: ${userPhone}`));
    console.log(chalk.green(`   🆔 LID: ${userLid}`));
    
    // 🟢 MONGODB ID UPDATE LOGIC
    // When connected, we know the real number. Update DB immediately.
    if (botsCollection) {
        const realBotId = `bot_${userPhone}`;
        await botsCollection.updateOne(
            { botId: botId }, // Find by current ID (even if it's the old 'bot1' format)
            { 
                $set: { 
                    status: 'online', 
                    ownerNumber: userPhone, // <--- FORCE SAVE as ownerNumber
                    botId: realBotId,       // <--- FORCE UPDATE botId to new format
                    lastSeen: new Date() 
                },
                $unset: { jid: "" } 
            }
        );
        console.log(chalk.cyan(`💾 Database Fixed: ownerNumber=${userPhone}`));
    }

    if (global.store) {
        const standardJid = userPhone + '@s.whatsapp.net';
        const standardLid = userLid !== 'N/A' ? (userLid + '@lid') : null;

        global.store.contacts[standardJid] = {
            id: standardJid,
            lid: standardLid,
            name: 'Me',
            notify: 'Me',
            verifiedName: 'Me'
        };
        console.log(chalk.cyan(`🔗 Identity Linked in Store: ${userPhone} <==> ${userLid}`));
    }

    // Config Updates
    if (!global.botInstances[botId]) global.botInstances[botId] = {};
    global.botInstances[botId].phoneJid = rawUserJid;
    global.botInstances[botId].lid = rawUserLid;
    global.botInstances[botId].retryCount = 0;
    global.botInstances[botId].lastMessageTime = Date.now();

    if (global.expiryAlertSent) delete global.expiryAlertSent;

    if (botConfig.manuallyStopped) {
      delete botConfig.manuallyStopped;
      try {
        const settingsPath = path.join(__dirname, 'settings.js');
        const newSettings = { ...global.settings };
        if (newSettings.bots[botIndex]) {
          delete newSettings.bots[botIndex].manuallyStopped;
          const data = `exports.bots = ${JSON.stringify(newSettings.bots, null, 2)};
exports.userStates = ${JSON.stringify(newSettings.userStates || {}, null, 2)};
exports.blacklistedUsers = ${JSON.stringify(newSettings.blacklistedUsers || [], null, 2)};`;
          
          global.lastInternalSave = Date.now();
          fs.writeFileSync(settingsPath, data);
          global.settings = newSettings;
        }
      } catch (e) {}
    }
    
    const botNumber = userPhone + '@s.whatsapp.net';
    
    if (botConfig.sendConnectionMessage !== false) {
        const startupCaption = `
🤖 *${botConfig.botName} IS NOW ONLINE*

✅ *System Status:* Stable
⚡ *Response Speed:* Ultra Fast
🛡️ *Security:* Active

📢 *STAY UPDATED:*
Join our official channels for updates, giveaways, and support!

👥 *Official Group:*
https://chat.whatsapp.com/GGBjhgrxiAS1Xf5shqiGXH

📰 *Official Channel:*
https://whatsapp.com/channel/0029Vb1ydGk8qIzkvps0nZ04

_Power up your WhatsApp experience!_ 🚀
`;

    try {
        const lastNotification = global.botInstances[botId]?.lastOnlineNotification || 0;
        const notificationCooldown = 86400000;
        if (botConfig.telegramUserId && !botConfig.silentStart && 
           (Date.now() - lastNotification > notificationCooldown)) {
            if (global.botInstances[botId]) global.botInstances[botId].lastOnlineNotification = Date.now();
        }

        const videoPath = path.join(__dirname, 'assets', 'bot_startup.mp4');
        
        if (fs.existsSync(videoPath)) {
            await sock.sendMessage(botNumber, { 
                video: fs.readFileSync(videoPath),
                caption: startupCaption,
                gifPlayback: false, 
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363387922693296@newsletter',
                        newsletterName: 'SEPTORCH',
                        serverMessageId: -1
                    }
                },
                skipHumanize: true 
            });
        } else {
            await sock.sendMessage(botNumber, { 
                text: startupCaption,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363387922693296@newsletter',
                        newsletterName: 'SEPTORCH',
                        serverMessageId: -1
                    }
                },
                skipHumanize: true 
            });
        }
    } catch (e) {
        console.error("Startup Msg Error:", e.message);
    }
  }

  } else if (connection === 'close') {
    if (initialBotConfig.manuallyStopped) return;
    console.log(chalk.red(`❌ Connection Closed: ${statusCode}`));

    const fatalErrors = [401, 403, 423, 440];

    if (statusCode === DisconnectReason.loggedOut || fatalErrors.includes(statusCode)) {
      console.log(chalk.red(`🛑 ${botId} Session Invalid (Error: ${statusCode}). Cleaning session...`));
      
      const sessionPath = path.join(__dirname, 'session', botId);
      try { 
          if (fs.existsSync(sessionPath)) fs.rmSync(sessionPath, { recursive: true, force: true }); 
      } catch (e) {}
      
      if (global.botInstances[botId]) global.botInstances[botId].loggedOut = true;
      
      // Update DB Status
      if (botsCollection) {
          await botsCollection.updateOne({ botId: initialBotConfig.botId || `bot_${initialBotConfig.ownerNumber}` }, { $set: { status: 'logged_out', SESSION_ID: null } });
      }

      if (initialBotConfig.telegramUserId) {
        let reasonText = "Session Logged Out";
        if (statusCode === 401) reasonText = "Unauthorised Access";
        else if (statusCode === 403) reasonText = "Access Forbidden (Logged Out)";
        else if (statusCode === 423) reasonText = "Account Temporarily Locked";
        else if (statusCode === 440) reasonText = "Login Session Timed Out";

        const friendlyMessage = `
⚠️ *ATTENTION: ACTION REQUIRED*

🤖 *Bot Name:* ${initialBotConfig.botName}
🛑 *Status:* Disconnected
📉 *Reason:* ${reasonText} (Code ${statusCode})

_The previous session file has been removed to prevent system errors._

🔄 *TO RECONNECT:*
1️⃣ Click /start
2️⃣ Tap the *My Bots* button
3️⃣ Select your bot (*${initialBotConfig.botName}*)
4️⃣ Tap the *Reset* button
`;
        try { 
            await telegramBot.sendMessage(initialBotConfig.telegramUserId, friendlyMessage, { parse_mode: 'Markdown' }); 
        } catch (e) {}
      }
      return; 
    }
    
    console.log(chalk.yellow(`🔄 Reconnecting ${botId}...`));
    await safeStopBot(botId);
    await startBot(initialBotConfig, botId);
  }
}

// --- [EVENT SETUP] ---

function setupEventHandlers(sock, botId, botConfig) {
  sock.public = true;
  sock.serializeM = (m) => require('./lib/myfunc').smsg(sock, m, store);
  sock.decodeJid = (jid) => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {};
      return decode.user && decode.server && decode.user + '@' + decode.server || jid;
    } else return jid;
  };
  sock.ev.on('messages.upsert', async (chatUpdate) => {
    if (global.isReloading || botConfig.manuallyStopped) return;
    try {
        await handleMessageWithIsolation(sock, chatUpdate, botId, botConfig);
    } catch (e) { console.error('Msg Error:', e.message); }
  });
  sock.ev.on('group-participants.update', async (update) => {
    if (!global.isReloading) await handleGroupParticipantUpdate(sock, update, botId);
  });
  sock.ev.on('status.update', async (status) => {
    if (!global.isReloading) await handleStatus(sock, status, botId);
  });
}

// SAFE MESSAGE HANDLING
async function handleMessageWithIsolation(sock, chatUpdate, botId, initialBotConfig) {
  try {
    const mek = chatUpdate.messages[0];
    if (!mek?.message) return;

    if (global.botInstances[botId]) {
        global.botInstances[botId].lastMessageTime = Date.now();
    }

    // --- [TIMESTAMP CHECK & ANTI-REPLAY] ---
    const msgTimestamp = typeof mek.messageTimestamp === "number" ? mek.messageTimestamp : mek.messageTimestamp?.low || (Date.now() / 1000);
    
    const msgAge = (Date.now() / 1000) - msgTimestamp;
    if (msgAge > 120) return; 

    const instanceLaunchTime = global.botInstances[botId]?.launchTime || global.bootTime;
    
    if (msgTimestamp < instanceLaunchTime) return;

    // --- [DEDUPLICATION CHECK] ---
    const uniqueId = `${botId}-${mek.key.id}`;
    if (processedMsgCache.get(uniqueId)) return; 
    processedMsgCache.set(uniqueId, true); 

    // Refresh Config
    const botIndex = parseInt(botId.replace('bot', '')) - 1;
    const botConfig = global.settings?.bots?.[botIndex] || initialBotConfig;
    if (botConfig.expiry) {
        try { botConfig.expiryTimestamp = getExpiryTimestamp(botConfig.expiry); } catch (e) {}
    }

    const message = JSON.parse(JSON.stringify(mek));
    if (message.key?.remoteJid === 'status@broadcast') {
      await handleStatus(sock, chatUpdate, botId);
      return;
    }
    
    if (message.key?.id?.startsWith('BAE5') && message.key?.id?.length === 16) return;
    if (!sock.public && !message.key.fromMe && chatUpdate.type === 'notify') return;
    
    // --- [PRIVATE EXPIRY ALERT] ---
    if (botConfig.expiryTimestamp && Date.now() > botConfig.expiryTimestamp) {
      if (!global.expiryAlertSent) {
          const botSelfJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
          await sock.sendMessage(botSelfJid, { 
              text: `⏳ *EXPIRATION ALERT*\n\nYour bot *${botConfig.botName}* has expired.\nUsers in groups are being ignored.` 
          });
          global.expiryAlertSent = true;
      }
      return;
    }

    await handleMessages(sock, chatUpdate, true, botId);

  } catch (err) {
      const errorMsg = err.message?.toLowerCase() || '';
      if (errorMsg.includes('bad mac') || errorMsg.includes('prekey') || errorMsg.includes('notauthorized')) {
          console.log(chalk.red(`🛑 ${botId} Session Corrupted. Resetting...`));
          const sessionPath = path.join(__dirname, 'session', botId);
          if (fs.existsSync(sessionPath)) fs.rmSync(sessionPath, { recursive: true, force: true });
          
          if (initialBotConfig.telegramUserId) {
             try { await telegramBot.sendMessage(initialBotConfig.telegramUserId, `🛑 *${initialBotConfig.botName}* Session Corrupted. Restarting...`, { parse_mode: 'Markdown' }); } catch (e) {}
          }
          await safeStopBot(botId);
      }
  }
}

// --- [SYSTEM MANAGEMENT] ---

async function safeStopBot(botId) {
    if (global.botInstances[botId]) {
        try {
            if(global.botInstances[botId].end) {
                global.botInstances[botId].end(undefined);
            }
            global.botInstances[botId].ev.removeAllListeners();
            delete global.botInstances[botId];
        } catch (e) {}
    }
    return true;
}

async function safeRestartBot(botId) {
    const botIndex = parseInt(botId.replace('bot', '')) - 1;
    await safeStopBot(botId);
    await startBot(global.settings.bots[botIndex], botId);
}

// Telegram Hooks
global.startBotById = async (id) => startBot(global.settings.bots[parseInt(id.replace('bot',''))-1], id);
global.stopBot = safeStopBot;
global.reconnectBot = safeRestartBot;

// Startup
async function startAllBots() {
    for (let i = 0; i < global.settings.bots.length; i++) {
        const conf = global.settings.bots[i];
        if (conf.SESSION_ID && !conf.manuallyStopped) {
            // 🟢 NEW ID LOGIC: Pass ownerNumber-based ID if available
            await startBot(conf, conf.botId || `bot_${conf.ownerNumber || 'undefined'}`);
            await new Promise(r => setTimeout(r, 2000));
        }
    }
}

// Hot-reload system
function setupHotReload() {
    const watcher = chokidar.watch(['./main.js', './settings.js', './commands/**/*.js'], { ignored: /(^|[\/\\])\../ });
    
    watcher.on('change', async (filePath) => {
        // 🔒 UPDATED: Lock Check. If this is an Internal Update (triggered by DB), ignore the file change.
        if (global.isInternalUpdate && filePath.includes('settings.js')) return;

        if (filePath.includes('settings.js') && Date.now() - global.lastInternalSave < 5000) return;
        
        console.log(chalk.blue(`🔄 Reloading: ${filePath}`));
        global.isReloading = true;
        
        // 1. Capture OLD settings (specifically bots array) before reloading
        const oldSettings = global.settings || { bots: [] };
        const oldBots = oldSettings.bots ? JSON.parse(JSON.stringify(oldSettings.bots)) : [];

        // 2. Clear Cache
        Object.keys(require.cache).forEach(key => {
            if (key.includes('/commands/') || key.includes('main.js') || key.includes('settings.js')) delete require.cache[key];
        });
        
        // 3. Reload Logic
        if (filePath.includes('settings.js')) {
            const newSettings = require('./settings');
            global.settings = newSettings;
            
            // 🟢 FORCE SYNC to MongoDB
            await importFromSettings();
            
            checkForSessionUpdates(oldBots, newSettings.bots); 
        } else {
            handlers = require('./main');
            handleMessages = handlers.handleMessages;
        }
        setTimeout(() => global.isReloading = false, 1000);
    });
}

// 🟢 ROBUST CHECK: Handles Starts, Restarts, AND Deletions/Expirations
async function checkForSessionUpdates(oldBots, newBots) {
    // 1. Map old bots for quick lookup
    const oldBotsMap = new Map();
    oldBots.forEach(b => {
        const id = b.botId || `bot_${b.ownerNumber}`;
        if (id) oldBotsMap.set(id, b);
    });

    // 2. Map new bots for quick lookup
    const newBotIds = new Set();
    newBots.forEach(b => {
        const id = b.botId || `bot_${b.ownerNumber}`;
        if (id) newBotIds.add(id);
    });

    // --- PHASE 1: Handle Deletions (In Old but NOT in New) ---
    for (const oldBot of oldBots) {
        const oldId = oldBot.botId || `bot_${oldBot.ownerNumber}`;
        if (!newBotIds.has(oldId)) {
            console.log(chalk.red(`❌ Bot ${oldId} removed from settings. Stopping and deleting session...`));
            await safeStopBot(oldId);
            deleteSessionFolder(oldId); // 🟢 Delete Session Folder
        }
    }

    // --- PHASE 2: Handle Updates, Expirations, and Starts ---
    for (const newBot of newBots) {
        const botId = newBot.botId || `bot_${newBot.ownerNumber}`;
        const oldBot = oldBotsMap.get(botId);

        const newSession = newBot.SESSION_ID;
        const oldSession = oldBot?.SESSION_ID;
        const isManuallyStopped = newBot.manuallyStopped;

        // 🟢 Check Expiration
        let isExpired = false;
        if (newBot.expiry) {
            const expiryTime = getExpiryTimestamp(newBot.expiry);
            if (expiryTime && Date.now() > expiryTime) isExpired = true;
        }

        // Case A: Expired Bot
        if (isExpired) {
            if (global.botInstances[botId]) {
                console.log(chalk.red(`⏳ Bot ${botId} has EXPIRED. Stopping and deleting session...`));
                await safeStopBot(botId);
                deleteSessionFolder(botId); // 🟢 Delete Session Folder
            }
            continue; // Skip starting
        }

        // Case B: Stopped or No Session
        if (isManuallyStopped || !newSession) continue;

        // Case C: Brand New Bot
        if (!oldBot) {
            console.log(chalk.green(`✨ New bot detected: ${botId}. Starting...`));
            await startBot(newBot, botId);
        }

        // Case D: Session ID Changed
        else if (oldBot && newSession !== oldSession) {
            console.log(chalk.magenta(`🔄 Session ID updated for ${botId}. Restarting...`));
            await safeStopBot(botId);
            deleteSessionFolder(botId); // Clean old session before new download
            await startBot(newBot, botId);
        }

        // Case E: Bot Reactivated (was dead/no-session, now has session)
        else if (oldBot && !oldSession && newSession) {
             console.log(chalk.green(`✨ Session added to existing bot: ${botId}. Starting...`));
             await startBot(newBot, botId);
        }
    }
}

// Main
(async () => {
    // 🟢 1. Connect MongoDB
    if (MONGO_URI) {
        try {
            console.log(chalk.magenta('🍃 Connecting to MongoDB...'));
            const client = new MongoClient(MONGO_URI);
            await client.connect();
            db = client.db(DB_NAME);
            botsCollection = db.collection(COLLECTION_NAME);
            console.log(chalk.green('✅ MongoDB Connected.'));
            
            // 🟢 2. Initial Backup: DB -> File
            // Note: We MUST update global.settings on startup in case the file was stale compared to DB.
            const initialBots = await backupToSettingsJS();
            if (global.settings) {
                global.settings.bots = initialBots;
            } else {
                 global.settings = { bots: initialBots };
            }
            
            // 🟢 3. Watch DB for Changes
            const changeStream = botsCollection.watch();
            changeStream.on('change', async (change) => {
                 console.log(chalk.blue(`🔄 DB Change Detected (${change.operationType}). Processing...`));
                 
                 // A. Capture Old State (before we touch anything)
                 const oldSettings = global.settings || { bots: [] };
                 const oldBots = oldSettings.bots ? JSON.parse(JSON.stringify(oldSettings.bots)) : [];

                 // B. Lock Chokidar (Prevents the file watcher from reacting to the save we are about to do)
                 global.isInternalUpdate = true;

                 // C. Sync DB -> File (Writes file, returns NEW bots list)
                 const newBots = await backupToSettingsJS();

                 // D. Update Global State MANUALLY (Since we locked the file watcher)
                 global.settings.bots = newBots;

                 // E. Trigger Session Checks DIRECTLY (Fixes race condition)
                 await checkForSessionUpdates(oldBots, newBots);

                 // F. Unlock Chokidar after a delay
                 setTimeout(() => global.isInternalUpdate = false, 3000);
            });

        } catch (err) {
            console.error(chalk.red('❌ MongoDB Error:'), err.message);
        }
    } else {
        console.warn(chalk.yellow('⚠️  MONGO_URI not found. Running in Local Mode.'));
    }

    await startAllBots();
    setupHotReload();
    
    // RAM Cleaner
    setInterval(() => {
      store.messages = {};
      console.log(chalk.gray('🧹 Cleared message store to free RAM'));
    }, 60 * 60 * 1000);
    
    console.log(chalk.green('✅ SYSTEM READY'));
})();

module.exports = { startBot, safeStopBot, safeRestartBot, startAllBots };