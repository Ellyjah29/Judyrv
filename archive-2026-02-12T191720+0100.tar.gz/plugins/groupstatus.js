const { downloadContentFromMessage, prepareWAMessageMedia } = require('@whiskeysockets/baileys');

module.exports = {
    cmd: ['groupstatus', 'gstatus', 'gst'],
    category: 'group',
    desc: 'Post a message as a Group Status (Visible to all members)',
    use: '.gstatus <reply to image/video/text>',
    
    handler: async ({ sock, chatId, message, args, isGroup, reply }) => {
        try {
            if (!isGroup) return reply('❌ This command can only be used in groups.');

            // 1. Get Quoted Message & Type
            const contextInfo = message.message?.extendedTextMessage?.contextInfo;
            const quotedMsg = contextInfo?.quotedMessage;
            const textInput = args.join(" ");

            // 2. Handle TEXT Status
            // If user typed text (.gstatus hello) OR replied to text
            if (!quotedMsg && textInput) {
                await sock.sendGroupStatus(chatId, { text: textInput });
                return reply('✅ Text Status Posted!');
            }
            
            if (quotedMsg && (quotedMsg.conversation || quotedMsg.extendedTextMessage)) {
                const text = quotedMsg.conversation || quotedMsg.extendedTextMessage.text;
                await sock.sendGroupStatus(chatId, { text: text });
                return reply('✅ Text Status Posted!');
            }

            // 3. Handle MEDIA Status (Image/Video/Audio)
            if (quotedMsg) {
                const mtype = Object.keys(quotedMsg)[0];
                let mediaBuffer;
                
                // A. Images
                if (mtype === 'imageMessage') {
                    const stream = await downloadContentFromMessage(quotedMsg.imageMessage, 'image');
                    mediaBuffer = Buffer.from([]);
                    for await (const chunk of stream) mediaBuffer = Buffer.concat([mediaBuffer, chunk]);

                    // Upload to WhatsApp Server first
                    const mediaUpload = await prepareWAMessageMedia(
                        { image: mediaBuffer, caption: quotedMsg.imageMessage.caption || textInput }, 
                        { upload: sock.waUploadToServer }
                    );

                    await sock.sendGroupStatus(chatId, { image: mediaUpload.imageMessage });
                    return reply('✅ Image Status Posted!');
                }

                // B. Videos
                else if (mtype === 'videoMessage') {
                    const stream = await downloadContentFromMessage(quotedMsg.videoMessage, 'video');
                    mediaBuffer = Buffer.from([]);
                    for await (const chunk of stream) mediaBuffer = Buffer.concat([mediaBuffer, chunk]);

                    const mediaUpload = await prepareWAMessageMedia(
                        { video: mediaBuffer, caption: quotedMsg.videoMessage.caption || textInput }, 
                        { upload: sock.waUploadToServer }
                    );

                    await sock.sendGroupStatus(chatId, { video: mediaUpload.videoMessage });
                    return reply('✅ Video Status Posted!');
                }

                // C. Audio (Voice Notes)
                else if (mtype === 'audioMessage') {
                    // Note: Group Status doesn't officially support Audio yet, but we can try
                    return reply('⚠️ Audio status is not fully supported by WhatsApp yet.');
                }
            }

            return reply('❌ Please reply to an Image, Video, or Text message.');

        } catch (e) {
            console.error("Group Status Plugin Error:", e);
            reply(`❌ Failed: ${e.message}`);
        }
    }
};