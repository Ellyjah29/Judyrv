const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
    // Triggers
    cmd: ['externalplugin', 'extplugin', 'installplugin', 'reload', 'scanplugins', 'refresh'],
    
    // Description
    desc: 'Install from URL or Reload all plugins from folder',
    
    // Category
    category: 'system', // Changed from 'owner' to 'system'
    
    // The Logic
    handler: async ({ sock, chatId, args, reply, isOwner, botId }) => {
        
        // ❌ SECURITY CHECK REMOVED
        // Any user can now access this command.
        
        const url = args[0];

        // ============================================================
        // 🔄 MODE A: RELOAD / SCAN (No URL provided)
        // ============================================================
        if (!url || !url.startsWith('http')) {
            try {
                const pluginDir = path.join(__dirname, '../plugins');
                
                // 1. Clear "require" cache
                if (fs.existsSync(pluginDir)) {
                    const files = fs.readdirSync(pluginDir);
                    files.forEach(file => {
                        const fullPath = path.join(pluginDir, file);
                        if (require.cache[fullPath]) {
                            delete require.cache[fullPath];
                        }
                    });
                }

                // 2. Clear loader cache
                const loaderPath = require.resolve('../lib/plugins');
                if (require.cache[loaderPath]) delete require.cache[loaderPath];
                
                // 3. Reload everything
                const { loadPlugins } = require('../lib/plugins');
                loadPlugins(botId);

                return reply(`🔄 *System Refreshed!*
                
✅ Plugins reloaded
⚡ Cache cleared`);

            } catch (e) {
                console.error(e);
                return reply(`❌ *Reload Failed:*\n${e.message}`);
            }
        }

        // ============================================================
        // 📥 MODE B: DOWNLOAD & INSTALL (URL Provided)
        // ============================================================
        try {
            await reply('⏳ *Downloading plugin...*');
            
            const { data } = await axios.get(url);
            
            if (typeof data !== 'string' || !data.includes('module.exports') || !data.includes('handler:')) {
                return reply('⚠️ *Invalid Code:* The link does not appear to contain a valid plugin structure.');
            }

            let fileName = url.split('/').pop();
            fileName = fileName.split('?')[0]; 
            if (!fileName.endsWith('.js')) fileName += '.js';

            const pluginDir = path.join(__dirname, '../plugins');
            const filePath = path.join(pluginDir, fileName);
            fs.writeFileSync(filePath, data);
            
            if (require.cache[filePath]) {
                delete require.cache[filePath];
            }

            const { loadPlugins } = require('../lib/plugins');
            loadPlugins(botId);

            await reply(`✅ *Installed Successfully!*
📄 File: *${fileName}*
⚡ System reloaded.`);

        } catch (e) {
            console.error(e);
            await reply(`❌ *Installation Failed:*\n${e.message}`);
        }
    }
};