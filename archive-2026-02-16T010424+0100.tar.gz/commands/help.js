const settings = require('../settings');
const fs = require('fs');
const path = require('path');
const process = require('process');
const ffmpeg = require('fluent-ffmpeg'); 

// =========================================
// 🛠️ HELPER: ULTRA-COMPRESS VIDEO
// =========================================
const resizeVideo = (inputPath, outputPath) => {
    return new Promise((resolve, reject) => {
        console.log("⚙️  Compressing help video... please wait.");
        ffmpeg(inputPath)
            .size('320x320')            
            .autoPad(true, 'black')     
            .fps(15)                    
            .duration(6)                
            .noAudio()                  
            .videoBitrate('250k')       
            .outputOptions([
                '-preset veryfast',     
                '-crf 35',              
                '-pix_fmt yuv420p'      
            ])
            .on('end', () => {
                console.log("✅ Video compressed successfully!");
                resolve(outputPath);
            })
            .on('error', (err) => {
                console.error("❌ Error compressing video:", err);
                reject(err);
            })
            .save(outputPath);
    });
};

// =========================================
// 🎨 PROFESSIONAL THEME
// =========================================
const theme = {
    div: '━━━━━━━━━━━━━━━━━━━━',
    general: '🌐',   ai: '🤖',      admin: '🛡️',
    owner: '👑',     media: '📥',   tools: '🔧',
    fun: '🎮',       games: '🎲',   creative: '🎨',
    group: '👥',     search: '🔍'
};

// =========================================
// 🗂️ FULL COMMAND LIST WITH DESCRIPTIONS
// =========================================
const baseCategories = {
  ai: {
    title: 'ARTIFICIAL INTELLIGENCE',
    icon: theme.ai,
    commands: [
        '.bot <query> - Ask Septorch AI',
        '.gpt <text> - Chat with GPT-4',
        '.gemini <text> - Google Gemini',
        '.vision - Analyze image (Reply)',
        '.imagine <idea> - Generate AI Art',
        '.notes - AI Note Taker',
        '.flux <idea> - High Quality Gen'
    ]
  },
  search: {
    title: 'SEARCH ENGINE',
    icon: theme.search,
    commands: [
        '.google <query> - Google Search',
        '.img <query> - Image Search',
        '.anime <name> - Anime Info',
        '.pinterest <query> - Pinterest Imgs',
        '.lyrics <song> - Find Lyrics',
        '.weather <city> - Weather Forecast',
        '.wiki <query> - Wikipedia',
        '.github <user> - GitHub Profile',
        '.ytsearch <query> - YouTube Search'
    ]
  },
  admin: {
    title: 'GROUP ADMIN COMMANDS',
    icon: theme.admin,
    commands: [
        '.kick @user - Remove member',
        '.ban @user - Ban from group',
        '.unban @user - Unban member',
        '.promote @user - Give admin',
        '.demote @user - Remove admin',
        '.mute - Close group chat',
        '.unmute - Open group chat',
        '.delete - Delete bot message',
        '.tagall - Tag everyone',
        '.hidetag - Invisible tag',
        '.antilink on/off - Block links',
        '.antibadword on/off - Filter insults',
        '.welcome on/off - Welcome msg',
        '.goodbye on/off - Goodbye msg',
        '.resetlink - Reset invite link',
        '.warn @user - Warn user'
    ]
  },
  group: {
    title: 'GROUP COMMANDS',
    icon: theme.group,
    commands: [
        '.groupinfo - Group details',
        '.staff - List Admins',
        '.topmembers - Most active users',
        '.pair - Link WhatsApp',
        '.link - Get Group Link'
    ]
  },
  tools: {
    title: 'SYSTEM UTILITIES',
    icon: theme.tools,
    commands: [
        '.ping - Check latency',
        '.alive - Check bot status',
        '.owner - Contact Owner',
        '.menu / .help - Show Menu',
        '.ocr - Read text from image',
        '.urlshort - Shorten Link',
        '.upload - File to URL',
        '.ss <url> - Screenshot Website',
        '.translate - Translate text',
        '.tts <text> - Text to Speech',
        '.stt - Speech to Text'
    ]
  },
  media: {
    title: 'MEDIA & DOWNLOADS',
    icon: theme.media,
    commands: [
        '.play <song> - Download Audio',
        '.video <url> - Download Video',
        '.tiktok <url> - TikTok (No WM)',
        '.instagram <url> - Instagram DL',
        '.facebook <url> - Facebook DL',
        '.twitter <url> - X/Twitter DL',
        '.threads <url> - Threads DL',
        '.tomp3 - Video to Audio',
        '.vv - View Once Retreiver'
    ]
  },
  creative: {
    title: 'STICKERS & TEXT EFFECTS',
    icon: theme.creative,
    commands: [
        '.sticker - Create Sticker',
        '.simage - Sticker to Image',
        '.take <name> - Steal Sticker',
        '.emojimix - Mix Emojis',
        '.attp <text> - Flash Sticker',
        '.tgsticker <url> - TG to WA',
        '.blur - Blur Image',
        '.wasted - GTA Wasted Effect',
        '.metallic <text> - Metallic Logo',
        '.neon <text> - Neon Logo',
        '.fire <text> - Fire Logo',
        '.glitch <text> - Glitch Text'
    ]
  },
  games: {
    title: 'GAMING ZONE',
    icon: theme.games,
    commands: [
        '.ttt @user - Tic-Tac-Toe',
        '.hangman - Guess the word',
        '.trivia - General Quiz',
        '.math - Math Quiz',
        '.riddle - Hard Riddles',
        '.livescore - Sports Scores'
    ]
  },
  fun: {
    title: 'SOCIAL & FUN',
    icon: theme.fun,
    commands: [
        '.compliment @user - Be nice',
        '.insult @user - Roast user',
        '.ship - Love Calculator',
        '.meme - Random Meme',
        '.joke - Tell a joke',
        '.fact - Random Fact',
        '.quote - Daily Quote',
        '.8ball <q> - Magic Ball',
        '.dare - Truth or Dare',
        '.truth - Truth or Dare',
        '.flirt - Pick-up lines',
        '.simp @user - Simp Rate',
        '.stupid @user - Stupidity Test'
    ]
  },
  owner: {
    title: 'OWNER CONTROL',
    icon: theme.owner,
    commands: [
        '.mode public/private - Set Mode',
        '.autostatus on/off - Status View',
        '.antidelete on/off - Msg Log',
        '.setpp - Set Bot PP',
        '.autoreact - Auto React',
        '.autoreply - Auto Reply',
        '.fake - Fake Recording',
        '.broadcast - Send to all',
        '.cleartmp - Clear Cache',
        '.shell - Terminal Access'
    ]
  }
};

// =========================================
// 🚀 MAIN COMMAND HANDLER
// =========================================

async function helpCommand(sock, chatId, message, botId) {
  try {
    const botName = settings.botName || 'SEPTORCH';
    const date = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    
    let senderName = "User";
    try { senderName = message.pushName || "User"; } catch (e) {}

    // 🟢 1. DYNAMICALLY MERGE EXTERNAL PLUGINS
    const categories = JSON.parse(JSON.stringify(baseCategories));

    if (global.plugins) {
        global.plugins.forEach((plugin) => {
            const cmdName = Array.isArray(plugin.cmd) ? plugin.cmd[0] : plugin.cmd;
            let catKey = plugin.category ? plugin.category.toLowerCase() : 'tools';
            
            // Normalize Keys
            if (catKey === 'utility') catKey = 'tools';
            if (catKey === 'game') catKey = 'games';
            if (catKey === 'download') catKey = 'media';
            if (catKey === 'gpt') catKey = 'ai';
            if (catKey === 'sticker') catKey = 'creative';
            if (catKey === 'group') catKey = 'group';
            if (catKey === 'search') catKey = 'search';

            const description = plugin.desc || 'Plugin Feature';
            const entry = `.${cmdName} - ${description}`;

            if (categories[catKey]) {
                if (!categories[catKey].commands.includes(entry)) {
                    categories[catKey].commands.push(entry);
                }
            } else {
                categories['tools'].commands.push(entry);
            }
        });
    }

    // 🟢 2. PREPARE VIDEO
    const rawVideoPath = path.join(__dirname, '../assets/bot_video.mp4'); 
    const resizedVideoPath = path.join(__dirname, '../assets/bot_menu_resized.mp4');
    let finalVideoBuffer = null;

    if (fs.existsSync(resizedVideoPath)) {
        finalVideoBuffer = fs.readFileSync(resizedVideoPath);
    } else if (fs.existsSync(rawVideoPath)) {
        try {
            await sock.sendMessage(chatId, { text: '_🎨 System: Optimizing assets..._' }, { quoted: message });
            await resizeVideo(rawVideoPath, resizedVideoPath);
            finalVideoBuffer = fs.readFileSync(resizedVideoPath);
        } catch (e) {
            console.log("Resize failed, using raw video.");
            finalVideoBuffer = fs.readFileSync(rawVideoPath);
        }
    }

    // 🟢 3. BUILD PROFESSIONAL DASHBOARD (TREE STYLE)
    let helpText = `
┏━━━━━━━━━━━━━━━━━━━┓
┃   *${botName.toUpperCase()} V3 SYSTEM* ┗━━━━━━━━━━━━━━━━━━━┛
👤 *User:* ${senderName}
🕒 *Time:* ${time}
📅 *Date:* ${date}
${theme.div}
`;

    // Loop through categories
    Object.keys(categories).forEach(key => {
        const cat = categories[key];
        // Sort alphabetically
        const sortedCmds = cat.commands.sort();
        
        helpText += `\n*${cat.icon} ${cat.title}*\n`;
        
        // 🟢 TREE GENERATOR
        const cmdTree = sortedCmds.map((cmd, index) => {
            const isLast = index === sortedCmds.length - 1;
            const branch = isLast ? '└' : '├';
            return `${branch} ${cmd}`;
        }).join('\n');

        helpText += `\`\`\`${cmdTree}\`\`\`\n`;
    });

    helpText += `\n_${settings.footer || 'Powered by Septorch Intelligence'}_`;

    // 🟢 4. SEND MESSAGE
    const messageOptions = {
        caption: helpText,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363387922693296@newsletter',
                newsletterName: 'SEPTORCH UPDATES',
                serverMessageId: -1
            }
        }
    };

    if (finalVideoBuffer) {
        messageOptions.video = finalVideoBuffer;
        messageOptions.gifPlayback = true; 
    } else {
        messageOptions.text = helpText; 
    }

    await sock.sendMessage(chatId, messageOptions, { quoted: message });

  } catch (err) {
    console.error('Help Command Error:', err);
    await sock.sendMessage(chatId, { text: '❌ *System Error:* Unable to load help.' });
  }
}

module.exports = helpCommand;