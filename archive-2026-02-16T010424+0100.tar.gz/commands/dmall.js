// commands/dmall.js - Natural, non-forwarded, non-bot-looking DMs
const { isOwner } = require('../lib/isOwner');

// --- Safety Config (High Delays = Lower Risk) ---
const MIN_DELAY_BEFORE_TYPING = 4000;   // 4–12 sec before typing
const MAX_DELAY_BEFORE_TYPING = 12000;
const MIN_TYPING_DURATION = 1000;        // 1–3 sec typing
const MAX_TYPING_DURATION = 3000;
const MIN_DELAY_AFTER_SEND = 8000;       // 8–25 sec between users
const MAX_DELAY_AFTER_SEND = 25000;
const WARNING_THRESHOLD = 30; // Warn if group > 30 members
// --- End Config ---

function rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function dmallCommand(sock, chatId, message, botId) {
    const senderId = message.key.participant || message.key.remoteJid;

    // Owner check
    if (!message.key.fromMe && !isOwner(senderId, botId)) {
        await sock.sendMessage(chatId, { text: '❌ Owner only!' });
        return;
    }

    const fullText = message.message?.conversation ||
                     message.message?.extendedTextMessage?.text || '';
    const args = fullText.trim().split(/\s+/);

    if (args.length < 2) {
        await sock.sendMessage(chatId, {
            text: `❌ Usage: .dmall <group_jid> <message>\n` +
                  `Example: .dmall 1234567890@g.us Hi team!\n\n` +
                  `⚠️ Warning: Sending DMs to large groups (> ${WARNING_THRESHOLD} people) may risk your WhatsApp account. ` +
                  `Prefer .tag or .hidetag for group announcements.`
        });
        return;
    }

    const targetGroupId = args[1];
    const msgContent = args.slice(2).join(' ').trim();

    if (!msgContent) {
        await sock.sendMessage(chatId, { text: '❌ Please include a message to send.' });
        return;
    }

    if (!targetGroupId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: '❌ Invalid group ID. Must end with @g.us' });
        return;
    }

    // Fetch group members
    let groupMeta;
    try {
        groupMeta = await sock.groupMetadata(targetGroupId);
    } catch (e) {
        await sock.sendMessage(chatId, {
            text: `❌ Cannot access group. Ensure the bot is a member of ${targetGroupId}.`
        });
        return;
    }

    const participants = groupMeta.participants.filter(p => 
        p.id !== sock.user.id.split(':')[0] + '@s.whatsapp.net'
    );

    if (participants.length === 0) {
        await sock.sendMessage(chatId, { text: '⚠️ No valid recipients found.' });
        return;
    }

    // Safety warning for large groups
    if (participants.length > WARNING_THRESHOLD) {
        await sock.sendMessage(chatId, {
            text: `🚨 WARNING: This group has ${participants.length} members.\n` +
                  `Sending this many DMs — even with delays — **can trigger WhatsApp restrictions or bans**.\n\n` +
                  `✅ Safer alternative: Use **.hidetag** in the group to reach everyone at once.`
        });
        // You could optionally return here to force confirmation, but we'll proceed with caution.
    }

    await sock.sendMessage(chatId, {
        text: `📤 Starting natural DMs to ${participants.length} members...\n` +
              `⏱️ Estimated time: ${(participants.length * 15) / 60}+ minutes.`
    });

    // Send to each user with natural behavior
    for (let i = 0; i < participants.length; i++) {
        const jid = participants[i].id;

        try {
            // 1. Wait before typing
            await new Promise(r => setTimeout(r, rand(MIN_DELAY_BEFORE_TYPING, MAX_DELAY_BEFORE_TYPING)));

            // 2. Show typing
            await sock.sendPresenceUpdate('composing', jid);

            // 3. Simulate typing duration
            await new Promise(r => setTimeout(r, rand(MIN_TYPING_DURATION, MAX_TYPING_DURATION)));

            // 4. SEND MESSAGE — NO contextInfo! Plain text only.
            await sock.sendMessage(jid, { text: msgContent });

            // 5. Clear typing
            await sock.sendPresenceUpdate('paused', jid);

            // 6. Wait before next (skip after last)
            if (i < participants.length - 1) {
                await new Promise(r => setTimeout(r, rand(MIN_DELAY_AFTER_SEND, MAX_DELAY_AFTER_SEND)));
            }

            console.log(`✅ Sent natural DM to ${jid}`);
        } catch (err) {
            console.error(`❌ Failed to DM ${jid}:`, err.message);
            try { await sock.sendPresenceUpdate('paused', jid); } catch {}
        }
    }

    await sock.sendMessage(chatId, {
        text: `✅ Natural DM broadcast completed!\n` +
              `Total recipients: ${participants.length}`
    });
}

module.exports = { dmallCommand };
