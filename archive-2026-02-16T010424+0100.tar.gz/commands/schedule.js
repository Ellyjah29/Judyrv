const fs = require('fs');
const path = require('path');
const chrono = require('chrono-node');

// 🔴 REMOVED: Top-level require for Baileys
// const { downloadMediaMessage } = require('@whiskeysockets/baileys');

// =========================================
// 🎨 DESIGN & THEME (MATCHING YOUR BOT)
// =========================================
const icons = {
    gear  : '⚙️',   eye   : '👁️',   face  : '🎭',
    on    : '🟢',   off   : '🔴',   warn  : '⚠️',
    err   : '⛔',   info  : 'ℹ️',   check : '✅',
    list  : '📜',   arrow : '➔',   dot   : '◈',
    dice  : '🎲',   clock : '⏰',   send  : '📤'
};

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH_BOT',
            serverMessageId: -1
        }
    }
};

const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.clock} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

const sendCard = (sock, chatId, title, lines) =>
    sock.sendMessage(chatId, { text: makeCard(title, lines), ...channelInfo });

// Enforce Nigerian Time
process.env.TZ = process.env.TZ || 'Africa/Lagos';

// =========================================
// 🗂️ FILE MANAGEMENT
// =========================================
function safeAccess(obj, path, defaultValue = null) {
    try {
        return path.split('.').reduce((o, p) => o?.[p], obj) || defaultValue;
    } catch (e) {
        return defaultValue;
    }
}

function getUserSchedulePath(botId, senderId) {
    const dir = path.join(__dirname, '..', 'data', botId, 'schedules');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return path.join(dir, `${senderId}.json`);
}

function saveTempMedia(buffer, taskId, mediaType) {
    const tmpDir = path.join(__dirname, '..', 'tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
    
    let ext = 'bin';
    if (mediaType === 'image') ext = 'jpg';
    else if (mediaType === 'video') ext = 'mp4';
    else if (mediaType === 'audio') ext = 'mp3';
    else if (mediaType === 'document') ext = 'pdf';
    
    const filePath = path.join(tmpDir, `${taskId}.${ext}`);
    fs.writeFileSync(filePath, buffer);
    return filePath;
}

function parseTimeInput(timeStr) {
    if (!timeStr) return null;
    const relative = timeStr.match(/^in\s+(\d+)\s*(m|min|minute|minutes|h|hour|hours)$/i);
    if (relative) {
        const amount = parseInt(relative[1], 10);
        const unit = relative[2].toLowerCase();
        const now = new Date();
        if (unit.startsWith('m')) return new Date(now.getTime() + amount * 60000);
        if (unit.startsWith('h')) return new Date(now.getTime() + amount * 3600000);
    }
    const parsed = chrono.parse(timeStr, new Date(), { timezone: 'Africa/Lagos' });
    if (parsed[0]?.start) {
        const dt = parsed[0].start.date();
        return new Date(dt.toLocaleString('en-US', { timeZone: 'Africa/Lagos' }));
    }
    const isoMatch = timeStr.match(/^(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})$/);
    if (isoMatch) {
        const [_, datePart, timePart] = isoMatch;
        return new Date(`${datePart}T${timePart}:00`);
    }
    return null;
}

// =========================================
// 📜 COMMANDS
// =========================================

// 1. SCHEDULE COMMAND
async function scheduleCommand(sock, chatId, message, userMessage, senderId, botId) {
    // 🟢 v7 FIX: Dynamic Import
    const { downloadMediaMessage } = await import('@whiskeysockets/baileys');

    const rest = userMessage.trim().replace(/^\.schedule\s+/, '');
    
    if (!rest) {
        return sendCard(sock, chatId, 'SCHEDULER', [
            ` ${icons.warn} *Usage Error*`,
            ` .schedule <time> <target> <msg>`,
            ` ---`,
            ` ${icons.dot} .schedule in 5m me Test`,
            ` ${icons.dot} .schedule 9am 23480... Hello`,
            ` ${icons.dot} .schedule 2pm @user Hi`
        ]);
    }

    const tokens = rest.split(/\s+/);
    let targetIndex = -1;

    for (let i = tokens.length - 1; i >= 0; i--) {
        const token = tokens[i].toLowerCase();
        const isPhoneNumber = /^\d{7,15}$/.test(token);
        if (token === 'me' || (token.includes('@') && !token.startsWith('@')) || isPhoneNumber) {
            targetIndex = i;
            break;
        }
    }

    if (targetIndex === -1) {
        return sendCard(sock, chatId, 'ERROR', [` ${icons.err} Target (me, number, or JID) not found.`]);
    }

    const timeInput = tokens.slice(0, targetIndex).join(' ').trim();
    const targetInput = tokens[targetIndex];
    let content = tokens.slice(targetIndex + 1).join(' ');

    const scheduledDate = parseTimeInput(timeInput);
    if (!scheduledDate || scheduledDate <= new Date()) {
        return sendCard(sock, chatId, 'ERROR', [` ${icons.err} Invalid or past time provided.`]);
    }

    // Resolve Target
    let targetJid;
    let targetDisplay;
    const cleanTarget = targetInput.replace(/[^0-9@a-zA-Z.]/g, '');
    
    if (cleanTarget.toLowerCase() === 'me') {
        targetJid = senderId.endsWith('@lid') ? chatId : senderId;
        targetDisplay = "Saved Messages";
    }
    else if (cleanTarget.includes('@')) {
        targetJid = cleanTarget;
        targetDisplay = cleanTarget.split('@')[0];
    }
    else {
        targetJid = `${cleanTarget}@s.whatsapp.net`;
        targetDisplay = cleanTarget;
    }

    // Handle Media
    let mediaBuffer = null;
    let mediaType = null;
    const contextInfo = safeAccess(message, 'message.extendedTextMessage.contextInfo');
    let quoted = safeAccess(message, 'message.extendedTextMessage.contextInfo.quotedMessage');

    if (quoted?.viewOnceMessage?.message) quoted = quoted.viewOnceMessage.message;
    if (quoted?.message) quoted = quoted.message;

    const mediaTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage'];
    if (quoted) {
        const foundType = mediaTypes.find(type => quoted?.[type]);
        if (foundType) {
            const mediaMsg = {
                key: { remoteJid: chatId, id: contextInfo?.stanzaId, fromMe: false },
                message: { [foundType]: quoted[foundType] }
            };
            mediaBuffer = await downloadMediaMessage(mediaMsg, 'buffer', {}, { reuploadRequest: sock });
            mediaType = foundType.replace('Message', '').toLowerCase();
            if (!content && (foundType === 'imageMessage' || foundType === 'videoMessage')) {
                content = quoted[foundType].caption || '';
            }
        } else if (quoted.conversation || quoted.extendedTextMessage?.text) {
            content = quoted.conversation || quoted.extendedTextMessage?.text || content;
        }
    }

    if (!content && !mediaBuffer) {
        return sendCard(sock, chatId, 'ERROR', [` ${icons.warn} Provide text or reply to media.`]);
    }

    // Save Task
    const taskId = Date.now().toString();
    const task = {
        id: taskId,
        targetJid,
        content,
        mediaType,
        sendTime: scheduledDate.getTime(),
        createdAt: Date.now(),
        chatId
    };

    if (mediaBuffer) {
        task.mediaPath = saveTempMedia(mediaBuffer, taskId, mediaType);
    }

    const userPath = getUserSchedulePath(botId, senderId);
    let tasks = [];
    try { tasks = JSON.parse(fs.readFileSync(userPath, 'utf8')); } catch (e) {}
    tasks.push(task);
    fs.writeFileSync(userPath, JSON.stringify(tasks, null, 2));

    if (!global.scheduler?.[botId]) {
        global.scheduler = global.scheduler || {};
        global.scheduler[botId] = setInterval(() => processSchedules(botId), 30000);
    }

    const timeStr = scheduledDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Lagos' });
    
    return sendCard(sock, chatId, 'SCHEDULED', [
        ` ${icons.check} *Message Queued*`,
        ` ${icons.dot} ID: ${taskId}`,
        ` ${icons.clock} Time: ${timeStr}`,
        ` ${icons.send} To: ${targetDisplay}`
    ]);
}

// 2. MY SCHEDULES COMMAND
async function myschedulesCommand(sock, chatId, senderId, botId) {
    const userPath = getUserSchedulePath(botId, senderId);
    if (!fs.existsSync(userPath)) return sendCard(sock, chatId, 'QUEUE', [` ${icons.info} No pending messages.`]);

    try {
        const tasks = JSON.parse(fs.readFileSync(userPath, 'utf8'));
        if (tasks.length === 0) return sendCard(sock, chatId, 'QUEUE', [` ${icons.info} No pending messages.`]);

        let lines = [` ${icons.list} *Pending Tasks (${tasks.length})*`, '---'];
        tasks.forEach((task, index) => {
            const date = new Date(task.sendTime);
            const timeStr = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Lagos' });
            const target = task.targetJid.split('@')[0];
            const type = task.mediaType ? `[${task.mediaType.toUpperCase()}]` : '📝';
            
            lines.push(` ${index + 1}. *${timeStr}* ${icons.arrow} ${target}`);
            lines.push(`    🆔 ${task.id} | ${type}`);
        });
        lines.push('---');
        lines.push(` ${icons.dot} Use .unschedule <id> to cancel`);

        return sendCard(sock, chatId, 'MY SCHEDULES', lines);
    } catch (e) {
        return sendCard(sock, chatId, 'ERROR', [` ${icons.err} Could not load queue.`]);
    }
}

// 3. UNSCHEDULE COMMAND
async function unscheduleCommand(sock, chatId, userMessage, senderId, botId) {
    const args = userMessage.trim().split(/\s+/);
    const taskId = args[1];
    if (!taskId) return sendCard(sock, chatId, 'ERROR', [` ${icons.warn} Missing ID.`, ` Use .myschedules to find IDs.`]);

    const userPath = getUserSchedulePath(botId, senderId);
    if (!fs.existsSync(userPath)) return sendCard(sock, chatId, 'ERROR', [` ${icons.info} Queue is empty.`]);

    try {
        let tasks = JSON.parse(fs.readFileSync(userPath, 'utf8'));
        const initialCount = tasks.length;
        tasks = tasks.filter(task => {
            if (task.id === taskId) {
                if (task.mediaPath && fs.existsSync(task.mediaPath)) fs.unlinkSync(task.mediaPath);
                return false;
            }
            return true;
        });

        if (tasks.length === initialCount) return sendCard(sock, chatId, 'ERROR', [` ${icons.err} ID not found.`]);
        
        if (tasks.length === 0) fs.unlinkSync(userPath);
        else fs.writeFileSync(userPath, JSON.stringify(tasks, null, 2));

        return sendCard(sock, chatId, 'SUCCESS', [` ${icons.check} Task ${taskId} cancelled.`]);
    } catch (e) {
        return sendCard(sock, chatId, 'ERROR', [` ${icons.err} Error processing request.`]);
    }
}

// 4. CLEAR ALL COMMAND
async function clearScheduleCommand(sock, chatId, senderId, botId) {
    const userPath = getUserSchedulePath(botId, senderId);
    if (!fs.existsSync(userPath)) return sendCard(sock, chatId, 'INFO', [` ${icons.info} Queue already empty.`]);

    try {
        const tasks = JSON.parse(fs.readFileSync(userPath, 'utf8'));
        for (const task of tasks) {
            if (task.mediaPath && fs.existsSync(task.mediaPath)) fs.unlinkSync(task.mediaPath);
        }
        fs.unlinkSync(userPath);
        return sendCard(sock, chatId, 'CLEARED', [` ${icons.check} Removed ${tasks.length} tasks.`]);
    } catch (e) {
        return sendCard(sock, chatId, 'ERROR', [` ${icons.err} Failed to clear.`]);
    }
}

// =========================================
// 🚀 BACKGROUND PROCESSOR
// =========================================
async function processSchedules(botId) {
    const dir = path.join(__dirname, '..', 'data', botId, 'schedules');
    if (!fs.existsSync(dir)) return;

    const files = fs.readdirSync(dir);
    const now = Date.now();

    for (const file of files) {
        if (!file.endsWith('.json')) continue;
        const filePath = path.join(dir, file);
        try {
            const tasks = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            const remaining = [];

            for (const task of tasks) {
                if (task.sendTime <= now) {
                    const sock = global.botInstances?.[botId];
                    if (!sock) { remaining.push(task); continue; }

                    try {
                        // STANDARD SENDING (Chat/Group/Me)
                        if (task.mediaPath && fs.existsSync(task.mediaPath)) {
                            const buffer = fs.readFileSync(task.mediaPath);
                            await sock.sendMessage(task.targetJid, { 
                                [task.mediaType]: buffer, 
                                caption: task.content,
                                mimetype: task.mediaType === 'audio' ? 'audio/mpeg' : undefined,
                                ptt: task.mediaType === 'audio'
                            });
                            fs.unlinkSync(task.mediaPath);
                        } else {
                            await sock.sendMessage(task.targetJid, { text: task.content });
                        }
                    } catch (e) {
                        console.error(`❌ Send error:`, e);
                        remaining.push(task); // Retry if network fail
                    }
                } else {
                    remaining.push(task);
                }
            }
            if (remaining.length === 0) fs.unlinkSync(filePath);
            else fs.writeFileSync(filePath, JSON.stringify(remaining, null, 2));
        } catch (e) { console.error(`❌ File error ${file}:`, e); }
    }
}

module.exports = {
    scheduleCommand,
    myschedulesCommand,
    unscheduleCommand,
    clearScheduleCommand
};