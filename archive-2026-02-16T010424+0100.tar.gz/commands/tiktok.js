const axios = require('axios');

// Store processed message IDs to prevent duplicates
const processedMessages = new Set();

async function tiktokCommand(sock, chatId, message) {
    try {
        // 1. DUPLICATE CHECK
        if (processedMessages.has(message.key.id)) return;
        processedMessages.add(message.key.id);
        setTimeout(() => processedMessages.delete(message.key.id), 5 * 60 * 1000);

        // 2. EXTRACT LINK
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        if (!text) return await sock.sendMessage(chatId, { text: "❌ Please provide a TikTok link." });

        const urlMatch = text.match(/https?:\/\/(?:www\.|vm\.|vt\.|t\.)?tiktok\.com\/[^\s]+/);
        const url = urlMatch ? urlMatch[0] : null;
        if (!url) return await sock.sendMessage(chatId, { text: "❌ Please provide a valid TikTok link." });

        // 3. REACT
        await sock.sendMessage(chatId, { react: { text: '⬇️', key: message.key } });

        // 4. MAIN DOWNLOAD LOGIC (TikWM)
        try {
            const { data: response } = await axios.post('https://www.tikwm.com/api/', {
                url: url,
                count: 12,
                cursor: 0,
                web: 1,
                hd: 1
            }, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
                }
            });

            if (!response || response.code !== 0) {
                throw new Error("TikWM API could not find video.");
            }

            const data = response.data;
            
            // Fix URL protocols
            let videoUrl = data.play;
            if (!videoUrl.startsWith('http')) videoUrl = `https://tikwm.com${videoUrl}`;

            const title = data.title || "No Title";
            const author = data.author ? data.author.nickname : "Unknown";

            // 5. SEND VIDEO
            await sock.sendMessage(chatId, { 
                video: { url: videoUrl }, 
                caption: `🎬 *TikTok Downloaded*\n\n👤 *Author:* ${author}\n📝 *Title:* ${title}\n\nDownloaded by Septorch`,
                mimetype: "video/mp4"
            }, { quoted: message });

            // --- SAFE AUDIO SENDING ---
            // We wrap this in its own try/catch so if it fails, it doesn't trigger an error message
            try {
                let musicUrl = data.music;
                if (musicUrl) {
                    if (!musicUrl.startsWith('http')) musicUrl = `https://tikwm.com${musicUrl}`;
                    
                    await sock.sendMessage(chatId, {
                        audio: { url: musicUrl },
                        mimetype: 'audio/mp4',
                        ptt: false, 
                        contextInfo: {
                            externalAdReply: {
                                title: "🎵 TikTok Audio",
                                body: title,
                                thumbnailUrl: data.cover ? (data.cover.startsWith('http') ? data.cover : `https://tikwm.com${data.cover}`) : "",
                                sourceUrl: url,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, { quoted: message });
                }
            } catch (audioError) {
                console.log("Audio failed to send (but video worked), ignoring error.");
            }
            // --------------------------

        } catch (apiError) {
            console.error("TikWM Failed, trying backup...", apiError.message);
            
            // BACKUP LOGIC (Lovetik)
            try {
                const { data: loveData } = await axios.get(`https://lovetik.com/api/ajax/search?query=${url}`);
                if (loveData.status === 'ok') {
                    await sock.sendMessage(chatId, { 
                        video: { url: loveData.links[0].a }, 
                        caption: `🎬 *TikTok Downloaded (Backup)*\n\nDownloaded by Septorch` 
                    }, { quoted: message });
                } else {
                    throw new Error("Backup failed");
                }
            } catch (backupError) {
                await sock.sendMessage(chatId, { text: "❌ Failed to download video. The link might be private or deleted." });
            }
        }

    } catch (error) {
        console.error('TikTok Command Error:', error);
        // We do not send a message here to avoid spamming errors if something else broke
    }
}

module.exports = tiktokCommand;