const axios = require('axios');
const yts = require('yt-search');
const fs = require('fs');
const path = require('path');

// =========================================
// ⚙️ CONFIGURATION
// =========================================
const WEBSITE_URL = "https://septorch.tech";
const TEMP_DIR = path.join(__dirname, '../temp');

// Ensure temp directory exists
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

const icons = {
    music: '🎵', search: '🔎', duration: '⏱️', 
    views: '👁️', author: '👤', check: '✅', load: '📥'
};

/**
 * Creates a premium metadata card
 */
const makeCard = (v) => {
    return `╭─────────────────────────╮
│  ${icons.music} *SEPTORCH MUSIC*
├─────────────────────────┤
│ 📌 *Title:* ${v.title}
│ ${icons.duration} *Time:* ${v.timestamp || v.duration}
│ ${icons.views} *Views:* ${v.views ? v.views.toLocaleString() : 'N/A'}
│ ${icons.author} *Artist:* ${v.author?.name || 'Unknown'}
├─────────────────────────┤
│ ${icons.load} _Downloading High Quality Audio..._
╰─────────────────────────╯`;
};

/**
 * Helper: Stream file download
 */
const downloadFile = async (url, outputPath) => {
    const writer = fs.createWriteStream(outputPath);
    const response = await axios({
        url,
        method: 'GET',
        responseType: 'stream',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    });

    response.data.pipe(writer);

    return new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
    });
};

// =========================================
// 🚀 MAIN COMMAND HANDLER
// =========================================
const songCommand = async (sock, chatId, message) => {
    let tempFilePath = null;

    try {
        const text = message.message?.conversation || 
                     message.message?.extendedTextMessage?.text || 
                     message.message?.imageMessage?.caption || "";
        
        // Remove command prefix
        const query = text.replace(/^\.play|^\.song|^\!play/i, '').trim();

        if (!query) {
            return await sock.sendMessage(chatId, { text: `❌ *Usage:* .play <Song Name>` }, { quoted: message });
        }

        // 1. SEARCH REACTION
        await sock.sendMessage(chatId, { react: { text: icons.search, key: message.key } });

        // 2. SEARCH WITH YT-SEARCH (Better Metadata)
        let songUrl = query;
        let songMeta = {};

        // If not a link, search it
        if (!query.startsWith('http')) {
            const search = await yts(query);
            if (!search.videos.length) throw new Error("Song not found.");
            
            songMeta = search.videos[0];
            songUrl = songMeta.url;
        }

        // 3. FETCH DOWNLOAD LINK (David Cyril API)
        const apiUrl = `https://apis.davidcyril.name.ng/download/ytmp3?url=${encodeURIComponent(songUrl)}`;
        const { data } = await axios.get(apiUrl);

        if (!data.status || !data.result) {
            throw new Error("API failed to process audio.");
        }

        const result = data.result;

        // Normalize Metadata (API vs Search)
        const displayMeta = {
            title: result.title || songMeta.title || "Unknown Song",
            duration: result.duration || songMeta.timestamp || "Unknown",
            views: songMeta.views || 0,
            author: songMeta.author || { name: "Septorch Music" },
            thumbnail: result.thumbnail || songMeta.thumbnail
        };

        // 4. SEND INFO CARD
        await sock.sendMessage(chatId, { 
            image: { url: displayMeta.thumbnail }, 
            caption: makeCard(displayMeta) 
        }, { quoted: message });

        // 5. DOWNLOAD
        const fileName = `septorch_audio_${Date.now()}.mp3`;
        tempFilePath = path.join(TEMP_DIR, fileName);

        await downloadFile(result.download_url, tempFilePath);

        // 6. UPLOAD AUDIO
        await sock.sendMessage(chatId, { react: { text: '⬆️', key: message.key } });

        await sock.sendMessage(chatId, {
            audio: { url: tempFilePath },
            mimetype: 'audio/mpeg',
            fileName: `${displayMeta.title}.mp3`,
            contextInfo: {
                externalAdReply: {
                    title: displayMeta.title,
                    body: `Played via Septorch • ${displayMeta.duration}`,
                    thumbnailUrl: displayMeta.thumbnail,
                    sourceUrl: WEBSITE_URL,
                    mediaType: 1,
                    showAdAttribution: true,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: message });

        await sock.sendMessage(chatId, { react: { text: icons.check, key: message.key } });

    } catch (error) {
        console.error('[SONG ERROR]', error);
        await sock.sendMessage(chatId, { text: `❌ *Error:* ${error.message || 'Could not download song.'}` });
    } finally {
        // CLEANUP
        if (tempFilePath && fs.existsSync(tempFilePath)) {
            setTimeout(() => fs.unlinkSync(tempFilePath), 15000); 
        }
    }
};

// 🟢 EXPORT FOR MAIN.JS
module.exports = songCommand;