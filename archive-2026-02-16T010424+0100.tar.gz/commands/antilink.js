const { setAntilink, getAntilink, removeAntilink } = require('../lib/index');

// 1. DEFINE LINK REGEX (What to look for)
const linkRegex = /(https?:\/\/|www\.)[^\s]+|chat\.whatsapp\.com\/[^\s]+/gi;

// =========================================
// 🎨 DESIGN & THEME CONFIGURATION
// =========================================
const icons = {
    shield : '🛡️',    link  : '🔗',    gear  : '⚙️',
    on     : '🟢',    off   : '🔴',    warn  : '⚠️',
    check  : '✅',    err   : '⛔',    action: '⚡',
    list   : '📜',    arrow : '➔'
};

const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.shield} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

const sendCard = (sock, chatId, title, lines, quoted) =>
    sock.sendMessage(chatId, { text: makeCard(title, lines) }, { quoted });

// =========================================
// 🚀 COMMAND HANDLER (The Setup Menu)
// =========================================
async function handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message, botId) {
    try {
        if (!isSenderAdmin) {
            return sendCard(sock, chatId, 'ACCESS DENIED', [
                ` ${icons.err}  *Admins Only*`,
                "---",
                " You need admin privileges."
            ], message);
        }

        const args = userMessage.trim().split(/\s+/).slice(1);
        const action = args[0] ? args[0].toLowerCase() : null;

        if (!action) {
            const config = await getAntilink(chatId, 'on', botId);
            const statusIcon = config?.enabled ? icons.on : icons.off;
            const currentAction = config?.action || 'delete';

            return sendCard(sock, chatId, 'ANTILINK SECURITY', [
                ` ${icons.gear}  *Status:* ${statusIcon}`,
                ` ${icons.action}  *Action:* ${currentAction.toUpperCase()}`,
                '---',
                ` ${icons.arrow}  *.antilink on*`,
                ` ${icons.arrow}  *.antilink off*`,
                '---',
                ` ${icons.list}  *Set Punishment:*`,
                ` .antilink set delete`,
                ` .antilink set kick`,
                ` .antilink set warn`
            ], message);
        }

        switch (action) {
            case 'on': {
                const config = await getAntilink(chatId, 'on', botId);
                if (config?.enabled) return sendCard(sock, chatId, 'STATUS', [` ${icons.on} Already Active`], message);
                await setAntilink(chatId, 'on', 'delete', botId);
                return sendCard(sock, chatId, 'ENABLED', [` ${icons.check} Antilink is now ON`], message);
            }
            case 'off': {
                await removeAntilink(chatId, botId);
                return sendCard(sock, chatId, 'DISABLED', [` ${icons.off} Antilink is now OFF`], message);
            }
            case 'set': {
                const setAction = args[1]?.toLowerCase();
                if (!['delete', 'kick', 'warn'].includes(setAction)) {
                    return sendCard(sock, chatId, 'ERROR', [` ${icons.err} Use delete, kick, or warn`], message);
                }
                await setAntilink(chatId, 'on', setAction, botId);
                return sendCard(sock, chatId, 'UPDATED', [` ${icons.check} Action set to: ${setAction}`], message);
            }
            default:
                return sendCard(sock, chatId, 'ERROR', [` ${icons.err} Unknown command`], message);
        }
    } catch (error) {
        console.error('Error in antilink command:', error);
    }
}

// =========================================
// 🕵️ DETECTION HANDLER (The Security Guard)
// =========================================
async function handleLinkDetection(sock, chatId, message, userMessage, senderId, isSenderAdmin, botId) {
    try {
        // 1. Check if text contains a link
        if (!linkRegex.test(userMessage)) return;

        // 2. Check Database: Is it enabled?
        const config = await getAntilink(chatId, 'on', botId);
        if (!config || !config.enabled) return;

        // 3. Admin Immunity: Don't punish admins
        if (isSenderAdmin) return;

        // 4. Execute Punishment
        const action = config.action || 'delete';
        
        // Always delete the message first
        try {
            await sock.sendMessage(chatId, { delete: message.key });
        } catch (e) {
            console.error("Failed to delete message", e);
        }

        if (action === 'kick') {
            await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
            await sock.sendMessage(chatId, { text: `🛡️ *Link Detected & User Kicked*` });
        } else if (action === 'warn') {
            await sock.sendMessage(chatId, { text: `⚠️ *Warning! Links are not allowed here.*`, mentions: [senderId] });
        } else {
            // Delete only (already done above)
            await sock.sendMessage(chatId, { text: `⛔ *Link Deleted*`, mentions: [senderId] });
        }

    } catch (error) {
        console.error('Error in link detection:', error);
    }
}

module.exports = {
    handleAntilinkCommand,
    handleLinkDetection
};