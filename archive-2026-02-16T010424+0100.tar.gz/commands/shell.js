const { exec } = require('child_process');
const util = require('util');
const fs = require('fs'); // Ensure fs is required for file operations
const execPromise = util.promisify(exec);

// Define allowed owner(s) here
// Note: WhatsApp IDs usually end with @s.whatsapp.net or @lid
const OWNER_NUMBER = '2349047943737'; 

async function shellCommand(sock, chatId, message, senderId) {
    // 1. 🛡️ SECURITY CHECK
    // Check if the sender's ID contains the owner number
    const isOwner = senderId.includes(OWNER_NUMBER);

    if (!isOwner) {
        return sock.sendMessage(chatId, {
            text: '❌ **Access Denied:** You are not authorized to use this command.',
        });
    }

    // 2. Parse Arguments
    const args = message.trim().split(' ').slice(1).join(' ');
    
    if (!args) {
        return sock.sendMessage(chatId, {
            text: '❌ Please provide a shell command to execute.',
        });
    }

    // 3. Execute Command
    try {
        const { stdout, stderr } = await execPromise(args);
        
        let output = '';
        if (stdout) output += '✅ Output:\n' + stdout;
        if (stderr) output += '\n⚠️ Error:\n' + stderr;

        if (output.length > 4096) {
            // Send as file if too long
            const tmpFilePath = `/tmp/shell_output_${Date.now()}.txt`;
            fs.writeFileSync(tmpFilePath, output);
            
            await sock.sendMessage(chatId, {
                document: fs.readFileSync(tmpFilePath),
                mimetype: 'text/plain',
                fileName: 'shell_output.txt',
                caption: 'Output too long, sent as file.'
            });

            // Cleanup temp file
            fs.unlinkSync(tmpFilePath); 
        } else {
            await sock.sendMessage(chatId, {
                text: `\`\`\`${output || 'No output'}\`\`\``
            });
        }
    } catch (error) {
        console.error('Error executing shell command:', error);
        await sock.sendMessage(chatId, {
            text: `❌ Failed to execute command: ${error.message}`,
        });
    }
}

module.exports = { shellCommand };