const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');

// Register the custom font
registerFont(path.join(__dirname, '../assets/fonts/Lobster-Regular.ttf'), { family: 'Lobster' });

const flirtMessages = [
  "Babe, your smile dey scatter my brain like Lagos traffic! 😍🚗",
  "Oya, fine girl, gimme one chance, I fit spoil you with jollof! 🍲💕",
  "See your eyes, e dey shine pass NEPA light—wetin be your secret? ✨😘",
  "My heart dey beat for you like Fuji music, abeg dance with me! 🎶💃",
  "You too fine, I go need visa to approach you sef! ✈️😉",
  "Fine boy, your swagger dey move pass PH traffic—teach me! 🚦💪",
  "Babe, your beauty dey shine pass Abuja nightlife—glow for me! 🌃😍",
  "Oga, if I wink at you, you go fall or na me go fall? 😉💥",
  "My love, your voice sweet pass amala—sing me a song! 🍲😘",
  "See your shape, e be like say na Kano sculptor carve you! 🎨💕",
  "Babe, if I buy you suya, you go gimme kiss? 🍢😉",
  "Fine girl, your hips dey sway like Afrobeat—dance with me! 🎵💃",
  "Oya, show me your vibe, make I join you for this love train! 🚂😍",
  "My heart, your laugh dey sweet pass plantain porridge! 🍌😘",
  "Babe, your eyes dey pull me like magnet—abeg hold me! 🧲💕",
  "Fine boy, if you smile again, I go melt like ice cream! 🍦😉",
  "Oga, your style dey make me jealous—dress me up nau! 👔💪",
  "My love, your hug dey warm me pass electric blanket! 🤗😘",
  "Babe, your beauty dey cause traffic for my mind—slow down! 🚦😍",
  "Fine girl, if I call you sugar, you go answer? 🍬💕",
  "Oya, let’s gist till morning, your talk dey pepper me! 😂💬",
  "My heart, your smile dey bright pass generator light! 🔋😘",
  "Babe, if I propose now, you go say yes or na slap? 💍😉",
  "Fine boy, your charm dey make me shy—save me o! 🥰💪",
  "Oga, your eyes dey sparkle like gold—wetin you rub? ✨😍",
  "My love, your dance moves dey kill me softly—more! 💃😘",
  "Babe, your legs dey fine pass new Range Rover! 🚗💕",
  "Fine girl, if I send you airtime, you go call me? 📱😉",
  "Oya, show me your cooking, make I taste your love! 🍲😍",
  "My heart, your beauty dey make me forget my name! 😂💓",
  "Babe, your voice dey sweet pass Davido’s beat! 🎤😘",
  "Fine boy, if I hold your hand, you go run? 🤝💪",
  "Oga, your swag dey pull me like tractor—stop am! 🚜😉",
  "My love, your hug dey feel like heaven—stay close! 🤗😍",
  "Babe, your smile dey bright pass solar panel! ☀️💕",
  "Fine girl, your beauty dey make me stammer—wetin be this? 😂💃",
  "Oya, let’s vibe together, your energy dey sweet! 🎉😘",
  "My heart, your laugh dey heal my soul—keep it! 😂💓",
  "Babe, if I cook you egusi, you go marry me? 🍲😉",
  "Fine boy, your style dey give me inspiration—lead me! 👞💪",
  "Oga, if you dance with me, I go fall for you! 💃😍",
  "My love, your eyes dey tell me ‘yes’—am I right? 👀😘",
  "Babe, your beauty dey shine pass diamond! 💎💕",
  "Fine girl, your hips dey move like carnival—join me! 🎊💃",
  "Oya, show me your swag, make I learn from you! 💪😉",
  "My heart, your voice dey sweet pass morning tea! ☕😍",
  "Babe, if I wink at you, you go blush? 😉💕",
  "Fine boy, your smile dey give me butterflies—catch me! 🦋😘",
  "Oga, your charisma dey pull me—abeg no run! 🧲💪",
  "My love, your vibe dey give me life—more please! 🌟😍",
  "Babe, your beauty dey make me dream big! 🌹💕",
  "Fine girl, your dance dey make me jealous—teach me! 💃😉",
  "Oya, let’s take a walk, your presence dey sweet! 🚶‍♂️😘",
  "My heart, your smile dey make me weak—save me! 😍💓",
  "Babe, your eyes dey sparkle like stars—wink back! ✨😉",
  "Fine boy, your charm dey make me trip—hold me! 🚶‍♂️💪",
  "Oga, if I call you king, you go rule my heart? 👑😍",
  "My love, your hug dey feel like home—hug me! 🤗😘",
  "Babe, your beauty dey shine pass moonlight! 🌕💕",
  "Fine girl, if I hold you, you go push me? 🤝😉",
  "Oya, show me your cooking skills, make I chop! 🍲😍",
  "My heart, your vibe dey give me joy—keep it up! 😘💓",
  "Babe, if I send you money, you go call me bae? 💸😉",
  "Fine boy, your swag dey make me follow you! 👟💪",
  "Oga, your smile dey melt my heart—stop it! 😂😍",
  "My love, your voice dey sweet pass egusi soup! 🍲😘",
  "Babe, your beauty dey make me sing—listen! 🎶💕",
  "Fine girl, your eyes dey pull me like hook—reel me! 🎣😉",
  "Oya, let’s gist about love, your words dey sweet! 💬😍",
  "My heart, your laugh dey make me happy—more! 😂💓",
  "Babe, if I buy you puff-puff, you go smile? 🍩😉",
  "Fine boy, your style dey give me vibes—join me! 👞💪",
  "Oga, if you hold me, I go stay? 🤗😍",
  "My love, your beauty dey make my day—shine on! 🌟😘",
  "Babe, your smile dey light my world—keep it! 😍💕",
  "Fine girl, your dance moves dey steal my heart! 💃😉",
  "Oya, show me your love, make I feel it! ❤️😍",
  "My heart, your voice dey call me—answer me! 📞💓",
  "Babe, your eyes dey shine pass gold—blink! ✨😉",
  "Fine boy, your charm dey make me blush—help! 🥰💪",
  "Oga, if I kiss you, you go run? 😘😍",
  "My love, your hug dey heal me—hold tight! 🤗💕",
  "Babe, your beauty dey beat my imagination! 🌹😉",
  "Fine girl, if I call you queen, you go crown me? 👑😍",
  "Oya, let’s vibe till night, your energy dey hot! 🎉💕",
  "My heart, your smile dey make me fly—catch me! 🕊️😘",
  "Babe, your voice dey sweet pass honey—taste me! 🍯😉",
  "Fine boy, your swag dey make me dance—join in! 💃💪",
  "Oga, your eyes dey tell me love—say it! 👀😍",
  "My love, your beauty dey make me pray—amen! 🙏💓",
  "Babe, if I hold your hand, you go stay? 🤝😉",
  "Fine girl, your hips dey move my heart—sway! 💃😍",
  "Oya, show me your heart, make I enter! ❤️💕",
  "My heart, your laugh dey make me live—keep it! 😂😘",
  "Babe, your smile dey bright my night—shine! 🌙😉",
  "Fine boy, your style dey make me love—wear more! 👞💪",
  "Oga, if I love you, you go love me back? 😘😍",
  "My love, your vibe dey give me peace—stay! ✌️💕",
  "Babe, your beauty dey make me write—read me! 📝😉",
  "Fine girl, your dance dey steal my soul—dance on! 💃😍",
  "Oya, let’s dream together, your love dey sweet! 🌟💕",
  "My heart, your eyes dey call me home—come! 👀😘",
  "Babe, if I give you my heart, you go keep it? ❤️😉",
  "Fine boy, your smile dey make me weak—strengthen me! 🥰💪",
  "Oga, your charm dey pull me deep—dive in! 🧲😍",
  "My love, your hug dey save me—hold on! 🤗💕"
  // Total: 105 messages (exceeds 100)
];

async function flirtCommand(sock, chatId) {
  try {
    const flirtPath = path.join(__dirname, '../assets/flirt.jpg');
    const image = await loadImage(flirtPath);

    const canvas = createCanvas(image.width, image.height);
    const ctx = canvas.getContext('2d');

    ctx.drawImage(image, 0, 0, image.width, image.height);

    const randomFlirt = flirtMessages[Math.floor(Math.random() * flirtMessages.length)];
    const lines = splitTextToLines(randomFlirt, 15);

    const fontSize = Math.floor(image.height * 0.07);
    ctx.font = `bold ${fontSize}px "Lobster"`;
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(255, 255, 255, 1.0)';
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
    ctx.lineWidth = 5;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetX = 3;
    ctx.shadowOffsetY = 3;

    const centerX = image.width / 2;
    const totalHeight = lines.length * fontSize * 1.5;
    const startY = (image.height - totalHeight) / 2 + fontSize;

    lines.forEach((line, i) => {
      const y = startY + i * fontSize * 1.5;
      ctx.strokeText(line, centerX, y);
      ctx.fillText(line, centerX, y);
    });

    const buffer = canvas.toBuffer('image/jpeg');

    await sock.sendMessage(chatId, {
      image: buffer,
      caption: '😘 Flirt mode activated by your love! 💕'
    });

  } catch (error) {
    console.error('❌ Error generating flirt image:', error);
    await sock.sendMessage(chatId, {
      text: '❌ Failed to send flirt message. Try again later.'
    });
  }
}

// Helper: Split text into lines with max `maxChars` per line
function splitTextToLines(text, maxChars) {
  const words = text.split(/\s+/);
  const lines = [];
  let current = '';

  for (const word of words) {
    if ((current + word).length > maxChars) {
      lines.push(current.trim());
      current = word + ' ';
    } else {
      current += word + ' ';
    }
  }

  if (current.trim()) lines.push(current.trim());
  return lines;
}

module.exports = { flirtCommand };