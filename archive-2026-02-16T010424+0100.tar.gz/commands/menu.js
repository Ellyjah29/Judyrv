const settings = require('../settings');
const fs = require('fs');
const path = require('path');
const process = require('process');
const ffmpeg = require('fluent-ffmpeg'); 

// =========================================
// 🛠️ HELPER: ULTRA-COMPRESS VIDEO
// =========================================
const resizeVideo = (inputPath, outputPath) => {
    return new Promise((resolve, reject) => {
        console.log("⚙️  Compressing menu video... please wait.");
        ffmpeg(inputPath)
            .size('320x320')            
            .autoPad(true, 'black')     
            .fps(15)                    
            .duration(6)                
            .noAudio()                  
            .videoBitrate('250k')       
            .outputOptions([
                '-preset veryfast',     
                '-crf 35',              
                '-pix_fmt yuv420p'      
            ])
            .on('end', () => {
                console.log("✅ Video compressed successfully!");
                resolve(outputPath);
            })
            .on('error', (err) => {
                console.error("❌ Error compressing video:", err);
                reject(err);
            })
            .save(outputPath);
    });
};

// =========================================
// 🎨 PROFESSIONAL THEME
// =========================================
const theme = {
    div: '━━━━━━━━━━━━━━━━━━━━',
    
    // Category Icons
    general: '🌐',   ai: '🤖',      admin: '🛡️',
    owner: '👑',     media: '📥',   tools: '🔧',
    fun: '🎮',       games: '🎲',   creative: '🎨',
    group: '👥',     search: '🔍'   // 🟢 New Icon
};

// =========================================
// 🗂️ FULL COMMAND LIST (With Search Added)
// =========================================
const baseCategories = {
  ai: {
    title: 'ARTIFICIAL INTELLIGENCE',
    icon: theme.ai,
    commands: [
        '.bot <query>', '.gpt', '.gemini', '.vision', 
        '.imagine', '.notes', '.flux'
    ]
  },
  search: {
    title: 'SEARCH ENGINE', // 🟢 New Category
    icon: theme.search,
    commands: [
        '.google', '.img', '.anime', '.pinterest', 
        '.wallpaper', '.lyrics', '.weather', '.wiki', 
        '.github', '.imdb', '.ytsearch', '.ringtone'
    ]
  },
  media: {
    title: 'MEDIA & DOWNLOADS',
    icon: theme.media,
    commands: [
        '.play', '.song', '.video', '.ytmp4', '.qvideo', 
        '.tiktok', '.instagram', '.facebook', '.spotify', 
        '.threads', '.tomp3', '.vv', '.vv2'
    ]
  },
  admin: {
    title: 'GROUP ADMIN COMMANDS',
    icon: theme.admin,
    commands: [
        '.kick', '.ban', '.unban', '.promote', '.demote', 
        '.mute', '.unmute', '.delete', '.clear', '.tagall', 
        '.hidetag', '.antilink', '.antibadword', '.welcome', 
        '.goodbye', '.resetlink', '.warn', '.warnings'
    ]
  },
  group: {
    title: 'GROUP COMMANDS',
    icon: theme.group,
    commands: [
        '.groupinfo', '.staff', '.topmembers', '.pair', 
        '.link'
    ]
  },
  tools: {
    title: 'SYSTEM UTILITIES',
    icon: theme.tools,
    commands: [
        '.ping', '.alive', '.uptime', '.owner', '.menu', 
        '.list', '.help', '.news', '.bible', '.ocr', 
        '.urlshort', '.upload', '.ss', '.translate', 
        '.qr', '.tts', '.stt'
    ]
  },
  creative: {
    title: 'STICKERS & TEXT EFFECTS',
    icon: theme.creative,
    commands: [
        '.sticker', '.simage', '.take', '.emojimix', '.attp', 
        '.tgsticker', '.blur', '.wasted', '.metallic', '.ice', 
        '.snow', '.impressive', '.matrix', '.light', '.neon', 
        '.devil', '.purple', '.thunder', '.leaves', '.1917', 
        '.arena', '.hacker', '.sand', '.blackpink', '.glitch', 
        '.fire'
    ]
  },
  games: {
    title: 'GAMING ZONE',
    icon: theme.games,
    commands: [
        '.ttt', '.move', '.surrender', '.hangman', '.guess', 
        '.trivia', '.answer', '.math', '.riddle', '.livescore'
    ]
  },
  fun: {
    title: 'SOCIAL & FUN',
    icon: theme.fun,
    commands: [
        '.compliment', '.insult', '.ship', '.meme', '.joke', 
        '.fact', '.quote', '.8ball', '.dare', '.truth', 
        '.flirt', '.shayari', '.goodnight', '.roseday', 
        '.simp', '.stupid', '.character'
    ]
  },
  owner: {
    title: 'OWNER CONTROL',
    icon: theme.owner,
    commands: [
        '.mode', '.autostatus', '.antidelete', '.setpp', 
        '.autoreact', '.autoreply', '.fake', '.switchfake', 
        '.schedule', '.unschedule', '.myschedules', '.clearschedule', 
        '.cleartmp', '.clearsession', '.shell', '.dmall'
    ]
  }
};

// =========================================
// 🚀 MAIN MENU HANDLER
// =========================================

async function menuCommand(sock, chatId, command = null, page = 0, senderName = 'User', message, botId) {
  try {
    const botName = settings.botName || 'SEPTORCH';
    const date = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    // 🟢 1. DYNAMICALLY MERGE EXTERNAL PLUGINS
    const categories = JSON.parse(JSON.stringify(baseCategories));

    if (global.plugins) {
        global.plugins.forEach((plugin) => {
            const cmdName = Array.isArray(plugin.cmd) ? plugin.cmd[0] : plugin.cmd;
            let catKey = plugin.category ? plugin.category.toLowerCase() : 'tools';
            
            // Normalize Keys
            if (catKey === 'utility') catKey = 'tools';
            if (catKey === 'game') catKey = 'games';
            if (catKey === 'download') catKey = 'media';
            if (catKey === 'gpt') catKey = 'ai';
            if (catKey === 'sticker') catKey = 'creative';
            if (catKey === 'group') catKey = 'group';
            if (catKey === 'search') catKey = 'search'; // Plugin support for search

            const entry = `.${cmdName}`;

            if (categories[catKey]) {
                if (!categories[catKey].commands.includes(entry)) {
                    categories[catKey].commands.push(entry);
                }
            } else {
                // If category fits nowhere, put in Tools
                categories['tools'].commands.push(entry);
            }
        });
    }

    // 🟢 2. PREPARE VIDEO
    const rawVideoPath = path.join(__dirname, '../assets/bot_video.mp4'); 
    const resizedVideoPath = path.join(__dirname, '../assets/bot_menu_resized.mp4');
    let finalVideoBuffer = null;

    if (fs.existsSync(resizedVideoPath)) {
        finalVideoBuffer = fs.readFileSync(resizedVideoPath);
    } else if (fs.existsSync(rawVideoPath)) {
        try {
            await sock.sendMessage(chatId, { text: '_🎨 System: Optimizing assets..._' }, { quoted: message });
            await resizeVideo(rawVideoPath, resizedVideoPath);
            finalVideoBuffer = fs.readFileSync(resizedVideoPath);
        } catch (e) {
            console.log("Resize failed, using raw video.");
            finalVideoBuffer = fs.readFileSync(rawVideoPath);
        }
    }

    // 🟢 3. BUILD PROFESSIONAL DASHBOARD (TREE STYLE)
    let menuText = `
┏━━━━━━━━━━━━━━━━━━━┓
┃   *${botName.toUpperCase()} V3 SYSTEM* ┗━━━━━━━━━━━━━━━━━━━┛
👤 *User:* ${senderName}
🕒 *Time:* ${time}
📅 *Date:* ${date}
${theme.div}
`;

    // Loop through categories
    Object.keys(categories).forEach(key => {
        const cat = categories[key];
        // Sort alphabetically
        const sortedCmds = cat.commands.sort();
        
        menuText += `\n*${cat.icon} ${cat.title}*\n`;
        
        // 🟢 TREE GENERATOR
        const cmdTree = sortedCmds.map((cmd, index) => {
            const isLast = index === sortedCmds.length - 1;
            const branch = isLast ? '└' : '├';
            return `${branch} ${cmd}`;
        }).join('\n');

        menuText += `\`\`\`${cmdTree}\`\`\`\n`;
    });

    menuText += `\n_${settings.footer || 'Powered by Septorch Intelligence'}_`;

    // 🟢 4. SEND MESSAGE
    const messageOptions = {
        caption: menuText,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363387922693296@newsletter',
                newsletterName: 'SEPTORCH UPDATES',
                serverMessageId: -1
            }
        }
    };

    if (finalVideoBuffer) {
        messageOptions.video = finalVideoBuffer;
        messageOptions.gifPlayback = true; 
    } else {
        messageOptions.text = menuText; 
    }

    await sock.sendMessage(chatId, messageOptions, { quoted: message });

  } catch (err) {
    console.error('Menu error:', err);
    await sock.sendMessage(chatId, { text: '❌ *System Error:* Unable to load menu.' });
  }
}

module.exports = {
  menuCommand
};