// ✅ ai_notes.js (Verified v7 Compatible)
const fs = require('fs');
const path = require('path');

function getNotesPath(botId, chatId) {
    // Safety check for undefined IDs
    if (!botId || !chatId) return null;
    
    const dir = path.join(__dirname, '../data', botId, 'ai_notes', chatId);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return dir;
}

async function saveNote(sock, chatId, sender, text, botId) {
    if (!text || !chatId || !botId) return;

    const notesDir = getNotesPath(botId, chatId);
    if (!notesDir) return;

    const now = new Date().toLocaleString();
    const fileName = path.join(notesDir, `${Date.now()}.json`);

    const data = { sender, text, time: now };

    try {
        fs.writeFileSync(fileName, JSON.stringify(data, null, 2));
    } catch (err) {
        console.error(`[NOTES] Failed to save message in ${chatId}:`, err.message);
    }
}

async function loadChatHistory(botId, chatId, limit = 50) {
    const dir = getNotesPath(botId, chatId);
    if (!dir) return [];

    let files = [];
    try {
        files = fs.readdirSync(dir).sort();
    } catch {
        return [];
    }

    const history = [];
    for (const file of files.slice(-limit)) {
        try {
            const content = fs.readFileSync(path.join(dir, file));
            const note = JSON.parse(content.toString());
            history.push({
                role: note.sender === 'bot' ? 'assistant' : 'user',
                content: `${note.text}\n(Sent on ${note.time})`,
            });
        } catch (err) {
            console.warn(`[NOTES] Failed to parse file: ${file}`);
        }
    }
    return history;
}

async function listTopics(sock, chatId, botId) {
    const dir = getNotesPath(botId, chatId);
    if (!dir) {
        await sock.sendMessage(chatId, { text: "❌ No notes found." });
        return;
    }

    let files = [];
    try {
        files = fs.readdirSync(dir);
    } catch {
        await sock.sendMessage(chatId, { text: "❌ No notes found." });
        return;
    }

    const allNotes = files.map(file => {
        try {
            const content = fs.readFileSync(path.join(dir, file));
            return JSON.parse(content.toString());
        } catch { return null; }
    }).filter(n => n);

    if (allNotes.length === 0) {
        await sock.sendMessage(chatId, { text: "📭 This chat has no recorded history." });
        return;
    }

    const words = allNotes.flatMap(note => note.text.toLowerCase().split(/\s+/))
        .filter(word => word.length > 3)
        .reduce((acc, word) => {
            acc[word] = (acc[word] || 0) + 1;
            return acc;
        }, {});

    const sortedWords = Object.entries(words)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([word]) => word);

    let reply = "🧠 *Common Topics in Chat*:\n\n";
    sortedWords.forEach((topic, i) => {
        reply += `${i + 1}. ${topic}\n`;
    });

    await sock.sendMessage(chatId, { text: reply });
}

async function summarizeChat(sock, chatId, botId) {
    const dir = getNotesPath(botId, chatId);
    if (!dir) {
        await sock.sendMessage(chatId, { text: "❌ No notes found." });
        return;
    }

    let files = [];
    try {
        files = fs.readdirSync(dir);
    } catch {
        await sock.sendMessage(chatId, { text: "❌ No notes found." });
        return;
    }

    const allNotes = files.map(file => {
        try {
            const content = fs.readFileSync(path.join(dir, file));
            return JSON.parse(content.toString());
        } catch { return null; }
    }).filter(n => n).sort((a, b) => new Date(b.time) - new Date(a.time));

    if (allNotes.length === 0) {
        await sock.sendMessage(chatId, { text: "❌ No messages to summarize." });
        return;
    }

    let reply = "📜 *Latest Messages Summary*:\n\n";
    allNotes.slice(0, 5).forEach((note, i) => {
        const user = note.sender.split('@')[0];
        reply += `${i + 1}. @${user}: "${note.text}"\n🕒 ${note.time}\n\n`;
    });

    await sock.sendMessage(chatId, {
        text: reply,
        mentions: allNotes.map(n => n.sender)
    });
}

module.exports = {
    saveNote,
    loadChatHistory,
    listTopics,
    summarizeChat
};