const { fbdl } = require("ruhend-scraper"); // Using your local scraper
const axios = require('axios');

module.exports = async function facebookCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        
        // 1. Validate Input
        if (!text) return await sock.sendMessage(chatId, { text: "❌ Please provide a Facebook URL." });
        
        const urlMatch = text.match(/(?:https?:\/\/)?(?:www\.|web\.|m\.|fb\.)?(?:facebook\.com|fb\.watch|fb\.com)\/\S+/);
        const url = urlMatch ? urlMatch[0] : null;

        if (!url) {
            return await sock.sendMessage(chatId, { text: "❌ Invalid Facebook URL." });
        }

        // 2. React
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        let videoUrl = null;
        let quality = "SD";

        // =====================================================================
        // 🏠 METHOD 1: LOCAL SCRAPER (Direct Use)
        // This runs on YOUR server, not an external API.
        // =====================================================================
        try {
            console.log("Trying Local Scraper...");
            const data = await fbdl(url);
            if (data && data.data && data.data.length > 0) {
                // Find HD if available, else SD
                const best = data.data.find(v => v.resolution === '720p (HD)') || data.data.find(v => v.resolution === '360p (SD)') || data.data[0];
                videoUrl = best.url;
                quality = best.resolution;
            }
        } catch (e) {
            console.log("Local Scraper failed, trying Cobalt Engine...");
        }

        // =====================================================================
        // ⚙️ METHOD 2: COBALT ENGINE (Direct Backend)
        // This connects directly to a high-performance processing engine
        // =====================================================================
        if (!videoUrl) {
            try {
                const cobaltResponse = await axios.post('https://cobalt.tools/api/json', {
                    url: url,
                    vQuality: "720",
                    filenamePattern: "classic"
                }, {
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    }
                });

                if (cobaltResponse.data && cobaltResponse.data.url) {
                    videoUrl = cobaltResponse.data.url;
                    quality = "HD (Cobalt)";
                }
            } catch (e) {
                console.log("Cobalt Engine failed.");
            }
        }

        // =====================================================================
        // ❌ FINAL CHECK
        // =====================================================================
        if (!videoUrl) {
            return await sock.sendMessage(chatId, { text: "❌ Failed. This video is likely private or age-restricted." });
        }

        // 3. Download & Send
        // We use a buffer to ensure the file sends correctly even if the link expires quickly
        try {
            const bufferRes = await axios.get(videoUrl, { 
                responseType: 'arraybuffer',
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });

            const videoBuffer = Buffer.from(bufferRes.data);

            await sock.sendMessage(chatId, { 
                video: videoBuffer, 
                caption: `🎬 *Facebook Direct*\n✨ *Quality:* ${quality}\n⬇️ *Downloaded by Septorch*`,
                mimetype: "video/mp4"
            }, { quoted: message });

        } catch (downloadError) {
            // Backup: Send as document if video conversion fails (common for huge files)
            await sock.sendMessage(chatId, { 
                document: { url: videoUrl }, 
                mimetype: "video/mp4",
                fileName: "septorch_fb.mp4",
                caption: `🎬 *Video File*\n(Sent as file due to size)`
            }, { quoted: message });
        }

    } catch (error) {
        console.error('FB Command Error:', error);
        await sock.sendMessage(chatId, { text: "❌ An internal error occurred." });
    }
};