const axios = require("axios");
const moment = require("moment-timezone");
const fs = require('fs');
const path = require('path');

// =========================================
// 🎨 PREMIUM UI THEME
// =========================================
const theme = {
    header: "━━━━━━━━━━━━━━━━━━━━━",
    live: "🔴",
    time: "🕒",
    finish: "🏁",
    sched: "📅",
    goal: "⚽",
    card: "🟥",
    vs: "🆚",
    trophy: "🏆"
};

// =========================================
// 🗂️ DATA MANAGEMENT
// =========================================
function getAutoFile(botId) {
    const dir = path.join(__dirname, '../data', botId);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return path.join(dir, 'livescore_auto.json');
}

function loadAutoConfig(botId) {
    const file = getAutoFile(botId);
    if (!fs.existsSync(file)) return {};
    return JSON.parse(fs.readFileSync(file));
}

function saveAutoConfig(botId, data) {
    fs.writeFileSync(getAutoFile(botId), JSON.stringify(data, null, 2));
}

let matchCache = {}; 
let monitorInterval = null;

// =========================================
// 🚀 COMMAND HANDLER
// =========================================
module.exports = async function livescoreCommand(sock, chatId, message, args, senderId, botId) {
    const safeBotId = botId || sock.user.id.split(':')[0];

    try {
        // 1. PARSE INPUT
        const fullText = 
            message.message?.conversation?.toLowerCase() ||
            message.message?.extendedTextMessage?.text?.toLowerCase() ||
            "";

        const cleanArgs = fullText.split(" ");
        const arg1 = cleanArgs[1];    // 'football', 'basketball', 'auto'
        const arg2 = cleanArgs[2];    // 'epl', league name
        const arg3 = cleanArgs[3];    // 'on', 'off'

        // 2. DEFINE LEAGUES & SPORTS
        const footballLeagues = {
            epl: "soccer/eng.1", laliga: "soccer/esp.1", ucl: "soccer/uefa.champions",
            afcon: "soccer/africa.cup", seriea: "soccer/ita.1", bundesliga: "soccer/ger.1",
            ligue1: "soccer/fra.1", npfl: "soccer/nga.1", uel: "soccer/uefa.europa"
        };

        const otherSports = {
            basketball: "basketball/nba",
            nba: "basketball/nba",
            baseball: "baseball/mlb",
            nfl: "football/nfl",
            hockey: "hockey/nhl",
            rugby: "rugby/eur.1",
            cricket: "cricket/icc.cwc" // Basic support
        };

        // =====================================
        // 🔄 PART 1: AUTO UPDATES CONFIG
        // =====================================
        if (arg1 === "auto") {
            if (!arg2 || !footballLeagues[arg2] || !['on', 'off'].includes(arg3)) {
                let text = `🔔 *LIVE MATCH ALERTS*\n${theme.header}\n`;
                text += `Get instant notifications for goals & scores.\n\n`;
                text += `*Usage:*\n`;
                text += `👉 .livescore auto epl on\n`;
                text += `👉 .livescore auto laliga off\n\n`;
                text += `*Supported:* epl, laliga, ucl, seriea, bundesliga, npfl`;
                return await sock.sendMessage(chatId, { text });
            }

            const config = loadAutoConfig(safeBotId);
            if (!config[chatId]) config[chatId] = [];

            if (arg3 === 'on') {
                if (!config[chatId].includes(arg2)) config[chatId].push(arg2);
                saveAutoConfig(safeBotId, config);
                startLiveMonitor(sock, safeBotId); 
                return await sock.sendMessage(chatId, { text: `✅ *Alerts Enabled* for ${arg2.toUpperCase()}` });
            } else {
                config[chatId] = config[chatId].filter(l => l !== arg2);
                saveAutoConfig(safeBotId, config);
                return await sock.sendMessage(chatId, { text: `❌ *Alerts Disabled* for ${arg2.toUpperCase()}` });
            }
        }

        // =====================================
        // 🎮 PART 2: MENUS & DASHBOARDS
        // =====================================
        
        // A. MAIN SPORTS MENU (If no args)
        if (!arg1) {
            let menu = `🏅 *SPORTS DASHBOARD*\n${theme.header}\n`;
            menu += `Select a sport to view live scores:\n\n`;
            menu += `⚽ *Football* → .livescore football\n`;
            menu += `🏀 *Basketball* → .livescore nba\n`;
            menu += `🏈 *NFL* → .livescore nfl\n`;
            menu += `⚾ *Baseball* → .livescore baseball\n`;
            menu += `🏒 *Hockey* → .livescore hockey\n`;
            menu += `🏉 *Rugby* → .livescore rugby\n\n`;
            menu += `_🔔 Auto Alerts: .livescore auto_`;
            
            return await sock.sendMessage(chatId, { text: menu });
        }

        // B. FOOTBALL LEAGUE MENU (If arg1 is football but no league)
        if (arg1 === "football" && !arg2) {
            let menu = `⚽ *FOOTBALL LEAGUES*\n${theme.header}\n`;
            menu += `Select a league:\n\n`;
            menu += `🇬🇧 *.livescore football epl*\n`;
            menu += `🇪🇸 *.livescore football laliga*\n`;
            menu += `🇪🇺 *.livescore football ucl*\n`;
            menu += `🇮🇹 *.livescore football seriea*\n`;
            menu += `🇩🇪 *.livescore football bundesliga*\n`;
            menu += `🇫🇷 *.livescore football ligue1*\n`;
            menu += `🇳🇬 *.livescore football npfl*\n`;
            menu += `🌍 *.livescore football afcon*\n\n`;
            menu += `_Type the command to view scores._`;
            
            return await sock.sendMessage(chatId, { text: menu });
        }

        // =====================================
        // 📡 PART 3: FETCH DATA
        // =====================================
        
        let apiLeague = null;
        let displayName = "";

        // Determine API Endpoint
        if (arg1 === "football") {
            apiLeague = footballLeagues[arg2];
            displayName = arg2?.toUpperCase();
        } else {
            apiLeague = otherSports[arg1];
            displayName = arg1.toUpperCase();
        }

        if (!apiLeague) {
            return await sock.sendMessage(chatId, { text: `❌ *Invalid Sport/League.*\nCheck the menu: .livescore` });
        }

        await sock.sendPresenceUpdate("composing", chatId);
        const apiUrl = `https://site.api.espn.com/apis/site/v2/sports/${apiLeague}/scoreboard`;
        const { data } = await axios.get(apiUrl);
        const events = data.events || [];

        if (!events.length) {
            return await sock.sendMessage(chatId, { text: `📭 No matches scheduled for *${displayName}* today.` });
        }

        // BUILD UI
        const leagueTitle = data.leagues?.[0]?.name || displayName;
        let messageText = `🏆 *${leagueTitle.toUpperCase()}*\n${theme.header}\n`;
        const updateTime = moment().tz("Africa/Lagos").format("h:mm A");

        events.slice(0, 15).forEach((event) => {
            const statusState = event.status.type.state; // pre, in, post
            const rawStatus = event.status.type.description;
            
            // Get Competitors
            const homeTeam = event.competitions[0].competitors.find(c => c.homeAway === 'home');
            const awayTeam = event.competitions[0].competitors.find(c => c.homeAway === 'away');
            
            // 🟢 FULL NAMES
            const homeName = homeTeam.team.shortDisplayName || homeTeam.team.displayName;
            const awayName = awayTeam.team.shortDisplayName || awayTeam.team.displayName;
            
            const homeScore = homeTeam.score || "0";
            const awayScore = awayTeam.score || "0";
            const clock = event.status.displayClock;

            // Format Status Line
            let statusLine = "";
            if (statusState === "in") {
                statusLine = `${theme.live} ${clock}' • LIVE`;
            } else if (statusState === "post") {
                statusLine = `${theme.finish} ${rawStatus}`; // FT
            } else {
                const matchDate = moment(event.date).tz("Africa/Lagos");
                const today = moment().tz("Africa/Lagos");
                if (matchDate.isSame(today, 'day')) {
                    statusLine = `${theme.sched} Today, ${matchDate.format("h:mm A")}`;
                } else {
                    statusLine = `${theme.sched} ${matchDate.format("DD/MM, h:mm A")}`;
                }
            }

            // CLEAN LAYOUT
            if (statusState === "pre") {
                messageText += `• ${homeName} ${theme.vs} ${awayName}\n`;
                messageText += `  └ ${statusLine}\n\n`;
            } else {
                messageText += `• ${homeName} *${homeScore}-${awayScore}* ${awayName}\n`;
                messageText += `  └ ${statusLine}\n\n`;
            }
        });

        messageText += `_🔄 Updated: ${updateTime}_`;

        await sock.sendMessage(chatId, { text: messageText });

    } catch (error) {
        console.error("LiveScore Error:", error.message);
        await sock.sendMessage(chatId, { text: "⚠️ Error connecting to sports server." });
    }
};

// =========================================
// 🔄 PROFESSIONAL MONITOR (BACKGROUND)
// =========================================
function startLiveMonitor(sock, botId) {
    if (monitorInterval) return; 
    console.log("⚽ Starting Live Match Monitor...");

    monitorInterval = setInterval(async () => {
        const config = loadAutoConfig(botId);
        const activeLeagues = new Set();
        Object.values(config).forEach(leagues => leagues.forEach(l => activeLeagues.add(l)));
        
        if (activeLeagues.size === 0) return;

        const footballLeagues = {
            epl: "soccer/eng.1", laliga: "soccer/esp.1", ucl: "soccer/uefa.champions",
            afcon: "soccer/africa.cup", seriea: "soccer/ita.1", bundesliga: "soccer/ger.1",
            ligue1: "soccer/fra.1", npfl: "soccer/nga.1"
        };

        for (const leagueKey of activeLeagues) {
            const apiLeague = footballLeagues[leagueKey];
            if (!apiLeague) continue;

            try {
                const sbUrl = `https://site.api.espn.com/apis/site/v2/sports/${apiLeague}/scoreboard`;
                const { data: sbData } = await axios.get(sbUrl);

                if (!sbData.events) continue;

                for (const event of sbData.events) {
                    const matchId = event.id;
                    const statusState = event.status.type.state; 
                    const homeComp = event.competitions[0].competitors.find(c => c.homeAway === 'home');
                    const awayComp = event.competitions[0].competitors.find(c => c.homeAway === 'away');

                    const currentData = {
                        state: statusState,
                        homeScore: parseInt(homeComp.score),
                        awayScore: parseInt(awayComp.score),
                        clock: event.status.displayClock
                    };

                    if (!matchCache[matchId]) {
                        matchCache[matchId] = currentData;
                        continue;
                    }

                    const prev = matchCache[matchId];
                    let alerts = [];
                    
                    const hName = homeComp.team.shortDisplayName;
                    const aName = awayComp.team.shortDisplayName;

                    // KICKOFF
                    if (prev.state === 'pre' && statusState === 'in') {
                         alerts.push({
                             msg: `⚡ *KICKOFF*\n${hName} ${theme.vs} ${aName}\nmatch has started!`
                         });
                    }

                    // GOALS
                    if (statusState === 'in') {
                        const summaryUrl = `https://site.api.espn.com/apis/site/v2/sports/${apiLeague}/summary?event=${matchId}`;
                        const { data: sumData } = await axios.get(summaryUrl);
                        
                        const details = sumData.header?.competitions?.[0]?.details || [];
                        const lastEvent = details[details.length - 1];

                        if (lastEvent) {
                            const eventType = lastEvent.type?.text?.toLowerCase() || "";
                            const eventTime = lastEvent.clock?.displayValue || currentData.clock;
                            const eventId = lastEvent.id; 

                            if (prev.lastEventId !== eventId) {
                                if (eventType.includes('goal')) {
                                    const scorer = lastEvent.participants?.[0]?.athlete?.shortName || "Player";
                                    const caption = `⚽ *GOAL! (${eventTime}')*\n` +
                                                    `👤 ${scorer}\n` +
                                                    `━━━━━━━━━━━━━\n` +
                                                    `🏟️ ${hName} ${currentData.homeScore} - ${currentData.awayScore} ${aName}`;
                                    alerts.push({ msg: caption });
                                }
                                currentData.lastEventId = eventId;
                            } else {
                                currentData.lastEventId = prev.lastEventId;
                            }
                        }
                    }

                    // FULL TIME
                    if (prev.state === 'in' && statusState === 'post') {
                        alerts.push({
                            msg: `🏁 *FULL TIME*\n${hName} ${currentData.homeScore} - ${currentData.awayScore} ${aName}`
                        });
                    }

                    if (alerts.length > 0) {
                        for (const [groupId, subscribedLeagues] of Object.entries(config)) {
                            if (subscribedLeagues.includes(leagueKey)) {
                                for (const alert of alerts) {
                                    try { await sock.sendMessage(groupId, { text: alert.msg }); } catch(e) {}
                                }
                            }
                        }
                    }
                    matchCache[matchId] = currentData;
                }
            } catch (e) {}
        }
    }, 60000); 
}