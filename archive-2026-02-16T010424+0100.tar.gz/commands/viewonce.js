// commands/viewonce.js
// 🔥 SEPTORCH ANTIVIEWONCE - Universal Media Extractor

// 🔴 REMOVED: Top-level require
// const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

const fs = require('fs');
const path = require('path');

// ✅ Global channel info — will be applied to ALL messages
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH',
            serverMessageId: -1
        }
    }
};

// Emoji map for media types
const TYPE_EMOJI = {
    image: '📸',
    video: '📹',
    document: '📁',
    audio: '🔊',
    sticker: '🪄',
    animation: '🔁',
    gif: '🔁',
    text: '💬'
};

async function viewOnceCommand(sock, chatId, message) {
    try {
        // 🟢 v7 FIX: Dynamic Import
        const { downloadContentFromMessage } = await import('@whiskeysockets/baileys');

        let msg = message.message;

        // 🔄 Unwrap ViewOnce wrappers (iPhone/Android)
        if (msg?.viewOnceMessage?.message) {
            msg = msg.viewOnceMessage.message;
        } else if (msg?.viewOnceMessageV2?.message) {
            msg = msg.viewOnceMessageV2.message;
        }

        // 🔄 Handle replies (quoted messages)
        else if (msg?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quoted = msg.extendedTextMessage.contextInfo.quotedMessage;

            if (quoted?.viewOnceMessage?.message) {
                msg = quoted.viewOnceMessage.message;
            } else if (quoted?.viewOnceMessageV2?.message) {
                msg = quoted.viewOnceMessageV2.message;
            } else {
                msg = quoted;
            }
        }

        // Normalize
        let media = null;
        let mediaType = null;
        let mimetype = '';
        let caption = '';
        let fileName = 'media';

        // 🔍 Detect media type
        const m = msg;

        if (m.imageMessage) {
            media = m.imageMessage;
            mediaType = 'image';
            mimetype = media.mimetype;
            caption = media.caption || '';
        } else if (m.videoMessage) {
            media = m.videoMessage;
            mediaType = m.videoMessage.gifPlayback ? 'animation' : 'video';
            mimetype = media.mimetype;
            caption = media.caption || '';
        } else if (m.documentMessage) {
            media = m.documentMessage;
            mediaType = 'document';
            mimetype = media.mimetype;
            caption = media.caption || '';
            fileName = media.fileName || 'document';
        } else if (m.audioMessage) {
            media = m.audioMessage;
            mediaType = 'audio';
            mimetype = media.mimetype;
        } else if (m.stickerMessage) {
            media = m.stickerMessage;
            mediaType = 'sticker';
        } else if (m.conversation && m.conversation.trim()) {
            return await sock.sendMessage(chatId, {
                text: '💬 *SEPTORCH ANTIVIEWONCE*\n\nNo media found in this message.',
                ...channelInfo
            });
        }

        if (!media) {
            return await sock.sendMessage(chatId, {
                text: '❌ *SEPTORCH ANTIVIEWONCE*\n\nNo media found to extract.',
                ...channelInfo
            });
        }

        // 🏷️ Set file name
        if (media.fileName) fileName = media.fileName;
        else if (caption && !['audio', 'sticker'].includes(mediaType)) fileName = caption;

        // Ensure temp dir
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);

        // Download helper
        const download = async (type) => {
            const stream = await downloadContentFromMessage(media, type);
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            return buffer;
        };

        // 🔥 Branding: Always use "SEPTORCH ANTIVIEWONCE"
        const header = '💀 *SEPTORCH ANTIVIEWONCE* 💀';
        const typeLabel = mediaType === 'animation' ? 'GIF' : 
                          mediaType.charAt(0).toUpperCase() + mediaType.slice(1);

        const emoji = TYPE_EMOJI[mediaType] || '📎';
        const statusLine = `*Status:* ${emoji} ${typeLabel}`;

        let finalCaption = `${header}\n\n${statusLine}`;

        if (caption && ['image', 'video', 'document'].includes(mediaType)) {
            finalCaption += `\n\n📝 *Caption:* ${caption}`;
        } else if (fileName && mediaType === 'document') {
            finalCaption += `\n\n📎 *File:* ${fileName}`;
        }

        // ✅ Send based on type
        if (mediaType === 'image') {
            const buffer = await download('image');
            await sock.sendMessage(chatId, {
                image: buffer,
                caption: finalCaption,
                ...channelInfo  // ✅ Included
            });

        } else if (mediaType === 'video') {
            const buffer = await download('video');
            await sock.sendMessage(chatId, {
                video: buffer,
                caption: finalCaption,
                ...channelInfo  // ✅ Included
            });

        } else if (mediaType === 'animation') {
            const buffer = await download('video');
            await sock.sendMessage(chatId, {
                video: buffer,
                gifPlayback: true,
                caption: finalCaption,
                ...channelInfo  // ✅ Included
            });

        } else if (mediaType === 'document') {
            const buffer = await download('document');
            await sock.sendMessage(chatId, {
                document: buffer,
                mimetype: mimetype,
                fileName: fileName,
                caption: finalCaption,
                ...channelInfo  // ✅ Included
            });

        } else if (mediaType === 'audio') {
            const buffer = await download('audio');
            await sock.sendMessage(chatId, {
                audio: buffer,
                mimetype: mimetype,
                caption: `${header}\n\n${statusLine}`,
                ...channelInfo  // ✅ Included
            });

        } else if (mediaType === 'sticker') {
            const buffer = await download('sticker');
            await sock.sendMessage(chatId, {
                image: buffer,
                caption: `${header}\n\n${statusLine}\n\n*Note:* Sticker extracted as image.`,
                ...channelInfo  // ✅ Included
            });
        }

        console.log(`✅ SEPTORCH ANTIVIEWONCE: Sent ${mediaType} media`);

    } catch (error) {
        console.error('❌ SEPTORCH ANTIVIEWONCE ERROR:', error);
        await sock.sendMessage(chatId, {
            text: `❌ *SEPTORCH ANTIVIEWONCE*\n\nFailed to process media!\n\`\`\`\n${error.message}\n\`\`\``,
            ...channelInfo  // ✅ Even error messages have branding
        });
    }
}

module.exports = viewOnceCommand;