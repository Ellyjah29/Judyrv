const settings = require('../settings.js');

// =========================================
// 🎨 PROFESSIONAL THEME (V3)
// =========================================
const theme = {
    div: '━━━━━━━━━━━━━━━━━━━━',
    ping: '🏓',   fast: '🚀',   good: '⚡',   slow: '🐢',
    bot: '🤖',    time: '⏱️',   sys: '🖥️'
};

// =========================================
// 🚀 COMMAND HANDLER
// =========================================
async function pingCommand(sock, chatId, botId) {
    try {
        const start = Date.now();
        
        // 1. Send Placeholder (To measure send time)
        const tmpMsg = await sock.sendMessage(chatId, { text: '_⚡ Analyzing Network Speed..._' });
        
        // 2. Calculate Latency
        const end = Date.now();
        const latency = end - start;
        const latencySec = (latency / 1000).toFixed(4); // 4 decimal precision

        // 3. Determine Status
        let icon = theme.slow;
        let condition = "High Latency";
        
        if (latency < 100) { 
            icon = theme.fast; 
            condition = "Excellent";
        } else if (latency < 300) { 
            icon = theme.good; 
            condition = "Stable"; 
        }

        // 4. Build V3 Dashboard
        const botName = settings.botName || 'SEPTORCH';
        
        let text = `
┏━━━━━━━━━━━━━━━━━━━┓
┃   *${botName.toUpperCase()} V3 SPEED* ┗━━━━━━━━━━━━━━━━━━━┛
${theme.div}

*${theme.sys} NETWORK ANALYTICS*
\`\`\`├ ${theme.time} Latency: ${latency}ms
├ ${theme.ping} Response: ${latencySec} s
└ ${icon} Status: ${condition}\`\`\`

_${settings.footer || 'Powered by Septorch Intelligence'}_
`;

        // 5. Edit Message with Result
        await sock.sendMessage(chatId, {
            text: text,
            edit: tmpMsg.key, // Updates the "Analyzing..." message
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363387922693296@newsletter',
                    newsletterName: 'SEPTORCH NETWORK',
                    serverMessageId: -1
                }
            }
        });

    } catch (e) {
        console.error('Ping Error:', e);
        await sock.sendMessage(chatId, { text: '❌ *Error:* Network timeout.' });
    }
}

module.exports = pingCommand;