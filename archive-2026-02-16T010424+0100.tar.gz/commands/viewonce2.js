// commands/viewonce.js
// Silent universal media extractor → sends branded media to self with channelInfo

const fs = require('fs');
const path = require('path');

// 🔴 REMOVED: Top-level require for Baileys
// const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ✅ Unified channel info for all messages
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH',
            serverMessageId: -1
        }
    }
};

async function viewOnceCommand(sock, chatId, message) {
    try {
        // 🟢 v7 FIX: Dynamic Import
        const { downloadContentFromMessage } = await import('@whiskeysockets/baileys');

        // Get bot's own JID (strip device suffix)
        const ownNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';

        let msg = message.message;

        // Unwrap ViewOnce messages (v1 or v2)
        if (msg?.viewOnceMessage?.message) {
            msg = msg.viewOnceMessage.message;
        } else if (msg?.viewOnceMessageV2?.message) {
            msg = msg.viewOnceMessageV2.message;
        }

        // Handle quoted message (reply)
        else if (msg?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quoted = msg.extendedTextMessage.contextInfo.quotedMessage;

            if (quoted?.viewOnceMessage?.message) {
                msg = quoted.viewOnceMessage.message;
            } else if (quoted?.viewOnceMessageV2?.message) {
                msg = quoted.viewOnceMessageV2.message;
            } else {
                msg = quoted;
            }
        }

        if (!msg || typeof msg !== 'object') return;

        // Detect media
        const media =
            msg.imageMessage ||
            msg.videoMessage ||
            msg.documentMessage ||
            msg.audioMessage ||
            msg.stickerMessage;

        if (!media) return; // No media → silent exit

        const isAudio = !!msg.audioMessage;
        const isImage = !!msg.imageMessage;
        const isVideo = !!msg.videoMessage && !media.gifPlayback;
        const isGif = !!(msg.videoMessage && (media.gifPlayback || media.mimetype?.includes('gif')));
        const isDocument = !!msg.documentMessage;
        const isSticker = !!msg.stickerMessage;

        const caption = media.caption || media.fileName || '';
        const fileName = media.fileName || `media_${Date.now()}`;

        // Ensure temp directory
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);

        // Download helper
        const downloadMedia = async (type) => {
            const stream = await downloadContentFromMessage(media, type);
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            return buffer;
        };

        // Branding header
        const header = '*💀 SEPTORCH ANTIVIEWONCE 💀*';

        // Determine type label and send
        if (isImage) {
            const buffer = await downloadMedia('image');
            await sock.sendMessage(
                ownNumber,
                {
                    image: buffer,
                    caption: `${header}\n\n*Type:* 📸 Image${caption ? `\n\n📝 Caption: ${caption}` : ''}`,
                    ...channelInfo
                }
            );
        }

        else if (isGif) {
            const buffer = await downloadMedia('video');
            await sock.sendMessage(
                ownNumber,
                {
                    video: buffer,
                    gifPlayback: true,
                    caption: `${header}\n\n*Type:* 🔁 GIF Animation${caption ? `\n\n📝 Caption: ${caption}` : ''}`,
                    ...channelInfo
                }
            );
        }

        else if (isVideo) {
            const buffer = await downloadMedia('video');
            await sock.sendMessage(
                ownNumber,
                {
                    video: buffer,
                    caption: `${header}\n\n*Type:* 🎥 Video${caption ? `\n\n📝 Caption: ${caption}` : ''}`,
                    ...channelInfo
                }
            );
        }

        else if (isAudio) {
            const buffer = await downloadMedia('audio');
            const isVoice = media.ptt || false;
            await sock.sendMessage(
                ownNumber,
                {
                    audio: buffer,
                    mimetype: media.mimetype,
                    caption: `${header}\n\n*Type:* ${isVoice ? '🔊 Voice Message' : '🎵 Audio File'}`,
                    ...channelInfo
                }
            );
        }

        else if (isDocument) {
            const buffer = await downloadMedia('document');
            await sock.sendMessage(
                ownNumber,
                {
                    document: buffer,
                    mimetype: media.mimetype,
                    fileName: fileName,
                    caption: `${header}\n\n*Type:* 📎 Document\n*Name:* ${fileName}${caption ? `\n\n📝 Caption: ${caption}` : ''}`,
                    ...channelInfo
                }
            );
        }

        else if (isSticker) {
            const buffer = await downloadMedia('sticker');
            await sock.sendMessage(
                ownNumber,
                {
                    image: buffer,
                    caption: `${header}\n\n*Type:* 🪄 Sticker (extracted as image)`,
                    ...channelInfo
                }
            );
        }

        console.log('📤 Branded media silently saved to SEPTORCH ANTIVIEWONCE.');

    } catch (error) {
        console.error('❌ Failed to process media (silent):', error.message);
        // Still silent — no message to user
    }
}

module.exports = viewOnceCommand;