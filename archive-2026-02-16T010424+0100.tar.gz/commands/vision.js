// 🔴 REMOVED: Top-level require
// const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

const axios = require('axios');
require('dotenv').config();

// ==========================================
// 🛠️ IMAGE DOWNLOADER HELPER
// ==========================================
const downloadImage = async (message, quoted) => {
    // 🟢 v7 FIX: Dynamic Import
    const { downloadContentFromMessage } = await import('@whiskeysockets/baileys');

    let msg = message.message?.imageMessage;
    
    // Check quoted message if direct image is missing
    if (!msg && quoted && quoted.imageMessage) {
        msg = quoted.imageMessage;
    }
    // Check ViewOnce messages
    if (!msg && message.message?.viewOnceMessageV2?.message?.imageMessage) {
        msg = message.message.viewOnceMessageV2.message.imageMessage;
    }
    if (!msg && quoted?.viewOnceMessageV2?.message?.imageMessage) {
        msg = quoted.viewOnceMessageV2.message.imageMessage;
    }

    if (!msg) throw new Error("No image found. Please reply to an image.");

    const stream = await downloadContentFromMessage(msg, 'image');
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
};

// ==========================================
// 👁️ MAIN VISION COMMAND
// ==========================================
const visionCommand = async (sock, chatId, message, prompt, botId) => {
    try {
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const userPrompt = prompt || "Describe this image in detail.";

        // 1. Download Image
        let imageBuffer;
        try {
            imageBuffer = await downloadImage(message, quoted);
        } catch (e) {
            await sock.sendMessage(chatId, { text: '❌ Please reply to an image with .vision' });
            return;
        }

        await sock.sendMessage(chatId, { text: '👀 _Analyzing image..._' });

        // 2. Check API Key
        if (!process.env.GROQ_API_KEY) throw new Error('GROQ_API_KEY missing in .env');

        // 3. Convert to Base64
        const base64Image = imageBuffer.toString('base64');

        // 4. Call Groq Vision API (Llama 4 Scout)
        const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
            model: 'meta-llama/llama-4-scout-17b-16e-instruct', // ✅ High-performance Vision Model
            messages: [
                {
                    role: 'user',
                    content: [
                        { 
                            type: 'text', 
                            text: userPrompt 
                        },
                        { 
                            type: 'image_url', 
                            image_url: { 
                                url: `data:image/jpeg;base64,${base64Image}` 
                            } 
                        }
                    ]
                }
            ],
            temperature: 0.5,
            max_tokens: 1024
        }, {
            headers: {
                'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
                'Content-Type': 'application/json'
            }
        });

        // 5. Extract Answer
        const description = response.data.choices[0].message.content;

        // 6. Reply
        await sock.sendMessage(chatId, { text: `👁️ *Vision Analysis:*\n\n${description}` }, { quoted: message });

    } catch (error) {
        console.error('Vision Error:', error.response?.data || error.message);
        
        let msg = '❌ Failed to analyze image.';
        if (error.response?.status === 400) msg = '❌ Error: Image too large or unsupported format.';
        if (error.response?.status === 401) msg = '❌ Error: Invalid GROQ_API_KEY.';
        
        await sock.sendMessage(chatId, { text: msg });
    }
};

module.exports = visionCommand;