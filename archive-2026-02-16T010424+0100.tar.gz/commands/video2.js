/*Créditos A Quien Correspondan 
Video Command Created and Edited 
Por Cuervo-Team-Supreme*/

const axios = require('axios');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

// Load environment variables
require('dotenv').config();

// 🔴 OPTIMIZATION: Heavy libraries moved inside the handler to speed up boot
// const yts = require('yt-search');
// const ytdl = require('@distube/ytdl-core');
// const youtubedl = require('youtube-dl-exec');
// const ffmpeg = require('fluent-ffmpeg');

const savetube = {
   api: {
      base: "https://media.savetube.me/api",
      cdn: "/random-cdn",
      info: "/v2/info",
      download: "/download"
   },
   headers: {
      'accept': '*/*',
      'content-type': 'application/json',
      'origin': 'https://yt.savetube.me',
      'referer': 'https://yt.savetube.me/',
      'user-agent': 'Postify/1.0.0'
   },
   formats: ['144', '240', '360', '480', '720', '1080'],
   crypto: {
      hexToBuffer: (hexString) => {
         const matches = hexString.match(/.{1,2}/g);
         return Buffer.from(matches.join(''), 'hex');
      },
      decrypt: async (enc) => {
         try {
            const secretKey = process.env.SAVETUBE_KEY || 'C5D58EF67A7584E4A29F6C35BBC4EB12';
            const data = Buffer.from(enc, 'base64');
            const iv = data.slice(0, 16);
            const content = data.slice(16);
            const key = savetube.crypto.hexToBuffer(secretKey);
            const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
            let decrypted = decipher.update(content);
            decrypted = Buffer.concat([decrypted, decipher.final()]);
            return JSON.parse(decrypted.toString());
         } catch (error) {
            throw new Error(`Decryption failed: ${error.message}`);
         }
      }
   },
   youtube: url => {
      if (!url) return null;
      const a = [
         /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
         /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
         /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
         /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
         /youtu\.be\/([a-zA-Z0-9_-]{11})/
      ];
      for (let b of a) {
         if (b.test(url)) return url.match(b)[1];
      }
      return null;
   },
   request: async (endpoint, data = {}, method = 'post') => {
      try {
         const { data: response } = await axios({
            method,
            url: `${endpoint.startsWith('http') ? '' : savetube.api.base}${endpoint}`,
            data: method === 'post' ? data : undefined,
            params: method === 'get' ? data : undefined,
            headers: savetube.headers
         });
         return {
            status: true,
            code: 200,
            data: response
         };
      } catch (error) {
         throw new Error(`API request failed: ${error.message}`);
      }
   },
   getCDN: async () => {
      const response = await savetube.request(savetube.api.cdn, {}, 'get');
      if (!response.status) throw new Error(response);
      return {
         status: true,
         code: 200,
         data: response.data.cdn
      };
   },
   download: async (link, format, retries = 3) => {
      if (!link) {
         return {
            status: false,
            code: 400,
            error: "No link provided. Please provide a valid YouTube link."
         };
      }
      if (!format || !savetube.formats.includes(format)) {
         return {
            status: false,
            code: 400,
            error: "Invalid format. Please choose one of the available formats: 144, 240, 360, 480, 720, 1080.",
            available_fmt: savetube.formats
         };
      }
      const id = savetube.youtube(link);
      if (!id) throw new Error('Invalid YouTube link.');
      try {
         const cdnx = await savetube.getCDN();
         if (!cdnx.status) return cdnx;
         const cdn = cdnx.data;
         const result = await savetube.request(`https://${cdn}${savetube.api.info}`, {
            url: `https://www.youtube.com/watch?v=${id}`
         });
         if (!result.status) return result;
         const decrypted = await savetube.crypto.decrypt(result.data.data);
         let dl;
         for (let attempt = 1; attempt <= retries; attempt++) {
            try {
               dl = await savetube.request(`https://${cdn}${savetube.api.download}`, {
                  id: id,
                  downloadType: 'video',
                  quality: format,
                  key: decrypted.key
               });
               if (dl.data.data.downloadUrl) break;
               if (attempt === retries) throw new Error('No valid download URL after retries.');
            } catch (error) {
               if (attempt === retries) throw new Error(`Failed to get download link after ${retries} attempts: ${error.message}`);
            }
         }
         return {
            status: true,
            code: 200,
            result: {
               title: decrypted.title || "Unknown Title",
               type: 'video',
               format: format,
               thumbnail: decrypted.thumbnail || `https://i.ytimg.com/vi/${id}/0.jpg`,
               download: dl.data.data.downloadUrl,
               id: id,
               key: decrypted.key,
               duration: decrypted.duration,
               quality: format,
               downloaded: dl.data.data.downloaded
            }
         };
      } catch (error) {
         throw new Error(`Download processing failed: ${error.message}`);
      }
   }
};

async function videoCommand(sock, chatId, message) {
    // 🟢 OPTIMIZED: Lazy Load Heavy Libraries
    const yts = require('yt-search');
    const ytdl = require('@distube/ytdl-core');
    const youtubedl = require('youtube-dl-exec');
    const ffmpeg = require('fluent-ffmpeg');

   try {
      const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
      if (!text) {
         return await sock.sendMessage(chatId, { text: "Please provide a video name or YouTube link." });
      }

      // Parse quality from the command
      let quality = '720'; // Default quality
      let searchQuery = text.split(' ').slice(1).join(' ').trim();

      // Extract quality if provided
      const qualityMatch = searchQuery.match(/quality:(\w+)/);
      if (qualityMatch) {
         quality = qualityMatch[1];
         searchQuery = searchQuery.replace(/quality:\w+/, '').trim();
      }

      // Validate quality
      const supportedQualities = ['144', '240', '360', '480', '720', '1080'];
      if (!supportedQualities.includes(quality)) {
         return await sock.sendMessage(chatId, {
            text: `Invalid quality. Please choose one of: ${supportedQualities.join(', ')}.`
         });
      }

      // Determine if input is a YouTube link or search query
      let videoUrl = '';
      let videoTitle = 'Unknown Title';
      let videoThumbnail = '';
      if (searchQuery.startsWith('http://') || searchQuery.startsWith('https://')) {
         videoUrl = searchQuery;
         try {
            const cookies = fs.existsSync('cookies.json') ? JSON.parse(fs.readFileSync('cookies.json')) : [];
            const agent = cookies.length ? ytdl.createAgent(cookies) : undefined;
            const info = await ytdl.getInfo(videoUrl, { agent });
            videoTitle = info.videoDetails.title;
            videoThumbnail = info.videoDetails.thumbnails[0]?.url || `https://i.ytimg.com/vi/${savetube.youtube(videoUrl)}/0.jpg`;
            const duration = parseInt(info.videoDetails.lengthSeconds);
            if (duration > 300) { // 5 minutes
               return await sock.sendMessage(chatId, { text: "Video is too long (>5 minutes). Try a shorter video or lower quality." });
            }
         } catch (e) {
            console.error(`Failed to get video info for ${videoUrl}: ${e.message}`);
         }
      } else {
         // Search YouTube for the video
         const { videos } = await yts(searchQuery);
         if (!videos || videos.length === 0) {
            return await sock.sendMessage(chatId, { text: "No videos found! Try a different query." });
         }
         // Filter out live streams, Shorts, and prefer videos with audio
         const suitableVideo = videos.find(v => 
            !v.live && 
            !v.url.includes('/shorts/') && 
            v.duration.seconds > 30 && 
            v.duration.seconds <= 300 && // 5 minutes max
            (v.title.toLowerCase().includes('official') || v.title.toLowerCase().includes('video') || v.title.toLowerCase().includes('music'))
         );
         if (!suitableVideo) {
            return await sock.sendMessage(chatId, { text: "No suitable videos found (must be 30s-5min). Try a direct YouTube link or different query." });
         }
         videoUrl = suitableVideo.url;
         videoTitle = suitableVideo.title;
         videoThumbnail = suitableVideo.thumbnail;
         console.log(`Selected video: ${videoTitle} (${videoUrl})`);
      }

      // Download with fallback qualities
      let result;
      let tempFile;
      let outputFile;
      const tempDir = path.join(__dirname, '../temp');
      if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
      const fileExtension = 'mp4';
      tempFile = path.join(tempDir, `${Date.now()}_raw.${fileExtension}`);
      outputFile = path.join(tempDir, `${Date.now()}_processed.${fileExtension}`);

      const qualitiesToTry = [quality, '480', '360'];
      let downloadSuccess = false;
      let lastError = null;

      for (const tryQuality of qualitiesToTry) {
         console.log(`Attempting download with quality: ${tryQuality}p`);
         
         // Try savetube
         try {
            result = await savetube.download(videoUrl, tryQuality);
            if (!result || !result.status || !result.result || !result.result.download) {
               throw new Error("Invalid API response");
            }

            // Download the file
            const response = await axios({
               url: result.result.download,
               method: 'GET',
               responseType: 'stream',
               timeout: 120000
            });
            if (response.status !== 200) {
               throw new Error(`Download failed: Status ${response.status}`);
            }

            const writer = fs.createWriteStream(tempFile);
            response.data.pipe(writer);
            await new Promise((resolve, reject) => {
               writer.on('finish', resolve);
               writer.on('error', reject);
            });

            // Check file size
            const stats = fs.statSync(tempFile);
            if (stats.size < 100000) {
               throw new Error(`File too small (${stats.size} bytes)`);
            }

            // Validate video stream
            const metadata = await new Promise((resolve, reject) => {
               ffmpeg.ffprobe(tempFile, (err, metadata) => {
                  if (err) reject(new Error(`ffprobe failed: ${err.message}`));
                  else resolve(metadata);
               });
            });
            const hasVideo = metadata.streams.some(s => s.codec_type === 'video');
            const hasAudio = metadata.streams.some(s => s.codec_type === 'audio');
            console.log(`Savetube file codecs: Video=${hasVideo ? metadata.streams.find(s => s.codec_type === 'video').codec_name : 'None'}, Audio=${hasAudio ? metadata.streams.find(s => s.codec_type === 'audio').codec_name : 'None'}`);
            if (!hasVideo) {
               throw new Error('No video stream found');
            }

            downloadSuccess = true;
            break;
         } catch (error) {
            console.error(`Savetube failed for ${videoUrl} at ${tryQuality}p: ${error.message}`);
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            lastError = error;

            // Fallback to @distube/ytdl-core
            console.log(`Falling back to @distube/ytdl-core for ${videoUrl} at ${tryQuality}p`);
            try {
               const cookies = fs.existsSync('cookies.json') ? JSON.parse(fs.readFileSync('cookies.json')) : [];
               const agent = cookies.length ? ytdl.createAgent(cookies) : undefined;
               const info = await ytdl.getInfo(videoUrl, { agent });
               videoTitle = info.videoDetails.title;
               videoThumbnail = info.videoDetails.thumbnails[0]?.url || `https://i.ytimg.com/vi/${savetube.youtube(videoUrl)}/0.jpg`;
               const stream = ytdl(videoUrl, { 
                  filter: format => format.container === 'mp4' && format.qualityLabel === `${tryQuality}p`, 
                  agent 
               });
               const writer = fs.createWriteStream(tempFile);
               stream.pipe(writer);
               await new Promise((resolve, reject) => {
                  writer.on('finish', resolve);
                  writer.on('error', reject);
               });

               // Check file size
               const stats = fs.statSync(tempFile);
               if (stats.size < 100000) {
                  throw new Error(`@distube/ytdl-core file too small (${stats.size} bytes)`);
               }

               // Validate video stream
               const metadata = await new Promise((resolve, reject) => {
                  ffmpeg.ffprobe(tempFile, (err, metadata) => {
                     if (err) reject(new Error(`ffprobe failed: ${err.message}`));
                     else resolve(metadata);
                  });
               });
               const hasVideo = metadata.streams.some(s => s.codec_type === 'video');
               const hasAudio = metadata.streams.some(s => s.codec_type === 'audio');
               console.log(`ytdl-core file codecs: Video=${hasVideo ? metadata.streams.find(s => s.codec_type === 'video').codec_name : 'None'}, Audio=${hasAudio ? metadata.streams.find(s => s.codec_type === 'audio').codec_name : 'None'}`);
               if (!hasVideo) {
                  throw new Error('No video stream found');
               }

               downloadSuccess = true;
               break;
            } catch (ytdlError) {
               console.error(`@distube/ytdl-core failed for ${videoUrl} at ${tryQuality}p: ${ytdlError.message}`);
               if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
               lastError = ytdlError;

               // Fallback to youtube-dl-exec
               console.log(`Falling back to youtube-dl-exec for ${videoUrl} at ${tryQuality}p`);
               try {
                  const cookies = fs.existsSync('cookies.txt') ? 'cookies.txt' : undefined;
                  await youtubedl(videoUrl, {
                     format: `bestvideo[height<=${tryQuality}][ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best`,
                     output: tempFile,
                     quiet: true,
                     cookie: cookies
                  });

                  // Check file size
                  const stats = fs.statSync(tempFile);
                  if (stats.size < 100000) {
                     throw new Error(`Youtube-dl-exec file too small (${stats.size} bytes)`);
                  }

                  // Validate video stream
                  const metadata = await new Promise((resolve, reject) => {
                     ffmpeg.ffprobe(tempFile, (err, metadata) => {
                        if (err) reject(new Error(`ffprobe failed: ${err.message}`));
                        else resolve(metadata);
                     });
                  });
                  const hasVideo = metadata.streams.some(s => s.codec_type === 'video');
                  const hasAudio = metadata.streams.some(s => s.codec_type === 'audio');
                  console.log(`youtube-dl-exec file codecs: Video=${hasVideo ? metadata.streams.find(s => s.codec_type === 'video').codec_name : 'None'}, Audio=${hasAudio ? metadata.streams.find(s => s.codec_type === 'audio').codec_name : 'None'}`);
                  if (!hasVideo) {
                     throw new Error('No video stream found');
                  }

                  downloadSuccess = true;
                  break;
               } catch (ytdlExecError) {
                  console.error(`Youtube-dl-exec failed for ${videoUrl} at ${tryQuality}p: ${ytdlExecError.message}`);
                  if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
                  lastError = ytdlExecError;
               }
            }
         }
      }

      if (!downloadSuccess) {
         return await sock.sendMessage(chatId, {
            text: `Download failed for all methods: ${lastError.message}. Try a different video or link.`
         });
      }

      // Re-encode video to ensure WhatsApp compatibility
      try {
         const metadata = await new Promise((resolve, reject) => {
            ffmpeg.ffprobe(tempFile, (err, metadata) => {
               if (err) reject(new Error(`ffprobe failed: ${err.message}`));
               else resolve(metadata);
            });
         });
         const hasAudio = metadata.streams.some(s => s.codec_type === 'audio');
         const duration = metadata.format.duration || 60;
         console.log(`Raw file duration: ${duration}s, Size: ${fs.statSync(tempFile).size} bytes`);

         // Re-encode with or without silent audio
         await new Promise((resolve, reject) => {
            const ffmpegCmd = ffmpeg(tempFile)
               .videoCodec('libx264')
               .outputOptions([
                  '-preset medium', // Better compression
                  '-movflags +faststart',
                  '-max_muxing_queue_size 1024'
               ]);
            if (hasAudio) {
               ffmpegCmd.audioCodec('aac');
            } else {
               console.log('No audio stream detected. Adding silent audio...');
               ffmpegCmd.input('anullsrc=channel_layout=stereo:sample_rate=44100')
                  .inputOptions(['-f lavfi'])
                  .outputOptions(['-shortest']);
            }
            ffmpegCmd
               .output(outputFile)
               .on('end', resolve)
               .on('error', err => reject(new Error(`Re-encoding failed: ${err.message}`)))
               .run();
         });

         // Verify re-encoded file
         let stats = fs.statSync(outputFile);
         console.log(`Re-encoded file size: ${stats.size} bytes`);
         if (stats.size < 100000) {
            throw new Error(`Re-encoded file too small (${stats.size} bytes)`);
         }
         if (stats.size > 16000000) {
            console.warn(`File size (${stats.size} bytes) exceeds WhatsApp video limit. Attempting aggressive compression...`);
            const compressedFile = path.join(tempDir, `${Date.now()}_compressed.${fileExtension}`);
            await new Promise((resolve, reject) => {
               ffmpeg(outputFile)
                  .videoCodec('libx264')
                  .audioCodec('aac')
                  .videoBitrate('500k') // Lower bitrate
                  .outputOptions([
                     '-preset medium',
                     '-movflags +faststart',
                     '-max_muxing_queue_size 1024'
                  ])
                  .output(compressedFile)
                  .on('end', resolve)
                  .on('error', err => reject(new Error(`Compression failed: ${err.message}`)))
                  .run();
            });
            fs.unlinkSync(outputFile);
            outputFile = compressedFile;
            stats = fs.statSync(outputFile);
            console.log(`Compressed file size: ${stats.size} bytes`);
            if (stats.size > 16000000) {
               console.warn(`Compressed file still too large (${stats.size} bytes). Sending as document...`);
               // Send as document (up to 100MB)
               const sendOptions = {
                  document: { url: outputFile },
                  mimetype: 'video/mp4',
                  fileName: `${videoTitle}.mp4`
               };
               try {
                  await sock.sendMessage(chatId, sendOptions, { quoted: message });
                  await sock.sendMessage(chatId, { text: "Video sent as a document due to size limit. Download and play it from there." });
               } catch (error) {
                  console.error(`Document send failed for ${outputFile}: ${error.message}`);
                  throw new Error(`Failed to send as document: ${error.message}. Try a lower quality (e.g., 360p) or shorter video.`);
               }
            }
         }

         // Final validation
         await new Promise((resolve, reject) => {
            ffmpeg.ffprobe(outputFile, (err, metadata) => {
               if (err) reject(new Error(`ffprobe failed on re-encoded file: ${err.message}`));
               const hasVideo = metadata.streams.some(s => s.codec_type === 'video' && s.codec_name === 'h264');
               const hasAudio = metadata.streams.some(s => s.codec_type === 'audio' && s.codec_name === 'aac');
               console.log(`Re-encoded file codecs: Video=${hasVideo ? 'H.264' : 'Other'}, Audio=${hasAudio ? 'AAC' : 'Other'}`);
               if (!hasVideo || !hasAudio) reject(new Error('Re-encoded file lacks H.264 video or AAC audio'));
               else resolve();
            });
         });
      } catch (error) {
         console.error(`Re-encoding failed for ${tempFile}: ${error.message}`);
         if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
         if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
         return await sock.sendMessage(chatId, { text: `Failed to process video: ${error.message}. Try a lower quality (e.g., 360p) or shorter video.` });
      }

      // Send thumbnail
      try {
         await sock.sendMessage(chatId, {
            image: { url: videoThumbnail },
            caption: `*${videoTitle}*\n\n> _Downloading your ${quality}p video..._\n > *_By SEPTORCH`
         }, { quoted: message });
      } catch (e) {
         console.error(`Thumbnail send failed: ${e.message}`);
      }

      // Send the file as video if under 16MB
      if (fs.statSync(outputFile).size <= 16000000) {
         const sendOptions = {
            video: { url: outputFile },
            mimetype: 'video/mp4',
            fileName: `${videoTitle}.mp4`
         };
         try {
            await sock.sendMessage(chatId, sendOptions, { quoted: message });
         } catch (error) {
            console.error(`Video send failed for ${outputFile}: ${error.message}`);
            // Fallback to document
            const sendOptions = {
               document: { url: outputFile },
               mimetype: 'video/mp4',
               fileName: `${videoTitle}.mp4`
            };
            try {
               await sock.sendMessage(chatId, sendOptions, { quoted: message });
               await sock.sendMessage(chatId, { text: "Video sent as a document due to sending issues. Download and play it from there." });
            } catch (error) {
               console.error(`Document send failed for ${outputFile}: ${error.message}`);
               return await sock.sendMessage(chatId, { text: `Failed to send the file: ${error.message}. Try a lower quality (e.g., 360p) or shorter video.` });
            }
         }
      }

      // Clean up temp files
      setTimeout(() => {
         try {
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
         } catch {}
      }, 15000); // 15 seconds
   } catch (error) {
      console.error(`General error for ${text}: ${error.message}`);
      await sock.sendMessage(chatId, { text: `Download failed: ${error.message}. Try a lower quality (e.g., 360p) or shorter video.` });
   }
}

module.exports = videoCommand;