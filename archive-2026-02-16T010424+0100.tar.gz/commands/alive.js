const settings = require("../settings");
const process = require('process');
const os = require('os');

// =========================================
// 🎨 PROFESSIONAL THEME (V3)
// =========================================
const theme = {
    div: '━━━━━━━━━━━━━━━━━━━━',
    
    // Icons
    system: '🖥️',   ram: '📟',    time: '⏳',
    ping: '⚡',     os: '💿',     bot: '🤖',
    user: '👤',     date: '📅'
};

// Helper: Format Uptime
const formatRuntime = (seconds) => {
    seconds = Number(seconds);
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor(seconds % (3600 * 24) / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    return `${d}d ${h}h ${m}m ${s}s`;
};

// Helper: Get RAM Usage
const getRam = () => {
    const total = (os.totalmem() / 1024 / 1024).toFixed(0);
    const free = (os.freemem() / 1024 / 1024).toFixed(0);
    const used = total - free;
    return `${used}MB / ${total}MB`;
};

// =========================================
// 🚀 COMMAND HANDLER
// =========================================
async function aliveCommand(sock, chatId, botId) {
    try {
        const botName = settings.botName || 'SEPTORCH';
        const uptime = formatRuntime(process.uptime());
        const platform = os.platform() === 'win32' ? 'Windows' : 'Linux';
        const ram = getRam();
        
        // Date & Time
        const date = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
        const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

        // 🟢 BUILD V3 DASHBOARD
        let text = `
┏━━━━━━━━━━━━━━━━━━━┓
┃   *${botName.toUpperCase()} V3 SYSTEM* ┗━━━━━━━━━━━━━━━━━━━┛
${theme.date} *Date:* ${date}
${theme.time} *Time:* ${time}
${theme.div}

*${theme.system} SYSTEM STATUS*
\`\`\`├ ${theme.time} Uptime: ${uptime}
├ ${theme.ram} RAM: ${ram}
├ ${theme.os} Host: ${platform}
└ ${theme.ping} Status: Operational\`\`\`

_${settings.footer || 'Powered by Septorch Intelligence'}_
`;

        // Send Message
        await sock.sendMessage(chatId, {
            text: text,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363387922693296@newsletter',
                    newsletterName: 'SEPTORCH NETWORK',
                    serverMessageId: -1
                }
            }
        });

    } catch (error) {
        console.error('Error in alive command:', error);
        await sock.sendMessage(chatId, { text: '✅ System Online.' });
    }
}

module.exports = aliveCommand;