// commands/owner.js
const fs = require('fs');
const path = require('path');

const settingsPath = path.resolve(__dirname, '../settings');
let settings = require(settingsPath);

// 🔄 Watch for changes in settings.js and reload automatically
fs.watch(settingsPath + '.js', (eventType) => {
    if (eventType === 'change') {
        try {
            delete require.cache[require.resolve(settingsPath)];
            settings = require(settingsPath);
            console.log('♻️ settings.js reloaded automatically');
        } catch (err) {
            console.error('❌ Failed to reload settings.js:', err);
        }
    }
});

async function ownerCommand(sock, chatId) {
    try {
        // 🟢 1. DYNAMIC SELF-IDENTIFICATION
        // Instead of relying on arguments, we extract the ID from the active socket connection.
        // sock.user.id format: "2348012345678:5@s.whatsapp.net" -> "2348012345678"
        const currentBotNumber = sock.user.id.split(':')[0].split('@')[0];
        const currentBotId = `bot_${currentBotNumber}`;

        // 🟢 2. ROBUST CONFIG LOOKUP
        // Find the bot config where:
        // A. The botId matches 'bot_NUMBER' (The new standard)
        // B. OR the ownerNumber matches the connected number (Fallback)
        let botConfig = settings.bots.find(b => 
            (b.botId === currentBotId) || 
            (b.ownerNumber && b.ownerNumber.replace(/\D/g, '') === currentBotNumber)
        );

        // 3. Fallback for Legacy Configs (if botId is missing in settings)
        if (!botConfig && settings.bots.length > 0) {
            // If we can't find a specific match, check if this is a single-bot setup
            if (settings.bots.length === 1) {
                botConfig = settings.bots[0];
            }
        }

        if (!botConfig) {
            console.error(`❌ Owner Command Error: Configuration not found for ${currentBotId}`);
            await sock.sendMessage(chatId, { 
                text: '❌ Bot configuration error. Owner info unavailable.' 
            });
            return;
        }

        const ownerNumber = botConfig.ownerNumber?.trim();
        const botName = botConfig.botName || 'Septorch Bot';

        // Validate owner number
        if (!ownerNumber) {
            await sock.sendMessage(chatId, {
                text: `ℹ️ No owner number set for *${botName}*`
            });
            return;
        }

        // Clean number for WhatsApp ID (Remove '+' or spaces)
        const cleanNumber = ownerNumber.replace(/\D/g, '');
        
        if (!cleanNumber) {
            await sock.sendMessage(chatId, {
                text: '❌ Invalid owner number format in settings.'
            });
            return;
        }

        // 4. Create VCard
        // We use the cleaned number for the 'waid' and the display number for the label
        const vcard = 'BEGIN:VCARD\n' +
                      'VERSION:3.0\n' + 
                      `FN:${botName} Owner\n` + // Full Name
                      `ORG:${botName};\n` + // Organization
                      `TEL;type=CELL;type=VOICE;waid=${cleanNumber}:${ownerNumber}\n` + // WhatsApp ID
                      'END:VCARD';

        // 5. Send Contact
        await sock.sendMessage(chatId, {
            contacts: {
                displayName: `${botName} Owner`,
                contacts: [{ vcard }]
            }
        });

    } catch (error) {
        console.error(`❌ Error in ownerCommand:`, error);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to fetch owner contact.'
        });
    }
}

module.exports = ownerCommand;