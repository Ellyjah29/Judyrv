// ✅ notesAI.js
const axios = require('axios');
const { loadChatHistory, saveNote } = require('./ai_notes');
require('dotenv').config(); // Ensure environment variables are loaded

// --- CONFIGURATION ---
// Use the same configuration as Septorch AI
const GROQ_API_KEY = process.env.GROQ_API_KEY;
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const MODEL_NAME = process.env.GROQ_MODEL || 'llama-3.1-8b-instant'; // Default model from Septorch AI config

async function sendGptQuery(sock, chatId, query, botId, sender) {
    if (!GROQ_API_KEY) {
        await sock.sendMessage(chatId, { text: '❌ *Configuration Error:* GROQ_API_KEY is missing in .env' });
        return;
    }

    if (!query || query.trim().length === 0) {
        await sock.sendMessage(chatId, {
            text: "❌ Please provide a question after .gpt"
        });
        return;
    }

    try {
        await sock.sendPresenceUpdate('composing', chatId);

        const history = await loadChatHistory(botId, chatId);

        // ✅ Always use Nigerian time (WAT)
        const nowDate = new Date().toLocaleString('en-NG', {
            timeZone: 'Africa/Lagos',
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            hour12: true
        });

        // Use a simple system prompt
        const messages = [
            { role: "system", content: `You are a helpful assistant running on the Groq API. Today is ${nowDate}. Keep your responses clear and concise.` },
            ...history,
            { role: "user", content: query } // Removed the time stamp from the user query to keep it clean for the LLM
        ];

        const response = await axios.post(
            GROQ_API_URL,
            {
                model: MODEL_NAME,
                messages: messages,
                max_tokens: 800, // Increased to 800, matching the Septorch AI plugin
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${GROQ_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const result = response.data.choices[0].message.content;

        // Save the AI response to chat history
        await saveNote(sock, chatId, 'bot', result, botId);

        // ✅ Send AI response
        await sock.sendMessage(chatId, { text: result }); // Removed the 'ai: true' which isn't standard WA

    } catch (error) {
        console.error(`[AI ERROR]`, error.message);
        const errorMessage = error.response?.data?.error?.message || error.message;

        if (errorMessage.includes('401')) {
            await sock.sendMessage(chatId, {
                text: '❌ *Configuration Error:* GROQ_API_KEY is invalid.'
            });
        } else {
            await sock.sendMessage(chatId, {
                text: `❌ Failed to get AI response: ${errorMessage.substring(0, 100)}...`
            });
        }
    }
}

module.exports = {
    sendGptQuery
};