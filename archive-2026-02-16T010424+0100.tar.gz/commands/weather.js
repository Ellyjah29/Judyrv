// ./commands/weather.js
const axios = require('axios');
const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');
require('dotenv').config();

const WEATHER_API_KEY = process.env.WEATHER_API_KEY || 'your_openweather_api_key';

// Register font once
registerFont(path.join(__dirname, '../assets/fonts/Poppins-Regular.ttf'), { family: 'Poppins' });
registerFont(path.join(__dirname, '../assets/fonts/Poppins-Bold.ttf'), { family: 'PoppinsBold' });

module.exports = async (sock, chatId, city, botId) => {
    try {
        const normalizedCity = city.trim().toLowerCase();

        const cityMap = {
            'lagos': 'Lagos',
            'abuja': 'Abuja',
            'kano': 'Kano',
            'portharcourt': 'Port Harcourt',
            'ph': 'Port Harcourt'
        };

        let displayCity = cityMap[normalizedCity] || city.trim();

        const response = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
            params: {
                q: displayCity,
                appid: WEATHER_API_KEY,
                units: 'metric'
            }
        });

        const data = response.data;
        const temp = Math.round(data.main.temp);
        const feelsLike = Math.round(data.main.feels_like);
        const humidity = data.main.humidity;
        const description = data.weather[0].description;
        const country = data.sys.country;
        const cityName = data.name;

        if (country !== 'NG') {
            return await sock.sendMessage(chatId, {
                text: `Found ${cityName}, ${country}, but this is not in Nigeria. Please specify a Nigerian city like Lagos, Abuja, or Kano.`
            });
        }

        // Load background image
        const bgPath = path.join(__dirname, '../assets/weather.jpg');
        const image = await loadImage(bgPath);

        const canvas = createCanvas(image.width, image.height);
        const ctx = canvas.getContext('2d');

        // Draw background
        ctx.drawImage(image, 0, 0, image.width, image.height);

        // ========= TITLE (City + Nigeria) =========
        const titleSize = Math.floor(image.height * 0.1); // big title font
        ctx.font = `bold ${titleSize}px "PoppinsBold"`;
        ctx.textAlign = 'center';
        ctx.fillStyle = 'white';
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 8;

        const centerX = image.width / 2;
        let y = image.height * 0.25;

        ctx.strokeText(`${cityName}, Nigeria`, centerX, y);
        ctx.fillText(`${cityName}, Nigeria`, centerX, y);

        // ========= WEATHER DETAILS =========
        const detailSize = Math.floor(image.height * 0.06);
        ctx.font = `${detailSize}px "Poppins"`;
        ctx.lineWidth = 5;

        const details = [
            `Temperature: ${temp}°C (Feels like ${feelsLike}°C)`,
            `Condition: ${description}`,
            `Humidity: ${humidity}%`
        ];

        y += titleSize * 1.5; // space below title

        details.forEach((line, i) => {
            const lineY = y + i * (detailSize * 1.5);
            ctx.strokeText(line, centerX, lineY);
            ctx.fillText(line, centerX, lineY);
        });

        // Send result
        const buffer = canvas.toBuffer('image/jpeg');
        await sock.sendMessage(chatId, {
            image: buffer,
            caption: `Weather update for ${cityName}, Nigeria`
        });

    } catch (error) {
        console.error('Weather command error:', error.message);
        const msg = error.response?.data?.message || error.message;

        if (msg.includes('not found')) {
            await sock.sendMessage(chatId, {
                text: `City "${city}" not found. Try a Nigerian city like: Lagos, Abuja, Kano, Port Harcourt.`
            });
        } else if (msg.includes('API key')) {
            await sock.sendMessage(chatId, {
                text: 'Weather API key is invalid or not set. Contact the bot owner.'
            });
        } else {
            await sock.sendMessage(chatId, {
                text: 'Could not fetch weather data. Try again later.'
            });
        }
    }
};