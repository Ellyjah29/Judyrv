// 🔴 REMOVED: Top-level require for Baileys
// const { downloadMediaMessage } = require('@whiskeysockets/baileys');

const mime = require('mime-types');
const axios = require('axios');
require('dotenv').config();

// ==========================================
// 🧠 AI INTENT CLASSIFIER (PURE AI)
// ==========================================
async function analyzeIntent(text) {
    // 1. Basic Validation: Ignore empty or super short text
    if (!text || text.length < 2) return false;

    try {
        if (!process.env.GROQ_API_KEY) return false;

        const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
            model: 'llama-3.1-8b-instant', // Very fast model
            messages: [
                {
                    role: "system",
                    content: `You are an Intent Classifier.
                    Analyze the user's reply to a WhatsApp Status.
                    
                    Does the user explicitly want to RECEIVE/DOWNLOAD the media file?
                    
                    CRITERIA:
                    - "Send", "Save", "I want this", "Gimme", "Send to my DM" -> YES
                    - "Lmao", "Funny", "Who is this?", "Nice shoes", "Where is this?" -> NO
                    - "😂😂", "🔥", "Wow" -> NO
                    
                    Reply strictly with "YES" or "NO".`
                },
                { role: "user", content: text }
            ],
            temperature: 0, // Strict logic
            max_tokens: 5
        }, {
            headers: { 
                'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
                'Content-Type': 'application/json' 
            }
        });

        const answer = response.data.choices[0].message.content.trim().toUpperCase();
        return answer.includes('YES');

    } catch (e) {
        console.error("AI Intent Check Failed:", e.message);
        return false; // Fail safe: Don't send if AI fails
    }
}

// ==========================================
// 📥 MAIN HANDLER
// ==========================================
async function handleAutoStatusReply(sock, msg, botId) {
    try {
        // 🟢 v7 FIX: Dynamic Import
        const { downloadMediaMessage } = await import('@whiskeysockets/baileys');

        const contextInfo = msg.message?.extendedTextMessage?.contextInfo;

        // 1. Strict Checks: Must be a reply to a Status
        const isStatusReply = contextInfo?.remoteJid === 'status@broadcast';
        if (!isStatusReply || !contextInfo?.stanzaId || !contextInfo?.participant) return;

        // 2. Get User Text
        const text = msg.message?.conversation?.toLowerCase() || 
                     msg.message?.extendedTextMessage?.text?.toLowerCase();

        // 3. 🧠 ASK AI: Is this a genuine request?
        const isRequest = await analyzeIntent(text);

        // If AI says NO, stop immediately.
        if (!isRequest) return;

        // 4. Notify user we are processing
        await sock.sendPresenceUpdate('composing', msg.key.remoteJid);

        // 5. Load Original Status
        let statusMsg;
        try {
            statusMsg = await sock.loadMessage('status@broadcast', contextInfo.stanzaId);
        } catch (err) {
            console.warn('[⚠️] Failed to loadMessage, maybe expired:', err.message);
        }

        const quoted = statusMsg?.message || contextInfo?.quotedMessage;
        if (!quoted) {
            await sock.sendMessage(msg.key.remoteJid, { text: '❌ Status has expired or cannot be loaded.' });
            return;
        }

        const type = Object.keys(quoted)[0];
        const supported = ['imageMessage', 'videoMessage', 'documentMessage'];
        
        if (!supported.includes(type)) return; // Ignore text statuses

        // 6. Download Media
        const stream = await downloadMediaMessage(
            { key: { remoteJid: 'status@broadcast', id: contextInfo.stanzaId, participant: contextInfo.participant }, message: quoted },
            'buffer',
            {},
            { reuploadRequest: sock }
        );

        const ext = mime.extension(quoted[type].mimetype || 'application/octet-stream');

        // 7. Send Media
        await sock.sendMessage(msg.key.remoteJid, {
            [type.replace('Message', '')]: stream,
            mimetype: quoted[type].mimetype,
            fileName: `status.${ext}`,
            caption: '✅ Here is the status you requested.'
        }, { quoted: msg });

    } catch (err) {
        console.error(`[AutoStatusReply] ❌ Error:`, err.message);
    }
}

module.exports = { handleAutoStatusReply };