// =========================================
// 🎨 DESIGN THEME
// =========================================
const icons = {
    book  : '📖',   cross : '✝️',    warn  : '⚠️',   list  : '📝'
};

const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.book} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

/**
 * Handle .bible [reference] command
 */
const bibleCommand = async (sock, chatId, message, botId) => {
    try {
        // 🟢 Dynamic Import for node-fetch
        const { default: fetch } = await import('node-fetch');

        await sock.sendPresenceUpdate("composing", chatId);

        // Normalize input
        const fullText = (typeof message === 'string') ? message : 
                         (message.message?.conversation || message.message?.extendedTextMessage?.text || "");
                         
        const input = fullText.replace(/^\.bible\s*/i, "").trim();

        // 1. INPUT CHECK
        if (!input) {
            return await sock.sendMessage(chatId, {
                text: makeCard("Bible Search", [
                    ` ${icons.warn}  *Missing Reference*`,
                    "---",
                    " Please provide a book & verse.",
                    "",
                    ` ${icons.list}  *Examples:*`,
                    " • .bible John 3:16",
                    " • .bible Psalm 23:1-4"
                ])
            });
        }

        // 2. PARSE ARGUMENTS (Allow hidden translation flag if user really wants it)
        const match = input.match(/(.*?)\s*--trans\s*(\w+)/i);
        const ref = match ? match[1].trim() : input;
        const translation = match ? match[2].trim().toLowerCase() : "kjv";

        const formattedRef = encodeURIComponent(ref.replace(/\s+/g, " "));
        const apiUrl = `https://bible-api.com/${formattedRef}?translation=${translation}`;

        // 3. FETCH DATA
        const response = await fetch(apiUrl);
        const data = await response.json();

        // 4. ERROR HANDLING
        if (!data || !data.verses || data.verses.length === 0 || data.error) {
            return await sock.sendMessage(chatId, {
                text: makeCard("Search Failed", [
                    ` ${icons.warn}  *Verse Not Found*`,
                    "---",
                    ` Query: "${ref}"`,
                    "",
                    " Please check spelling."
                ])
            });
        }

        // 5. FORMAT PROFESSIONAL RESPONSE
        let responseText = `╭─── ${icons.cross} *${data.reference}* ───╮\n`;
        responseText += `│ Ver: ${data.translation_id.toUpperCase()}\n`;
        responseText += `╰──────────────────────╯\n\n`;

        // Format Verses Cleanly
        for (const v of data.verses) {
            responseText += `*${v.verse}.* ${v.text.trim()}\n\n`;
        }

        // 6. SEND
        await sock.sendMessage(chatId, { text: responseText });

    } catch (error) {
        console.error("Bible verse fetch error:", error);
        await sock.sendMessage(chatId, { text: "❌ Error connecting to Bible API." });
    } finally {
        await sock.sendPresenceUpdate("paused", chatId);
    }
};

// 🟢 COMMONJS EXPORT
module.exports = { bibleCommand };