const axios = require('axios');
const yts = require('yt-search');
const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');

// =========================================
// ⚙️ CONFIGURATION
// =========================================
const MAX_VIDEO_BUFFER_MB = 90; // If > 90MB, send as Document
const WEBSITE_URL = "https://septorch.tech"; 
const TEMP_DIR = path.join(__dirname, '../temp');

// Ensure temp directory exists
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

const icons = {
    video : '🎥',   search: '🔎',    time  : '⏱️',
    down  : '⬇️',   file  : '📁',    warn  : '⚠️',
    check : '✅'
};

/**
 * Creates a premium CLI-style card
 */
const makeCard = (v) => {
    return `╭───────────────────────────╮
│  ${icons.video} *SEPTORCH CINEMA*
├───────────────────────────┤
│ 📌 *Title:* ${v.title}
│ ${icons.time} *Duration:* ${v.timestamp || v.duration}
│ ${icons.file} *Views:* ${v.views ? v.views.toLocaleString() : 'N/A'}
├───────────────────────────┤
│ ${icons.down} _Status: Downloading via Cloud API..._
╰───────────────────────────╯`;
};

/**
 * Helper: Download file from a direct URL to a local path
 */
const downloadFile = async (url, outputPath) => {
    const writer = fs.createWriteStream(outputPath);
    const response = await axios({
        url,
        method: 'GET',
        responseType: 'stream',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    });

    response.data.pipe(writer);

    return new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
    });
};

// =========================================
// 🚀 MAIN COMMAND HANDLER
// =========================================
const videoCommand = async (sock, chatId, message) => {
    let tempFilePath = null;

    try {
        const text = message.message?.conversation || 
                     message.message?.extendedTextMessage?.text || 
                     message.message?.imageMessage?.caption || "";
        
        const query = text.replace(/^\.video|^\.ytmp4/i, '').trim();

        if (!query) {
            return await sock.sendMessage(chatId, { text: `❌ *Usage:* .video <Link or Name>` }, { quoted: message });
        }

        // 1. SEARCH / RESOLVE URL
        await sock.sendMessage(chatId, { react: { text: icons.search, key: message.key } });

        let videoUrl = query;
        let videoMeta = {};

        // If it's NOT a link, search for it first
        if (!query.startsWith('http')) {
            const search = await yts(query);
            if (!search.videos.length) throw new Error("Video not found.");
            
            videoUrl = search.videos[0].url;
            videoMeta = search.videos[0];
        }

        // 2. FETCH DOWNLOAD LINK FROM API
        // API: David Cyril (Reliable/Free)
        const apiUrl = `https://apis.davidcyril.name.ng/download/ytmp4?url=${encodeURIComponent(videoUrl)}`;
        const { data } = await axios.get(apiUrl);

        if (!data.status || !data.result) {
            throw new Error("API could not process this video. Try .qvideo for a different server.");
        }

        const result = data.result;
        
        // Normalize Metadata (API usually returns title/thumb)
        const displayMeta = {
            title: result.title || videoMeta.title || "Unknown Video",
            timestamp: result.duration || videoMeta.timestamp || "Unknown",
            views: videoMeta.views || 0,
            thumbnail: result.thumbnail || videoMeta.thumbnail
        };

        // 3. SEND INFO CARD
        if (displayMeta.thumbnail) {
            await sock.sendMessage(chatId, { 
                image: { url: displayMeta.thumbnail }, 
                caption: makeCard(displayMeta) 
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, { text: makeCard(displayMeta) }, { quoted: message });
        }

        // 4. DOWNLOAD THE VIDEO
        const fileName = `septorch_vid_${Date.now()}.mp4`;
        tempFilePath = path.join(TEMP_DIR, fileName);

        await downloadFile(result.download_url, tempFilePath);

        // 5. CHECK SIZE & SEND
        const stats = fs.statSync(tempFilePath);
        const fileSizeMB = stats.size / (1024 * 1024);
        
        await sock.sendMessage(chatId, { react: { text: '⬆️', key: message.key } });

        if (fileSizeMB > MAX_VIDEO_BUFFER_MB) {
            // SEND AS DOCUMENT (If too big)
            await sock.sendMessage(chatId, {
                document: { url: tempFilePath },
                mimetype: 'video/mp4',
                fileName: `${displayMeta.title}.mp4`,
                caption: `*${displayMeta.title}*\n> 📁 Size: ${fileSizeMB.toFixed(1)}MB`,
                contextInfo: { 
                    externalAdReply: { 
                        title: "Septorch File Server", 
                        body: "Large File Transfer", 
                        thumbnailUrl: displayMeta.thumbnail, 
                        mediaType: 1, 
                        sourceUrl: WEBSITE_URL, 
                        renderLargerThumbnail: true 
                    } 
                }
            }, { quoted: message });
        } else {
            // SEND AS VIDEO
            await sock.sendMessage(chatId, {
                video: { url: tempFilePath },
                mimetype: 'video/mp4',
                caption: `*${displayMeta.title}*\n> 🕊 Powered by Septorch Cinema`,
                contextInfo: { 
                    externalAdReply: { 
                        title: displayMeta.title, 
                        body: "Septorch Cinema Engine", 
                        thumbnailUrl: displayMeta.thumbnail, 
                        mediaType: 1, 
                        sourceUrl: WEBSITE_URL, 
                        renderLargerThumbnail: true 
                    } 
                }
            }, { quoted: message });
        }

        await sock.sendMessage(chatId, { react: { text: icons.check, key: message.key } });

    } catch (error) {
        console.error('[VIDEO ERROR]', error);
        await sock.sendMessage(chatId, { text: `❌ *Error:* ${error.message || 'Could not download video.'}` });
    } finally {
        // CLEANUP
        if (tempFilePath && fs.existsSync(tempFilePath)) {
            setTimeout(() => fs.unlinkSync(tempFilePath), 15000); 
        }
    }
};

// 🟢 CRITICAL: This allows main.js 'require' to get the function directly
module.exports = videoCommand;