module.exports = {
    cmd: ['ss', 'screenshot', 'webshot', 'capture'],
    category: 'utility',
    desc: 'Take a screenshot of any website',
    use: '.ss <url>',
    
    handler: async ({ sock, chatId, args, reply }) => {
        let url = args[0];
        
        if (!url) {
            return reply('❌ Please provide a URL.\n*Example:* .ss https://github.com');
        }

        // Add https if missing to prevent errors
        if (!url.startsWith('http')) {
            url = 'https://' + url;
        }

        try {
            await reply(`📸 *Capturing ${url}...*`);

            // 1. Construct API URL
            // width=1200 simulates a desktop screen
            // noanimate=1 ensures we get a static image
            // refresh=1 forces a new capture
            const ssUrl = `https://image.thum.io/get/width/1200/crop/800/noanimate/refresh/${url}`;

            // 2. Send Image directly
            // Thum.io returns the image stream, so we just pass the URL to Baileys
            await sock.sendMessage(chatId, { 
                image: { url: ssUrl }, 
                caption: `📸 *Web Capture*\n🔗 *Site:* ${url}\n\n_Powered by Septorch_`
            });

        } catch (error) {
            console.error('SS Error:', error);
            await reply('❌ Failed to capture screenshot. The site might be blocking bots.');
        }
    }
};