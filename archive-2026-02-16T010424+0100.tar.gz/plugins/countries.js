module.exports = {
    cmd: ['country', 'nation', 'flag'],
    category: 'utility',
    desc: 'Get detailed information about a country',
    use: '.country <name>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import
            const { default: axios } = await import('axios');
            
            // 1. Get Query
            const query = args.join(" ");
            
            if (!query) {
                return reply('❌ Please provide a country name.\n*Example:* .country Nigeria');
            }

            await reply(`🔍 *Fetching data for "${query}"...*`);

            // 2. Fetch Data (RestCountries API)
            // We use 'v3.1/name/{name}?fullText=false' to get partial matches too
            const response = await axios.get(`https://restcountries.com/v3.1/name/${encodeURIComponent(query)}`);
            
            if (!response.data || response.data.length === 0) {
                return reply('❌ Country not found.');
            }

            const data = response.data[0];

            // 3. Safe Data Extraction (Prevents crashes if data is missing)
            
            // Currencies
            let currencyStr = 'N/A';
            if (data.currencies) {
                const currencyKeys = Object.keys(data.currencies);
                const currency = data.currencies[currencyKeys[0]];
                currencyStr = `${currency.name} (${currency.symbol || '$'})`;
            }

            // Languages
            const languages = data.languages ? Object.values(data.languages).join(', ') : 'N/A';

            // Capital
            const capital = data.capital ? data.capital[0] : 'N/A';

            // Population
            const population = data.population ? data.population.toLocaleString() : '0';

            // Driving Side
            const driveSide = data.car && data.car.side ? data.car.side.toUpperCase() : 'RIGHT';

            // 4. Build Message
            const msg = `🌍 *COUNTRY INFO: ${data.name.common.toUpperCase()}*

🏳️ *Official Name:* ${data.name.official}
🏛️ *Capital:* ${capital}
👥 *Population:* ${population}
🗺️ *Region:* ${data.region} (${data.subregion || ''})

💰 *Currency:* ${currencyStr}
🗣️ *Languages:* ${languages}
⏰ *Timezone:* ${data.timezones ? data.timezones[0] : 'UTC'}
🚗 *Driving Side:* ${driveSide}

🔗 *Maps:* ${data.maps.googleMaps}

_Powered by Septorch_`;

            // 5. Send Flag Image with Text
            if (data.flags && data.flags.png) {
                await sock.sendMessage(chatId, { 
                    image: { url: data.flags.png }, 
                    caption: msg 
                }, { quoted: message });
            } else {
                await reply(msg);
            }

        } catch (error) {
            console.error('Country Error:', error.message);
            await reply('❌ Country not found. Check the spelling (e.g., "USA" instead of "America").');
        }
    }
};