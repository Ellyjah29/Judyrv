const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// =========================================
// ⚙️ CONFIGURATION
// =========================================
const MAX_SIZE_MB = 5;
// Absolute Path to your website's folder
const UPLOAD_DIR = '/root/septorch-web-page/uploads'; 
const MY_DOMAIN = 'https://septorch.tech/uploads';

// Ensure the website folder exists
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// =========================================
// 🚀 COMMAND HANDLER
// =========================================
module.exports = {
    cmd: ['url', 'upload', 'tourl'],
    category: 'utility',
    desc: 'Upload to Septorch Server (Max 5MB)',
    
    handler: async ({ sock, chatId, message, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Baileys Utils
            const { downloadContentFromMessage } = await import('@whiskeysockets/baileys');
            const { writeFile } = require('fs').promises;

            // 1. Get Target Message (Quoted or Current)
            const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const target = quotedMsg || message.message;

            // 2. Detect Media Type & Extract Message Content
            let mediaType = '';
            let mediaMsg = null;

            if (target?.imageMessage) {
                mediaType = 'image';
                mediaMsg = target.imageMessage;
            } else if (target?.videoMessage) {
                mediaType = 'video';
                mediaMsg = target.videoMessage;
            } else if (target?.stickerMessage) {
                mediaType = 'sticker';
                mediaMsg = target.stickerMessage;
            } else if (target?.viewOnceMessageV2?.message) {
                const viewOnce = target.viewOnceMessageV2.message;
                mediaType = Object.keys(viewOnce)[0].replace('Message', '');
                mediaMsg = viewOnce[Object.keys(viewOnce)[0]];
            }

            if (!mediaMsg) {
                return reply('❌ Reply to an image, video, or sticker with *.url*');
            }

            await reply('📤 *Uploading to Septorch Cloud...*');

            // 3. Download Buffer
            const stream = await downloadContentFromMessage(mediaMsg, mediaType);
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            
            // 🛑 5MB LIMIT CHECK
            if (buffer.length > (MAX_SIZE_MB * 1024 * 1024)) {
                return reply(`❌ *File too large!*\nLimit is ${MAX_SIZE_MB}MB.`);
            }

            // 4. Generate Unique Filename
            const extMap = { 'image': 'jpg', 'video': 'mp4', 'sticker': 'webp' };
            const ext = extMap[mediaType] || 'bin';
            const filename = `file_${Date.now()}_${crypto.randomBytes(3).toString('hex')}.${ext}`;
            const filePath = path.join(UPLOAD_DIR, filename);

            // 5. Asynchronous Save (Better for v7 Performance)
            await writeFile(filePath, buffer);

            // 6. Send Link with External Ad Reply (Link Preview)
            const fileUrl = `${MY_DOMAIN}/${filename}`;
            
            await sock.sendMessage(chatId, {
                text: `✅ *Upload Complete*\n\n🔗 ${fileUrl}\n\n> 💾 Stored on Septorch Server`,
                contextInfo: {
                    externalAdReply: {
                        title: "☁️ Septorch Cloud",
                        body: `Format: ${ext.toUpperCase()} | Size: ${(buffer.length / 1024).toFixed(1)} KB`,
                        thumbnailUrl: mediaType === 'image' ? fileUrl : null,
                        sourceUrl: fileUrl,
                        mediaType: 1,
                        showAdAttribution: true,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: message });

        } catch (e) {
            console.error('URL Upload Error:', e);
            reply('❌ Server Error: Could not process upload.');
        }
    }
};