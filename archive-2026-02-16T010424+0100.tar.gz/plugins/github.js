module.exports = {
    // 1. Commands
    cmd: ['github', 'gh', 'gituser', 'git'],
    category: 'utility',
    desc: 'Get GitHub user profile details',
    use: '.github <username>',
    
    // 2. Logic
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import
            const { default: axios } = await import('axios');

            let username = args[0];

            if (!username) {
                return reply('❌ Please provide a GitHub username.\n*Example:* .github septorch');
            }

            // Remove '@' if user included it (e.g. @septorch -> septorch)
            username = username.replace('@', '');

            await reply(`🔍 *Fetching profile for "${username}"...*`);

            // 3. Call GitHub API
            const response = await axios.get(`https://api.github.com/users/${username}`);
            const user = response.data;

            // 4. Format Message
            const msg = `🐙 *GITHUB PROFILE*

👤 *Name:* ${user.name || user.login}
🔗 *Username:* @${user.login}
📜 *Bio:* ${user.bio || 'No bio available'}

📦 *Public Repos:* ${user.public_repos}
👥 *Followers:* ${user.followers}
👣 *Following:* ${user.following}
🏢 *Company:* ${user.company || 'None'}
📍 *Location:* ${user.location || 'Unknown'}

🔗 *Link:* ${user.html_url}

_Powered by Septorch_`;

            // 5. Send Image with Caption
            await sock.sendMessage(chatId, {
                image: { url: user.avatar_url },
                caption: msg
            }, { quoted: message }); // 👈 Added quoted reply

        } catch (error) {
            console.error('GitHub Error:', error.message);
            if (error.response && error.response.status === 404) {
                return reply('❌ User not found! Check the username.');
            }
            await reply('❌ Failed to fetch GitHub data. API might be limited.');
        }
    }
};