const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process'); 
require('dotenv').config();

// =======================================================
// 🎨 DESIGN & THEME
// =======================================================
const icons = {
    gear: '⚙️', on: '🟢', off: '🔴', brain: '🧠', robot: '🤖', 
    mic: '🎙️', globe: '🌍', book: '📚', search: '🔍', trash: '🗑️',
    check: '✅', info: 'ℹ️', warn: '⚠️', dot: '◈'
};

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH_AI',
            serverMessageId: -1
        }
    }
};

const makeCard = (title, contentLines) => {
    const divider = '├───────────────────────────┤';
    const header = `│  ${icons.robot} *${title.toUpperCase()}*`;
    const body = contentLines.map(line => line === '---' ? divider : `│ ${line}`).join('\n');
    return `╭───────────────────────────╮\n${header}\n${divider}\n${body}\n╰───────────────────────────╯`;
};

const sendCard = (sock, chatId, title, lines) =>
    sock.sendMessage(chatId, { text: makeCard(title, lines), ...channelInfo });

// =======================================================
// 🛠️ HELPER FUNCTIONS
// =======================================================

const getBotDir = (botId) => {
    const dir = path.join(process.cwd(), 'data', botId);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return dir;
};

const cleanForSpeech = (text) => {
    return text.replace(/\*/g, '').replace(/_/g, '').replace(/`/g, '').replace(/https?:\/\/\S+/g, 'link').trim();
};

const generateVoice = async (text, voiceId) => {
    return new Promise((resolve, reject) => {
        const tempFilePath = path.join(process.cwd(), `voice_${Date.now()}.mp3`);
        const ttsProcess = spawn('edge-tts', ['--text', text, '--voice', voiceId || 'en-NG-AbeoNeural', '--write-media', tempFilePath]);

        ttsProcess.on('close', (code) => {
            if (code !== 0 || !fs.existsSync(tempFilePath)) return reject(new Error("TTS Failed"));
            const audioBuffer = fs.readFileSync(tempFilePath);
            fs.unlinkSync(tempFilePath);
            resolve(audioBuffer);
        });
    });
};

// =======================================================
// 🧠 MEMORY MANAGER
// =======================================================
const manageMemory = (botId, action, chatId, payload = null) => {
    const dir = getBotDir(botId);
    const knowledgePath = path.join(dir, 'septorch_knowledge.json');
    const historyPath = path.join(dir, 'septorch_chat_logs.json');

    const load = (p) => fs.existsSync(p) ? JSON.parse(fs.readFileSync(p)) : {};
    const save = (p, d) => fs.writeFileSync(p, JSON.stringify(d, null, 2));

    let db = load(knowledgePath);
    let chatDb = load(historyPath);

    // Initialize structures
    if (!db.facts) db.facts = [];
    if (!db.config) db.config = { globalAssistant: false };
    if (!chatDb.history) chatDb.history = {};
    if (!chatDb.settings) chatDb.settings = {};

    switch (action) {
        case 'check_global': return db.config.globalAssistant;
        case 'toggle_global': db.config.globalAssistant = payload; save(knowledgePath, db); break;
        case 'learn_fact': db.facts.push(payload); save(knowledgePath, db); break;
        case 'get_knowledge': return db.facts;
        case 'check_enabled': return chatDb.settings[chatId]?.enabled || false;
        case 'toggle': 
            if(!chatDb.settings[chatId]) chatDb.settings[chatId] = {};
            chatDb.settings[chatId].enabled = payload; 
            save(historyPath, chatDb); 
            break;
        case 'history':
            let h = chatDb.history[chatId] || [];
            if (payload?.newMsg) h.push({ role: 'user', content: payload.newMsg });
            if (payload?.aiMsg) h.push({ role: 'assistant', content: payload.aiMsg });
            if (h.length > 10) h = h.slice(-10);
            chatDb.history[chatId] = h;
            save(historyPath, chatDb);
            return h;
        case 'inject_memory':
            let hist = chatDb.history[chatId] || [];
            hist.push({ role: 'system', content: `[SYSTEM ALERT]: ${payload.text}` });
            chatDb.history[chatId] = hist.slice(-10);
            save(historyPath, chatDb);
            break;
        case 'get_model': return chatDb.settings[chatId]?.model || 'groq';
        case 'get_voice_id': return chatDb.settings[chatId]?.voiceId || 'en-NG-AbeoNeural';
        case 'check_voice': return chatDb.settings[chatId]?.voiceMode || false;
        case 'toggle_voice': 
             if(!chatDb.settings[chatId]) chatDb.settings[chatId] = {};
             chatDb.settings[chatId].voiceMode = payload; 
             save(historyPath, chatDb); 
             break;
    }
};

// =======================================================
// 🔌 API CONNECTORS
// =======================================================
async function callGroq(messages) {
    const { default: axios } = await import('axios');
    const apiKey = process.env.GROQ_API_KEY; 
    const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
        model: 'llama-3.1-8b-instant',
        messages: messages,
        temperature: 0.7
    }, { headers: { 'Authorization': `Bearer ${apiKey}` } });
    return response.data.choices[0].message.content;
}

// =======================================================
// 🧠 MAIN AI HANDLER
// =======================================================
async function handleAIConversation(sock, chatId, text, senderId, botId, replyFunc, messageObject) {
    try {
        const isChatEnabled = manageMemory(botId, 'check_enabled', chatId);
        const isGlobalMode = manageMemory(botId, 'check_global', chatId);
        if (!isChatEnabled && !isGlobalMode) return;

        const isVoiceMode = manageMemory(botId, 'check_voice', chatId);
        const knowledgeBase = manageMemory(botId, 'get_knowledge', chatId);
        const chatHistory = manageMemory(botId, 'history', chatId, { newMsg: text });

        const systemPrompt = `You are Septorch AI. Knowledge: ${knowledgeBase.join('. ')}. User said: ${text}`;
        
        await sock.sendPresenceUpdate(isVoiceMode ? 'recording' : 'composing', chatId);

        const aiResponse = await callGroq([{ role: 'system', content: systemPrompt }, ...chatHistory]);

        if (aiResponse.trim().toUpperCase() === "IGNORE") return;

        manageMemory(botId, 'history', chatId, { aiMsg: aiResponse });

        if (isVoiceMode) {
            const audio = await generateVoice(cleanForSpeech(aiResponse), manageMemory(botId, 'get_voice_id', chatId));
            await sock.sendMessage(chatId, { audio, mimetype: 'audio/mp4', ptt: true }, { quoted: messageObject });
        } else {
            await replyFunc(aiResponse);
        }
    } catch (err) {
        console.error("AI Error:", err);
    }
}

module.exports = {
    cmd: ['septorch', 'ai', 'teach', 'learn', 'knowledge'],
    category: 'ai',
    addHistory: (botId, chatId, text) => manageMemory(botId, 'inject_memory', chatId, { text }),
    checkEnabled: (botId, chatId) => manageMemory(botId, 'check_enabled', chatId) || manageMemory(botId, 'check_global', chatId),
    handleConversation: handleAIConversation,

    handler: async ({ sock, chatId, message, args, text, reply, botId }) => {
        const command = args[0]?.toLowerCase();

        if (command === 'on') {
            manageMemory(botId, 'toggle', chatId, true);
            return sendCard(sock, chatId, 'AI STATUS', [` ${icons.on} Septorch AI *ENABLED*`]);
        }
        if (command === 'off') {
            manageMemory(botId, 'toggle', chatId, false);
            return sendCard(sock, chatId, 'AI STATUS', [` ${icons.off} Septorch AI *DISABLED*`]);
        }
        if (command === 'learn') {
            const fact = args.slice(1).join(' ');
            manageMemory(botId, 'learn_fact', chatId, fact);
            return sendCard(sock, chatId, 'LEARNED', [` ${icons.check} Added to Brain.`]);
        }
        if (command === 'voice') {
            const mode = args[1]?.toLowerCase() === 'on';
            manageMemory(botId, 'toggle_voice', chatId, mode);
            return sendCard(sock, chatId, 'VOICE', [` ${mode ? icons.on : icons.off} Voice Mode ${mode ? 'ON' : 'OFF'}`]);
        }

        // Default: Treat as AI query
        await handleAIConversation(sock, chatId, text || args.join(' '), null, botId, reply, message);
    }
};