module.exports = {
    cmd: ['currency', 'convert', 'exchange', 'rate'],
    category: 'utility',
    desc: 'Convert money between currencies',
    use: '.currency <amount> <from> <to>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import
            const { default: axios } = await import('axios');

            // Parsing arguments
            // Example: .currency 100 USD NGN
            // Defaults: Amount=Required, From=USD, To=NGN
            
            const amount = args[0];
            const from = args[1] ? args[1].toUpperCase() : 'USD';
            const to = args[2] ? args[2].toUpperCase() : 'NGN';

            // Validation
            if (!amount || isNaN(amount)) {
                return reply('❌ *Usage Examples:*\n' +
                             '1️⃣ .currency 50 (Converts 50 USD to NGN)\n' +
                             '2️⃣ .currency 100 EUR (Converts 100 EUR to NGN)\n' +
                             '3️⃣ .currency 200 GBP USD (Converts 200 GBP to USD)');
            }

            await reply(`💱 *Converting ${amount} ${from} to ${to}...*`);

            // Fetch Rates
            const response = await axios.get(`https://api.exchangerate-api.com/v4/latest/${from}`);
            
            // Check if API failed or currency invalid
            if (!response.data || !response.data.rates) {
                return reply(`❌ Invalid currency code: *${from}*`);
            }

            const rates = response.data.rates;

            if (!rates[to]) {
                return reply(`❌ Target currency code *${to}* not found.`);
            }

            // Calculation
            const rate = rates[to];
            const total = amount * rate;
            
            // Formatting (Adds commas and decimals)
            const formattedTotal = total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            const formattedRate = rate.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 });

            const msg = `💰 *CURRENCY CONVERTER*

💸 *${amount} ${from}* = *${formattedTotal} ${to}*

📊 *Exchange Rate:*
1 ${from} = ${formattedRate} ${to}

📅 *Date:* ${response.data.date}
_Powered by Septorch_`;

            await reply(msg);

        } catch (error) {
            console.error('Currency Error:', error.message);
            await reply('❌ Error fetching rates. Please check the currency code (e.g., USD, NGN, EUR).');
        }
    }
};