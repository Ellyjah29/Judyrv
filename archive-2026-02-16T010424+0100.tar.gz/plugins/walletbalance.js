module.exports = {
    cmd: ['wallet', 'balance', 'check'],
    category: 'finance',
    desc: 'Check Crypto Balance (BTC, ETH, SOL, TRX)',
    use: '.wallet <address>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Axios
            const { default: axios } = await import('axios');

            const address = args[0];
            if (!address) {
                return reply('❌ Please paste a crypto address.\n*Example:* .wallet 1A1zP1eP...');
            }

            // Helper: Get USD Price via CoinGecko
            async function getPrice(id) {
                try {
                    const { data } = await axios.get(`https://api.coingecko.com/api/v3/simple/price?ids=${id}&vs_currencies=usd`);
                    return data[id]?.usd || 0;
                } catch (e) { return 0; }
            }

            await reply('🔍 *Scanning blockchain...*');

            // ========================================================
            // 🟠 BITCOIN (Blockchain.info)
            // ========================================================
            if (address.match(/^(1|3|bc1)/)) {
                // Check for lowercase corruption
                if (address.match(/^(1|3)/) && address === address.toLowerCase()) {
                    return reply(`⚠️ *Format Warning:* Legacy BTC addresses (starting with 1 or 3) are CASE SENSITIVE. If your bot forces lowercase, this balance may show 0 incorrectly.`);
                }

                try {
                    const res = await axios.get(`https://blockchain.info/rawaddr/${address}`);
                    const data = res.data;

                    const btcVal = (data.final_balance / 100000000).toFixed(8);
                    const rate = await getPrice('bitcoin');
                    const usdVal = (btcVal * rate).toLocaleString(undefined, { minimumFractionDigits: 2 });

                    return reply(`🟠 *BITCOIN WALLET*\n\n💰 *Balance:* ${btcVal} BTC\n💵 *Value:* $${usdVal}\n🔢 *TXs:* ${data.n_tx}\n\n🔗 https://www.blockchain.com/explorer/addresses/btc/${address}`);
                } catch (e) {
                    return reply('❌ Bitcoin address not found or API error.');
                }
            }

            // ========================================================
            // 🔵 ETHEREUM (Ankr RPC)
            // ========================================================
            else if (address.startsWith('0x') && address.length === 42) {
                const { data } = await axios.post('https://rpc.ankr.com/eth', {
                    jsonrpc: "2.0", method: "eth_getBalance", params: [address, "latest"], id: 1
                });
                
                const ethVal = (parseInt(data.result, 16) / 1e18).toFixed(4);
                const rate = await getPrice('ethereum');
                const usdVal = (ethVal * rate).toLocaleString(undefined, { minimumFractionDigits: 2 });

                return reply(`🔵 *ETHEREUM WALLET*\n\n💰 *Balance:* ${ethVal} ETH\n💵 *Value:* $${usdVal}\n\n🔗 https://etherscan.io/address/${address}`);
            }

            // ========================================================
            // 🟣 SOLANA (Mainnet RPC)
            // ========================================================
            else if (address.length >= 32 && address.length <= 44 && !address.startsWith('0x')) {
                try {
                    const solRes = await axios.post('https://api.mainnet-beta.solana.com', {
                        jsonrpc: "2.0", id: 1, method: "getBalance", params: [address]
                    });

                    const solVal = (solRes.data.result.value / 1e9).toFixed(4);
                    const rate = await getPrice('solana');
                    const usdVal = (solVal * rate).toLocaleString(undefined, { minimumFractionDigits: 2 });

                    return reply(`🟣 *SOLANA WALLET*\n\n💰 *Balance:* ${solVal} SOL\n💵 *Value:* $${usdVal}\n\n🔗 https://solscan.io/account/${address}`);
                } catch (e) { /* Fallback to check other types */ }
            }

            // ========================================================
            // 🔴 TRON (Tronscan)
            // ========================================================
            if (address.startsWith('T') && address.length === 34) {
                const { data } = await axios.get(`https://apilist.tronscan.org/api/account?address=${address}`);
                const trxObj = data.balances?.find(b => b.tokenName === 'trx');
                const trxVal = trxObj ? (trxObj.balance / 1e6).toFixed(2) : 0;

                return reply(`🔴 *TRON WALLET*\n💰 *Balance:* ${trxVal} TRX`);
            }

            return reply('❌ Address not recognized. I support BTC, ETH, SOL, and TRX.');

        } catch (error) {
            console.error('Wallet Error:', error.message);
            await reply('❌ Error connecting to blockchain services.');
        }
    }
};