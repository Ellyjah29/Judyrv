module.exports = {
    cmd: ['anime', 'anisearch'], // Removed 'manga' because this API endpoint is specifically for Anime
    category: 'entertainment',
    desc: 'Search for Anime details from MyAnimeList',
    use: '.anime <name>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Axios
            const { default: axios } = await import('axios');

            // 1. Extract query using 'args' (Cleaner)
            const query = args.join(" ");

            if (!query) {
                return reply('❌ Please provide an anime name.\n*Example:* .anime Naruto');
            }

            await reply('🔍 *Searching MyAnimeList...*');

            // 2. Fetch from Jikan API (Jikan v4)
            const { data } = await axios.get(`https://api.jikan.moe/v4/anime?q=${query}&limit=1`);

            if (!data.data || data.data.length === 0) {
                return reply('❌ No anime found with that name.');
            }

            const anime = data.data[0];
            const title = anime.title;
            const titleJp = anime.title_japanese || 'N/A';
            const score = anime.score || 'N/A';
            const episodes = anime.episodes || '?';
            const status = anime.status || 'Unknown';
            const synopsis = anime.synopsis ? anime.synopsis.substring(0, 300) + '...' : 'No synopsis available.';
            
            // Safe image extraction
            const imageUrl = anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url;
            const url = anime.url;

            // 3. Build Caption
            let caption = `⛩️ *ANIME SEARCH RESULT*

📺 *Title:* ${title}
🇯🇵 *Original:* ${titleJp}
⭐ *Score:* ${score}/10
🎞️ *Episodes:* ${episodes}
📊 *Status:* ${status}

📝 *Synopsis:*
${synopsis}

🔗 *Link:* ${url}

_Powered by Septorch_`;

            // 4. Send Image with Caption
            await sock.sendMessage(chatId, { 
                image: { url: imageUrl }, 
                caption: caption 
            }, { quoted: message });

        } catch (error) {
            console.error('Anime API Error:', error);
            // Check if it's a 404 or network error
            if (error.response && error.response.status === 404) {
                return reply('❌ Anime not found.');
            }
            await reply('❌ Error fetching anime data. Try again later.');
        }
    }
};