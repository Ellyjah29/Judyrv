const os = require('os');
const process = require('process');

module.exports = {
    cmd: ['sys', 'system', 'info', 'ping2'],
    category: 'utility',
    desc: 'Displays detailed server & bot system information',
    
    handler: async ({ sock, chatId, reply }) => {
        // 1. Calculate Uptime (Bot Uptime vs System Uptime)
        const uptimeSeconds = process.uptime();
        const days = Math.floor(uptimeSeconds / (3600 * 24));
        const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        const seconds = Math.floor(uptimeSeconds % 60);
        const uptimeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

        // 2. RAM Metrics
        // Bot's Resident Set Size (RSS) is a better "total used by bot" metric than heapUsed
        const botRam = (process.memoryUsage().rss / 1024 / 1024).toFixed(2);
        const systemTotalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
        const systemFreeRam = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
        
        // 3. CPU Info
        const cpus = os.cpus();
        const cpuModel = cpus[0].model;
        const cpuCores = cpus.length;

        // 4. Platform & Version
        // os.type() gives "Linux" or "Windows_NT" instead of just "linux"
        const osType = os.type(); 
        const architecture = os.arch();

        // 5. Build Dashboard
        const text = `🖥️ *SYSTEM DASHBOARD*

🤖 *Bot Memory:* ${botRam} MB
📟 *System RAM:* ${systemFreeRam} GB Free / ${systemTotalRam} GB Total
⚙️ *CPU:* ${cpuModel} (${cpuCores} Cores)
⏳ *Bot Uptime:* ${uptimeStr}
💻 *OS:* ${osType} (${architecture})
🚀 *NodeJS:* ${process.version}

_Powered by Septorch Plugins_ 🔌`;

        await reply(text);
    }
};