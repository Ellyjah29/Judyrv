module.exports = {
    // 1. Added 'imagine' and 'genimg' aliases
    cmd: ['draw', 'imagine', 'genimg'],
    category: 'ai',
    desc: 'Generate an AI image from text',
    use: '.draw <text>',
    
    // 2. Use 'args' for cleaner input handling
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // Extract the prompt using args
            const prompt = args.join(" ");

            if (!prompt) {
                // Updated example to match the primary command
                return reply('❌ Please describe what you want me to draw.\n*Example:* .draw a cyberpunk cat in lagos');
            }

            await reply('🎨 *Generative AI is drawing... (Wait a moment)*');

            // Encode the prompt to handle spaces and special characters
            const encodedPrompt = encodeURIComponent(prompt);
            
            // Pollinations allows direct URL access to the image.
            // We add a random number (seed) to the end to prevent WhatsApp from caching the same image if requested twice.
            // Using 1024x1024 for high quality square images.
            const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1024&height=1024&nologo=true&seed=${Math.random()}`;

            // Send the image directly via URL. Baileys handles the fetching internally.
            await sock.sendMessage(chatId, { 
                image: { url: imageUrl }, 
                caption: `🖌️ *Here is your creation:*\n"${prompt}"\n\n_Powered by Septorch AI_` 
            }, { quoted: message });

        } catch (error) {
            console.error('AI Image Error:', error);
            // Sometimes Pollinations times out or returns a 500 error if busy
            await reply('❌ The AI service is currently overloaded or timed out. Please try again in a minute.');
        }
    }
};