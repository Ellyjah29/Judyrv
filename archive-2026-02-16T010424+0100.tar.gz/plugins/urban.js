module.exports = {
    cmd: ['urban', 'slang', 'ud'],
    category: 'entertainment',
    desc: 'Search Urban Dictionary for slang definitions',
    use: '.urban <word>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Axios (prevents ESM/CJS crash)
            const { default: axios } = await import('axios');

            const word = args.join(' ');
            
            if (!word) {
                return reply('❌ Please provide a slang word.\n*Example:* .urban lol');
            }

            await reply(`🔍 *Searching Urban Dictionary for "${word}"...*`);

            // Official Urban Dictionary API
            const response = await axios.get(`https://api.urbandictionary.com/v0/define?term=${encodeURIComponent(word)}`);
            const list = response.data.list;

            if (!list || list.length === 0) {
                return reply(`❌ No definition found for *"${word}"*. It might be too new!`);
            }

            // Get the top result (usually the most popular/accurate)
            const entry = list[0];

            // Helper to clean brackets [] used by UD for internal linking
            const clean = (str) => {
                if (!str) return "N/A";
                return str.replace(/\[|\]/g, '');
            };

            const msg = `🧢 *URBAN DICTIONARY*

📖 *Word:* ${entry.word}

💬 *Definition:*
${clean(entry.definition)}

📝 *Example:*
_"${clean(entry.example)}_"

👍 ${entry.thumbs_up.toLocaleString()} | 👎 ${entry.thumbs_down.toLocaleString()}
✍️ *Author:* ${entry.author}

_Powered by Septorch AI_`;

            // Send result with quoted message for better context
            await sock.sendMessage(chatId, { 
                text: msg 
            }, { quoted: message });

        } catch (error) {
            console.error('Urban Dictionary Error:', error.message);
            await reply('❌ Connection error. Urban Dictionary API might be busy or down.');
        }
    }
};