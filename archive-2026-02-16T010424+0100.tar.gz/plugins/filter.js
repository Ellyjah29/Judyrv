module.exports = {
    cmd: ['wasted', 'jail', 'mission', 'passed', 'comrade', 'trigger'],
    category: 'entertainment',
    desc: 'Apply funny filters to profile pictures',
    use: '.wasted @user | .jail @user',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import (Standardizing)
            const { jidNormalizedUser } = await import('@whiskeysockets/baileys');

            // 1. Get the target user
            // Order of priority: Mentioned > Quoted > Sender
            const sender = message.key.participant || message.key.remoteJid;
            const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            const quoted = message.message?.extendedTextMessage?.contextInfo?.participant;
            
            let targetJid = sender;
            if (mentions && mentions.length > 0) targetJid = mentions[0];
            else if (quoted) targetJid = quoted;

            // Normalize JID
            targetJid = jidNormalizedUser(targetJid);

            // 2. Identify which command was used (from the first word of the message)
            const txt = message.message?.conversation || message.message?.extendedTextMessage?.text || "";
            const cmd = txt.split(' ')[0].replace(/[.#]/, '').toLowerCase();

            // 3. Get Profile Picture URL
            let ppUrl;
            try {
                // Try to get high-res image
                ppUrl = await sock.profilePictureUrl(targetJid, 'image');
            } catch (e) {
                // If privacy settings prevent fetching, use a default placeholder
                ppUrl = 'https://i.imgur.com/HeIi0wV.png'; 
            }

            await reply('🎨 *Applying filter...*');

            // 4. Select API Endpoint based on command
            let endpoint = '';
            let caption = '';

            // Map commands to Some-Random-API endpoints
            switch (cmd) {
                case 'wasted':
                    endpoint = 'wasted';
                    caption = '😵 *WASTED*';
                    break;
                case 'jail':
                    endpoint = 'jail';
                    caption = '👮 *YOU ARE UNDER ARREST*';
                    break;
                case 'mission':
                case 'passed':
                    endpoint = 'passed';
                    caption = '🏆 *MISSION PASSED*';
                    break;
                case 'comrade':
                    endpoint = 'comrade';
                    caption = '☭ *OUR PROFILE PICTURE*';
                    break;
                case 'trigger':
                case 'triggered':
                    endpoint = 'triggered';
                    caption = '😡 *TRIGGERED*';
                    break;
                default:
                    endpoint = 'wasted';
                    caption = '😵 *WASTED*';
            }

            // 5. Construct API URL
            // Some-Random-API processes the image for us
            // We encode the PP URL to ensure it passes correctly
            const apiUrl = `https://some-random-api.com/canvas/overlay/${endpoint}?avatar=${encodeURIComponent(ppUrl)}`;

            // 6. Send the result
            // Baileys automatically fetches the image from the URL
            await sock.sendMessage(chatId, { 
                image: { url: apiUrl }, 
                caption: caption 
            }, { quoted: message });

        } catch (error) {
            console.error('Filter API Error:', error);
            await reply('❌ Could not process the image. The API might be down.');
        }
    }
};