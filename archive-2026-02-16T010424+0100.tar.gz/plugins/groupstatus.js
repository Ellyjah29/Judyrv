const crypto = require('crypto');

module.exports = {
    cmd: ['groupstatus', 'gstatus', 'gst'],
    category: 'group',
    desc: 'Post a message as Group Status',
    use: '.gstatus <reply to image/video/audio/text>',
    
    handler: async ({ sock, chatId, message, args, isGroup, reply }) => {
        try {
            const { downloadContentFromMessage } = await import('@whiskeysockets/baileys');

            if (!isGroup) return reply('❌ This command can only be used in groups.');

            const contextInfo = message.message?.extendedTextMessage?.contextInfo;
            const quotedMsg = contextInfo?.quotedMessage;
            const textInput = args.join(" ").trim();

            if (!quotedMsg && !textInput) return reply('❌ Reply to a message or provide text.');

            let statusPayload = {};

            // -------------------------------
            // 1. TEXT STATUS
            // -------------------------------
            if (!quotedMsg && textInput) {
                statusPayload = {
                    text: textInput,
                    contextInfo: { isGroupStatus: true }
                };
            }

            // -------------------------------
            // 2. QUOTED MEDIA STATUS
            // -------------------------------
            else if (quotedMsg) {
                const mtype = Object.keys(quotedMsg)[0];

                // IMAGE
                if (mtype === 'imageMessage') {
                    const stream = await downloadContentFromMessage(quotedMsg.imageMessage, 'image');
                    const chunks = [];
                    for await (const chunk of stream) chunks.push(chunk);
                    const mediaBuffer = Buffer.concat(chunks);

                    statusPayload = {
                        image: mediaBuffer,
                        caption: quotedMsg.imageMessage.caption || textInput || '',
                        contextInfo: { isGroupStatus: true }
                    };
                } 

                // VIDEO
                else if (mtype === 'videoMessage') {
                    const stream = await downloadContentFromMessage(quotedMsg.videoMessage, 'video');
                    const chunks = [];
                    for await (const chunk of stream) chunks.push(chunk);
                    const mediaBuffer = Buffer.concat(chunks);

                    statusPayload = {
                        video: mediaBuffer,
                        caption: quotedMsg.videoMessage.caption || textInput || '',
                        mimetype: 'video/mp4',
                        contextInfo: { isGroupStatus: true }
                    };
                } 

                // AUDIO
                else if (mtype === 'audioMessage') {
                    const stream = await downloadContentFromMessage(quotedMsg.audioMessage, 'audio');
                    const chunks = [];
                    for await (const chunk of stream) chunks.push(chunk);
                    const mediaBuffer = Buffer.concat(chunks);

                    statusPayload = {
                        audio: mediaBuffer,
                        mimetype: 'audio/mp4',
                        contextInfo: { isGroupStatus: true }
                    };
                } 

                // TEXT (quoted)
                else if (quotedMsg.conversation || quotedMsg.extendedTextMessage) {
                    const text = quotedMsg.conversation || quotedMsg.extendedTextMessage.text;
                    statusPayload = {
                        text: text,
                        contextInfo: { isGroupStatus: true }
                    };
                } 
                
                // FALLBACK
                else {
                    return reply('❌ Unsupported message type for group status.');
                }
            }

            // -------------------------------
            // 3. SEND TO GROUP STATUS
            // -------------------------------
            await sock.sendMessage(chatId, statusPayload);

            return reply('✅ Group Status Posted Successfully!');

        } catch (e) {
            console.error("Group Status Plugin Error:", e);
            return reply(`❌ Failed to post group status: ${e.message}`);
        }
    }
};
