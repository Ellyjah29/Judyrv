const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
require('dotenv').config();

console.log("[WebBuilder v7.0] SaaS Mode Active 🛡️");

// =======================================================
// ⚙️ CONFIGURATION
// =======================================================
const PORT = 3010; 
const MY_DOMAIN = "https://sites.septorch.tech"; 
const MAX_SITES = 3; 
const ADMIN_NUMBER = "2349047943737"; 

// =======================================================
// 💾 DATABASE & FOLDERS
// =======================================================
const DATA_DIR = path.join(process.cwd(), 'data/web_builder');
const SITES_DIR = path.join(DATA_DIR, 'sites');
const ROUTE_DB = path.join(DATA_DIR, 'routes.json'); 
const USER_DB = path.join(DATA_DIR, 'users.json');      

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(SITES_DIR)) fs.mkdirSync(SITES_DIR, { recursive: true });
if (!fs.existsSync(ROUTE_DB)) fs.writeFileSync(ROUTE_DB, '{}');
if (!fs.existsSync(USER_DB)) fs.writeFileSync(USER_DB, '{}');

const getRoutes = () => JSON.parse(fs.readFileSync(ROUTE_DB, 'utf8'));
const saveRoutes = (data) => fs.writeFileSync(ROUTE_DB, JSON.stringify(data, null, 2));
const getUsers = () => JSON.parse(fs.readFileSync(USER_DB, 'utf8'));
const saveUsers = (data) => fs.writeFileSync(USER_DB, JSON.stringify(data, null, 2));

// =======================================================
// 🧹 HTML EXTRACTOR
// =======================================================
function extractHtml(text) {
    let clean = text.replace(/```html|```/g, '').trim();
    const matchStart = clean.match(/<!DOCTYPE html>|<html/i);
    const startIndex = matchStart ? matchStart.index : -1;
    const endIndex = clean.lastIndexOf('</html>');
    if (startIndex !== -1 && endIndex !== -1) return clean.substring(startIndex, endIndex + 7);
    return clean; 
}

// =======================================================
// 🚀 EXPRESS SERVER
// =======================================================
let serverApp = null;
let globalSock = null;

async function startServer() {
    if (serverApp) return;
    const app = express();
    app.use(express.urlencoded({ extended: true }));
    app.use(express.json());

    // Root Showcase
    app.get('/', (req, res) => {
        const routes = getRoutes();
        const recentSites = Object.keys(routes).slice(-6).reverse().map(s => ({ slug: s, ...routes[s] }));
        // [Your existing Landing Page HTML here...]
        res.send(generateLandingHtml(recentSites, Object.keys(routes).length));
    });

    // Main Site Delivery
    app.get('/:slug', (req, res) => {
        const { slug } = req.params;
        const routes = getRoutes();
        if (routes[slug]) {
            const filePath = path.join(SITES_DIR, routes[slug].fileName);
            if (fs.existsSync(filePath)) {
                routes[slug].views = (routes[slug].views || 0) + 1;
                saveRoutes(routes);
                return res.sendFile(filePath);
            }
        }
        res.status(404).redirect('/');
    });

    serverApp = app.listen(PORT, () => console.log(`[WebBuilder] Server live on ${PORT}`));
}

// =======================================================
// 🎮 BOT HANDLER
// =======================================================
module.exports = {
    cmd: ['web', 'site', 'builder'],
    category: 'tools',
    desc: 'AI Web Builder SaaS',
    use: '.web create <idea>',
    
    handler: async ({ sock, chatId, args, reply, senderId }) => {
        try {
            const { default: axios } = await import('axios');
            globalSock = sock;
            startServer();

            const cleanNum = senderId.split('@')[0];
            const action = args[0]?.toLowerCase();
            const prompt = args.slice(1).join(' ');

            // User Management
            const users = getUsers();
            if (!users[cleanNum]) {
                users[cleanNum] = 'u_' + crypto.randomBytes(3).toString('hex');
                saveUsers(users);
            }
            const userId = users[cleanNum];

            if (!action) {
                return reply(`🛠️ *Web Builder Pro*\n🆔 *User ID:* ${userId}\n────────────────\n🔹 *.web create <idea>*\n🔹 *.web list* (My Sites)\n🔹 *.web delete <id>*`);
            }

            if (action === 'create') {
                const routes = getRoutes();
                const mySites = Object.values(routes).filter(r => r.ownerId === userId);
                if (mySites.length >= MAX_SITES && cleanNum !== ADMIN_NUMBER) {
                    return reply(`❌ Limit reached (${MAX_SITES} sites). Delete one to create more.`);
                }

                await reply(`🎨 *AI is designing your site...*`);
                
                const slug = crypto.randomBytes(2).toString('hex');
                const fileName = `${userId}_${slug}.html`;
                const filePath = path.join(SITES_DIR, fileName);

                const sysPrompt = `You are a Senior Web Dev. Build a premium, mobile-responsive single-page site using Tailwind CSS. Output ONLY the HTML code. Use high-quality placeholders or provided image links.`;
                
                const apiKey = process.env.GROQ_API_KEY; // Ensure this is in your .env
                const aiRes = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
                    model: 'llama-3.3-70b-versatile',
                    messages: [{ role: "system", content: sysPrompt }, { role: "user", content: prompt }]
                }, { headers: { 'Authorization': `Bearer ${apiKey}` } });

                const finalHtml = extractHtml(aiRes.data.choices[0].message.content);
                fs.writeFileSync(filePath, finalHtml);

                routes[slug] = { fileName, ownerId: userId, name: prompt.substring(0, 20), views: 0 };
                saveRoutes(routes);

                return reply(`✅ *Site Live!* 🔗\n\n${MY_DOMAIN}/${slug}`);
            }

            if (action === 'list') {
                const routes = getRoutes();
                let msg = `📈 *Your Sites*\n────────────────\n`;
                Object.entries(routes).forEach(([slug, data]) => {
                    if (data.ownerId === userId) msg += `🔗 ${slug} (${data.views || 0} views)\n`;
                });
                return reply(msg);
            }

            if (action === 'delete') {
                const slug = args[1];
                const routes = getRoutes();
                if (routes[slug] && (routes[slug].ownerId === userId || cleanNum === ADMIN_NUMBER)) {
                    try { fs.unlinkSync(path.join(SITES_DIR, routes[slug].fileName)); } catch(e) {}
                    delete routes[slug];
                    saveRoutes(routes);
                    return reply(`🗑️ Site deleted.`);
                }
                return reply("❌ Site not found or unauthorized.");
            }

        } catch (e) {
            console.error(e);
            reply("❌ System Error. Check console logs.");
        }
    }
};

// Placeholder for Landing Page HTML Generator
function generateLandingHtml(sites, count) {
    return `<html><body style="background:#0f172a;color:white;font-family:sans-serif;text-align:center;padding:50px"><h1>Septorch WebBuilder</h1><p>${count} Sites Hosted</p></body></html>`;
}