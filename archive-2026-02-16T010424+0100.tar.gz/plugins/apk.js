module.exports = {
    cmd: ['apk', 'app', 'download', 'mod'],
    category: 'tools',
    desc: 'Download Android apps (Direct API - No Crash)',
    use: '.apk <app name>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import
            const { default: axios } = await import('axios');

            // 1. Get Query from args (Cleaner)
            const query = args.join(" ");

            if (!query) return reply('❌ Please tell me the app name.\n*Example:* .apk spotify mod');

            await reply(`🔍 *Searching Aptoide for "${query}"...*`);

            // 2. SEARCH DIRECTLY (Bypassing broken libraries)
            // Aptoide hidden API is fast and usually has everything
            const searchUrl = `https://ws75.aptoide.com/api/7/apps/search/query=${encodeURIComponent(query)}/limit=1`;
            
            const { data } = await axios.get(searchUrl);

            // Check results
            if (!data || !data.datalist || !data.datalist.list || data.datalist.list.length === 0) {
                return reply('❌ App not found.');
            }

            // Get the best result
            const app = data.datalist.list[0];
            const sizeMB = (app.size / 1048576).toFixed(2); // Convert bytes to MB

            // 3. SIZE SAFETY CHECK
            // WhatsApp Bots usually crash if you send files > 100MB
            if (sizeMB > 100) {
                return await sock.sendMessage(chatId, {
                    image: { url: app.icon },
                    caption: `❌ *App Too Large*\n\n📱 *${app.name}*\n📦 Size: ${sizeMB} MB\n\n_I cannot send files larger than 100MB via WhatsApp._\n🔗 *Download Link:* ${app.file.path}`
                }, { quoted: message });
            }

            // 4. Send Info Message
            await sock.sendMessage(chatId, {
                image: { url: app.icon },
                caption: `📱 *Downloading: ${app.name}*\n` +
                         `📦 *Package:* ${app.package}\n` +
                         `⬇️ *Size:* ${sizeMB} MB\n` +
                         `⭐ *Rating:* ${app.stats.rating.avg}\n\n` +
                         `_Uploading file to chat..._`
            }, { quoted: message });

            // 5. DOWNLOAD & SEND
            // We download the file into a buffer first
            const apkResponse = await axios.get(app.file.path, { 
                responseType: 'arraybuffer',
                headers: { 'User-Agent': 'okhttp/4.9.3' } // Pretend to be a phone
            });

            const apkBuffer = Buffer.from(apkResponse.data);

            await sock.sendMessage(chatId, {
                document: apkBuffer,
                mimetype: 'application/vnd.android.package-archive',
                fileName: `${app.name}.apk`,
                caption: `📦 *${app.name}* Installed!`
            }, { quoted: message });

        } catch (error) {
            console.error('APK Direct Error:', error.message);
            await reply('❌ Error fetching the app. The server might be busy or the file is too large.');
        }
    }
};