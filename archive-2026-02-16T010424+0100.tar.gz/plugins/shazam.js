const fs = require('fs');
const path = require('path');
const { Shazam } = require('node-shazam');

module.exports = {
    cmd: ['shazam', 'findsong', 'identify', 'whatsong'],
    category: 'entertainment',
    desc: 'Identify music using Shazam (No API Key needed)',
    use: '.shazam (reply to audio/video)',
    
    handler: async ({ sock, chatId, message, reply }) => {
        const shazam = new Shazam();
        const tempFilePath = path.join(process.cwd(), `temp_shazam_${Date.now()}.mp3`);
        
        try {
            // 🟢 v7 FIX: Dynamic Import
            const { downloadContentFromMessage } = await import('@whiskeysockets/baileys');

            // 1. Get Quoted Message
            const contextInfo = message.message?.extendedTextMessage?.contextInfo || 
                                message.message?.imageMessage?.contextInfo || 
                                message.message?.videoMessage?.contextInfo;
            
            const quotedMsg = contextInfo?.quotedMessage;
            
            if (!quotedMsg) {
                return reply('❌ Please reply to an audio or video clip with *.shazam*');
            }

            // 2. Identify Media Type
            const audioMsg = quotedMsg.audioMessage;
            const videoMsg = quotedMsg.videoMessage;

            if (!audioMsg && !videoMsg) {
                return reply('❌ That is not an audio or video file.');
            }

            await reply('🎧 *Listening and identifying...*');

            // 3. Download the Media
            const stream = await downloadContentFromMessage(
                audioMsg || videoMsg, 
                audioMsg ? 'audio' : 'video'
            );

            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            // 4. Save to a temporary file
            fs.writeFileSync(tempFilePath, buffer);

            // 5. Recognize using Shazam
            const result = await shazam.recognise(tempFilePath, 'en-US');

            // 6. Check Results
            if (!result || !result.track || !result.track.title) {
                if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);
                return reply('❌ Could not identify this song. It might be too short or the background noise is too high.');
            }

            const track = result.track;
            const title = track.title;
            const artist = track.subtitle;
            const image = track.images?.coverart || track.images?.coverarthq;
            const url = track.url;
            const genre = track.genres?.primary || 'Unknown';

            // 7. Build Message
            let msg = `🎵 *SONG IDENTIFIED* 🎵\n\n`;
            msg += `🎼 *Title:* ${title}\n`;
            msg += `🎤 *Artist:* ${artist}\n`;
            msg += `🎹 *Genre:* ${genre}\n\n`;
            msg += `🔗 *Shazam Link:* ${url}`;

            // Add streaming links if available
            if (track.hub?.providers) {
                const providers = track.hub.providers
                    .filter(p => p.actions && p.actions[0]?.uri)
                    .map(p => `• ${p.caption}: ${p.actions[0].uri}`)
                    .join('\n');
                if (providers) msg += `\n\n*Stream On:*\n${providers}`;
            }

            msg += `\n\n_Powered by Septorch AI_`;

            // 8. Send Result
            if (image) {
                await sock.sendMessage(chatId, { 
                    image: { url: image }, 
                    caption: msg 
                }, { quoted: message });
            } else {
                await reply(msg);
            }

        } catch (error) {
            console.error('Shazam Error:', error);
            await reply('❌ Failed to identify song. Ensure the audio is clear and try again.');
        } finally {
            // 9. Mandatory Cleanup
            if (fs.existsSync(tempFilePath)) {
                fs.unlinkSync(tempFilePath);
            }
        }
    }
};