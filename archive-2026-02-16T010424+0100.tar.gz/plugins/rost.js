module.exports = {
    cmd: ['roast', 'insult', 'burn'],
    category: 'fun',
    desc: 'Generate a savage insult',
    use: '.roast (or reply to a message)',
    
    handler: async ({ sock, chatId, message, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Axios
            const { default: axios } = await import('axios');

            // 1. Get the target to tag (if replying to someone)
            const quoted = message.message?.extendedTextMessage?.contextInfo?.participant;
            const mentions = quoted ? [quoted] : [];

            // 2. Fetching the insult
            // Using evilinsult.com API
            const response = await axios.get('https://evilinsult.com/generate_insult.php?lang=en&type=json');
            const insult = response.data.insult;

            // 3. Build the Message
            let msg = `🔥 *ROAST INCOMING* 🔥\n\n`;
            
            if (quoted) {
                msg += `@${quoted.split('@')[0]} `; // Tag the person being roasted
            }
            
            msg += `"${insult}"\n\n_Apply cold water to the burned area._ 🧊`;

            // 4. Send with Mentions support
            await sock.sendMessage(chatId, { 
                text: msg, 
                mentions: mentions 
            }, { quoted: message });

        } catch (error) {
            console.error('Roast Error:', error.message);
            await reply('❌ I am feeling too nice to insult anyone right now. (API error)');
        }
    }
};