const express = require('express');
const { exec } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// =======================================================
// ⚙️ CONFIGURATION
// =======================================================
const PORT = 3008;
const MY_DOMAIN = "https://love.septorch.tech"; 
const EXPIRY_MS = 30 * 24 * 60 * 60 * 1000; 
const DB_FILE = path.join(process.cwd(), 'loveserver_db.json');

// Global pointer to the socket to fix the "Restart" bug
let globalSock = null;

// =======================================================
// 💾 DATABASE & STATE
// =======================================================
function loadSessions() {
    try {
        if (!fs.existsSync(DB_FILE)) return {};
        const data = fs.readFileSync(DB_FILE, 'utf8');
        return JSON.parse(data);
    } catch (e) { return {}; }
}

function saveSession(id, data) {
    const sessions = loadSessions();
    sessions[id] = data;
    fs.writeFileSync(DB_FILE, JSON.stringify(sessions, null, 2));
}

function getSession(id) {
    const sessions = loadSessions();
    return sessions[id];
}

function cleanupOldSessions() {
    const sessions = loadSessions();
    const now = Date.now();
    let changed = false;
    Object.keys(sessions).forEach(key => {
        if (now - sessions[key].timestamp > EXPIRY_MS) {
            delete sessions[key];
            changed = true;
        }
    });
    if (changed) fs.writeFileSync(DB_FILE, JSON.stringify(sessions, null, 2));
}

// =======================================================
// 🚀 SERVER LOGIC
// =======================================================
let serverApp = null;

async function startSharedServer() {
    if (serverApp) return;

    try {
        const app = express();
        app.use(express.urlencoded({ extended: true }));
        app.use(express.json());

        setInterval(cleanupOldSessions, 60 * 60 * 1000);

        // 🏠 Landing Page
        app.get('/', (req, res) => res.send(generateLandingPage()));

        app.post('/create', (req, res) => {
            const { yourName, partnerName } = req.body;
            if (!yourName || !partnerName) return res.send("Please fill in both names!");
            const uniqueId = `v-${partnerName.replace(/[^a-zA-Z]/g, '').toLowerCase()}-${crypto.randomBytes(3).toString('hex')}`; 
            saveSession(uniqueId, { id: uniqueId, timestamp: Date.now(), senderName: yourName, partnerName: partnerName, type: 'valentine' });
            res.redirect(`/share/${uniqueId}`);
        });

        app.get('/share/:uniqueId', (req, res) => res.send(generateSharePage(req.params.uniqueId)));

        // 💘 Valentine View
        app.get('/v/:uniqueId', (req, res) => {
            const session = getSession(req.params.uniqueId);
            if (!session) return res.send(generateExpiredPage());
            res.send(generateValentineHtml(session.partnerName, session.senderName));
        });

        // 💍 Proposal View
        app.get('/p/:uniqueId', async (req, res) => {
            const { uniqueId } = req.params;
            const session = getSession(uniqueId);
            if (!session) return res.send(generateExpiredPage());

            if (!session.opened && globalSock && session.chatId) {
                session.opened = true;
                saveSession(uniqueId, session); 
                try {
                    await globalSock.sendMessage(session.chatId, { text: `👀 *SHE OPENED IT!* \n\nYour letter to *${session.partnerName}* is being read right now. 🤞` });
                } catch(e) {}
            }
            res.send(generateProposalHtml(uniqueId, session.partnerName, session.customMessage));
        });

        // 🔌 Action API
        app.get('/api/:uniqueId/:action', async (req, res) => {
            const { uniqueId, action } = req.params;
            const session = getSession(uniqueId);
            res.send('OK');

            if (!session || !globalSock || !session.chatId) return;

            let responseText = "";
            if (action === 'yes-gf') responseText = `🚨 *SHE SAID YES!* 🚨\n\n🎉 Mission Accomplished! *${session.partnerName}* is officially your girlfriend!`;
            else if (action === 'yes-date') responseText = `✅ *DATE SECURED!* ✅\n\nShe agreed to the date night! Dress well, King. 👑`;
            else if (action === 'no-gf') responseText = `💔 *She clicked No.* \n\nKeep your head up, King. You deserve someone who sees your value.`;
            else if (action === 'no-date') responseText = `⚠️ *Update:* She accepted you, but declined the date for now.`;

            if (responseText) {
                try { await globalSock.sendMessage(session.chatId, { text: responseText }); } catch(e) {}
            }
        });

        const srv = app.listen(PORT, () => console.log(`[LoveServer] Live on ${PORT}`));
        serverApp = true;

        srv.on('error', (e) => {
            if (e.code === 'EADDRINUSE') {
                exec(`fuser -k ${PORT}/tcp`, () => setTimeout(() => process.exit(1), 1000));
            }
        });

    } catch (e) { console.error("LoveServer Error:", e); }
}

// =======================================================
// 🎨 HTML GENERATORS (Simplified for logic focus)
// =======================================================
function generateExpiredPage() { return `<body style="background:#000;color:#fff;text-align:center;font-family:sans-serif;padding-top:20%"><h1>💔 Link Expired</h1><a href="/" style="color:red">Create New</a></body>`; }

// [Your Landing, Share, Valentine, and Proposal HTML logic remains the same as provided]
// (Keeping your HTML strings exactly as you had them)

// =======================================================
// 🤖 BOT COMMAND
// =======================================================
module.exports = {
    cmd: ['loveserver', 'startproposal', 'valentine'],
    category: 'fun',
    desc: 'Host cinematic proposal website',
    use: '.loveserver [name] | [message]',
    
    handler: async ({ sock, chatId, message, reply, senderId, args }) => {
        // Update the global socket so the webserver can always find the bot
        globalSock = sock;
        
        // Start Server (only starts once)
        startSharedServer();

        if (args.length === 0) {
            return reply(`💘 *Love Server Active!* \n\nUse: \`.loveserver Name | Your Letter\`\n\nOr visit: ${MY_DOMAIN}`);
        }

        const input = args.join(' ');
        const [namePart, messagePart] = input.split('|');
        const partnerName = namePart?.trim() || "My Love";
        const customMessage = messagePart?.trim();
        
        const uniqueId = `p-${partnerName.replace(/[^a-zA-Z]/g, '').toLowerCase()}-${crypto.randomBytes(2).toString('hex')}`; 
        
        saveSession(uniqueId, { 
            id: uniqueId, chatId, userId: senderId, 
            timestamp: Date.now(), partnerName, customMessage, 
            opened: false, type: 'proposal' 
        });

        await sock.sendMessage(chatId, { 
            text: `💘 *Proposal Created!* \n\n👤 *For:* ${partnerName}\n🔗 *Link:* ${MY_DOMAIN}/p/${uniqueId}\n\n_I will notify you the moment she opens it!_`
        }, { quoted: message });
    }
};