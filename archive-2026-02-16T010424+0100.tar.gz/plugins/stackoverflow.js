module.exports = {
    cmd: ['stackoverflow', 'stack', 'so', 'error'],
    category: 'tech',
    desc: 'Search StackOverflow for coding solutions',
    use: '.so <error or question>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Axios (Prevents ESM/CJS crash)
            const { default: axios } = await import('axios');

            const query = args.join(' ');
            
            if (!query) {
                return reply('❌ What is the error?\n*Example:* .so cannot find module axios');
            }

            await reply(`🔍 *Searching StackOverflow for solutions...*`);

            // 1. Call StackExchange API (Advanced Search v2.3)
            // We sort by 'relevance' to get the most accurate answers first.
            const apiUrl = `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${encodeURIComponent(query)}&site=stackoverflow`;
            
            const { data } = await axios.get(apiUrl);
            const items = data.items;

            // 2. Validate Response
            if (!items || items.length === 0) {
                return reply(`❌ No matching solutions found for: *${query}*`);
            }

            // 3. Get Top Result
            const top = items[0];
            
            // 4. Build the Card
            const msg = `🥞 *STACKOVERFLOW RESULTS*

❓ *Question:* ${top.title}
✅ *Status:* ${top.is_answered ? 'Answered ✅' : 'Open ⏳'}
👀 *Views:* ${top.view_count.toLocaleString()}
⭐ *Score:* ${top.score}
🏷️ *Tags:* ${top.tags.join(', ')}

🔗 *Solution Link:* ${top.link}

_Powered by Septorch AI_`;

            // 5. Send result
            await sock.sendMessage(chatId, { 
                text: msg 
            }, { quoted: message });

        } catch (error) {
            console.error('StackOverflow Plugin Error:', error.message);
            // Handle API rate limits (Backoff)
            if (error.response && error.response.status === 400) {
                return reply('❌ StackOverflow API Error. Try a simpler query.');
            }
            await reply('❌ Search failed. The API might be limited or down.');
        }
    }
};