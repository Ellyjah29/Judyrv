module.exports = {
    cmd: ['mask', 'masklink', 'hideurl'],
    category: 'utility',
    desc: 'Hide a link inside a different URL text using Authority Format',
    use: '.mask <link> <text>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Axios (prevents ESM/CJS crash)
            const { default: axios } = await import('axios');

            // 1. Validation: We need the real URL and the fake text
            const targetUrl = args[0];
            const maskText = args.slice(1).join('-'); // Join words with hyphens for a clean URL look

            if (!targetUrl || !maskText) {
                return reply('❌ Usage: .mask <link> <text>\n\n*Example:* .mask https://youtube.com free-money');
            }

            // Ensure the target URL starts with a protocol
            const validUrl = targetUrl.startsWith('http') ? targetUrl : `https://${targetUrl}`;

            await reply('🎭 *Masking link...*');

            // 2. Shorten the real URL using TinyURL API
            // TinyURL's api-create is fast and doesn't require an API key
            const response = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(validUrl)}`);
            const shortUrl = response.data;

            // 3. Format the Masked Link
            // Authority Format: https://fake-text@tinyurl.com/xyz123
            // Most apps (like WhatsApp) will highlight the whole thing, 
            // but browsers ignore the "fake-text@" part and redirect to the short link.
            const urlParts = shortUrl.split('://'); 
            const protocol = urlParts[0];
            const domainAndPath = urlParts[1];

            const maskedLink = `${protocol}://${maskText}@${domainAndPath}`;

            const msg = `🎭 *LINK MASKED*

🔗 *Original:* ${validUrl}
👺 *Masked:* ${maskedLink}

_⚠️ Note: This works because browsers interpret the text before the '@' as user credentials, which are ignored by TinyURL._`;

            // 4. Send the result
            await sock.sendMessage(chatId, { 
                text: msg 
            }, { quoted: message });

        } catch (error) {
            console.error('Mask Plugin Error:', error.message);
            await reply('❌ Failed to mask link. Please ensure the URL is valid.');
        }
    }
};