const path = require('path');
const fs = require('fs');

// =======================================================
// 🔗 AI MEMORY LINKER (Safe Loader)
// =======================================================
let septorchAI = null;
const possiblePaths = [
    path.join(__dirname, 'septorch-ai.js'),
    path.join(__dirname, '../plugins/septorch-ai.js'),
    path.join(process.cwd(), 'plugins/septorch-ai.js'),
    path.join(process.cwd(), 'septorch-ai.js')
];

for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
        try {
            septorchAI = require(p);
            break;
        } catch (e) {
            console.error("⚠️ Failed to load AI Brain:", e.message);
        }
    }
}

module.exports = {
    cmd: ['google', 'search', 'find', 'ask'],
    category: 'educational',
    desc: 'AI Web Search (Natural Voice)',
    use: '.google <query>',
    
    handler: async ({ sock, chatId, args, reply, senderId, botId, message, isOwner, isAdmin }) => {
        try {
            // 🟢 v7 FIX: Dynamic Imports
            const { default: axios } = await import('axios');
            const cheerio = await import('cheerio');

            const query = args.join(' ');
            
            if (!query) {
                return reply('❌ Please provide a search query.\n*Example:* .google latest news in nigeria');
            }

            await reply(`🔍 *Researching "${query}"...*`);

            // 1. SCRAPE YAHOO (Mobile View for better text)
            const searchUrl = `https://search.yahoo.com/search?p=${encodeURIComponent(query)}`;
            const response = await axios.get(searchUrl, {
                headers: { 
                    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1'
                }
            });

            const $ = cheerio.load(response.data);
            const results = [];

            // Scrape logic compatible with Yahoo Mobile
            $('.algo').each((i, element) => {
                if (results.length >= 10) return; // Limit to 10 for speed
                const title = $(element).find('h3.title a').text().trim();
                // Try multiple selectors for the snippet
                const snippet = $(element).find('.compText').text().trim() || 
                                $(element).find('.fc-12th').text().trim() || 
                                $(element).find('p').text().trim();
                
                const link = $(element).find('h3.title a').attr('href');

                if (title && snippet) {
                    results.push({ title, snippet, link });
                }
            });

            if (results.length === 0) return reply('❌ No info found on the web.');

            // 2. FORMAT DATA (Hidden System Note)
            let memoryBlock = `[SYSTEM DATA: WEB SEARCH RESULTS]\n`;
            memoryBlock += `User Query: "${query}"\n`;
            memoryBlock += `Instructions: Use the facts below to answer the user. Prioritize recent dates. Do not mention "Yahoo" or "Search Results".\n\n`;
            
            let plainTextResponse = `🔍 *Search Results for:* ${query}\n\n`;

            results.forEach((r, i) => {
                memoryBlock += `(${i+1}) ${r.title}: ${r.snippet}\n`;
                plainTextResponse += `*${i+1}. ${r.title}*\n${r.snippet}\n🔗 ${r.link}\n\n`;
            });

            // 3. INJECT & SPEAK (With Fallback)
            if (septorchAI && typeof septorchAI.handleConversation === 'function') {
                
                // Inject memory if supported
                if (typeof septorchAI.addHistory === 'function') {
                    septorchAI.addHistory(botId, chatId, memoryBlock);
                }

                // ✨ NATURAL TRIGGER PROMPT
                const triggerPrompt = `Using the web data I just gave you, answer the user's question: "${query}". 
                
                IMPORTANT RULES:
                1. Answer NATURALLY, as if you already knew this information.
                2. DO NOT say "Based on search results" or "Injected memory".
                3. DO NOT list links unless explicitly asked.
                4. Be direct and conversational.`;
                
                await septorchAI.handleConversation(
                    sock, 
                    chatId, 
                    triggerPrompt, 
                    senderId, 
                    botId, 
                    reply, 
                    message, 
                    isOwner || isAdmin
                );

            } else {
                // ⚠️ FALLBACK: If AI is missing, send the raw list
                console.log("⚠️ AI Brain not found. Sending raw search results.");
                await sock.sendMessage(chatId, {
                    text: plainTextResponse + `_AI Module not loaded. Showing raw results._`
                }, { quoted: message });
            }

        } catch (error) {
            console.error('Search Error:', error.message);
            return reply('❌ Connection failed or Google is blocking requests.');
        }
    }
};