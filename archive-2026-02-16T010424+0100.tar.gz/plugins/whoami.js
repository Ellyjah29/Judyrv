const axios = require('axios');

module.exports = {
    cmd: ['whoami'],
    category: 'tools',
    desc: 'Predict age, gender and nationality from a name',
    use: '.whoami <name>',
    
    handler: async ({ sock, chatId, message, reply }) => {
        try {
            const text = message.message?.conversation || message.message?.extendedTextMessage?.text || "";
            const name = text.split(' ').slice(1).join(' ').trim();

            if (!name) {
                return reply('❌ Please give me a name.\n*Example:* .whoami Septorch');
            }

            // Run 3 API calls in parallel for speed
            const [ageRes, genRes, natRes] = await Promise.all([
                axios.get(`https://api.agify.io?name=${name}`),
                axios.get(`https://api.genderize.io?name=${name}`),
                axios.get(`https://api.nationalize.io?name=${name}`)
            ]);

            const age = ageRes.data.age || '?';
            const gender = genRes.data.gender || 'Unknown';
            const probability = (genRes.data.probability * 100).toFixed(1);
            
            // Get top 2 countries
            const countries = natRes.data.country.slice(0, 2).map(c => c.country_id).join(' or ');

            const msg = `🕵️ *IDENTITY PREDICTION*

👤 *Subject:* ${name}

🎂 *Predicted Age:* ${age} years old
⚧️ *Predicted Gender:* ${gender} (${probability}%)
🌍 *Likely Origin:* ${countries || 'Unknown'}

_Based on global statistical data._`;

            await reply(msg);

        } catch (error) {
            console.error('Profile API Error:', error);
            await reply('❌ Could not profile this identity.');
        }
    }
};