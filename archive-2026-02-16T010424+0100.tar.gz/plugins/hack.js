module.exports = {
    cmd: ['hack', 'prank', 'attack'],
    category: 'fun',
    desc: 'Prank your friends with a fake system hack (Works with Tag or Reply)',
    use: '.hack @user OR Reply to a message with .hack',
    
    handler: async ({ sock, chatId, message, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for JID normalization
            const { jidNormalizedUser } = await import('@whiskeysockets/baileys');

            // 1. Get the target (Check Mention OR Reply)
            const contextInfo = message.message?.extendedTextMessage?.contextInfo || 
                                message.message?.imageMessage?.contextInfo || 
                                message.message?.videoMessage?.contextInfo;

            const mentionedJid = contextInfo?.mentionedJid;
            const quotedSender = contextInfo?.participant; // The person you replied to

            // Priority: 1. Tagged User, 2. Quoted User
            let rawTarget = (mentionedJid && mentionedJid[0]) ? mentionedJid[0] : quotedSender;

            if (!rawTarget) {
                return reply('❌ Who are we hacking? Tag them or Reply to their message!\n*Example:* .hack @user');
            }

            // Normalize the JID (removes :suffixes for multi-device)
            const target = jidNormalizedUser(rawTarget);

            // 2. The Sequence of "Hacking" Messages
            const steps = [
                `💻 *INITIALIZING SEPTORCH V9...* \nTarget: @${target.split('@')[0]}`,
                `🔓 *Bypassing WhatsApp End-to-End Encryption...*`,
                `📂 *Accessing 'Hidden Photos' folder...* \n(Found: 342 images)`,
                `⬇️ *Downloading recent chat logs...* \n[████████░░] 80%`,
                `⚠️ *Injecting 'Trojan.Script.js' into device...*`,
                `✅ *HACK SUCCESSFUL* \n\nData has been uploaded to the Dark Web.\n_Device is now compromised._`
            ];

            // 3. Helper function for delay
            const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

            // 4. Send them one by one (Sequential sending)
            for (const step of steps) {
                await sock.sendMessage(chatId, { 
                    text: step, 
                    mentions: [target] 
                });
                // Short sleep to make it look like a terminal "typing" or "processing"
                await sleep(1500); 
            }

        } catch (e) {
            console.error("Hack Command Error:", e);
            reply("❌ An error occurred while executing the hack.");
        }
    }
};