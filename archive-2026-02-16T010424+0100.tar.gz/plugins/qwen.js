// =========================================
// 🧠 SEPTORCH AI (Direct API Version)
// =========================================

// 🔒 SECURITY: Use your actual token here
const HF_TOKEN = "hf_...PasteYourRealTokenHere..."; 

// 🔗 DIRECT API URL
const API_URL = "https://septorch-septorch-ai.hf.space/api/predict";

module.exports = {
    cmd: ['qwen', 'ask', 'gpt', 'ai'],
    category: 'ai',
    desc: 'Ask Septorch AI (Qwen-powered)',
    use: '.qwen <question>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 1. Extract prompt using args (Cleaner)
            const prompt = args.join(" ");

            if (!prompt) return reply('🤖 Ask me something!\n*Example:* .qwen How do I code a bot?');

            // 2. Visual Feedback (Reaction + Typing state)
            await sock.sendMessage(chatId, { react: { text: "🧠", key: message.key } });
            await sock.sendPresenceUpdate('composing', chatId);

            // 3. DIRECT FETCH to Hugging Face
            // Note: Native fetch is used here (Node.js 18+)
            const response = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${HF_TOKEN}`
                },
                body: JSON.stringify({
                    data: [prompt],
                    fn_index: 0 
                })
            });

            if (!response.ok) {
                const errText = await response.text();
                throw new Error(`HF Space Status ${response.status}: ${errText.substring(0, 50)}`);
            }

            const json = await response.json();
            
            // 4. Extract Answer safely
            // Gradio responses can be nested depending on the Space configuration
            const aiResponse = json.data && json.data[0] ? json.data[0] : "I couldn't generate a response. Please try again.";

            // 5. Send Response
            await sock.sendMessage(chatId, { 
                text: `🤖 *Septorch AI:*\n\n${aiResponse}` 
            }, { quoted: message });

            // Final Reaction
            await sock.sendMessage(chatId, { react: { text: "✅", key: message.key } });

        } catch (error) {
            console.error('Septorch AI Error:', error);
            
            // Common Hugging Face error: Space is sleeping
            if (error.message.includes('503') || error.message.includes('Sleeping')) {
                return await reply('😴 *Space is Sleeping:* I am waking it up now. Please try again in 30 seconds.');
            }

            await reply(`❌ *AI Error:* ${error.message}`);
        }
    }
};