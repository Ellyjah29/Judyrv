module.exports = {
    // Command Triggers
    cmd: ['movie', 'film', 'imdb'],
    category: 'downloads',
    desc: 'Search for movie details and ratings',
    use: '.movie <name>',

    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Axios
            const { default: axios } = await import('axios');

            // 1. Get the query from args
            const query = args.join(" ");

            if (!query) {
                return reply('❌ Please provide a movie name.\n*Example:* .movie Inception');
            }

            await reply('🎬 *Searching for movie details...*');

            // 2. Call the API
            const apiUrl = `https://movieapi.giftedtech.co.ke/api/search?q=${encodeURIComponent(query)}`;
            const { data } = await axios.get(apiUrl);

            // 3. Validate Response
            if (!data || (Array.isArray(data) && data.length === 0) || data.success === false) {
                return reply(`❌ No movie found for: *${query}*`);
            }

            // 4. Extract Data safely
            const movie = Array.isArray(data) ? data[0] : (data.result || data);

            const title = movie.title || movie.Title || query;
            const year = movie.year || movie.Year || 'N/A';
            const rating = movie.rating || movie.imdbRating || 'N/A';
            const runtime = movie.runtime || movie.Runtime || 'N/A';
            const genre = movie.genre || movie.Genre || 'N/A';
            const plot = movie.plot || movie.Plot || movie.overview || 'No description available.';
            
            // Poster logic with fallback
            let poster = movie.poster || movie.Poster;
            if (!poster || poster === 'N/A') {
                poster = 'https://i.imgur.com/1c88X6p.png'; 
            }

            const caption = `🎬 *MOVIE INFO* 🎬
            
🎥 *Title:* ${title}
📅 *Year:* ${year}
⭐ *Rating:* ${rating}
⏱️ *Runtime:* ${runtime}
🎭 *Genre:* ${genre}

📝 *Plot:*
${plot.length > 400 ? plot.substring(0, 400) + '...' : plot}

_Powered by Septorch Bot_`;

            // 5. Send Image with Caption
            await sock.sendMessage(chatId, {
                image: { url: poster },
                caption: caption
            }, { quoted: message });

        } catch (e) {
            console.error("Movie Plugin Error:", e);
            await reply('❌ Error fetching movie data. The API might be down or limited.');
        }
    }
};