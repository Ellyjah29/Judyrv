module.exports = {
    // 1. Command Config
    cmd: ['devjoke', 'codejoke', 'joke'],
    category: 'entertainment',
    desc: 'Get a random programming joke',
    use: '.devjoke',
    
    // 2. The Logic
    handler: async ({ sock, chatId, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import
            const { default: axios } = await import('axios');

            // Using the reliable Official Joke API (Programming category)
            const response = await axios.get('https://official-joke-api.appspot.com/jokes/programming/random');
            
            // The API usually returns an array [ { ... } ], but sometimes a single object { ... }
            // We handle both cases here:
            const data = Array.isArray(response.data) ? response.data[0] : response.data;

            if (!data || !data.setup || !data.punchline) {
                return reply('❌ No jokes found right now. Try again!');
            }

            const jokeMessage = `🖥️ *Dev Joke:*

🗣️ ${data.setup}

... 😆 ${data.punchline}`;

            await reply(jokeMessage);

        } catch (error) {
            console.error('[DevJoke] Error:', error.message);
            await reply('❌ Failed to fetch joke. The API might be busy.');
        }
    }
};