const fs = require('fs');
const path = require('path');

module.exports = {
    // Triggers
    cmd: ['externalplugin', 'extplugin', 'installplugin', 'reload', 'scanplugins', 'refresh'],
    category: 'system',
    desc: 'Install from URL or Reload all plugins from folder',
    use: '.reload OR .installplugin <url>',
    
    handler: async ({ sock, chatId, args, reply, botId }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Axios
            const { default: axios } = await import('axios');

            const url = args[0];
            const pluginDir = path.join(process.cwd(), 'plugins');

            // Ensure the directory exists
            if (!fs.existsSync(pluginDir)) {
                fs.mkdirSync(pluginDir, { recursive: true });
            }

            // ============================================================
            // 🔄 MODE A: RELOAD / REFRESH (No URL provided)
            // ============================================================
            if (!url || !url.startsWith('http')) {
                try {
                    // 1. Clear "require" cache for all files in plugins
                    const files = fs.readdirSync(pluginDir);
                    files.forEach(file => {
                        const fullPath = path.resolve(path.join(pluginDir, file));
                        if (require.cache[fullPath]) {
                            delete require.cache[fullPath];
                        }
                    });

                    // 2. Clear loader cache to ensure fresh re-import
                    const loaderPath = require.resolve('../lib/plugins');
                    if (require.cache[loaderPath]) delete require.cache[loaderPath];
                    
                    // 3. Re-import the loader and execute
                    const { loadPlugins } = require('../lib/plugins');
                    loadPlugins(botId);

                    return reply(`🔄 *System Refreshed!*\n\n✅ Plugins reloaded\n⚡ Cache cleared for ${files.length} files`);

                } catch (e) {
                    console.error("Reload Error:", e);
                    return reply(`❌ *Reload Failed:*\n${e.message}`);
                }
            }

            // ============================================================
            // 📥 MODE B: DOWNLOAD & INSTALL (URL Provided)
            // ============================================================
            try {
                await reply('⏳ *Downloading plugin from source...*');
                
                const response = await axios.get(url);
                const data = response.data;
                
                // Structure Validation
                if (typeof data !== 'string' || !data.includes('module.exports') || !data.includes('handler:')) {
                    return reply('⚠️ *Invalid Structure:* This link does not contain a compatible Septorch plugin.');
                }

                // Clean file name generation
                let fileName = url.split('/').pop().split('?')[0]; 
                if (!fileName.endsWith('.js')) fileName += '.js';
                // Avoid filename collisions or weird characters
                fileName = fileName.replace(/[^a-zA-Z0-9.-]/g, '_');

                const filePath = path.join(pluginDir, fileName);
                
                // Write file to disk
                fs.writeFileSync(filePath, data);
                
                // Clear cache if it was already loaded
                if (require.cache[path.resolve(filePath)]) {
                    delete require.cache[path.resolve(filePath)];
                }

                // Trigger reload
                const { loadPlugins } = require('../lib/plugins');
                loadPlugins(botId);

                await reply(`✅ *Installation Successful!*\n📄 File: *${fileName}*\n⚡ Plugin is now live.`);

            } catch (e) {
                console.error("Install Error:", e);
                await reply(`❌ *Installation Failed:*\n${e.message}`);
            }

        } catch (e) {
            console.error("Main Handler Error:", e);
            reply("❌ System error during plugin management.");
        }
    }
};