module.exports = {
    cmd: ['ip', 'whois', 'lookup', 'ipinfo'],
    category: 'utility',
    desc: 'Get detailed info about an IP address or Domain',
    use: '.ip <address>',

    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import
            const { default: axios } = await import('axios');

            const query = args[0];
            if (!query) {
                return reply('❌ Please provide an IP or Domain.\n*Example:* .ip google.com');
            }

            await reply(`🔍 *Tracing ${query}...*`);

            // Using ip-api.com (Free, No Key Required)
            const response = await axios.get(`http://ip-api.com/json/${query}?fields=status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,query`);
            const data = response.data;

            if (data.status === 'fail') {
                return reply(`❌ *Lookup Failed:*\nReason: ${data.message}`);
            }

            // Corrected Google Maps URL
            const mapLink = `https://www.google.com/maps?q=${data.lat},${data.lon}`;

            const msg = `🌍 *IP LOOKUP: ${data.query}*

🏳️ *Country:* ${data.country} (${data.countryCode})
🏙️ *Region:* ${data.city}, ${data.regionName}
📮 *Zip:* ${data.zip}
🕐 *Timezone:* ${data.timezone}

🏢 *ISP:* ${data.isp}
🏢 *Org:* ${data.org}
🛰️ *AS:* ${data.as}

📍 *Coordinates:* ${data.lat}, ${data.lon}
🔗 *Map:* ${mapLink}

_Powered by Septorch_`;

            await sock.sendMessage(chatId, { text: msg }, { quoted: message });

        } catch (error) {
            console.error('IP Error:', error.message);
            await reply('❌ Connection failed. Unable to trace IP.');
        }
    }
};