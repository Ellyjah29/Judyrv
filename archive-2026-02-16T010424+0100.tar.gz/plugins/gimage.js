const gis = require('g-i-s');

module.exports = {
    cmd: ['img', 'image', 'googleimg', 'gimage'],
    category: 'entertainment',
    desc: 'Search for images on Google (Auto-Retry Fix)',
    use: '.img <query>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            const query = args.join(' ');
            
            if (!query) {
                return reply('❌ Please provide a search query.\n*Example:* .img naruto');
            }

            await reply(`🔍 *Searching Google for "${query}"...*`);

            // 1. Promisify GIS (Convert messy callback to clean Async/Await)
            const fetchImages = (searchTerm) => {
                return new Promise((resolve, reject) => {
                    gis(searchTerm, (error, results) => {
                        if (error) reject(error);
                        else resolve(results);
                    });
                });
            };

            const results = await fetchImages(query);

            if (!results || results.length === 0) {
                return reply('❌ No images found.');
            }

            // 2. Filter Results
            // We ensure it starts with http and IS NOT an SVG (WhatsApp can't render SVGs)
            const validImages = results.filter(img => 
                img.url && 
                img.url.startsWith('http') && 
                !img.url.endsWith('.svg')
            );

            if (validImages.length === 0) {
                return reply('❌ No sendable images found.');
            }

            // Shuffle to get variety, then take top 5 candidates
            const candidates = validImages.sort(() => 0.5 - Math.random()).slice(0, 5);
            
            // 3. Smart Send Loop (The Fix)
            // Many Google Images have "Hotlink Protection" which causes sending to fail.
            // We try up to 3 images. If one works, we stop.
            let sent = false;

            for (let i = 0; i < Math.min(3, candidates.length); i++) {
                try {
                    const imgUrl = candidates[i].url;
                    // console.log(`Attempting to send image ${i+1}: ${imgUrl}`); // Debug log

                    await sock.sendMessage(chatId, { 
                        image: { url: imgUrl }, 
                        caption: `🖼️ *Google Image:* ${query}\n\n_Powered by Septorch_`
                    }, { quoted: message });
                    
                    sent = true;
                    break; // ✅ Success! Exit the loop.
                } catch (sendErr) {
                    console.log(`⚠️ Image ${i+1} failed (Protected). Trying next...`);
                    // Continue to next iteration
                }
            }

            if (!sent) {
                await reply('❌ Found images, but they are all protected (Anti-Hotlink). Please try a different query.');
            }

        } catch (error) {
            console.error('GIS Error:', error);
            await reply('❌ Scraper error. Google might be blocking requests temporarily.');
        }
    }
};