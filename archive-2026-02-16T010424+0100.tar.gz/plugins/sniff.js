module.exports = {
    cmd: ['sniff', 'inspect', 'json'],
    category: 'dev',
    handler: async ({ sock, chatId, message, reply }) => {
        try {
            // 1. Define a "Circular Safe" Stringifier
            // This forces the bot to show us everything, even hidden items
            const getCircularReplacer = () => {
                const seen = new WeakSet();
                return (key, value) => {
                    if (typeof value === "object" && value !== null) {
                        if (seen.has(value)) return "[Circular]";
                        seen.add(value);
                    }
                    return value;
                };
            };

            // 2. Capture the ENTIRE message object
            // Not just the quote, but the message you just sent + what it replied to
            const fullStructure = JSON.stringify(message, getCircularReplacer(), 2);

            // 3. Log to Console (This is the most reliable place to check)
            console.log("\n================ [ NUCLEAR SNIFF START ] ================");
            console.log(fullStructure);
            console.log("================ [ NUCLEAR SNIFF END ] ==================\n");

            // 4. Try to send to chat (might be too long, so we try/catch)
            try {
                await reply(`✅ Check your **Console/Terminal** for the full log.\n\nHere is a snippet of the quote:\n\n` + 
                    '```json\n' + 
                    JSON.stringify(message.message?.extendedTextMessage?.contextInfo || "No Context Found", null, 2).substring(0, 500) + 
                    '\n```'
                );
            } catch (err) {
                await reply("✅ Logged to console (Message was too big to send here).");
            }

        } catch (e) {
            console.error("Sniff Error:", e);
            reply('❌ Fatal Sniff Error.');
        }
    }
};