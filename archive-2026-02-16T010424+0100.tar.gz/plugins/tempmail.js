const path = require('path');

// Global memory to store sid_tokens per chat
// This allows users to just type .checkmail without re-entering the address
const mailSessions = new Map();

module.exports = {
    cmd: ['tempmail', 'guerrilla', 'checkmail', 'inbox'],
    category: 'utility',
    desc: 'Disposable email from Guerrilla Mail (v7 Optimized)',
    use: '.tempmail | .checkmail',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            // 🟢 v7 FIX: Dynamic Import for Axios
            const { default: axios } = await import('axios');

            const text = message.message?.conversation || message.message?.extendedTextMessage?.text || "";
            const command = text.trim().split(/\s+/)[0].toLowerCase();

            // Browser Headers to prevent blocking
            const headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            };

            // ========================================================
            // 📧 GENERATE EMAIL (.tempmail)
            // ========================================================
            if (command.includes('tempmail')) {
                await reply('📧 *Generating new disposable address...*');

                // f=get_email_address initializes a new session and returns a sid_token
                const response = await axios.get(`https://api.guerrillamail.com/ajax.php?f=get_email_address&lang=en`, { headers });
                
                const data = response.data;
                const email = data.email_addr;
                const sid = data.sid_token;

                // Save session for this chat
                mailSessions.set(chatId, { email, sid });

                const msg = `📧 *TEMP MAIL GENERATED*

📮 *Email:* ${email}
⏱️ *Expires:* 60 Minutes

_I will remember this address for you._
_Just type_ \`.checkmail\` _to see your inbox!_`;

                return await reply(msg);
            }

            // ========================================================
            // 📬 CHECK INBOX (.checkmail)
            // ========================================================
            if (command.includes('checkmail') || command.includes('inbox')) {
                const session = mailSessions.get(chatId);
                
                // If no active session, check if they provided an email in args
                if (!session && (!args[0] || !args[0].includes('@'))) {
                    return reply('❌ No active session. Use *.tempmail* first or provide an email.');
                }

                const sid_token = session ? session.sid : null;
                const targetEmail = session ? session.email : args[0];

                await reply(`🔄 *Checking inbox for ${targetEmail}...*`);

                // 1. Get Email List
                // If we have an SID, we use it. If not, we set the user first.
                let finalSid = sid_token;
                if (!finalSid) {
                    const user = targetEmail.split('@')[0];
                    const login = await axios.get(`https://api.guerrillamail.com/ajax.php?f=set_email_user&email_user=${user}`, { headers });
                    finalSid = login.data.sid_token;
                }

                const listRes = await axios.get(`https://api.guerrillamail.com/ajax.php?f=get_email_list&offset=0&sid_token=${finalSid}`, { headers });
                const list = listRes.data.list;

                if (!list || list.length === 0) {
                    return reply('📭 *Inbox is empty.*');
                }

                // 2. Fetch the latest non-welcome email if possible
                const latestMail = list[0];

                // 3. Fetch Full Content
                const mailRes = await axios.get(`https://api.guerrillamail.com/ajax.php?f=fetch_email&email_id=${latestMail.mail_id}&sid_token=${finalSid}`, { headers });
                const fullMsg = mailRes.data;

                // 4. Clean Body (Remove HTML tags)
                let body = (fullMsg.mail_body || "No content").replace(/<[^>]*>/g, '').trim();

                const display = `📬 *LATEST EMAIL*

👤 *From:* ${fullMsg.mail_from}
📝 *Subject:* ${fullMsg.mail_subject}
📅 *Date:* ${fullMsg.mail_date}

📄 *Message:*
${body.length > 800 ? body.substring(0, 800) + '...' : body}

_Septorch TempMail Service_`;

                return await reply(display);
            }

        } catch (error) {
            console.error('TempMail Error:', error);
            await reply('❌ Service error. Guerrilla Mail might be rate-limiting or down.');
        }
    }
};