module.exports = {
    cmd: ['tweet', 'twitter', 'post'],
    category: 'entertainment',
    desc: 'Create a realistic fake tweet',
    use: '.tweet <username> <text>',
    
    handler: async ({ sock, chatId, message, args, reply }) => {
        try {
            const { default: axios } = await import('axios');

            // 1. Validate Input
            if (args.length < 2) {
                return reply('❌ Usage: .tweet <username> <text>\n*Example:* .tweet elonmusk buying the moon');
            }

            const username = args[0].replace('@', ''); // The target handle
            const content = args.slice(1).join(' ');   // The tweet text

            let displayName = '';
            let handle = username;
            let ppUrl = '';
            let isVerified = false;

            // 2. Fetch User Data (Real Name & Verification Status)
            // We use unavatar.io/json to get the profile metadata for free
            await reply('🐦 *Verifying profile & generating tweet...*');
            
            try {
                const metaRes = await axios.get(`https://unavatar.io/twitter/${username}?json`);
                const userData = metaRes.data;

                displayName = userData.name || username;
                ppUrl = userData.avatar || `https://unavatar.io/twitter/${username}`;
                
                // Check if verified (unavatar provides this in metadata)
                // Note: verified status depends on the provider's current data
                isVerified = userData.twitter?.verified || false;

            } catch (e) {
                // Fallback if metadata fetch fails
                displayName = username.charAt(0).toUpperCase() + username.slice(1);
                ppUrl = `https://unavatar.io/twitter/${username}`;
                isVerified = false;
            }

            // 3. Generate the Tweet Canvas
            // Adding &verified=${isVerified} enables the blue checkmark
            const apiUrl = `https://some-random-api.com/canvas/misc/tweet?displayname=${encodeURIComponent(displayName)}&username=${encodeURIComponent(handle)}&avatar=${encodeURIComponent(ppUrl)}&comment=${encodeURIComponent(content)}&replies=8.5k&retweets=25k&likes=150k&theme=dark&verified=${isVerified}`;

            // 4. Send Result
            await sock.sendMessage(chatId, { 
                image: { url: apiUrl }, 
                caption: `🐦 *Official Tweet from @${handle.toUpperCase()}*` 
            }, { quoted: message });

        } catch (error) {
            console.error('Tweet Plugin Error:', error);
            await reply('❌ Error: Could not generate the tweet. The API might be busy.');
        }
    }
};