exports.bots = [];

exports.userStates = {};

exports.blacklistedUsers = [];