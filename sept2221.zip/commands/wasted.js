// commands/wasted.js
const axios = require('axios');
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH',
            serverMessageId: -1
        }
    }
};

/* 📦 Box helper */
const box = (title, lines) => [
  `╭━━━[ *${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

/* ⚰️ Wasted command */
async function wastedCommand(sock, chatId, message) {
  // 1️⃣ Detect target user
  const ctx = message.message?.extendedTextMessage?.contextInfo;
  const target =
    ctx?.mentionedJid?.[0] ||
    ctx?.participant;

  if (!target) {
    await sock.sendMessage(chatId, {
      text: box('Wasted', [
        '❌ Mention a user or reply to their message to waste them!'
      ]),
      ...channelInfo
    });
    return;
  }

  try {
    // 2️⃣ Fetch profile picture (fallback image if none)
    let avatar;
    try {
      avatar = await sock.profilePictureUrl(target, 'image');
    } catch {
      avatar = 'https://i.imgur.com/2wzGhpF.jpeg';
    }

    // 3️⃣ Generate “wasted” overlay
    const url = `https://some-random-api.com/canvas/overlay/wasted?avatar=${encodeURIComponent(avatar)}`;
    const res = await axios.get(url, { responseType: 'arraybuffer' });

    if (res.status !== 200) throw new Error('Image API returned an error');

    // 4️⃣ Send result
    await sock.sendMessage(chatId, {
      image: Buffer.from(res.data),
      caption: box('Wasted', [
        `⚰️ @${target.split('@')[0]} has been *WASTED!* 💀`,
        '',
        'Rest in pieces…'
      ]),
      mentions: [target],
      ...channelInfo
    });

  } catch (err) {
    console.error('wastedCommand error:', err);
    await sock.sendMessage(chatId, {
      text: box('Wasted', [
        '❌ Failed to create wasted overlay.',
        '🔄 Please try again later.'
      ]),
      ...channelInfo
    });
  }
}

module.exports = wastedCommand;