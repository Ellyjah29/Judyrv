const fs = require('fs');
const path = require('path');

// Function to get bot-specific tmp directory
function getTmpDirectory(botId) {
    const tmpDir = path.join(process.cwd(), 'tmp', botId);
    try {
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }
        return tmpDir;
    } catch (err) {
        console.error(`❌ Failed to create or access tmp directory for bot ${botId}:`, err);
        return null;
    }
}

// Function to clear tmp directory
async function clearTmpDirectory(botId) {
    try {
        const tmpDir = getTmpDirectory(botId);

        if (!tmpDir) {
            return { success: false, message: 'Failed to initialize temporary directory!' };
        }

        // Check if tmp directory exists
        if (!fs.existsSync(tmpDir)) {
            return { success: true, message: 'Temporary directory does not exist!' };
        }

        // Remove all contents of the tmp directory
        fs.rmSync(tmpDir, { recursive: true, force: true });

        // Recreate the directory to ensure it exists
        fs.mkdirSync(tmpDir, { recursive: true });

        return { 
            success: true, 
            message: `Successfully cleared temporary directory for bot ${botId}!`,
            count: 0 // No need to count files since we're deleting everything
        };

    } catch (error) {
        console.error(`❌ Error clearing tmp directory for bot ${botId}:`, error);
        return { 
            success: false, 
            message: 'Failed to clear temporary files!',
            error: error.message
        };
    }
}

// Function to handle manual command
async function clearTmpCommand(sock, chatId, msg, botId) {
    try {
        // Check if user is owner
        const isOwner = msg.key.fromMe;
        if (!isOwner) {
            await sock.sendMessage(chatId, { 
                text: '❌ This command is only available for the owner!' 
            });
            return;
        }

        const result = await clearTmpDirectory(botId);

        if (result.success) {
            await sock.sendMessage(chatId, { 
                text: `✅ ${result.message}` 
            });
        } else {
            await sock.sendMessage(chatId, { 
                text: `❌ ${result.message}` 
            });
        }

    } catch (error) {
        console.error('❌ Error in cleartmp command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Failed to clear temporary files!' 
        });
    }
}

// Start automatic clearing every 6 hours
function startAutoClear(botId) {
    // Run immediately on startup
    clearTmpDirectory(botId).then(result => {
        if (result.success) {
            console.log(`[Auto Clear] ${result.message}`);
        } else {
            console.error(`[Auto Clear] ${result.message}`);
        }
    });

    // Set interval for every 6 hours
    setInterval(async () => {
        const result = await clearTmpDirectory(botId);
        if (result.success) {
            console.log(`[Auto Clear] ${result.message}`);
        } else {
            console.error(`[Auto Clear] ${result.message}`);
        }
    }, 6 * 60 * 60 * 1000); // 6 hours in milliseconds
}

// Export the clearTmpCommand function
module.exports = clearTmpCommand;