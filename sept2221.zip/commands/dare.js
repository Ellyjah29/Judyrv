// commands/dare.js

const { channelInfo } = require('../lib/messageConfig');

// 🎁 List of dares
const dares = [
    "Do 10 push-ups.",
    "Sing a song out loud.",
    "Call a friend and say 'I love you' dramatically.",
    "Speak in an accent for the next 5 minutes.",
    "Send a funny selfie to the group.",
    "Say the alphabet backward.",
    "Dance like nobody's watching for 30 seconds.",
    "Do your best impression of a celebrity.",
    "Let someone else tickle you for 10 seconds.",
    "Eat something without using your hands.",
    "Try to lick your elbow.",
    "Talk like a baby for the next 2 rounds.",
    "Act like a chicken for 20 seconds.",
    "Let the person to your left draw on your face with a pen.",
    "Wear socks on your hands for the next 5 minutes.",
    "Tell the most embarrassing story about yourself.",
    "Post a selfie on your WhatsApp status with no filter.",
    "Imitate your favorite movie character for 30 seconds.",
    "Text your crush and say 'Hey' then wait 1 minute before sending anything else.",
    "Let someone write a word on your forehead with a marker.",
    "Make a silly face and hold it for 1 minute.",
    "Pretend to be a waiter/waitress and serve someone imaginary food.",
    "Do your best evil laugh.",
    "Speak only in rhymes for the next 3 messages.",
    "Let someone else do your hair however they want.",
    "Mime a scene from your favorite movie.",
    "Make a drink for someone using whatever ingredients they choose.",
    "Try to touch your nose with your tongue.",
    "Try to do a cartwheel.",
    "Try to juggle 3 random objects.",
    "Do your best robot dance.",
    "Try to balance a spoon on your nose for 10 seconds.",
    "Speak with your tongue sticking out for the next 2 minutes.",
    "Let someone else challenge you to a dance-off.",
    "Do a dramatic reading of a random text message.",
    "Act like a dog until your next turn.",
    "Do a silly walk across the room.",
    "Let someone else feed you a blindfolded bite.",
    "Try to stand on one foot for 60 seconds.",
    "Do your best impression of a news anchor.",
    "Try to rap your favorite song lyric.",
    "Give yourself a funny nickname and use it for the next 10 minutes.",
    "Make a silly TikTok-style video right now.",
    "Do your best impression of a grandparent.",
    "Try to speak in slow motion for the next 2 minutes.",
    "Try to make everyone laugh as hard as they can.",
    "Do a silly fashion show with whatever clothes are nearby.",
    "Let someone else give you a new hairstyle.",
    "Do your best villain monologue.",
    "Try to beatbox for 10 seconds."
];

// 🧾 Styled box message
function formatDareBox(usernameTag, dareText) {
    return [
        '╭━━━━━━[🔥 *DARE TIME* 🔥]━━━━━━╮',
        `┃ Hey ${usernameTag}, here’s your dare!`,
        '┃',
        ...dareText.split('\n').map(line => `┃ ${line}`),
        '╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯'
    ].join('\n');
}

// 📤 Dare command handler
async function sendDare(sock, chatId, senderId) {
    try {
        const randomIndex = Math.floor(Math.random() * dares.length);
        const selectedDare = dares[randomIndex];
        const userTag = `@${senderId.split('@')[0]}`;
        
        const boxMessage = formatDareBox(userTag, selectedDare);

        await sock.sendMessage(chatId, {
            text: boxMessage,
            mentions: [senderId],
            ...channelInfo
        });

    } catch (error) {
        console.error('❌ Error sending dare:', error);
        await sock.sendMessage(chatId, {
            text: 'Something went wrong while sending the dare. Try again!'
        });
    }
}

module.exports = { sendDare };