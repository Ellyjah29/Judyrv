const fs = require('fs');
const path = require('path');

// Load auto-replies from JSON file
function loadAutoReplies(botId) {
    const filePath = path.join(__dirname, '../data', botId, 'autoreply.json');
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify({}, null, 2));
    }
    return JSON.parse(fs.readFileSync(filePath));
}

function saveAutoReplies(botId, data) {
    const filePath = path.join(__dirname, '../data', botId, 'autoreply.json');
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

// Load or create group settings (e.g. allowGroupReplies)
function loadSettings(botId) {
    const filePath = path.join(__dirname, '../data', botId, 'settings.json');
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify({ groupReplies: false }, null, 2));
    }
    return JSON.parse(fs.readFileSync(filePath));
}

function saveSettings(botId, settings) {
    const filePath = path.join(__dirname, '../data', botId, 'settings.json');
    fs.writeFileSync(filePath, JSON.stringify(settings, null, 2));
}

// Handle .autoreply command (add/remove/list/group)
async function handleAutoReplyCommand(sock, chatId, message, botId) {
    const rawText = message.message?.conversation?.trim() ||
        message.message?.extendedTextMessage?.text?.trim() || '';

    const args = rawText.match(/(?:[^\s"]+|"[^"]*")+/g)?.map(arg => arg.replace(/(^"|"$)/g, '')) || [];

    if (args.length < 2) {
        await sock.sendMessage(chatId, {
            text: "Usage:\n.autoreply add \"[keyword(s)]\" [response]\n.autoreply remove \"[keyword]\"\n.autoreply list\n.autoreply group on/off",
        });
        return;
    }

    const subCommand = args[1].toLowerCase();

    switch (subCommand) {
        case 'add':
            if (args.length < 4) {
                await sock.sendMessage(chatId, {
                    text: "Usage: .autoreply add \"[keyword or multiple keywords]\" [response]",
                });
                return;
            }

            const keywordAdd = args[2].toLowerCase().trim();
            const response = args.slice(3).join(' ');

            const dataAdd = loadAutoReplies(botId);
            dataAdd[keywordAdd] = response;
            saveAutoReplies(botId, dataAdd);

            await sock.sendMessage(chatId, {
                text: `✅ Added auto-reply for keyword(s): *${keywordAdd}*`,
            });
            break;

        case 'remove':
            if (args.length < 3) {
                await sock.sendMessage(chatId, {
                    text: "Usage: .autoreply remove \"[keyword or multi-keyword]\"",
                });
                return;
            }

            const keywordRemove = args[2].toLowerCase().trim();
            const dataRemove = loadAutoReplies(botId);

            if (dataRemove.hasOwnProperty(keywordRemove)) {
                delete dataRemove[keywordRemove];
                saveAutoReplies(botId, dataRemove);
                await sock.sendMessage(chatId, {
                    text: `✅ Removed auto-reply for keyword(s): *${keywordRemove}*`,
                });
            } else {
                await sock.sendMessage(chatId, {
                    text: `❌ No auto-reply found for keyword(s): *${keywordRemove}*`,
                });
            }
            break;

        case 'list':
            const data = loadAutoReplies(botId);
            if (Object.keys(data).length === 0) {
                await sock.sendMessage(chatId, {
                    text: "📭 No auto-replies set yet.",
                });
                return;
            }
            let reply = "📋 Current Auto-Replies:\n";
            for (let key in data) {
                const formatted = key.split('|').map(k => `"${k}"`).join(', ');
                reply += `\n• ${formatted} → ${data[key]}`;
            }
            await sock.sendMessage(chatId, { text: reply });
            break;

        case 'group':
            if (args.length < 3 || !['on', 'off'].includes(args[2].toLowerCase())) {
                await sock.sendMessage(chatId, {
                    text: "Usage: .autoreply group on/off",
                });
                return;
            }
            const settings = loadSettings(botId);
            const value = args[2].toLowerCase() === 'on';
            settings.groupReplies = value;
            saveSettings(botId, settings);

            await sock.sendMessage(chatId, {
                text: `🛠️ Group auto-replies are now *${value ? 'ENABLED' : 'DISABLED'}*.`,
            });
            break;

        default:
            await sock.sendMessage(chatId, {
                text: "Invalid sub-command. Use: add, remove, list, or group",
            });
            break;
    }
}

// Check auto-replies for groups (respects group toggle)
async function checkAutoReply(sock, chatId, message, userMessage, botId) {
    if (!message.key.remoteJid.endsWith('@g.us')) return false;

    const settings = loadSettings(botId);
    if (!settings.groupReplies) return false; // group replies turned off

    const data = loadAutoReplies(botId);
    const lowerMessage = userMessage.toLowerCase();

    for (let keywordGroup in data) {
        const keywords = keywordGroup.split('|').map(k => k.trim());
        for (let keyword of keywords) {
            if (lowerMessage.includes(keyword)) {
                await sock.sendMessage(chatId, {
                    text: data[keywordGroup],
                });
                return true;
            }
        }
    }
    return false;
}

// Check auto-replies in private chat (always allowed)
async function checkPrivateAutoReply(sock, chatId, message, userMessage, botId) {
    const data = loadAutoReplies(botId);
    const lowerMessage = userMessage.toLowerCase();

    for (let keywordGroup in data) {
        const keywords = keywordGroup.split('|').map(k => k.trim());
        for (let keyword of keywords) {
            if (lowerMessage.includes(keyword)) {
                await sock.sendMessage(chatId, {
                    text: data[keywordGroup],
                });
                return true;
            }
        }
    }
    return false;
}

module.exports = {
    handleAutoReplyCommand,
    checkAutoReply,
    checkPrivateAutoReply
};