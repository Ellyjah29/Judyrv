const QRCode = require('qrcode');

async function qrCommand(sock, chatId, message, botId) {
    const input = message.trim().split(' ').slice(1);

    if (!input.length) {
        return sock.sendMessage(chatId, {
            text: '❌ Please provide text or a URL to generate a QR code.\n\nExample:\n`!qr https://example.com`\n\nCustomize:\n`!qr --size 400 --dark #0000FF --light #FFFF00 Hello world!`',
        });
    }

    // Default options
    let size = 300;
    let dark = '#000000';
    let light = '#FFFFFF';

    // Extract flags
    const args = [];
    for (let i = 0; i < input.length; i++) {
        const word = input[i];
        if (word === '--size' && input[i + 1]) {
            const parsed = parseInt(input[i + 1]);
            if (!isNaN(parsed) && parsed >= 100 && parsed <= 1000) {
                size = parsed;
            }
            i++;
        } else if (word === '--dark' && input[i + 1]) {
            dark = input[i + 1];
            i++;
        } else if (word === '--light' && input[i + 1]) {
            light = input[i + 1];
            i++;
        } else {
            args.push(word);
        }
    }

    const qrText = args.join(' ').trim();

    if (!qrText) {
        return sock.sendMessage(chatId, {
            text: '❌ You need to provide the text to encode after the flags.',
        });
    }

    try {
        // Generate QR code as buffer (no need to save to disk)
        const qrBuffer = await QRCode.toBuffer(qrText, {
            width: size,
            color: { dark, light }
        });

        await sock.sendMessage(chatId, {
            image: qrBuffer,
            caption: `✅ QR Code Generated!\n\n🔹 Size: ${size}px\n🔹 Dark: ${dark}\n🔹 Light: ${light}`
        });

    } catch (error) {
        console.error('QR Generation Error:', error.stack || error);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to generate QR code. Please check your input and try again.',
        });
    }
}

module.exports = { qrCommand };