const { setFakeMode, getFakeMode } = require('../lib/presenceState');

async function sendFakeTyping(sock, chatId) {
    await sock.sendPresenceUpdate('composing', chatId);
    setTimeout(() => sock.sendPresenceUpdate('paused', chatId), 3000);
}

async function sendFakeRecording(sock, chatId) {
    await sock.sendPresenceUpdate('recording', chatId);
    setTimeout(() => sock.sendPresenceUpdate('paused', chatId), 4000);
}

async function sendAutoTypeAndRecord(sock, chatId) {
    await sock.sendPresenceUpdate('composing', chatId);
    setTimeout(async () => {
        await sock.sendPresenceUpdate('recording', chatId);
    }, 2000);
    setTimeout(() => {
        sock.sendPresenceUpdate('paused', chatId);
    }, 6000);
}

// Handle `.fake [typing/recording/typerecord]`
async function handleFakeCommand(sock, chatId, command, botId) {
    const validCommands = ['typing', 'recording', 'typerecord'];

    if (!validCommands.includes(command)) {
        await sock.sendMessage(chatId, {
            text: "Usage: .fake [typing/recording/typerecord]"
        });
        return;
    }

    // Save fake mode for this bot
    setFakeMode(botId, false, command); // Only store the type

    let replyText = '';
    switch (command) {
        case 'typing':
            replyText = '✅ Typing indicator selected!';
            break;
        case 'recording':
            replyText = '🎙️ Recording indicator selected!';
            break;
        case 'typerecord':
            replyText = '✍️ + 🎙️ Typing & recording selected!';
            break;
    }

    await sock.sendMessage(chatId, { text: replyText });
}

// Trigger fake presence if fakemode is ON
async function triggerAutoFakePresence(sock, chatId, botId) {
    const { active, type } = getFakeMode(botId);

    if (!active || !type) return;

    switch (type) {
        case 'typing':
            await sock.sendPresenceUpdate('composing', chatId);
            break;
        case 'recording':
            await sock.sendPresenceUpdate('recording', chatId);
            break;
        case 'typerecord':
            await sock.sendPresenceUpdate('composing', chatId);
            setTimeout(async () => {
                await sock.sendPresenceUpdate('recording', chatId);
            }, 2000);
            setTimeout(() => {
                sock.sendPresenceUpdate('paused', chatId);
            }, 6000);
            break;
    }
}

// Handle `.fakemode on/off`
async function handleFakeModeCommand(sock, chatId, message, botId) {
    const args = message.message?.conversation?.trim().split(' ') ||
                 message.message?.extendedTextMessage?.text?.trim().split(' ') || [];

    if (args.length < 2) {
        await sock.sendMessage(chatId, {
            text: "Usage: .fakemode [on/off]"
        });
        return;
    }

    const mode = args[1].toLowerCase();

    if (mode === 'on') {
        const currentState = getFakeMode(botId);

        if (!currentState.type) {
            await sock.sendMessage(chatId, {
                text: "❌ Please use `.fake [typing/recording/typerecord]` first to select type!"
            });
            return;
        }

        setFakeMode(botId, true, currentState.type);
        await sock.sendMessage(chatId, {
            text: "🔁 Auto fake presence is now ON"
        });

    } else if (mode === 'off') {
        setFakeMode(botId, false, null);
        await sock.sendMessage(chatId, {
            text: "🛑 Auto fake presence is OFF"
        });
    } else {
        await sock.sendMessage(chatId, {
            text: "Usage: .fakemode [on/off]"
        });
    }
}

module.exports = {
    handleFakeCommand,
    handleFakeModeCommand,
    triggerAutoFakePresence
};