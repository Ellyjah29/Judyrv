// ✅ notesAI.js
const axios = require('axios');
const { loadChatHistory, saveNote } = require('./ai_notes');

const OPENROUTER_API_KEY = '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';
const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const MODEL_NAME = 'meta-llama/llama-3-8b-instruct';

async function sendGptQuery(sock, chatId, query, botId, sender) {
    if (!query || query.trim().length === 0) {
        await sock.sendMessage(chatId, {
            text: "❌ Please provide a question after .gpt"
        });
        return;
    }

    try {
        const history = await loadChatHistory(botId, chatId);

        // ✅ Always use Nigerian time
        const nowDate = new Date().toLocaleString('en-NG', {
            timeZone: 'Africa/Lagos',
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            hour12: true
        });

        const messages = [
            { role: "system", content: `You are a helpful assistant. Today is ${nowDate}.` },
            ...history,
            { role: "user", content: `${query} (Asked at ${nowDate})` }
        ];

        const response = await axios.post(
            OPENROUTER_API_URL,
            {
                model: MODEL_NAME,
                messages: messages,
                max_tokens: 600,
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const result = response.data.choices[0].message.content;

        await saveNote(sock, chatId, 'bot', result, botId);

        // ✅ Send AI response with AI icon
await sock.sendMessage(chatId, { text: result, ai: true });

    } catch (error) {
        console.error(`[AI ERROR]`, error.message);
        await sock.sendMessage(chatId, {
            text: "❌ Failed to get AI response."
        });
    }
}

module.exports = {
    sendGptQuery
};