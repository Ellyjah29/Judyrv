const fs = require('fs');
const path = require('path');

const dataFilePath = path.join(__dirname, '..', 'data', 'messageCount.json');

// Load message counts from file (returns {} if file doesn't exist or is broken)
function loadMessageCounts() {
    try {
        if (!fs.existsSync(dataFilePath)) return {};
        const data = fs.readFileSync(dataFilePath, 'utf-8');
        return JSON.parse(data || '{}');
    } catch (error) {
        console.error("⚠️ Failed to load message counts:", error);
        return {};
    }
}

// Save updated counts to file
function saveMessageCounts(counts) {
    try {
        fs.writeFileSync(dataFilePath, JSON.stringify(counts, null, 2));
    } catch (error) {
        console.error("❌ Failed to save message counts:", error);
    }
}

// Increments message count per user in a group
function incrementMessageCount(groupId, userId) {
    const counts = loadMessageCounts();

    if (!counts[groupId]) counts[groupId] = {};
    if (!counts[groupId][userId]) counts[groupId][userId] = 0;

    counts[groupId][userId] += 1;

    saveMessageCounts(counts);
}

// Command: Display top 5 active members
async function topMembers(sock, chatId, isGroup) {
    if (!isGroup) {
        await sock.sendMessage(chatId, { text: '❌ This command only works in groups.' });
        return;
    }

    const counts = loadMessageCounts();
    const groupCounts = counts[chatId] || {};

    const sorted = Object.entries(groupCounts)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5);

    if (sorted.length === 0) {
        await sock.sendMessage(chatId, { text: 'No message activity tracked in this group yet.' });
        return;
    }

    const mentionList = sorted.map(([userId]) => userId);
    const message = [
        '*📊 SEPTORCH Activity Tracker*',
        '🏆 *Top 5 Most Active Members*:\n',
        ...sorted.map(([id, count], i) =>
            `${i + 1}. @${id.split('@')[0]} - *${count}* messages`
        )
    ].join('\n');

    await sock.sendMessage(chatId, {
        text: message,
        mentions: mentionList
    });
}

module.exports = {
    incrementMessageCount,
    topMembers
};