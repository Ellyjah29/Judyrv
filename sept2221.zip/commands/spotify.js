const axios = require('axios');
const cheerio = require('cheerio');
const WebTorrent = require('webtorrent');
const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegStatic = require('ffmpeg-static');

// Set FFmpeg path from ffmpeg-static
ffmpeg.setFfmpegPath(ffmpegStatic);

// TMDb API key (hardcoded as requested)
const TMDB_API_KEY = 'f5f7a63fee75dcc18f2653353b3050df';

/**
 * Handles the movie download command for the WhatsApp bot.
 * @param {Object} sock - WhatsApp socket connection (Baileys)
 * @param {string} chatId - Chat ID to send messages to
 * @param {Object} message - Incoming message object
 */
async function movieCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        if (!text) {
            return await sock.sendMessage(chatId, { text: "Please provide a movie name (e.g., 'Metropolis 1927')." });
        }

        // Parse quality and year from the command
        let quality = '480'; // Default to 480p for smaller files
        let searchQuery = text.split(' ').slice(1).join(' ').trim();
        let releaseYear = null;
        const qualityMatch = searchQuery.match(/quality:(\w+)/);
        if (qualityMatch) {
            quality = qualityMatch[1];
            searchQuery = searchQuery.replace(/quality:\w+/, '').trim();
        }
        const yearMatch = searchQuery.match(/\b(19\d{2}|20\d{2})\b/);
        if (yearMatch) {
            releaseYear = yearMatch[0];
            searchQuery = searchQuery.replace(/\b(19\d{2}|20\d{2})\b/, '').trim();
        }

        // Validate quality
        const supportedQualities = ['360', '480', '720'];
        if (!supportedQualities.includes(quality)) {
            return await sock.sendMessage(chatId, {
                text: `Invalid quality. Please choose one of: ${supportedQualities.join(', ')}.`
            });
        }

        // Search TMDb for metadata
        let videoTitle = searchQuery;
        let videoDescription = 'No description available.';
        try {
            const tmdbResponse = await axios.get(`https://api.themoviedb.org/3/search/movie`, {
                params: {
                    api_key: TMDB_API_KEY,
                    query: searchQuery,
                    year: releaseYear,
                    include_adult: false
                },
                timeout: 5000 // 5-second timeout for TMDb
            });
            const movie = tmdbResponse.data.results[0];
            if (movie) {
                videoTitle = movie.title;
                videoDescription = movie.overview || videoDescription;
                console.log(`TMDb found: ${videoTitle} (${movie.release_date})`);
            } else {
                console.warn('No TMDb results; using raw query for Public Domain Torrents.');
                await sock.sendMessage(chatId, { text: "No TMDb results found; searching Public Domain Torrents directly." });
            }
        } catch (error) {
            console.error(`TMDb search failed: ${error.message}`);
            await sock.sendMessage(chatId, { text: "TMDb metadata unavailable; searching Public Domain Torrents directly." });
        }

        // Construct URL for Public Domain Torrents
        const movieTitleForUrl = (releaseYear ? `${videoTitle} ${releaseYear}` : videoTitle)
            .replace(/[^a-zA-Z0-9]/g, '-').toLowerCase();
        // Try direct movie page first, then fallback to search page
        let torrentUrl = `http://publicdomaintorrents.info/noreg/all/${movieTitleForUrl}.html`;
        let magnetLink = null;
        try {
            console.log(`Fetching movie page: ${torrentUrl}`);
            let response = await axios.get(torrentUrl, { timeout: 10000 });
            let $ = cheerio.load(response.data);
            // Try multiple selectors for magnet link (adjust after inspecting site)
            magnetLink = $('a[href^="magnet:"]').first().attr('href') ||
                         $('a.magnet-link').first().attr('href') ||
                         $('a:contains("Magnet")').first().attr('href') ||
                         $('a:contains("Download Magnet")').first().attr('href');
            if (!magnetLink || !magnetLink.startsWith('magnet:')) {
                // Fallback to search page
                console.log('No magnet link found on movie page; trying search page...');
                torrentUrl = `http://publicdomaintorrents.info/search?query=${encodeURIComponent(movieTitleForUrl)}`;
                response = await axios.get(torrentUrl, { timeout: 10000 });
                $ = cheerio.load(response.data);
                // Find movie link in search results (adjust selector based on site)
                const movieLink = $('a:contains("' + videoTitle + '")').first().attr('href') ||
                                 $('a[href*="' + movieTitleForUrl + '"]').first().attr('href');
                if (!movieLink) {
                    throw new Error('No movie found in search results');
                }
                // Fetch the movie page from search results
                const moviePageUrl = movieLink.startsWith('http') ? movieLink : `http://publicdomaintorrents.info${movieLink}`;
                response = await axios.get(moviePageUrl, { timeout: 10000 });
                $ = cheerio.load(response.data);
                magnetLink = $('a[href^="magnet:"]').first().attr('href') ||
                             $('a.magnet-link').first().attr('href') ||
                             $('a:contains("Magnet")').first().attr('href') ||
                             $('a:contains("Download Magnet")').first().attr('href');
                if (!magnetLink || !magnetLink.startsWith('magnet:')) {
                    throw new Error('No valid magnet link found on the page');
                }
            }
            console.log(`Found magnet link: ${magnetLink}`);
        } catch (error) {
            console.error(`Error fetching movie page: ${error.message}`);
            const popcornflixSearchUrl = `https://www.popcornflix.com/search?query=${encodeURIComponent(videoTitle)}`;
            return await sock.sendMessage(chatId, {
                text: `Could not find "${videoTitle}" on Public Domain Torrents: ${error.message}. Try a specific query (e.g., 'Nosferatu 1922') or stream it on Popcornflix: ${popcornflixSearchUrl}. Alternatively, visit https://www.openculture.com/freemedia for free movies.`
            });
        }

        // Download movie using webtorrent
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        const tempFile = path.join(tempDir, `${Date.now()}_raw.mp4`);
        const outputFile = path.join(tempDir, `${Date.now()}_processed.mp4`);
        let client = new WebTorrent();
        try {
            console.log(`Downloading movie via torrent...`);
            await new Promise((resolve, reject) => {
                client.add(magnetLink, { path: tempDir }, (torrent) => {
                    // Set a timeout for torrent download (5 minutes)
                    const downloadTimeout = setTimeout(() => {
                        client.destroy();
                        reject(new Error('Torrent download timed out after 5 minutes'));
                    }, 5 * 60 * 1000);

                    torrent.on('done', () => {
                        clearTimeout(downloadTimeout);
                        const file = torrent.files.find(file => file.name.toLowerCase().endsWith('.mp4'));
                        if (file) {
                            file.getBuffer((err, buffer) => {
                                if (err) {
                                    reject(err);
                                    return;
                                }
                                fs.writeFileSync(tempFile, buffer);
                                resolve();
                            });
                        } else {
                            reject(new Error('No MP4 file found in torrent'));
                        }
                    });
                    torrent.on('error', (err) => {
                        clearTimeout(downloadTimeout);
                        reject(err);
                    });
                });
            });
            client.destroy(); // Clean up WebTorrent client
            client = null;

            // Check file size
            const stats = fs.statSync(tempFile);
            if (stats.size < 100000) {
                throw new Error(`Downloaded file too small (${stats.size} bytes)`);
            }
        } catch (error) {
            console.error(`Torrent download failed: ${error.message}`);
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            if (client) client.destroy();
            const popcornflixSearchUrl = `https://www.popcornflix.com/search?query=${encodeURIComponent(videoTitle)}`;
            return await sock.sendMessage(chatId, {
                text: `Failed to download "${videoTitle}" from Public Domain Torrents: ${error.message}. Try a specific query (e.g., 'Nosferatu 1922') or stream it on Popcornflix: ${popcornflixSearchUrl}. Alternatively, visit https://www.openculture.com/freemedia for free movies.`
            });
        }

        // Estimate duration for bitrate calculation
        let duration = 3600; // Default to 1 hour if unknown
        try {
            const metadata = await new Promise((resolve, reject) => {
                ffmpeg.ffprobe(tempFile, (err, metadata) => {
                    if (err) reject(err);
                    else resolve(metadata);
                });
            });
            duration = metadata.format.duration || 3600;
        } catch (error) {
            console.warn(`ffprobe failed, using default duration: ${error.message}`);
        }

        // Calculate bitrate for 100MB WhatsApp document limit
        const maxFileSizeBits = 100 * 8 * 1024 * 1024; // 100MB in bits
        const audioBitrate = 128; // 128kbps for audio
        const audioBits = audioBitrate * 1000 * duration;
        let videoBitrate = Math.floor((maxFileSizeBits - audioBits) / (duration * 1000));
        if (videoBitrate > 2000) videoBitrate = 2000; // Cap at 2000kbps
        if (videoBitrate < 500) videoBitrate = 500; // Minimum 500kbps
        console.log(`Calculated video bitrate: ${videoBitrate}kbps for ${duration}s`);

        // Check if downloaded video is WhatsApp-compatible
        try {
            const metadata = await new Promise((resolve, reject) => {
                ffmpeg.ffprobe(tempFile, (err, metadata) => {
                    if (err) reject(err);
                    else resolve(metadata);
                });
            });

            const videoStream = metadata.streams.find(s => s.codec_type === 'video');
            const audioStream = metadata.streams.find(s => s.codec_type === 'audio');
            const fileSize = fs.statSync(tempFile).size;

            if (fileSize < 100000000 && 
                videoStream && audioStream && 
                videoStream.codec_name === 'h264' && 
                audioStream.codec_name === 'aac' && 
                metadata.format.format_name.includes('mp4')) {
                console.log(`Video is already compatible. Sending as document.`);
                await sock.sendMessage(chatId, {
                    document: { url: tempFile },
                    fileName: `${videoTitle.replace(/[^a-zA-Z0-9]/g, '_')}.mp4`,
                    mimetype: 'video/mp4',
                    caption: `🎬 *${videoTitle}* (${quality}p)\n${videoDescription}`
                });
                if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
                return;
            }
        } catch (error) {
            console.error(`ffprobe failed: ${error.message}`);
        }

        // Re-encode video for WhatsApp compatibility
        try {
            console.log(`Re-encoding video for WhatsApp compatibility...`);
            await new Promise((resolve, reject) => {
                const ffmpegCmd = ffmpeg(tempFile)
                    .videoCodec('libx264')
                    .audioCodec('aac')
                    .videoBitrate(`${videoBitrate}k`)
                    .audioBitrate('128k')
                    .outputOptions([
                        '-preset ultrafast',
                        '-movflags +faststart',
                        '-max_muxing_queue_size 1024',
                        '-map 0:v:0',
                        '-map 0:a:0?',
                        '-c:a aac',
                        '-ar 44100',
                        '-ac 2'
                    ]);

                if (quality === '720') {
                    ffmpegCmd.size('1280x720');
                } else if (quality === '480') {
                    ffmpegCmd.size('854x480');
                } else if (quality === '360') {
                    ffmpegCmd.size('640x360');
                }

                ffmpegCmd
                    .output(outputFile)
                    .on('end', resolve)
                    .on('error', err => {
                        console.error(`FFmpeg error: ${err.message}`);
                        reject(new Error(`Re-encoding failed: ${err.message}`));
                    })
                    .run();
            });

            // Verify re-encoded file
            let stats = fs.statSync(outputFile);
            if (stats.size < 100000) {
                throw new Error(`Re-encoded file too small (${stats.size} bytes)`);
            }
            if (stats.size > 100000000) {
                console.warn(`File size (${stats.size} bytes) exceeds WhatsApp document limit. Compressing...`);
                const compressedFile = path.join(tempDir, `${Date.now()}_compressed.mp4`);
                await new Promise((resolve, reject) => {
                    ffmpeg(outputFile)
                        .size('640x360')
                        .videoCodec('libx264')
                        .audioCodec('aac')
                        .videoBitrate('500k')
                        .audioBitrate('64k')
                        .outputOptions([
                            '-preset ultrafast',
                            '-movflags +faststart',
                            '-max_muxing_queue_size 1024',
                            '-map 0:v:0',
                            '-map 0:a:0?',
                            '-c:a aac',
                            '-ar 44100',
                            '-ac 2'
                        ])
                        .output(compressedFile)
                        .on('end', () => {
                            fs.unlinkSync(outputFile);
                            fs.renameSync(compressedFile, outputFile);
                            resolve();
                        })
                        .on('error', err => {
                            console.error(`FFmpeg compression error: ${err.message}`);
                            reject(new Error(`Compression failed: ${err.message}`));
                        })
                        .run();
                });
            }

            // Send as document
            await sock.sendMessage(chatId, {
                document: { url: outputFile },
                fileName: `${videoTitle.replace(/[^a-zA-Z0-9]/g, '_')}.mp4`,
                mimetype: 'video/mp4',
                caption: `🎬 *${videoTitle}* (${quality}p)\n${videoDescription}`
            });

            // Clean up
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
        } catch (error) {
            console.error(`Processing failed: ${error.message}`);
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
            const popcornflixSearchUrl = `https://www.popcornflix.com/search?query=${encodeURIComponent(videoTitle)}`;
            return await sock.sendMessage(chatId, {
                text: `Processing failed: ${error.message}. Try a specific query (e.g., 'Nosferatu 1922') or stream it on Popcornflix: ${popcornflixSearchUrl}. Alternatively, visit https://www.openculture.com/freemedia for free movies.`
            });
        }
    } catch (error) {
        console.error(`Error in movieCommand: ${error.message}`);
        const popcornflixSearchUrl = `https://www.popcornflix.com/search?query=${encodeURIComponent(videoTitle || searchQuery)}`;
        return await sock.sendMessage(chatId, {
            text: `An error occurred: ${error.message}. Please try again with a specific query (e.g., 'Nosferatu 1922') or stream it on Popcornflix: ${popcornflixSearchUrl}. Alternatively, visit https://www.openculture.com/freemedia for free movies.`
        });
    }
}

module.exports = movieCommand;