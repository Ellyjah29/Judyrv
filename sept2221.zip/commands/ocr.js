const fs = require('fs');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { downloadMediaMessage } = require('baileys');

function ensureTmpDir() {
    const tmpDir = path.join(__dirname, '../tmp');
    if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
    }
    return tmpDir;
}

async function ocrCommand(sock, chatId, message, botId) {
    try {
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const contextInfo = message.message?.extendedTextMessage?.contextInfo;

        if (!quoted) {
            return await sock.sendMessage(chatId, {
                text: '❌ Please reply to an image to extract text.'
            });
        }

        const mediaType = Object.keys(quoted).find(type => ['imageMessage'].includes(type));
        if (!mediaType) {
            return await sock.sendMessage(chatId, {
                text: '❌ Unsupported media type. Only images are supported.'
            });
        }

        const mediaMsg = {
            key: {
                remoteJid: chatId,
                id: contextInfo?.stanzaId,
                fromMe: false,
                participant: contextInfo?.participant
            },
            message: quoted
        };

        const mediaBuffer = await downloadMediaMessage(mediaMsg, 'buffer', {}, { reuploadRequest: sock });

        const mimeType = quoted[mediaType]?.mimetype || 'image/jpeg';
        const ext = mimeType.split('/')[1]?.split(';')[0] || 'jpg';

        const tmpDir = ensureTmpDir();
        const filePath = path.join(tmpDir, `ocr_image_${Date.now()}.${ext}`);
        fs.writeFileSync(filePath, mediaBuffer);

        const formData = new FormData();
        formData.append('file', fs.createReadStream(filePath));
        formData.append('apikey', 'helloworld'); // Free OCR.space demo key

        const response = await axios.post('https://api.ocr.space/parse/image', formData, {
            headers: formData.getHeaders()
        });

        fs.unlinkSync(filePath); // Clean up

        const parsedText = response.data.ParsedResults?.[0]?.ParsedText?.trim();

        if (parsedText && parsedText.length > 0) {
            if (parsedText.length > 1024) {
                const outputPath = path.join(tmpDir, `ocr_result_${Date.now()}.txt`);
                fs.writeFileSync(outputPath, parsedText);
                await sock.sendMessage(chatId, {
                    document: fs.readFileSync(outputPath),
                    mimetype: 'text/plain',
                    fileName: 'ocr_result.txt'
                });
                fs.unlinkSync(outputPath);
            } else {
                await sock.sendMessage(chatId, {
                    text: `✅ Extracted Text:\n\n${parsedText}`
                });
            }
        } else {
            await sock.sendMessage(chatId, {
                text: '⚠️ No readable text found in the image.'
            });
        }

    } catch (error) {
        console.error('❌ OCR.space Error:', error.stack || error.message);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to process image. Try again later.'
        });
    }
}

module.exports = { ocrCommand };