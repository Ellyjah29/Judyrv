let aiMode = {}; // { botId: boolean }

// 📌 Get AI Mode
function getAiMode(botId) {
    return aiMode[botId] || false;
}

// 📌 Set AI Mode
function setAiMode(botId, enabled) {
    aiMode[botId] = enabled;
}

// 🔰 Bot-style message formatter
const box = (title, lines) => [
  `╭━━━[ *🤖 ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

const sendBox = (sock, chatId, title, lines) =>
  sock.sendMessage(chatId, { text: box(title, lines) });

/**
 * Handle AI Mode Toggle
 * @param {object} sock - WhatsApp socket
 * @param {string} chatId - Group or user JID
 * @param {string[]} args - Command arguments
 * @param {string} botId - Unique bot identifier
 */
async function handleAiToggle(sock, chatId, args, botId) {
    if (!args || args.length < 2) {
        return sendBox(sock, chatId, 'Notes AI', [
            '⚠️  Usage:',
            '.notes on   – Enable AI Notes',
            '.notes off  – Disable AI Notes'
        ]);
    }

    const toggle = args[1].toLowerCase();

    if (toggle === 'on') {
        setAiMode(botId, true);
        return sendBox(sock, chatId, 'Notes AI', [
            '✅  AI Mode has been *enabled*!'
        ]);
    }

    if (toggle === 'off') {
        setAiMode(botId, false);
        return sendBox(sock, chatId, 'Notes AI', [
            '🛑  AI Mode has been *disabled*!'
        ]);
    }

    return sendBox(sock, chatId, 'Notes AI', [
        '❌  Invalid option. Use `.notes on` or `.notes off`'
    ]);
}

module.exports = {
    getAiMode,
    setAiMode,
    handleAiToggle
};