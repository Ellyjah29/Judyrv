const mathGames = new Map();

const difficulties = {
    noob: { ops: ['+', '-'], min: 1, max: 10, time: 15000, exp: [300, 600] },
    easy: { ops: ['+', '-', '*'], min: 10, max: 30, time: 20000, exp: [600, 1000] },
    medium: { ops: ['+', '-', '*'], min: 30, max: 70, time: 25000, exp: [1000, 1500] },
    hard: { ops: ['+', '-', '*'], min: 70, max: 120, time: 30000, exp: [1500, 2000] },
    extreme: { ops: ['+', '-', '*', '/'], min: 100, max: 250, time: 35000, exp: [2000, 3000] },
    impossible: { ops: ['+', '-', '*', '/'], min: 200, max: 999, time: 40000, exp: [3000, 5000] }
};

async function mathGameCommand(sock, chatId, message, userMessage, botId) {
    const args = userMessage.slice(1).split(' ').filter(Boolean);
    const difficulty = (args[1] || '').toLowerCase();

    if (!difficulty || !difficulties[difficulty]) {
        return sock.sendMessage(chatId, {
            text: `⚠️ Please choose a valid difficulty.\n\nExamples:\n.math noob\n.math easy\n.math hard\n\nAvailable difficulties:\n${Object.keys(difficulties).map(k => `- ${k}`).join('\n')}`
        });
    }

    const level = difficulties[difficulty];
    const a = Math.floor(Math.random() * (level.max - level.min + 1)) + level.min;
    const b = Math.floor(Math.random() * (level.max - level.min + 1)) + level.min;
    const op = level.ops[Math.floor(Math.random() * level.ops.length)];
    const result = op === '/' ? parseFloat((a / b).toFixed(2)) : eval(`${a}${op}${b}`);
    const reward = Math.floor(Math.random() * (level.exp[1] - level.exp[0] + 1)) + level.exp[0];

    mathGames.set(message.key.participant || chatId, { result, exp: reward, attempts: 3 });

    setTimeout(() => {
        const sender = message.key.participant || chatId;
        if (mathGames.has(sender)) {
            mathGames.delete(sender);
            sock.sendMessage(chatId, {
                text: `⌛ Time's up! The correct answer was: *${result}*`
            });
        }
    }, level.time);

    return sock.sendMessage(chatId, {
        text: `╭┄〔 *Math Game* 〕┄⊱
┆What is the result of: *${a} ${op} ${b} = ?*
┆┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
┆🧭 Time: *${level.time / 1000} seconds*
┆┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
┆Reply to this message and win
┆🏆 *${reward} XP*
╰━━━⊰ 🧠 MathBot ⊱━━━━⊷`
    });
}

// Handle answers before main handler
async function mathAnswerHandler(sock, chatId, message, userMessage, botId) {
    const sender = message.key.participant || chatId;

    if (!mathGames.has(sender)) return;

    const data = mathGames.get(sender);
    const { result, exp, attempts } = data;
    const input = userMessage.trim();
    let correct = false;

    if (String(result).includes('.') || input.includes('.')) {
        correct = parseFloat(input).toFixed(2) === result.toFixed(2);
    } else {
        correct = Number(input) === result;
    }

    if (correct) {
        mathGames.delete(sender);
        // You can add XP logic here if you have a database
        return sock.sendMessage(chatId, {
            text: `✅ Correct! You earned *${exp} XP*`
        });
    } else {
        data.attempts--;
        if (data.attempts <= 0) {
            mathGames.delete(sender);
            return sock.sendMessage(chatId, {
                text: `❌ You failed 3 times. The correct answer was *${result}*`
            });
        } else {
            mathGames.set(sender, data);
            return sock.sendMessage(chatId, {
                text: `❌ Incorrect. You have *${data.attempts}* attempt(s) left.`
            });
        }
    }
}

export { mathGameCommand, mathAnswerHandler };