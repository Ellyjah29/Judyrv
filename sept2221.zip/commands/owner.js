// commands/owner.js
const fs = require('fs');
const path = require('path');

const settingsPath = path.resolve(__dirname, '../settings');
let settings = require(settingsPath);

// 🔄 Watch for changes in settings.js and reload automatically
fs.watch(settingsPath + '.js', (eventType) => {
    if (eventType === 'change') {
        try {
            delete require.cache[require.resolve(settingsPath)];
            settings = require(settingsPath);
            console.log('♻️ settings.js reloaded automatically');
        } catch (err) {
            console.error('❌ Failed to reload settings.js:', err);
        }
    }
});

async function ownerCommand(sock, chatId, botId) {
    try {
        // Extract numeric part from "bot1" → "1"
        const match = botId.match(/bot(\d+)/);
        if (!match) {
            await sock.sendMessage(chatId, {
                text: '❌ Invalid bot ID format. Expected format: "bot1", "bot2", etc.'
            });
            return;
        }

        // Convert to 0-based index (bot1 → index 0)
        const index = parseInt(match[1]) - 1;

        // Validate index
        if (index < 0 || index >= settings.bots.length) {
            await sock.sendMessage(chatId, {
                text: `❌ Bot configuration not found for ID ${index + 1}. Max bots: ${settings.bots.length}`
            });
            return;
        }

        const botConfig = settings.bots[index];
        const ownerNumber = botConfig.ownerNumber?.trim();
        const botName = botConfig.botName || 'Unknown Bot';

        // Validate owner number
        if (!ownerNumber) {
            await sock.sendMessage(chatId, {
                text: `ℹ️ No owner number set for *${botName}*`
            });
            return;
        }

        // Clean number for WhatsApp ID
        const cleanNumber = ownerNumber.replace(/\D/g, '');
        if (!cleanNumber) {
            await sock.sendMessage(chatId, {
                text: '❌ Invalid owner number format.'
            });
            return;
        }

        // Create VCARD
        const vcard = `
BEGIN:VCARD
VERSION:3.0
FN:${botName}'s Owner
ORG:${botName};
TEL;waid=${cleanNumber}:${ownerNumber}
END:VCARD
        `.trim();

        // Send contact
        await sock.sendMessage(chatId, {
            contacts: {
                displayName: `${botName}'s Owner`,
                contacts: [{ vcard }]
            }
        });
    } catch (error) {
        console.error(`❌ Error in ownerCommand for bot ${botId}:`, error);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to send owner contact.'
        });
    }
}

module.exports = ownerCommand;