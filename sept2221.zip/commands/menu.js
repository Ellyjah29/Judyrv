// commands/menu.js
const settings = require('../settings');
const fs = require('fs');
const path = require('path');

// Define command categories
const categories = {
  general: {
    title: '🧰 General',
    commands: [
      '.help - Show this help menu',
      '.menu - Show interactive menu',
      '.bot [question] - Ask AI about the bot (e.g., ".bot how to make a sticker?")',
      '.list - List all commands',
      '.ping - Check bot response time',
      '.alive - Confirm bot is running',
      '.tts <text> - Convert text to speech',
      '.joke - Get a random joke',
      '.quote - Get an inspirational quote',
      '.fact - Get a random fact',
      '.weather <city> - Get weather information',
      '.news - Latest news headlines',
      '.attp <text> - Animated text to picture',
      '.lyrics <song> - Get song lyrics',
      '.8ball <question> - Ask the magic 8-ball',
      '.groupinfo - Group information',
      '.infogp - Group info',
      '.infogrupo - Group details',
      '.staff - List group staff',
      '.admins - Show group admins',
      '.listadmin - Admin list',
      '.🫣 – View Once Message  ➝ Sends a view-once photo/video to your private chat (Saved Messages) 🤫',
      '.vv2 – View Once Message  ➝ Sends a view-once photo/video to your private chat (Saved Messages) 🤫',
      '.vv – View Once Media  ➝ Reveal view-once photos/videos directly in chat 👀',
      '.pair <query> - Pairing information',
      '.rent <query> - Rental information',
      '.trt <lang> <text> - Translate text',
      '.translate <lang> <text> - Text translation',
      '.ss <url> - Take a screenshot',
      '.ssweb <url> - Web screenshot',
      '.screenshot <url> - URL screenshot'
    ]
  },
  admin: {
    title: '⚙️ Admin',
    commands: [
      '.ban @user - Ban a user',
      '.unban @user - Unban a user',
      '.kick @user - Kick a user',
      '.promote @user - Promote to admin',
      '.demote @user - Demote from admin',
      '.mute <minutes> - Mute the group',
      '.unmute - Unmute the group',
      '.delete - Delete a message',
      '.del - Delete a message',
      '.warnings - View user warnings',
      '.warn @user - Warn a user',
      '.antilink on - Enable anti-link',
      '.antilink off - Disable anti-link',
      '.antibadword on - Enable word filter',
      '.antibadword off - Disable word filter',
      '.clear - Clear messages',
      '.tagall - Tag all members',
      '.🔊 <msg> – Silent Message  ➝ Tags users silently (without using @mention) 🤫',
      '.chatbot on - Enable chatbot',
      '.chatbot off - Disable chatbot',
      '.resetlink - Reset group link'
    ]
  },
  owner: {
    title: '👑 Owner',
    commands: [
      '.mode public - Set bot to public mode',
      '.mode private - Set bot to private mode',
      '.autostatus on - Enable auto status',
      '.autostatus off - Disable auto status',
      '.clearsession - Clear bot sessions',
      '.antidelete on - Enable anti-delete',
      '.antidelete off - Disable anti-delete',
      '.cleartmp - Clear temporary files',
      '.setpp - Set profile picture',
      '.autoreact on - Enable auto react',
      '.autoreact off - Disable auto react',
      '.areact on - Auto react enabled',
      '.areact off - Auto react disabled',
      '.autoreply add <trigger> <response> - Add auto reply',
      '.autoreply remove <trigger> - Remove auto reply',
      '.autoreply list - List auto replies',
      '.fake typing - Fake typing status',
      '.fake recording - Fake recording status',
      '.switchfake - Switch fake status mode'
    ]
  },
  utility: {
    title: '🔧 Utility',
    commands: [
      '.ocr - Extract text from image',
      '.bible <verse> - Get a bible verse',
      '.getprofile - Get user profile',
      '.profile - User profile',
      '.welcome on - Enable welcome message',
      '.welcome off - Disable welcome message',
      '.goodbye on - Enable goodbye message',
      '.goodbye off - Disable goodbye message',
      '.urlshort <url> - Shorten a URL',
      '.short <url> - Shorten a URL',
      '.upload - Upload media',
      '.autoStatus on - Auto status on',
      '.autoStatus off - Auto status off',
      '.notes on - Enable AI notes',
      '.notes off - Disable AI notes'
    ]
  },
  stickers: {
    title: '🧩 Stickers & Images',
    commands: [
      '.blur - Blur an image',
      '.simage - Image to sticker',
      '.sticker - Create a sticker',
      '.tgsticker <url> - Telegram sticker',
      '.stickertelegram <url> - Telegram stickers',
      '.meme - Random meme',
      '.take <name> - Custom sticker pack',
      '.emojimix 😄+😍 - Mix two emojis'
    ]
  },
  ai: {
    title: '🤖 AI Tools',
    commands: [
      '.gpt <prompt> - Chat with ChatGPT',
      '.gemini <prompt> - Chat with Gemini',
      '.imagine <idea> - Generate image (Imagine)',
      '.dalle <idea> - Generate image (DALL-E)',
      '.flux <idea> - Generate image (Flux)'
    ]
  },
  fun: {
    title: '🎮 Fun Zone',
    commands: [
      '.compliment @user - Compliment a user',
      '.insult @user - Insult a user',
      '.flirt - Get a flirt message',
      '.shayari - Get a shayari',
      '.goodnight - Goodnight message',
      '.roseday - Rose day message',
      '.character <name> - Get character info',
      '.wasted - Wasted overlay',
      '.ship - Ship two users',
      '.simp @user - Call user a simp',
      '.stupid @user - Call user stupid',
      '.itssostupid @user - "It\'s so stupid"',
      '.iss @user - ISS message'
    ]
  },
  games: {
    title: '🎲 Games',
    commands: [
      '.tictactoe @user - Start Tic-Tac-Toe',
      '.ttt @user - Play Tic-Tac-Toe',
      '.move <1-9> - Make a move',
      '.surrender - Surrender the game',
      '.hangman - Play Hangman',
      '.guess <letter> - Guess a letter',
      '.trivia - Start a trivia question',
      '.answer <ans> - Answer trivia',
      '.riddle - Get a riddle',
      '.mathgame - Math challenge',
      '.mates - Math game',
      '.matemáticas - Math game'
    ]
  },
  downloads: {
    title: '📥 Downloads',
    commands: [
      '.play <name> - Play audio',
      '.song <name> - Download a song',
      '.ytmp3 <song> - YouTube to MP3',
      '.spotify <song> - Spotify download',
      '.music <song> - Music download',
      '.instagram <link> - Instagram download',
      '.facebook <link> - Facebook download',
      '.tiktok <url> - TikTok download',
      '.tt <url> - TikTok video',
      '.threads <url> - Threads download',
      '.thread <url> - Thread download',
      '.threaddl <url> - Thread media',
      '.video <url> - Video download',
      '.ytmp4 <url> - YouTube to MP4'
    ]
  },
  media: {
    title: '🎥 Media Tools',
    commands: [
      '.toMp3 - Convert to MP3',
      '.toaudio - Convert to audio',
      '.viewonce - View once media',
      '.viewonce2 - View once video',
      '.vv - View once media',
      '.vv2 - View once video',
      '.🫣 - View once message'
    ]
  },
  extra: {
    title: '✨ Extra Features',
    commands: [
      '.topmembers - Top active members',
      '.notes <query> - Search chat notes',
      '.summary - Chat summary',
      '.topics - Chat topics',
      '.github - GitHub info',
      '.sc - Source code',
      '.repo - Repository info',
      '.owner - Bot owner info'
    ]
  },
  fonts: {
    title: '🔤 Text Maker (Fonts)',
    commands: [
      '.metallic <text> - Metallic text',
      '.ice <text> - Ice text',
      '.snow <text> - Snow text',
      '.impressive <text> - Impressive text',
      '.matrix <text> - Matrix text',
      '.light <text> - Light text',
      '.neon <text> - Neon text',
      '.devil <text> - Devil text',
      '.purple <text> - Purple text',
      '.thunder <text> - Thunder text',
      '.leaves <text> - Leaves text',
      '.1917 <text> - 1917 style text',
      '.arena <text> - Arena text',
      '.hacker <text> - Hacker text',
      '.sand <text> - Sand text',
      '.blackpink <text> - Blackpink style',
      '.glitch <text> - Glitch text',
      '.fire <text> - Fire text'
    ]
  },
  credits: {
    title: '🏆 Credits',
    commands: [
      '.owner - Bot owner',
      '.credits - Show credits',
      '.channel - Official channel'
    ]
  }
};

// Function to paginate command lists
function paginate(items, perPage = 5) {
  const pages = [];
  for (let i = 0; i < items.length; i += perPage) {
    pages.push(items.slice(i, i + perPage));
  }
  return pages;
}

/**
 * Main menu command handler
 * @param {object} sock - WhatsApp socket instance
 * @param {string} chatId - The chat ID
 * @param {string|null} command - The category command (e.g., 'general', 'admin') or null for main menu
 * @param {number} page - The page number for pagination (0-indexed)
 */
async function menuCommand(sock, chatId, command = null, page = 0) {
  // If no specific command/category is given, show the main menu
  if (!command) {
    // Show main menu with category buttons
    await sock.sendMessage(chatId, {
      text: `*🤖 ${settings.botName || 'SEPTORCH_BOT'} MENU*\n_Select a category below:_`,
      buttons: [
        { buttonId: '.menu general', buttonText: { displayText: '🧰 General' }, type: 1 },
        { buttonId: '.menu admin', buttonText: { displayText: '⚙️ Admin' }, type: 1 },
        { buttonId: '.menu ai', buttonText: { displayText: '🤖 AI Tools' }, type: 1 },
        { buttonId: '.menu downloads', buttonText: { displayText: '📥 Downloads' }, type: 1 },
        { buttonId: '.menu games', buttonText: { displayText: '🎲 Games' }, type: 1 }
      ],
      footer: `${settings.botName || 'SEPTORCH_BOT'} v${settings.version || '1.0.0'}`
    });

    // Second row of buttons for more categories
    await sock.sendMessage(chatId, {
      text: '*More Categories:*',
      buttons: [
        { buttonId: '.menu stickers', buttonText: { displayText: '🧩 Stickers' }, type: 1 },
        { buttonId: '.menu fun', buttonText: { displayText: '🎮 Fun' }, type: 1 },
        { buttonId: '.menu utility', buttonText: { displayText: '🔧 Utility' }, type: 1 },
        { buttonId: '.menu owner', buttonText: { displayText: '👑 Owner' }, type: 1 },
        { buttonId: '.menu credits', buttonText: { displayText: '🏆 Credits' }, type: 1 }
      ]
    });
  } else {
    // Show commands for a specific category
    const key = command.trim().toLowerCase();
    const cat = categories[key];

    // Check if the requested category exists
    if (!cat) {
      await sock.sendMessage(chatId, {
        text: '*❌ Unknown category.* Use .menu to start again.'
      });
      return;
    }

    // Paginate the commands for the selected category (6 commands per page)
    const pages = paginate(cat.commands, 6);
    const pageNum = parseInt(page, 10) || 0;

    // Validate the requested page number
    if (pageNum >= pages.length || pageNum < 0) {
      await sock.sendMessage(chatId, {
        text: '*❌ Invalid page number.* Use .menu to start again.'
      });
      return;
    }

    // Get the current page of commands
    const currentPage = pages[pageNum];
    // Format the message caption
    const caption = `*${cat.title} Commands (${pageNum + 1}/${pages.length}):*\n\n` +
      currentPage.map(cmd => '🔥 ' + cmd).join('\n');

    // Prepare navigation buttons
    const buttons = [];

    // Add "Previous" button if not on the first page
    if (pageNum > 0) {
      buttons.push({
        buttonId: `.menu ${key} ${pageNum - 1}`,
        buttonText: { displayText: '⬅️ Previous' },
        type: 1
      });
    }

    // Add "Next" button if not on the last page
    if (pageNum < pages.length - 1) {
      buttons.push({
        buttonId: `.menu ${key} ${pageNum + 1}`,
        buttonText: { displayText: '➡️ Next' },
        type: 1
      });
    }

    // Always add "Back to Menu" button
    buttons.push({
      buttonId: '.menu',
      buttonText: { displayText: '🔙 Main Menu' },
      type: 1
    });

    // Send the message with the command list and navigation buttons
    await sock.sendMessage(chatId, {
      text: caption,
      buttons: buttons
    });
  }
}

// ✅ CRITICAL FIX: Export both the menuCommand AND categories object
module.exports = {
  menuCommand,
  categories
};