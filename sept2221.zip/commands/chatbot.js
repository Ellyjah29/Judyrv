const fs   = require('fs');
const path = require('path');
const axios = require('axios'); // Using axios for consistency with botAI.js

const USER_GROUP_DATA = path.join(__dirname, '../data/userGroupData.json');

/* ──────────────────────────────────────
   🔰  BOX-STYLE HELPERS
   ────────────────────────────────────── */
const icons = { header:'💬', info:'ℹ️', ok:'✅', off:'🛑', err:'❌', warn:'⚠️' };

const box = (title, lines) => [
  `╭━━━[ *${icons.header} ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

const sendBox = (sock, chatId, title, lines, extra = {}) =>
  sock.sendMessage(chatId, { text: box(title, lines), ...extra });

/* ──────────────────────────────────────
   🗂️  IN-MEMORY CHAT CONTEXT
   ────────────────────────────────────── */
const chatMemory = {
  messages : new Map(),   // last 20 msgs / user
  userInfo : new Map()    // extracted user info
};

/* ──────────────────────────────────────
   📂  LOAD / SAVE GROUP DATA
   ────────────────────────────────────── */
const loadUserGroupData = () => {
  try   { return JSON.parse(fs.readFileSync(USER_GROUP_DATA)); }
  catch { return { groups:[], chatbot:{} }; }
};
const saveUserGroupData = d =>
  fs.writeFileSync(USER_GROUP_DATA, JSON.stringify(d, null, 2));

/* ──────────────────────────────────────
   🕓  TYPING SIMULATION
   ────────────────────────────────────── */
const randDelay = () => Math.floor(Math.random()*3000)+2000;
const showTyping = async (sock, chatId) => {
  try {
    await sock.presenceSubscribe(chatId);
    await sock.sendPresenceUpdate('composing', chatId);
    await new Promise(r => setTimeout(r, randDelay()));
  } catch(e){ console.error('Typing indicator error:', e); }
};

/* ──────────────────────────────────────
   🔍  USER INFO EXTRACTION
   ────────────────────────────────────── */
function extractUserInfo(msg){
  const info={};
  if (/my name is/i.test(msg))
    info.name = msg.split(/my name is/i)[1].trim().split(' ')[0];
  if (/i am .*years old/i.test(msg))
    info.age = msg.match(/\d+/)?.[0];
  if (/i (?:live in|am from)/i.test(msg))
    info.location = msg.split(/i (?:live in|am from)/i)[1]
                      .trim().split(/[.,!?]/)[0];
  return info;
}

/* ──────────────────────────────────────
   ⚙️  .chatbot ON / OFF (FIXED WITH botId PARAMETER)
   ────────────────────────────────────── */
async function handleChatbotCommand(sock, chatId, message, match, botId) {
  // usage box if no sub-command
  if(!match){
    await showTyping(sock, chatId);
    return sendBox(sock, chatId,'Chatbot',[
      `${icons.info}  Usage:`,
      '.chatbot on   – Enable in this group',
      '.chatbot off  – Disable in this group'
    ], { quoted: message });
  }

  const data   = loadUserGroupData();
  const owner  = sock.user.id.split(':')[0]+'@s.whatsapp.net';
  const sender = message.key.participant || message.participant ||
                 message.pushName       || message.key.remoteJid;
  const isOwner = sender === owner;

  /* owners bypass admin checks */
  let isAdmin = false;
  if(!isOwner && chatId.endsWith('@g.us')){
    try{
      const meta = await sock.groupMetadata(chatId);
      isAdmin = meta.participants.some(p =>
        p.id === sender && ['admin','superadmin'].includes(p.admin));
    }catch{ /* ignore */ }
  }
  if(!isOwner && !isAdmin){
    await showTyping(sock, chatId);
    return sendBox(sock, chatId,'Chatbot',[
      `${icons.err}  Only *group admins* or the *bot owner* can use this.`
    ], { quoted: message });
  }

  /* handle on/off */
  const currentlyOn = !!data.chatbot[chatId];

  if(match === 'on'){
    if(currentlyOn){
      await showTyping(sock, chatId);
      return sendBox(sock, chatId,'Chatbot',[`${icons.info}  Already *enabled*.`],{quoted:message});
    }
    data.chatbot[chatId] = true; saveUserGroupData(data);
    console.log(`Chatbot enabled for ${chatId}`);
    await showTyping(sock, chatId);
    return sendBox(sock, chatId,'Chatbot',[`${icons.ok}  Chatbot *enabled* for this group.`],{quoted:message});
  }

  if(match === 'off'){
    if(!currentlyOn){
      await showTyping(sock, chatId);
      return sendBox(sock, chatId,'Chatbot',[`${icons.info}  Already *disabled*.`],{quoted:message});
    }
    delete data.chatbot[chatId]; saveUserGroupData(data);
    console.log(`Chatbot disabled for ${chatId}`);
    await showTyping(sock, chatId);
    return sendBox(sock, chatId,'Chatbot',[`${icons.off}  Chatbot *disabled* for this group.`],{quoted:message});
  }

  await showTyping(sock, chatId);
  return sendBox(sock, chatId,'Chatbot',[`${icons.err}  Invalid option.`],{quoted:message});
}

/* ──────────────────────────────────────
   🔧 DETECT COMMAND INTENT (same as botAI.js)
   ────────────────────────────────────── */
function detectCommandIntent(query) {
  const q = query.toLowerCase();

  if (/play|song|music/.test(q)) return { action: 'execute', command: 'play', args: q.replace(/play|song|music/, '').trim() };
  if (/joke/.test(q)) return { action: 'execute', command: 'joke', args: '' };
  if (/fact/.test(q)) return { action: 'execute', command: 'fact', args: '' };
  if (/quote/.test(q)) return { action: 'execute', command: 'quote', args: '' };
  if (/news/.test(q)) return { action: 'execute', command: 'news', args: '' };
  if (/bible/.test(q)) return { action: 'execute', command: 'bible', args: q.replace(/bible/, '').trim() };
  if (/riddle/.test(q)) return { action: 'execute', command: 'riddle', args: '' };
  if (/weather/.test(q)) return { action: 'execute', command: 'weather', args: q.replace(/weather/, '').trim() };
  if (/lyrics/.test(q)) return { action: 'execute', command: 'lyrics', args: q.replace(/lyrics/, '').trim() };
  if (/sticker/.test(q)) return { action: 'execute', command: 'sticker', args: '' };
  if (/meme/.test(q)) return { action: 'execute', command: 'meme', args: '' };
  if (/tts|speak/.test(q)) return { action: 'execute', command: 'tts', args: q.replace(/tts|speak/, '').trim() };
  if (/imagine|generate image|ai art/.test(q)) return { action: 'execute', command: 'imagine', args: q.replace(/imagine|generate image|ai art/, '').trim() };
  if (/tiktok/.test(q)) return { action: 'execute', command: 'tiktok', args: q };
  if (/instagram|ig/.test(q)) return { action: 'execute', command: 'instagram', args: q };
  if (/facebook|fb/.test(q)) return { action: 'execute', command: 'facebook', args: q };
  if (/youtube|yt/.test(q)) return { action: 'execute', command: 'video', args: q };
  return null;
}

/* ──────────────────────────────────────
   🔗 EXECUTE COMMAND (same as botAI.js)
   ────────────────────────────────────── */
async function executeCommand(intent, sock, chatId, senderId, botId) {
  const { command, args } = intent;
  const fakeMessage = {
    key: { remoteJid: chatId, participant: senderId },
    message: { conversation: args ? `.${command} ${args}` : `.${command}` },
    pushName: 'User'
  };

  try {
    switch (command) {
      case 'play': case 'song': await playCommand(sock, chatId, fakeMessage, botId); break;
      case 'spotify': await spotifyCommand(sock, chatId, fakeMessage, botId); break;
      case 'sticker': await stickerCommand(sock, chatId, fakeMessage, botId); break;
      case 'meme': await memeCommand(sock, chatId, botId); break;
      case 'tts': await ttsCommand(sock, chatId, args || 'Hello', botId); break;
      case 'imagine': await imagineCommand(sock, chatId, fakeMessage, botId); break;
      case 'weather': await weatherCommand(sock, chatId, args, botId); break;
      case 'lyrics': await lyricsCommand(sock, chatId, args, botId); break;
      case 'tiktok': await tiktokCommand(sock, chatId, fakeMessage, botId); break;
      case 'instagram': await instagramCommand(sock, chatId, fakeMessage, botId); break;
      case 'facebook': await facebookCommand(sock, chatId, fakeMessage, botId); break;
      case 'video': case 'ytmp4': await videoCommand(sock, chatId, fakeMessage); break;
      case 'qvideo': case 'yt2mp4': await videoCommand2(sock, chatId, fakeMessage); break;

      case 'joke': await jokeCommand(sock, chatId, botId); break;
      case 'fact': await factCommand(sock, chatId, botId); break;
      case 'quote': await sendQuoteOfDay(sock, chatId, senderId); break;
      case 'news': await newsCommand(sock, chatId, botId); break;
      case 'bible': await bibleCommand(sock, chatId, args, botId); break;
      case 'riddle': await sendRiddle(sock, chatId); break;
      case 'dare': await sendDare(sock, chatId, senderId); break;
      case 'truth': await sendTruth(sock, chatId, senderId); break;
      case 'alive': await aliveCommand(sock, chatId, botId); break;
      case 'ping': await pingCommand(sock, chatId, botId); break;
      case 'help': case 'menu': await helpCommand(sock, chatId, global.channelLink, botId); break;
      case 'github': await githubCommand(sock, chatId, botId); break;
      case 'clear': await clearCommand(sock, chatId, botId); break;
      case 'compliment': await complimentCommand(sock, chatId, fakeMessage, botId); break;
      case 'insult': await insultCommand(sock, chatId, fakeMessage, botId); break;
      case '8ball': await eightBallCommand(sock, chatId, args, botId); break;

      // Games
      case 'hangman': await startHangman(sock, chatId, botId); break;
      case 'guess': await guessLetter(sock, chatId, args, botId); break;
      case 'trivia': await startTrivia(sock, chatId, botId); break;
      case 'answer': await answerTrivia(sock, chatId, args, botId); break;
      case 'math': await mathGameCommand(sock, chatId, fakeMessage, args, botId); break;
      case 'tictactoe': case 'ttt': await tictactoeCommand(sock, chatId, senderId, args, botId); break;
      case 'move': await handleTicTacToeMove(sock, chatId, senderId, args, botId); break;
      case 'surrender': await handleTicTacToeMove(sock, chatId, senderId, 'surrender', botId); break;

      // Admin/Owner
      case 'ban': await banCommand(sock, chatId, fakeMessage, botId); break;
      case 'unban': await unbanCommand(sock, chatId, fakeMessage, botId); break;
      case 'kick': await kickCommand(sock, chatId, senderId, [], fakeMessage, botId); break;
      case 'mute': await muteCommand(sock, chatId, senderId, parseInt(args) || 5, botId); break;
      case 'unmute': await unmuteCommand(sock, chatId, senderId, botId); break;
      case 'promote': await promoteCommand(sock, chatId, [], fakeMessage, botId); break;
      case 'demote': await demoteCommand(sock, chatId, [], fakeMessage, botId); break;
      case 'tagall': await tagAllCommand(sock, chatId, senderId, botId); break;
      case 'warn': await warnCommand(sock, chatId, senderId, [], fakeMessage, botId); break;
      case 'warnings': await warningsCommand(sock, chatId, [], botId); break;
      case 'welcome': await welcomeCommand(sock, chatId, fakeMessage, botId); break;
      case 'goodbye': await goodbyeCommand(sock, chatId, fakeMessage, botId); break;
      case 'staff': await staffCommand(sock, chatId, fakeMessage, botId); break;
      case 'groupinfo': await groupInfoCommand(sock, chatId, fakeMessage, botId); break;
      case 'resetlink': await resetlinkCommand(sock, chatId, senderId, botId); break;
      case 'owner': await ownerCommand(sock, chatId, botId); break;

      default:
        await sock.sendMessage(chatId, { text: `❌ Unknown command: ${command}` });
    }
  } catch (err) {
    console.error(`Failed to execute: ${command}`, err);
    await sock.sendMessage(chatId, { text: `❌ Failed to run: ${command}` });
  }
}

/* ──────────────────────────────────────
   🤖  CALL OPENROUTER AI (same as botAI.js)
   ────────────────────────────────────── */
const OPENROUTER_API_KEY = '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';
const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const MODEL_NAME = 'meta-llama/llama-3-8b-instruct';

async function getAIResponse(userMessage, context, sock, chatId, senderId, botId) {
  const systemPrompt = `
You are SEPTORCH, a smart WhatsApp bot assistant.
- Respond in JSON ONLY: { "action": "execute", "command": "...", "args": "..." } or { "action": "reply", "text": "..." }
- NEVER invent commands. Only use the ones listed below.

## 📚 Commands
(play, song, spotify, tiktok, instagram, facebook, video, qvideo, tomp3, simage, sticker, stickertelegram, attp, imagine, tts, blur, upload, qr, ss, weather, news, lyrics, bible, github, help, menu, quote, fact, joke, livescore, threads, urlshort, riddle, dare, truth, compliment, insult, 8ball, hangman, guess, trivia, answer, math, tictactoe, move, surrender, ban, unban, kick, mute, unmute, promote, demote, tagall, warn, warnings, welcome, goodbye, staff, groupinfo, resetlink, owner, clear, alive, ping, ai, translate, goodnight, shayari, roseday, flirt, character, ship, simp, stupid, wasted, pair)

Today: ${new Date().toLocaleString('en-NG', { timeZone: 'Africa/Lagos' })}
`;

  const messages = [
    { role: "system", content: systemPrompt },
    ...context.messages.slice(-6).map(m => ({ role: "user", content: m })),
    { role: "user", content: userMessage }
  ];

  try {
    const response = await axios.post(
      OPENROUTER_API_URL,
      { model: MODEL_NAME, messages, max_tokens: 400, temperature: 0.7 },
      { headers: { 'Authorization': `Bearer ${OPENROUTER_API_KEY}`, 'Content-Type': 'application/json' } }
    );

    const raw = response.data.choices[0]?.message?.content.trim();
    const aiResponse = JSON.parse(raw);

    if (aiResponse.action === 'execute') {
      // Execute command and return true to prevent fallback reply
      await executeCommand(aiResponse, sock, chatId, senderId, botId);
      return true; // indicates a command was executed
    } else if (aiResponse.action === 'reply') {
      return aiResponse.text;
    }
    return null;
  } catch (err) {
    console.error('[CHATBOT AI ERROR]', err);
    return "I'm having trouble thinking right now. Try again?";
  }
}

/* ──────────────────────────────────────
   🤖  BOT RESPONSE HANDLER (MAIN)
   ────────────────────────────────────── */
async function handleChatbotResponse(sock, chatId, message, userMsg, senderId, botId) {
  const data = loadUserGroupData();
  if (!data.chatbot[chatId]) return;

  const botIdClean = sock.user.id.split(':')[0] + '@s.whatsapp.net';

  // Detect mention or reply
  let mentioned = false;
  let replyToBot = false;

  if (message.message?.extendedTextMessage) {
    const ctx = message.message.extendedTextMessage.contextInfo;
    mentioned = (ctx.mentionedJid || []).includes(botIdClean);
    replyToBot = ctx.participant === botIdClean;
  } else if (message.message?.conversation) {
    mentioned = userMsg.includes(`@${botIdClean.split('@')[0]}`);
  }

  if (!mentioned && !replyToBot) return;

  // Strip bot mention
  userMsg = userMsg.replace(new RegExp(`@${botIdClean.split('@')[0]}`, 'g'), '').trim();
  if (!userMsg) return;

  // Init memory
  if (!chatMemory.messages.has(senderId)) {
    chatMemory.messages.set(senderId, []);
    chatMemory.userInfo.set(senderId, {});
  }

  // Update user info & history
  const info = extractUserInfo(userMsg);
  if (Object.keys(info).length) {
    chatMemory.userInfo.set(senderId, { ...chatMemory.userInfo.get(senderId), ...info });
  }

  const hist = chatMemory.messages.get(senderId);
  hist.push(userMsg);
  if (hist.length > 20) hist.shift();

  await showTyping(sock, chatId);

  // Try fallback intent (e.g. "play xyz")
  const fallbackIntent = detectCommandIntent(userMsg.toLowerCase());
  if (fallbackIntent) {
    return await executeCommand(fallbackIntent, sock, chatId, senderId, botId);
  }

  // Call AI
  const aiResult = await getAIResponse(
    userMsg,
    { messages: hist, userInfo: chatMemory.userInfo.get(senderId) },
    sock,
    chatId,
    senderId,
    botId
  );

  // If AI executed a command (action: execute), don't send reply
  if (aiResult === true) {
    return; // command already handled
  }

  // Otherwise, send text reply
  if (aiResult) {
    await sock.sendMessage(chatId, { text: aiResult }, { quoted: message });
  } else {
    await sock.sendMessage(chatId, {
      text: "Hmm, I'm not sure how to respond to that.",
      quoted: message
    });
  }
}

/* ──────────────────────────────────────
   📤  EXPORTS
   ────────────────────────────────────── */
// Import commands (same as botAI.js)
const playCommand = require('./play');
const songCommand = require('./song');
const stickerCommand = require('./sticker');
const memeCommand = require('./meme');
const ttsCommand = require('./tts');
const imagineCommand = require('./imagine');
const weatherCommand = require('./weather');
const lyricsCommand = require('./lyrics');
const tiktokCommand = require('./tiktok');
const instagramCommand = require('./instagram');
const facebookCommand = require('./facebook');
const spotifyCommand = require('./spotify');
const videoCommand = require('./video');
const videoCommand2 = require('./video2');
const livescoreCommand = require('./livescore');
const { mathGameCommand, mathAnswerHandler } = require('./mathgame');
const tikTokStalkCommand = require('./tiktokstalk');
const threadsCommand = require('./threads');
const toMp3Command = require('./tomp3');
const { getProfileCommand } = require('./getprofile');
const { ocrCommand } = require('./ocr');
const { bibleCommand } = require('./bible');
const tagAllCommand = require('./tagall');
const { sendRiddle, checkAnswer } = require('./riddle');
const menuCommand = require('./menu');
const helpCommand = require('./help');
const banCommand = require('./ban');
const { shellCommand } = require('./shell');
const { promoteCommand } = require('./promote');
const { demoteCommand } = require('./demote');
const muteCommand = require('./mute');
const unmuteCommand = require('./unmute');
const { uploadCommand } = require('./upload');
const { qrCommand } = require('./qr');
const warnCommand = require('./warn');
const warningsCommand = require('./warnings');
const { tictactoeCommand, handleTicTacToeMove } = require('./tictactoe');
const { incrementMessageCount, topMembers } = require('./topmembers');
const ownerCommand = require('./owner');
const deleteCommand = require('./delete');
const jokeCommand = require('./joke');
const { sendQuoteOfDay } = require('./quoteofday');
const { urlShortCommand } = require('./urlshort');
const factCommand = require('./fact');
const newsCommand = require('./news');
const kickCommand = require('./kick');
const simageCommand = require('./simage');
const attpCommand = require('./attp');
const { startHangman, guessLetter } = require('./hangman');
const { startTrivia, answerTrivia } = require('./trivia');
const { complimentCommand } = require('./compliment');
const { insultCommand } = require('./insult');
const { eightBallCommand } = require('./eightball');
const { sendDare } = require('./dare');
const { sendTruth } = require('./truth');
const { clearCommand } = require('./clear');
const pingCommand = require('./ping');
const aliveCommand = require('./alive');
const blurCommand = require('./img-blur');
const welcomeCommand = require('./welcome');
const goodbyeCommand = require('./goodbye');
const githubCommand = require('./github');
const antibadwordCommand = require('./antibadword');
const takeCommand = require('./take');
const { flirtCommand } = require('./flirt');
const characterCommand = require('./character');
const wastedCommand = require('./wasted');
const shipCommand = require('./ship');
const groupInfoCommand = require('./groupinfo');
const resetlinkCommand = require('./resetlink');
const staffCommand = require('./staff');
const unbanCommand = require('./unban');
const emojimixCommand = require('./emojimix');
const viewOnceCommand = require('./viewonce');
const viewOnceCommand2 = require('./viewonce2');
const clearSessionCommand = require('./clearsession');
const { autoStatusCommand } = require('./autostatus');
const { simpCommand } = require('./simp');
const { stupidCommand } = require('./stupid');
const pairCommand = require('./pair');
const stickerTelegramCommand = require('./stickertelegram');
const textmakerCommand = require('./textmaker');
const clearTmpCommand = require('./cleartmp');
const setProfilePicture = require('./setpp');
const aiCommand = require('./ai');
const { handleTranslateCommand } = require('./translate');
const { handleSsCommand } = require('./ss');
const { goodnightCommand } = require('./goodnight');
const { shayariCommand } = require('./shayari');
const { rosedayCommand } = require('./roseday');

module.exports = {
  handleChatbotCommand,
  handleChatbotResponse
};