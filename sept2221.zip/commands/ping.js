// commands/ping.js
const settings = require('../settings.js');

/* 📦 Box formatter */
const box = (title, lines) => [
  `╭━━━[ *${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

/* 🚀 Ping command */
async function pingCommand(sock, chatId, message) {
  try {
    const sendTime = Date.now();
    const tmpMsg = await sock.sendMessage(chatId, { text: '🏓 Pinging…' });
    const ping = Date.now() - sendTime;

    const summary = box('SEPTORCH BOT', [
      `🚀 Ping   : ${ping} ms`,
      `🔖 Version: v${settings.version}`
    ]);

    await sock.sendMessage(chatId, {
      text: summary,
      edit: tmpMsg.key,
      quoted: message
    });

  } catch (e) {
    console.error('pingCommand error:', e);
    await sock.sendMessage(chatId, {
      text: '❌ Could not fetch bot status.'
    });
  }
}

module.exports = pingCommand;