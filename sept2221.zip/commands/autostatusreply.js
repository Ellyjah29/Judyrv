const triggerWords = ['send', 'save',];
const mime = require('mime-types');
const { downloadMediaMessage } = require('baileys'); // Required

async function handleAutoStatusReply(sock, msg, botId) {
    try {
        const text = msg.message?.conversation?.toLowerCase() ||
                     msg.message?.extendedTextMessage?.text?.toLowerCase();

        const isTrigger = triggerWords.some(word => text?.includes(word));
        const contextInfo = msg.message?.extendedTextMessage?.contextInfo;

        const isStatusReply = contextInfo?.remoteJid === 'status@broadcast';

        if (!isTrigger || !isStatusReply || !contextInfo?.stanzaId || !contextInfo?.participant) return;

        const quotedKey = {
            remoteJid: 'status@broadcast',
            id: contextInfo.stanzaId,
            fromMe: false,
            participant: contextInfo.participant
        };

        // Try to load the status message
        let statusMsg;
        try {
            statusMsg = await sock.loadMessage('status@broadcast', contextInfo.stanzaId);
        } catch (err) {
            console.warn('[⚠️] Failed to loadMessage, maybe expired:', err.message);
        }

        const quoted = statusMsg?.message || contextInfo?.quotedMessage;
        if (!quoted) {
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❌ Could not retrieve the original status media.'
            });
            return;
        }

        const type = Object.keys(quoted)[0];
        const supported = ['imageMessage', 'videoMessage', 'documentMessage'];
        if (!supported.includes(type)) {
            await sock.sendMessage(msg.key.remoteJid, {
                text: '❌ Unsupported or expired status type.'
            });
            return;
        }

        // Download media content
        const stream = await downloadMediaMessage(
            { key: quotedKey, message: quoted },
            'buffer',
            {},
            { reuploadRequest: sock }
        );

        const ext = mime.extension(quoted[type].mimetype || 'application/octet-stream');

        await sock.sendMessage(msg.key.remoteJid, {
            [type.replace('Message', '')]: stream,
            mimetype: quoted[type].mimetype,
            fileName: `status.${ext}`,
            caption: '📤 Here is the status you requested.'
        }, { quoted: msg });

    } catch (err) {
        console.error(`[AutoStatusReply] ❌ Error for bot ${botId}:`, err);
        await sock.sendMessage(msg.key.remoteJid, {
            text: '❌ Failed to send the status you requested.'
        });
    }
}

module.exports = { handleAutoStatusReply };