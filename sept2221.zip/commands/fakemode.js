async function handleFakeModeCommand(sock, chatId, message, botId) {
    let args = [];

    // Extract input from button or normal message
    if (message.message?.buttonsResponseMessage?.selectedButtonId) {
        args = message.message.buttonsResponseMessage.selectedButtonId.trim().split(' ');
    } else if (message.message?.conversation) {
        args = message.message.conversation.trim().split(' ');
    } else if (message.message?.extendedTextMessage?.text) {
        args = message.message.extendedTextMessage.text.trim().split(' ');
    }

    if (args.length < 2) {
        await sock.sendMessage(chatId, {
            text: "Usage: .switchfake [on/off]",
            buttons: [
                { buttonId: '.switchfake on', buttonText: { displayText: '🔁 Switch ON' }, type: 1 },
                { buttonId: '.switchfake off', buttonText: { displayText: '🛑 Switch OFF' }, type: 1 }
            ],
            headerType: 1
        });
        return;
    }

    const mode = args[1].toLowerCase();

    if (mode === 'on') {
        const { getFakeMode, setFakeMode } = require('../lib/presenceState');
        const currentState = getFakeMode(botId);

        if (!currentState.type) {
            await sock.sendMessage(chatId, {
                text: "❌ Please use `.fake [typing/recording/typerecord]` first to select type!"
            });
            return;
        }

        setFakeMode(botId, true, currentState.type);

        await sock.sendMessage(chatId, {
            text: "🔁 Auto fake presence is now ON"
        });

    } else if (mode === 'off') {
        const { setFakeMode } = require('../lib/presenceState');
        setFakeMode(botId, false, null);

        await sock.sendMessage(chatId, {
            text: "🛑 Auto fake presence is OFF"
        });

    } else {
        await sock.sendMessage(chatId, {
            text: "Usage: .switchfake [on/off]",
            buttons: [
                { buttonId: '.switchfake on', buttonText: { displayText: '🔁 Switch ON' }, type: 1 },
                { buttonId: '.switchfake off', buttonText: { displayText: '🛑 Switch OFF' }, type: 1 }
            ],
            headerType: 1
        });
    }
}

module.exports = { handleFakeModeCommand };