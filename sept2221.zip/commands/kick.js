const isAdmin = require('../lib/isAdmin');

async function kickCommand(sock, chatId, senderId, mentionedJids, message, botId) {
    // ✅ Add botId parameter

    try {
        // Validate botId
        if (!botId) {
            console.error('kickCommand: Missing botId');
            return;
        }

        // Only works in groups
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, {
                text: '❌ This command can only be used in groups.'
            });
            return;
        }

        // Check if sender is the owner (bot itself)
        const isOwner = message.key.fromMe;

        // If not owner, enforce admin rules
        if (!isOwner) {
            const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId, botId);

            if (!isBotAdmin) {
                await sock.sendMessage(chatId, {
                    text: '❌ Please make the bot an admin first to use this command.'
                });
                return;
            }

            if (!isSenderAdmin) {
                await sock.sendMessage(chatId, {
                    text: '❌ Only group admins can use the kick command.'
                });
                return;
            }
        }

        // Get users to kick
        let usersToKick = [];

        if (Array.isArray(mentionedJids) && mentionedJids.length > 0) {
            usersToKick = [...mentionedJids];
        } else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            usersToKick = [message.message.extendedTextMessage.contextInfo.participant];
        }

        if (usersToKick.length === 0) {
            await sock.sendMessage(chatId, {
                text: '⚠️ Please mention the user or reply to their message to kick.'
            });
            return;
        }

        // Get bot's true JID from global config (not from sock.user.id)
        const botData = global.botInstances?.[botId];
        if (!botData) {
            await sock.sendMessage(chatId, {
                text: '❌ Bot configuration not found. Cannot proceed.'
            });
            return;
        }

        const botPhoneJid = botData.phoneJid;
        const botLidJid = botData.lidJid;

        // Extract pure digits for comparison (handles LID/phone)
        const getPure = (jid) => jid?.split('@')[0].replace(/\D/g, '') || '';
        const botPhonePure = getPure(botPhoneJid);
        const botLidPure = getPure(botLidJid);

        const senderPure = getPure(senderId);

        // Prevent bot self-kick
        const isTryingToKickBot = usersToKick.some(jid => {
            const jidPure = getPure(jid);
            return jidPure === botPhonePure || jidPure === botLidPure;
        });

        if (isTryingToKickBot) {
            await sock.sendMessage(chatId, {
                text: "🤖 I can't kick myself!"
            });
            return;
        }

        // Prevent non-owner from kicking owner (optional safety)
        if (!isOwner) {
            const groupMetadata = await sock.groupMetadata(chatId);
            const ownerJid = groupMetadata.owner;
            if (ownerJid && usersToKick.includes(ownerJid)) {
                await sock.sendMessage(chatId, {
                    text: "⚠️ Only the group owner can be removed by the owner. You can't kick them."
                });
                return;
            }
        }

        // Perform kick
        await sock.groupParticipantsUpdate(chatId, usersToKick, 'remove');

        const kickedNames = usersToKick.map(jid => `@${jid.split('@')[0]}`).join(', ');

        await sock.sendMessage(chatId, {
            text: `✅ Successfully kicked:\n${kickedNames}`,
            mentions: usersToKick
        });

        console.log(`👢 Kicked ${usersToKick.length} user(s) in ${chatId} by ${senderId}`);

    } catch (error) {
        console.error('Error in kickCommand:', error);

        let errorMsg = '❌ Failed to kick user(s).';
        if (error.message.includes('not in chat')) {
            errorMsg = '❌ One or more users are not in the group.';
        } else if (error.message.includes('admin') || error.status === 403) {
            errorMsg = '❌ Missing permissions. Make sure the bot is a group admin.';
        }

        try {
            await sock.sendMessage(chatId, { text: errorMsg });
        } catch (sendErr) {
            console.error('Failed to send error message:', sendErr);
        }
    }
}

module.exports = kickCommand;