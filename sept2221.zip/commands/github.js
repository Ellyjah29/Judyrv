async function githubCommand(sock, chatId) {
    const repoInfo = `*🤖 SEPTORCH_BOT MD*

*📂 About:*  
SEPTORCH_BOT was developed by an anonymous creator for the fun of WhatsApp — designed to give users the best experience and make the app even more special.  
Powered by *WhiskeySockets (Baileys)*.  

*📢 Official Channel:*  
https://whatsapp.com/channel/0029Vb1ydGk8qIzkvps0nZ04  

*📢 Feedback & Suggestions:*  
https://ngl.link/septorch  

_Stay connected and enjoy the ride with SEPTORCH!_`;

    try {
        await sock.sendMessage(chatId, {
            text: repoInfo,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363387922693296@newsletter',
                    newsletterName: 'SEPTORCH_BOT MD',
                    serverMessageId: -1
                }
            }
        });
    } catch (error) {
        console.error('Error in github command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Error fetching repository information.' 
        });
    }
}

module.exports = githubCommand;