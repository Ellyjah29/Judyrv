// commands/quoteofday.js

const quotes = [
    "The only way to do great work is to love what you do. – Steve Jobs",
    "Believe you can and you're halfway there. – Theodore Roosevelt",
    "Your time is limited, so don't waste it living someone else's life. – Steve Jobs",
    "Success is not final, failure is not fatal: It is the courage to continue that counts. – Winston Churchill",
    "It always seems impossible until it's done. – Nelson Mandela",
    "Don’t watch the clock; do what it does. Keep going. – Sam Levenson",
    "The harder I work, the luckier I get. – Samuel Goldwyn",
    "If you can dream it, you can do it. – Walt Disney",
    "You miss 100% of the shots you don’t take. – Wayne Gretzky",
    "Do what you can, with what you have, where you are. – Theodore Roosevelt",
    "Start where you are. Use what you have. Do what you can. – Arthur Ashe",
    "The best revenge is massive success. – Frank Sinatra",
    "Don't let yesterday take up too much of today. – Will Rogers",
    "Life is what happens when you're busy making other plans. – John Lennon",
    "Everything you’ve ever wanted is on the other side of fear. – George Addair",
    "Hardships often prepare ordinary people for an extraordinary destiny. – C.S. Lewis",
    "Act as if what you do makes a difference. It does. – William James",
    "You are never too old to set another goal or to dream a new dream. – C.S. Lewis",
    "Success usually comes to those who are too busy to be looking for it. – Henry David Thoreau",
    "Don’t count the days, make the days count. – Muhammad Ali",
    "Keep your face always toward the sunshine—and shadows will fall behind you. – Walt Whitman",
    "Dream big and dare to fail. – Norman Vaughan",
    "A goal without a plan is just a wish. – Antoine de Saint-Exupéry",
    "What lies behind us and what lies before us are tiny matters compared to what lies within us. – Ralph Waldo Emerson",
    "Happiness is not something ready-made. It comes from your own actions. – Dalai Lama",
    "Believe in yourself and all that you are. – Christian D. Larson",
    "Work hard in silence, let success make the noise. – Frank Ocean",
    "I never dreamed about success. I worked for it. – Estée Lauder",
    "Strive not to be a success, but rather to be of value. – Albert Einstein",
    "Opportunities don't happen, you create them. – Chris Grosser",
    "Push yourself, because no one else is going to do it for you. – Unknown",
    "Great things never come from comfort zones. – Unknown",
    "Don’t limit your challenges. Challenge your limits. – Jerry Dunn",
    "Success is the sum of small efforts, repeated day in and day out. – Robert Collier",
    "The future belongs to those who believe in the beauty of their dreams. – Eleanor Roosevelt",
    "You don’t have to be great to start, but you have to start to be great. – Zig Ziglar",
    "If you’re going through hell, keep going. – Winston Churchill",
    "Don’t wish it were easier. Wish you were better. – Jim Rohn",
    "You are braver than you believe, stronger than you seem, and smarter than you think. – A.A. Milne",
    "Do not wait for the perfect moment. Take the moment and make it perfect. – Unknown",
    "Discipline is the bridge between goals and accomplishment. – Jim Rohn",
    "Make each day your masterpiece. – John Wooden",
    "Don’t be pushed around by the fears in your mind. Be led by the dreams in your heart. – Roy T. Bennett",
    "Failure will never overtake me if my determination to succeed is strong enough. – Og Mandino",
    "Small deeds done are better than great deeds planned. – Peter Marshall",
    "The man who moves a mountain begins by carrying away small stones. – Confucius",
    "It does not matter how slowly you go as long as you do not stop. – Confucius",
    "Success is how high you bounce when you hit bottom. – George S. Patton",
    "Energy and persistence conquer all things. – Benjamin Franklin",
    "To live a creative life, we must lose our fear of being wrong. – Joseph Chilton Pearce",
    "A river cuts through rock not because of its power, but because of its persistence. – James Watkins",
    "The expert in anything was once a beginner. – Helen Hayes",
    "The secret of getting ahead is getting started. – Mark Twain"
];

function getRandomQuote() {
    const index = Math.floor(Math.random() * quotes.length);
    return quotes[index];
}

async function sendQuoteOfDay(sock, chatId, senderId) {
    const quote = getRandomQuote();
    const userTag = `@${senderId.split('@')[0]}`;

    await sock.sendMessage(chatId, {
        text: `📖 ${userTag}, Here’s your Quote of the Day:\n\n"${quote}"`,
        mentions: [senderId]
    });
}

module.exports = { sendQuoteOfDay };