const res = await axios.get('https://onlinesim.io/api/v1/free_numbers_content/countries', {
  timeout: 15000,
  headers: { 'User-Agent': 'Mozilla/5.0 (compatible; tempnumber-bot/1.0)' }
});

// ✅ Log the entire response
console.log("Full response data:", JSON.stringify(res.data, null, 2));

// Safely pick countries or counties
const countriesRaw = res.data.countries || res.data.counties;

if (!countriesRaw) {
  await sock.sendMessage(chatId, { text: '❌ No country data returned.' });
  return;
}

// In some cases, the API returns an array instead of an object
if (Array.isArray(countriesRaw)) {
  let msg = '*🌍 Available Countries:*\n\n';
  for (const entry of countriesRaw) {
    if (typeof entry === "object") {
      msg += `• *${entry.country}* — ${entry.name}\n`;
    }
  }
  await sock.sendMessage(chatId, { text: msg });
  return;
}

// If it's an object
if (typeof countriesRaw === "object") {
  let msg = '*🌍 Available Countries:*\n\n';
  for (const [code, name] of Object.entries(countriesRaw)) {
    if (typeof name === "string") {
      msg += `• *${code}* — ${name}\n`;
    } else if (typeof name === "object") {
      msg += `• *${code}* — ${name.name}\n`;
    }
  }
  await sock.sendMessage(chatId, { text: msg });
  return;
}

// If unknown structure
await sock.sendMessage(chatId, { text: '❌ Received unknown format from API.' });