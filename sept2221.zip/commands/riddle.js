// commands/riddle.js

const riddles = [
    {
        question: "I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?",
        answer: "An echo"
    },
    {
        question: "What has keys but can’t open locks, has space but no room, and you can enter but not go inside?",
        answer: "A keyboard"
    },
    {
        question: "The more you take, the more you leave behind. What am I?",
        answer: "Footsteps"
    },
    {
        question: "I’m not alive, but I can grow. I don’t have lungs, but I need air. What am I?",
        answer: "Fire"
    },
    {
        question: "What belongs to you but is used more by others?",
        answer: "Your name"
    }
];

let activeRiddles = {}; // { chatId: { question, answer, timeout } }

function getRandomRiddle() {
    const index = Math.floor(Math.random() * riddles.length);
    return riddles[index];
}

async function sendRiddle(sock, chatId) {
    const riddle = getRandomRiddle();
    activeRiddles[chatId] = {
        ...riddle,
        timeout: setTimeout(() => {
            delete activeRiddles[chatId];
            sock.sendMessage(chatId, {
                text: `⏰ Time's up! The answer was: *${riddle.answer}*`
            });
        }, 30000)
    };

    await sock.sendMessage(chatId, {
        text: `❓ Riddle Time!\n\n${riddle.question}\n\nYou have 30 seconds to answer!`
    });
}

async function checkAnswer(sock, chatId, userAnswer, senderId) {
    const activeRiddle = activeRiddles[chatId];
    if (!activeRiddle) return;

    if (userAnswer.toLowerCase().includes(activeRiddle.answer.toLowerCase())) {
        clearTimeout(activeRiddle.timeout);
        delete activeRiddles[chatId];
        await sock.sendMessage(chatId, {
            text: `✅ Correct, @${senderId.split('@')[0]}! The answer was: *${activeRiddle.answer}*`,
            mentions: [senderId]
        });
    }
}

module.exports = { sendRiddle, checkAnswer };