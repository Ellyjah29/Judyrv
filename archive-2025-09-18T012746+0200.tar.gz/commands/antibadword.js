const { handleAntiBadwordCommand } = require('../lib/antibadword');
const isAdminHelper = require('../lib/isAdmin');

// 🔰 Bot-style boxed message helper
const box = (title, lines) => [
  `╭━━━[ *🔰 ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

const sendBox = (sock, chatId, title, lines) =>
  sock.sendMessage(chatId, { text: box(title, lines) });

/**
 * Handle .antibadword command
 * @param {object} sock - Baileys socket
 * @param {string} chatId - Group JID
 * @param {object} message - Message object
 * @param {string} senderId - User JID
 * @param {boolean} isSenderAdmin - Admin check
 */
async function antibadwordCommand(sock, chatId, message, senderId, isSenderAdmin) {
    try {
        if (!isSenderAdmin) {
            return sendBox(sock, chatId, 'Antibadword', [
                '❌  *For Group Admins Only!*'
            ]);
        }

        // Extract match from message
        const text = message.message?.conversation || 
                     message.message?.extendedTextMessage?.text || '';
        const match = text.split(' ').slice(1).join(' ').trim();

        await handleAntiBadwordCommand(sock, chatId, message, match);
    } catch (error) {
        console.error('Error in antibadword command:', error);
        await sendBox(sock, chatId, 'Antibadword', [
            '❌  *Error processing antibadword command.*'
        ]);
    }
}

module.exports = antibadwordCommand;