const fs = require('fs');
const path = require('path');
const { Buffer } = require('buffer');
const { fetch } = globalThis;
const { downloadMediaMessage } = require('baileys');

// Ensure tmp directory exists
function ensureTmpDir() {
    const tmpDir = path.join(__dirname, '../tmp');
    if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
    }
    return tmpDir;
}

async function getProfileInfo(sock, chatId, targetJid, botId) {
    try {
        // Get user profile picture
        let profilePic;
        try {
            profilePic = await sock.profilePictureUrl(targetJid, 'image');
        } catch (err) {
            profilePic = null;
        }

        // Try get display name from presence or contact list
        const contact = sock.contacts?.[targetJid] || {};
        const displayName = contact.name || contact.notify || contact.vname || targetJid.split('@')[0];

        // Get user about/status
        let about = 'No status available';
        try {
            const status = await sock.fetchStatus(targetJid);
            about = status?.status || 'No status available';
        } catch (err) {
            about = 'No status available';
        }

        // Prepare message
        let profileInfo = `👤 *User Profile*\n📛 Name: ${displayName}\n🔢 WhatsApp ID: ${targetJid}\n📝 Status: ${about}\n`;

        if (profilePic) {
            profileInfo += '📷 Profile Picture: Above\n';

            // Download profile picture
            const response = await fetch(profilePic);
            const buffer = Buffer.from(await response.arrayBuffer());

            const tmpDir = ensureTmpDir();
            const filePath = path.join(tmpDir, `profile_${Date.now()}.jpg`);
            fs.writeFileSync(filePath, buffer);

            await sock.sendMessage(chatId, {
                image: fs.readFileSync(filePath),
                caption: profileInfo,
                mentions: [targetJid]
            });

            fs.unlinkSync(filePath);
        } else {
            await sock.sendMessage(chatId, {
                text: profileInfo,
                mentions: [targetJid]
            });
        }

    } catch (error) {
        console.error('Error getting profile info:', error);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to retrieve profile information.'
        });
    }
}

async function getProfileCommand(sock, chatId, message, botId) {
    try {
        const body = message?.message?.conversation ||
                     message?.message?.extendedTextMessage?.text || '';

        const args = body.trim().split(/\s+/);
        let targetJid = null;

        // If replying to a message
        const contextInfo = message.message?.extendedTextMessage?.contextInfo;
        if (contextInfo?.quotedMessage) {
            targetJid = contextInfo?.participant || contextInfo?.mentionedJid?.[0];
        }

        // If direct JID or number provided
        if (!targetJid && args.length > 1) {
            const input = args[1];
            if (input.includes('@')) {
                targetJid = input.endsWith('@s.whatsapp.net') ? input : `${input}`;
            } else if (/^\d+$/.test(input)) {
                targetJid = `${input}@s.whatsapp.net`;
            }
        }

        // Default to self
        if (!targetJid) {
            targetJid = sock.user?.id;
        }

        await getProfileInfo(sock, chatId, targetJid, botId);

    } catch (error) {
        console.error('Error in getProfileCommand:', error);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to retrieve profile information.'
        });
    }
}

module.exports = { getProfileCommand };