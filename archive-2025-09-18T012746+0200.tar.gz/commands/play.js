/*Créditos A Quien Correspondan 
Play Traido y Editado 
Por Cuervo-Team-Supreme*/
const axios = require('axios');
const crypto = require('crypto');
const yts = require('yt-search');
const ytdl = require('@distube/ytdl-core'); // Updated to @distube/ytdl-core
const youtubedl = require('youtube-dl-exec');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const ffmpeg = require('fluent-ffmpeg');

const savetube = {
   api: {
      base: "https://media.savetube.me/api",
      cdn: "/random-cdn",
      info: "/v2/info",
      download: "/download"
   },
   headers: {
      'accept': '*/*',
      'content-type': 'application/json',
      'origin': 'https://yt.savetube.me',
      'referer': 'https://yt.savetube.me/',
      'user-agent': 'Postify/1.0.0'
   },
   formats: ['144', '240', '360', '480', '720', '1080', 'mp3'],
   crypto: {
      hexToBuffer: (hexString) => {
         const matches = hexString.match(/.{1,2}/g);
         return Buffer.from(matches.join(''), 'hex');
      },
      decrypt: async (enc) => {
         try {
            const secretKey = process.env.SAVETUBE_KEY || 'C5D58EF67A7584E4A29F6C35BBC4EB12'; // Use env variable
            const data = Buffer.from(enc, 'base64');
            const iv = data.slice(0, 16);
            const content = data.slice(16);
            const key = savetube.crypto.hexToBuffer(secretKey);
            const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
            let decrypted = decipher.update(content);
            decrypted = Buffer.concat([decrypted, decipher.final()]);
            return JSON.parse(decrypted.toString());
         } catch (error) {
            throw new Error(`Decryption failed: ${error.message}`);
         }
      }
   },
   youtube: url => {
      if (!url) return null;
      const a = [
         /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
         /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
         /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
         /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
         /youtu\.be\/([a-zA-Z0-9_-]{11})/
      ];
      for (let b of a) {
         if (b.test(url)) return url.match(b)[1];
      }
      return null;
   },
   request: async (endpoint, data = {}, method = 'post') => {
      try {
         const { data: response } = await axios({
            method,
            url: `${endpoint.startsWith('http') ? '' : savetube.api.base}${endpoint}`,
            data: method === 'post' ? data : undefined,
            params: method === 'get' ? data : undefined,
            headers: savetube.headers
         });
         return {
            status: true,
            code: 200,
            data: response
         };
      } catch (error) {
         throw new Error(`API request failed: ${error.message}`);
      }
   },
   getCDN: async () => {
      const response = await savetube.request(savetube.api.cdn, {}, 'get');
      if (!response.status) throw new Error(response);
      return {
         status: true,
         code: 200,
         data: response.data.cdn
      };
   },
   download: async (link, format, retries = 3) => {
      if (!link) {
         return {
            status: false,
            code: 400,
            error: "No link provided. Please provide a valid YouTube link."
         };
      }
      if (!format || !savetube.formats.includes(format)) {
         return {
            status: false,
            code: 400,
            error: "Invalid format. Please choose one of the available formats: 144, 240, 360, 480, 720, 1080, mp3.",
            available_fmt: savetube.formats
         };
      }
      const id = savetube.youtube(link);
      if (!id) throw new Error('Invalid YouTube link.');
      try {
         const cdnx = await savetube.getCDN();
         if (!cdnx.status) return cdnx;
         const cdn = cdnx.data;
         const result = await savetube.request(`https://${cdn}${savetube.api.info}`, {
            url: `https://www.youtube.com/watch?v=${id}`
         });
         if (!result.status) return result;
         const decrypted = await savetube.crypto.decrypt(result.data.data);
         let dl;
         for (let attempt = 1; attempt <= retries; attempt++) {
            try {
               dl = await savetube.request(`https://${cdn}${savetube.api.download}`, {
                  id: id,
                  downloadType: format === 'mp3' ? 'audio' : 'video',
                  quality: format === 'mp3' ? '128' : format,
                  key: decrypted.key
               });
               if (dl.data.data.downloadUrl) break;
               if (attempt === retries) throw new Error('No valid download URL after retries.');
            } catch (error) {
               if (attempt === retries) throw new Error(`Failed to get download link after ${retries} attempts: ${error.message}`);
            }
         }
         return {
            status: true,
            code: 200,
            result: {
               title: decrypted.title || "Unknown Title",
               type: format === 'mp3' ? 'audio' : 'video',
               format: format,
               thumbnail: decrypted.thumbnail || `https://i.ytimg.com/vi/${id}/0.jpg`,
               download: dl.data.data.downloadUrl,
               id: id,
               key: decrypted.key,
               duration: decrypted.duration,
               quality: format === 'mp3' ? '128' : format,
               downloaded: dl.data.data.downloaded
            }
         };
      } catch (error) {
         throw new Error(`Download processing failed: ${error.message}`);
      }
   }
};

async function songCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        if (!text) {
            return await sock.sendMessage(chatId, { text: "Please provide a song name or YouTube link." });
        }

        // Parse format and quality from the command
        let format = 'mp3'; // Default format
        let quality = '128'; // Default quality for mp3
        let searchQuery = text.split(' ').slice(1).join(' ').trim();

        // Extract format and quality if provided
        const formatMatch = searchQuery.match(/format:(\w+)/);
        const qualityMatch = searchQuery.match(/quality:(\w+)/);
        if (formatMatch) {
            format = formatMatch[1].toLowerCase();
            searchQuery = searchQuery.replace(/format:\w+/, '').trim();
        }
        if (qualityMatch) {
            quality = qualityMatch[1];
            searchQuery = searchQuery.replace(/quality:\w+/, '').trim();
        }

        // Validate format
        const supportedFormats = ['mp3', 'mp4'];
        if (!supportedFormats.includes(format)) {
            return await sock.sendMessage(chatId, {
                text: `Invalid format. Please choose one of: ${supportedFormats.join(', ')}.`
            });
        }

        // Validate quality
        const supportedQualities = format === 'mp3' ? ['128'] : ['144', '240', '360', '480', '720', '1080'];
        if (!supportedQualities.includes(quality)) {
            return await sock.sendMessage(chatId, {
                text: `Invalid quality for ${format}. Please choose one of: ${supportedQualities.join(', ')}.`
            });
        }

        // Adjust format for savetube if mp3
        const savetubeFormat = format === 'mp3' ? 'mp3' : quality;

        // Determine if input is a YouTube link or search query
        let videoUrl = '';
        let videoTitle = 'Unknown Title';
        let videoThumbnail = '';
        if (searchQuery.startsWith('http://') || searchQuery.startsWith('https://')) {
            videoUrl = searchQuery;
            try {
                const cookies = fs.existsSync('cookies.json') ? JSON.parse(fs.readFileSync('cookies.json')) : [];
                const agent = cookies.length ? ytdl.createAgent(cookies) : undefined;
                const info = await ytdl.getInfo(videoUrl, { agent });
                videoTitle = info.videoDetails.title;
                videoThumbnail = info.videoDetails.thumbnails[0]?.url || `https://i.ytimg.com/vi/${savetube.youtube(videoUrl)}/0.jpg`;
            } catch (e) {
                console.error(`Failed to get video info for ${videoUrl}: ${e.message}`);
            }
        } else {
            // Search YouTube for the video
            const { videos } = await yts(searchQuery);
            if (!videos || videos.length === 0) {
                return await sock.sendMessage(chatId, { text: "No songs found! Try a different query." });
            }
            // Filter out live streams, Shorts, and prefer music videos
            const suitableVideo = videos.find(v => 
                !v.live && 
                !v.url.includes('/shorts/') && 
                v.duration.seconds > 30 && 
                v.duration.seconds < 600 && 
                (v.title.toLowerCase().includes('official') || v.title.toLowerCase().includes('audio'))
            );
            if (!suitableVideo) {
                return await sock.sendMessage(chatId, { text: "No suitable videos found. Try a direct YouTube link or different query." });
            }
            videoUrl = suitableVideo.url;
            videoTitle = suitableVideo.title;
            videoThumbnail = suitableVideo.thumbnail;
            console.log(`Selected video: ${videoTitle} (${videoUrl})`);
        }

        // Download using savetube first
        let result;
        let tempFile;
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
        const fileExtension = format === 'mp3' ? 'mp3' : 'mp4';
        tempFile = path.join(tempDir, `${Date.now()}.${fileExtension}`);

        // Try savetube
        try {
            result = await savetube.download(videoUrl, savetubeFormat);
            if (!result || !result.status || !result.result || !result.result.download) {
                throw new Error("Invalid API response");
            }

            // Download the file
            const response = await axios({
                url: result.result.download,
                method: 'GET',
                responseType: 'stream',
                timeout: 60000 // 60-second timeout
            });
            if (response.status !== 200) {
                throw new Error(`Download failed: Status ${response.status}`);
            }

            const writer = fs.createWriteStream(tempFile);
            response.data.pipe(writer);
            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });

            // Check file size
            const stats = fs.statSync(tempFile);
            if (stats.size < 50000) { // 50KB threshold
                throw new Error(`File too small (${stats.size} bytes)`);
            }

            // Validate audio stream for MP3
            if (format === 'mp3') {
                await new Promise((resolve, reject) => {
                    ffmpeg.ffprobe(tempFile, (err, metadata) => {
                        if (err || !metadata.streams.some(s => s.codec_type === 'audio')) {
                            reject(new Error('No audio stream found in file'));
                        } else {
                            resolve();
                        }
                    });
                });
            }
        } catch (error) {
            console.error(`Savetube failed for ${videoUrl}: ${error.message}`);
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);

            // Fallback to @distube/ytdl-core for MP3
            if (format === 'mp3') {
                console.log(`Falling back to @distube/ytdl-core for ${videoUrl}`);
                try {
                    const cookies = fs.existsSync('cookies.json') ? JSON.parse(fs.readFileSync('cookies.json')) : [];
                    const agent = cookies.length ? ytdl.createAgent(cookies) : undefined;
                    const info = await ytdl.getInfo(videoUrl, { agent });
                    videoTitle = info.videoDetails.title;
                    videoThumbnail = info.videoDetails.thumbnails[0]?.url || `https://i.ytimg.com/vi/${savetube.youtube(videoUrl)}/0.jpg`;
                    const stream = ytdl(videoUrl, { filter: 'audioonly', quality: 'highestaudio', agent });
                    const writer = fs.createWriteStream(tempFile);
                    stream.pipe(writer);
                    await new Promise((resolve, reject) => {
                        writer.on('finish', resolve);
                        writer.on('error', reject);
                    });

                    // Check file size
                    const stats = fs.statSync(tempFile);
                    if (stats.size < 50000) {
                        throw new Error(`@distube/ytdl-core file too small (${stats.size} bytes)`);
                    }

                    // Validate audio stream
                    await new Promise((resolve, reject) => {
                        ffmpeg.ffprobe(tempFile, (err, metadata) => {
                            if (err || !metadata.streams.some(s => s.codec_type === 'audio')) {
                                reject(new Error('No audio stream in @distube/ytdl-core file'));
                            } else {
                                resolve();
                            }
                        });
                    });
                } catch (ytdlError) {
                    console.error(`@distube/ytdl-core failed for ${videoUrl}: ${ytdlError.message}`);
                    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);

                    // Fallback to youtube-dl-exec for MP3
                    console.log(`Falling back to youtube-dl-exec for ${videoUrl}`);
                    try {
                        const cookies = fs.existsSync('cookies.txt') ? 'cookies.txt' : undefined;
                        await youtubedl(videoUrl, {
                            extractAudio: true,
                            audioFormat: 'mp3',
                            output: tempFile,
                            quiet: true,
                            cookie: cookies
                        });

                        // Check file size
                        const stats = fs.statSync(tempFile);
                        if (stats.size < 50000) {
                            throw new Error(`Youtube-dl-exec file too small (${stats.size} bytes)`);
                        }

                        // Validate audio stream
                        await new Promise((resolve, reject) => {
                            ffmpeg.ffprobe(tempFile, (err, metadata) => {
                                if (err || !metadata.streams.some(s => s.codec_type === 'audio')) {
                                    reject(new Error('No audio stream in youtube-dl-exec file'));
                                } else {
                                    resolve();
                                }
                            });
                        });
                    } catch (ytdlExecError) {
                        console.error(`Youtube-dl-exec failed for ${videoUrl}: ${ytdlExecError.message}`);
                        if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
                        return await sock.sendMessage(chatId, {
                            text: `Download failed for all methods: ${ytdlExecError.message}. Try a different song or link.`
                        });
                    }
                }
            } else {
                return await sock.sendMessage(chatId, {
                    text: `Download failed: ${error.message}. Try a different song or link.`
                });
            }
        }

        // Send thumbnail
        try {
            await sock.sendMessage(chatId, {
                image: { url: videoThumbnail },
                caption: `*${videoTitle}*\n\n> _Downloading your ${format}..._\n > *_By SEPTORCH`
            }, { quoted: message });
        } catch (e) {
            console.error(`Thumbnail send failed: ${e.message}`);
        }

        // Send the file
        const sendOptions = {
            [format === 'mp3' ? 'audio' : 'video']: { url: tempFile },
            mimetype: format === 'mp3' ? 'audio/mpeg' : 'video/mp4',
            fileName: `${videoTitle}.${fileExtension}`,
            ptt: format === 'mp3' ? false : undefined
        };
        try {
            await sock.sendMessage(chatId, sendOptions, { quoted: message });
        } catch (error) {
            console.error(`Send failed for ${tempFile}: ${error.message}`);
            return await sock.sendMessage(chatId, { text: `Failed to send the file: ${error.message}` });
        }

        // Clean up temp file
        setTimeout(() => {
            try {
                if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            } catch {}
        }, 10000); // 10 seconds
    } catch (error) {
        console.error(`General error for ${text}: ${error.message}`);
        await sock.sendMessage(chatId, { text: `Download failed: ${error.message}. Try a different song or link.` });
    }
}

module.exports = songCommand;