// commands/botAI.js
const axios = require('axios');
const { loadChatHistory, saveNote } = require('./ai_notes');
const categories = require('./menu').categories;

// Import ALL commands from main.js
const playCommand = require('./play');
const songCommand = require('./song');
const stickerCommand = require('./sticker');
const memeCommand = require('./meme');
const ttsCommand = require('./tts');
const imagineCommand = require('./imagine');
const weatherCommand = require('./weather');
const lyricsCommand = require('./lyrics');
const tiktokCommand = require('./tiktok');
const instagramCommand = require('./instagram');
const facebookCommand = require('./facebook');
const spotifyCommand = require('./spotify');
const videoCommand = require('./video');
const videoCommand2 = require('./video2');
const livescoreCommand = require('./livescore');
const { mathGameCommand, mathAnswerHandler } = require('./mathgame');
const tikTokStalkCommand = require('./tiktokstalk');
const threadsCommand = require('./threads');
const toMp3Command = require('./tomp3');
const { getProfileCommand } = require('./getprofile');
const { ocrCommand } = require('./ocr');
const { bibleCommand } = require('./bible');
const tagAllCommand = require('./tagall');
const { sendRiddle, checkAnswer } = require('./riddle');
const menuCommand = require('./menu');
const helpCommand = require('./help');
const banCommand = require('./ban');
const { shellCommand } = require('./shell');
const { promoteCommand } = require('./promote');
const { demoteCommand } = require('./demote');
const muteCommand = require('./mute');
const unmuteCommand = require('./unmute');
const { uploadCommand } = require('./upload');
const { qrCommand } = require('./qr');
const warnCommand = require('./warn');
const warningsCommand = require('./warnings');
const { tictactoeCommand, handleTicTacToeMove } = require('./tictactoe');
const { incrementMessageCount, topMembers } = require('./topmembers');
const ownerCommand = require('./owner');
const deleteCommand = require('./delete');
const jokeCommand = require('./joke');
const { sendQuoteOfDay } = require('./quoteofday');
const { urlShortCommand } = require('./urlshort');
const factCommand = require('./fact');
const newsCommand = require('./news');
const kickCommand = require('./kick');
const simageCommand = require('./simage');
const attpCommand = require('./attp');
const { startHangman, guessLetter } = require('./hangman');
const { startTrivia, answerTrivia } = require('./trivia');
const { complimentCommand } = require('./compliment');
const { insultCommand } = require('./insult');
const { eightBallCommand } = require('./eightball');
const { sendDare } = require('./dare');
const { sendTruth } = require('./truth');
const { clearCommand } = require('./clear');
const pingCommand = require('./ping');
const aliveCommand = require('./alive');
const blurCommand = require('./img-blur');
const welcomeCommand = require('./welcome');
const goodbyeCommand = require('./goodbye');
const githubCommand = require('./github');
const antibadwordCommand = require('./antibadword');
const { handleChatbotCommand } = require('./chatbot');
const takeCommand = require('./take');
const { flirtCommand } = require('./flirt');
const characterCommand = require('./character');
const wastedCommand = require('./wasted');
const shipCommand = require('./ship');
const groupInfoCommand = require('./groupinfo');
const resetlinkCommand = require('./resetlink');
const staffCommand = require('./staff');
const unbanCommand = require('./unban');
const emojimixCommand = require('./emojimix');
const viewOnceCommand = require('./viewonce');
const viewOnceCommand2 = require('./viewonce2');
const clearSessionCommand = require('./clearsession');
const { autoStatusCommand } = require('./autostatus');
const { simpCommand } = require('./simp');
const { stupidCommand } = require('./stupid');
const pairCommand = require('./pair');
const stickerTelegramCommand = require('./stickertelegram');
const textmakerCommand = require('./textmaker');
const clearTmpCommand = require('./cleartmp');
const setProfilePicture = require('./setpp');
const aiCommand = require('./ai');
const { handleTranslateCommand } = require('./translate');
const { handleSsCommand } = require('./ss');
const { goodnightCommand } = require('./goodnight');
const { shayariCommand } = require('./shayari');
const { rosedayCommand } = require('./roseday');

// ✅ API Key (yours)
const OPENROUTER_API_KEY = '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';
const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const MODEL_NAME = 'meta-llama/llama-3-8b-instruct';

// --- Normalize query ---
function normalizeQuery(query) {
    return query
        .toLowerCase()
        .replace(/[\?\!]/g, '')
        .replace(/\bme\b/g, '')
        .replace(/\bplease\b/g, '')
        .replace(/\bcould you\b/g, '')
        .replace(/\bcan you\b/g, '')
        .replace(/\bwould you\b/g, '')
        .trim();
}

// --- Detect Intent ---
function detectCommandIntent(query) {
    const q = query.toLowerCase();

    if (/play|song|music/.test(q)) return { action: 'execute', command: 'play', args: q.replace(/play|song|music/, '').trim() };
    if (/joke/.test(q)) return { action: 'execute', command: 'joke', args: '' };
    if (/fact/.test(q)) return { action: 'execute', command: 'fact', args: '' };
    if (/quote/.test(q)) return { action: 'execute', command: 'quote', args: '' };
    if (/news/.test(q)) return { action: 'execute', command: 'news', args: '' };
    if (/bible/.test(q)) return { action: 'execute', command: 'bible', args: q.replace(/bible/, '').trim() };
    if (/riddle/.test(q)) return { action: 'execute', command: 'riddle', args: '' };
    if (/weather/.test(q)) return { action: 'execute', command: 'weather', args: q.replace(/weather/, '').trim() };
    if (/lyrics/.test(q)) return { action: 'execute', command: 'lyrics', args: q.replace(/lyrics/, '').trim() };
    if (/sticker/.test(q)) return { action: 'execute', command: 'sticker', args: '' };
    if (/meme/.test(q)) return { action: 'execute', command: 'meme', args: '' };
    if (/tts|speak/.test(q)) return { action: 'execute', command: 'tts', args: q.replace(/tts|speak/, '').trim() };
    if (/imagine|generate image|ai art/.test(q)) return { action: 'execute', command: 'imagine', args: q.replace(/imagine|generate image|ai art/, '').trim() };
    if (/tiktok/.test(q)) return { action: 'execute', command: 'tiktok', args: q };
    if (/instagram|ig/.test(q)) return { action: 'execute', command: 'instagram', args: q };
    if (/facebook|fb/.test(q)) return { action: 'execute', command: 'facebook', args: q };
    if (/youtube|yt/.test(q)) return { action: 'execute', command: 'video', args: q };
    return null;
}

// --- Execute Commands ---
async function executeCommand(intent, sock, chatId, senderId, botId) {
    const { command, args } = intent;
    const fakeMessage = {
        key: { remoteJid: chatId, participant: senderId },
        message: { conversation: args ? `.${command} ${args}` : `.${command}` },
        pushName: 'User'
    };

    try {
        switch (command) {
            case 'play': case 'song': await playCommand(sock, chatId, fakeMessage, botId); break;
            case 'spotify': await spotifyCommand(sock, chatId, fakeMessage, botId); break;
            case 'sticker': await stickerCommand(sock, chatId, fakeMessage, botId); break;
            case 'meme': await memeCommand(sock, chatId, botId); break;
            case 'tts': await ttsCommand(sock, chatId, args || 'Hello', botId); break;
            case 'imagine': await imagineCommand(sock, chatId, fakeMessage, botId); break;
            case 'weather': await weatherCommand(sock, chatId, args, botId); break;
            case 'lyrics': await lyricsCommand(sock, chatId, args, botId); break;
            case 'tiktok': await tiktokCommand(sock, chatId, fakeMessage, botId); break;
            case 'instagram': await instagramCommand(sock, chatId, fakeMessage, botId); break;
            case 'facebook': await facebookCommand(sock, chatId, fakeMessage, botId); break;
            case 'video': case 'ytmp4': await videoCommand(sock, chatId, fakeMessage); break;
            case 'qvideo': case 'yt2mp4': await videoCommand2(sock, chatId, fakeMessage); break;

            case 'joke': await jokeCommand(sock, chatId, botId); break;
            case 'fact': await factCommand(sock, chatId, botId); break;
            case 'quote': await sendQuoteOfDay(sock, chatId, senderId); break;
            case 'news': await newsCommand(sock, chatId, botId); break;
            case 'bible': await bibleCommand(sock, chatId, args, botId); break;
            case 'riddle': await sendRiddle(sock, chatId); break;
            case 'dare': await sendDare(sock, chatId, senderId); break;
            case 'truth': await sendTruth(sock, chatId, senderId); break;
            case 'alive': await aliveCommand(sock, chatId, botId); break;
            case 'ping': await pingCommand(sock, chatId, botId); break;
            case 'help': case 'menu': await helpCommand(sock, chatId, global.channelLink, botId); break;
            case 'github': await githubCommand(sock, chatId, botId); break;
            case 'clear': await clearCommand(sock, chatId, botId); break;
            case 'compliment': await complimentCommand(sock, chatId, fakeMessage, botId); break;
            case 'insult': await insultCommand(sock, chatId, fakeMessage, botId); break;
            case '8ball': await eightBallCommand(sock, chatId, args, botId); break;

            // Games
            case 'hangman': await startHangman(sock, chatId, botId); break;
            case 'guess': await guessLetter(sock, chatId, args, botId); break;
            case 'trivia': await startTrivia(sock, chatId, botId); break;
            case 'answer': await answerTrivia(sock, chatId, args, botId); break;
            case 'math': await mathGameCommand(sock, chatId, fakeMessage, args, botId); break;
            case 'tictactoe': case 'ttt': await tictactoeCommand(sock, chatId, senderId, args, botId); break;
            case 'move': await handleTicTacToeMove(sock, chatId, senderId, args, botId); break;
            case 'surrender': await handleTicTacToeMove(sock, chatId, senderId, 'surrender', botId); break;

            // Admin/Owner
            case 'ban': await banCommand(sock, chatId, fakeMessage, botId); break;
            case 'unban': await unbanCommand(sock, chatId, fakeMessage, botId); break;
            case 'kick': await kickCommand(sock, chatId, senderId, [], fakeMessage, botId); break;
            case 'mute': await muteCommand(sock, chatId, senderId, parseInt(args) || 5, botId); break;
            case 'unmute': await unmuteCommand(sock, chatId, senderId, botId); break;
            case 'promote': await promoteCommand(sock, chatId, [], fakeMessage, botId); break;
            case 'demote': await demoteCommand(sock, chatId, [], fakeMessage, botId); break;
            case 'tagall': await tagAllCommand(sock, chatId, senderId, botId); break;
            case 'warn': await warnCommand(sock, chatId, senderId, [], fakeMessage, botId); break;
            case 'warnings': await warningsCommand(sock, chatId, [], botId); break;
            case 'welcome': await welcomeCommand(sock, chatId, fakeMessage, botId); break;
            case 'goodbye': await goodbyeCommand(sock, chatId, fakeMessage, botId); break;
            case 'staff': await staffCommand(sock, chatId, fakeMessage, botId); break;
            case 'groupinfo': await groupInfoCommand(sock, chatId, fakeMessage, botId); break;
            case 'resetlink': await resetlinkCommand(sock, chatId, senderId, botId); break;
            case 'owner': await ownerCommand(sock, chatId, botId); break;

            default:
                await sock.sendMessage(chatId, { text: `❌ Unknown command: ${command}` });
        }
    } catch (err) {
        console.error(`Failed to execute: ${command}`, err);
        await sock.sendMessage(chatId, { text: `❌ Failed to run: ${command}` });
    }
}

// --- AI Query Handler ---
async function sendBotAiQuery(sock, chatId, query, senderId, botId) {
    if (!query || !query.trim()) {
        await sock.sendMessage(chatId, { text: "🤖 Try asking: `.bot play Kiss Daniel Showa` or `.bot tell me a joke`" });
        return;
    }

    const normalizedQuery = normalizeQuery(query);
    let fallbackIntent = detectCommandIntent(normalizedQuery);
    if (fallbackIntent) {
        return await executeCommand(fallbackIntent, sock, chatId, senderId, botId);
    }

    const systemPrompt = `
You are SEPTORCH, a smart WhatsApp bot assistant.
- Respond in JSON ONLY: { "action": "execute", "command": "...", "args": "..." } or { "action": "reply", "text": "..." }
- NEVER invent commands. Only use the ones listed below.

## 📚 Commands
(play, song, spotify, tiktok, instagram, facebook, video, qvideo, tomp3, simage, sticker, stickertelegram, attp, imagine, tts, blur, upload, qr, ss, weather, news, lyrics, bible, github, help, menu, quote, fact, joke, livescore, threads, urlshort, riddle, dare, truth, compliment, insult, 8ball, hangman, guess, trivia, answer, math, tictactoe, move, surrender, ban, unban, kick, mute, unmute, promote, demote, tagall, warn, warnings, welcome, goodbye, staff, groupinfo, resetlink, owner, clear, alive, ping, ai, translate, goodnight, shayari, roseday, flirt, character, ship, simp, stupid, wasted, pair)

Today: ${new Date().toLocaleString('en-NG', { timeZone: 'Africa/Lagos' })}
`;

    const messages = [
        { role: "system", content: systemPrompt },
        { role: "user", content: normalizedQuery }
    ];

    try {
        const response = await axios.post(
            OPENROUTER_API_URL,
            { model: MODEL_NAME, messages, max_tokens: 400, temperature: 0.5 },
            { headers: { 'Authorization': `Bearer ${OPENROUTER_API_KEY}`, 'Content-Type': 'application/json' } }
        );

        const raw = response.data.choices[0]?.message?.content.trim();
        const aiResponse = JSON.parse(raw);

        if (aiResponse.action === 'execute') {
            await executeCommand(aiResponse, sock, chatId, senderId, botId);
        } else if (aiResponse.action === 'reply') {
            await sock.sendMessage(chatId, { text: aiResponse.text });
            await saveNote(sock, chatId, 'bot', aiResponse.text, botId);
        }
    } catch (err) {
        console.error("[BOT AI ERROR]", err);
        await sock.sendMessage(chatId, { text: "❌ AI failed, please try again." });
    }
}

module.exports = { sendBotAiQuery, executeCommand };