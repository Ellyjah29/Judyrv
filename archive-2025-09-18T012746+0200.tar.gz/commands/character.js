const axios = require('axios');
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH_BOT MD',
            serverMessageId: -1
        }
    }
};


// 🔰 Box-style header formatter
const formatBox = (title, lines) => [
  `╭━━━[ *🔮 ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(line => `┃ ${line}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

async function characterCommand(sock, chatId, message) {
    let userToAnalyze;

    // 🔍 Detect mention or replied user
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    } else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.participant;
    }

    if (!userToAnalyze) {
        return sock.sendMessage(chatId, { 
            text: formatBox('Character', [
                '❌ Please *mention* someone or *reply* to their message to analyze character.'
            ]),
            ...channelInfo
        });
    }

    try {
        // 🖼️ Fetch profile pic
        let profilePic;
        try {
            profilePic = await sock.profilePictureUrl(userToAnalyze, 'image');
        } catch {
            profilePic = 'https://i.imgur.com/2wzGhpF.jpeg';
        }

        // 🎭 Trait pool
        const traits = [
            "Intelligent", "Creative", "Determined", "Ambitious", "Caring",
            "Charismatic", "Confident", "Empathetic", "Energetic", "Friendly",
            "Generous", "Honest", "Humorous", "Imaginative", "Independent",
            "Intuitive", "Kind", "Logical", "Loyal", "Optimistic",
            "Passionate", "Patient", "Persistent", "Reliable", "Resourceful",
            "Sincere", "Thoughtful", "Understanding", "Versatile", "Wise"
        ];

        // 🧠 Random traits
        const numTraits = Math.floor(Math.random() * 3) + 3; // 3–5
        const selected = [];
        while (selected.length < numTraits) {
            const t = traits[Math.floor(Math.random() * traits.length)];
            if (!selected.includes(t)) selected.push(t);
        }

        // 🎲 Trait % values
        const percentTraits = selected.map(trait =>
            `✨ ${trait}: ${Math.floor(Math.random() * 41) + 60}%`
        );

        const overall = Math.floor(Math.random() * 21) + 80; // 80–100%

        const caption = formatBox('Character Analysis', [
            `👤 User: @${userToAnalyze.split('@')[0]}`,
            '',
            ...percentTraits,
            '',
            `🎯 Overall Rating: ${overall}%`,
            '',
            '📝 *Note:* This is a fun prediction, not a real analysis.'
        ]);

        await sock.sendMessage(chatId, {
            image: { url: profilePic },
            caption,
            mentions: [userToAnalyze],
            ...channelInfo
        });

    } catch (err) {
        console.error('Character command error:', err);
        await sock.sendMessage(chatId, { 
            text: formatBox('Character', [
                '❌ Failed to analyze character. Try again later.'
            ]),
            ...channelInfo
        });
    }
}

module.exports = characterCommand;