const axios = require('axios');

// put your OpenRouter API key here directly
const OPENROUTER_API_KEY = "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";

async function imagineCommand(sock, chatId, message) {
    try {
        // Get the prompt from the message
        const prompt = message.message?.conversation?.trim() ||
                       message.message?.extendedTextMessage?.text?.trim() || '';

        // Remove the command prefix and trim
        const imagePrompt = prompt.slice(8).trim();

        if (!imagePrompt) {
            await sock.sendMessage(chatId, {
                text: '❌ Please provide a prompt for the image generation.\nExample: .imagine a beautiful sunset over mountains'
            }, { quoted: message });
            return;
        }

        // Send processing message
        await sock.sendMessage(chatId, {
            text: '🎨 Generating your image... Please wait.'
        }, { quoted: message });

        // Enhance the prompt with quality keywords
        const enhancedPrompt = enhancePrompt(imagePrompt);

        // Make API request to OpenRouter
        const response = await axios.post(
            "https://openrouter.ai/api/v1/images",
            {
                model: "stabilityai/stable-diffusion-xl-base-1.0", // good free/cheap model
                prompt: enhancedPrompt,
                size: "512x512"
            },
            {
                headers: {
                    "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
                    "Content-Type": "application/json"
                }
            }
        );

        // Convert base64 response to buffer
        const imageBase64 = response.data.data[0].b64_json;
        const imageBuffer = Buffer.from(imageBase64, "base64");

        // Send the generated image
        await sock.sendMessage(chatId, {
            image: imageBuffer,
            caption: `🎨 Generated image for: "${imagePrompt}"`
        }, { quoted: message });

    } catch (error) {
        console.error('Error in imagine command:', error?.response?.data || error.message);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to generate image. Please try again later.'
        }, { quoted: message });
    }
}

// Function to enhance the prompt
function enhancePrompt(prompt) {
    const qualityEnhancers = [
        'high quality',
        'detailed',
        'masterpiece',
        'best quality',
        'ultra realistic',
        '4k',
        'highly detailed',
        'professional photography',
        'cinematic lighting',
        'sharp focus'
    ];

    const numEnhancers = Math.floor(Math.random() * 2) + 3; // 3-4 enhancers
    const selectedEnhancers = qualityEnhancers
        .sort(() => Math.random() - 0.5)
        .slice(0, numEnhancers);

    return `${prompt}, ${selectedEnhancers.join(', ')}`;
}

module.exports = imagineCommand;