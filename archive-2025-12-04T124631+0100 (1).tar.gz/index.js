/**
 * WhatsApp Bot - Multi-Account Support with AUTO-RELOAD + SESSION LIFECYCLE
 * Fully compatible with Telegram Admin Bot
 * 
 * Copyright (c) 2025 Septorch 
 * UPGRADDED FOR BAILEYS v7.0.0-rc9
 */

// 👇 LOAD ENV FIRST
require('dotenv').config();

const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const telegramBot = require('./telegrambot.js').bot;
const { promises: fsp } = fs;
const axios = require('axios');
const FileType = require('file-type');
const { Boom } = require('@hapi/boom');
const PhoneNumber = require('awesome-phonenumber');
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif');
const {
  smsg,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetch,
  sleep,
  reSize
} = require('./lib/myfunc');

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  jidDecode,
  proto,
  jidNormalizedUser,
  makeCacheableSignalKeyStore,
  delay,
  getContentType
} = require('baileys');

const NodeCache = require("node-cache");
const pino = require("pino");

// Load handlers — will be reloaded only on full restart or settings change
let handlers = require('./main');
let handleMessages = handlers.handleMessages;
let handleGroupParticipantUpdate = handlers.handleGroupParticipantUpdate;
let handleStatus = handlers.handleStatus;

global.botInstances = {};
global.settings = require('./settings');
global.isReloading = false;

// Store for messages
const msgStore = {};

// ✅ CORRECTED: Valid store object with proper async groupMetadata
const store = {
  messages: msgStore,
  contacts: {},
  chats: {},
  // 👇 FIX: Proper async method syntax
  groupMetadata: async (jid) => {
    return {};
  },
  bind: function (ev) {
    ev.on('messages.upsert', ({ messages }) => {
      messages.forEach(msg => {
        if (msg.key && msg.key.remoteJid) {
          this.messages[msg.key.remoteJid] = this.messages[msg.key.remoteJid] || {};
          this.messages[msg.key.remoteJid][msg.key.id] = msg;
        }
      });
    });
    ev.on('contacts.update', (contacts) => {
      contacts.forEach(contact => {
        if (contact.id) {
          this.contacts[contact.id] = contact;
        }
      });
    });
  },
  loadMessage: async (jid, id) => {
    return this.messages[jid]?.[id] || null;
  }
};

// Clean session manager
async function downloadSession(sessionPath, sessionId) {
  const sessionFile = path.join(sessionPath, 'creds.json');
  if (!fs.existsSync(sessionFile)) {
    if (!sessionId) {
      console.log(chalk.yellow(`⚠️ SESSION_ID not provided for ${sessionPath}`));
      return;
    }
    try {
      console.log(chalk.blue(`📥 Downloading session for ${sessionPath}...`));
      const file = require('megajs').File.fromURL(`https://mega.nz/file/${sessionId}`);
      const data = await new Promise((resolve, reject) => {
        file.download((err, data) => (err ? reject(err) : resolve(data)));
      });
      fs.mkdirSync(sessionPath, { recursive: true });
      fs.writeFileSync(sessionFile, data);
      console.log(chalk.green(`✅ Session downloaded for ${sessionPath}.`));
    } catch (error) {
      console.error(
        chalk.red(`❌ Session download failed for ${sessionPath}:`, error.message)
      );
    }
  }
}

function getExpiryTimestamp(expiryDateStr) {
  const date = new Date(expiryDateStr);
  if (isNaN(date.getTime())) {
    throw new Error(`Invalid expiry date: ${expiryDateStr}`);
  }
  return date.setHours(23, 59, 59, 999);
}

// SAFE START
async function startBot(botConfig, botId) {
  console.log(chalk.cyan(`🚀 Attempting to start ${botId}...`));
  await safeStopBot(botId);
  const sessionPath = path.join(__dirname, 'session', botId);

  // ✅ EXPIRY CHECK ON STARTUP
  if (botConfig.expiry) {
    botConfig.expiryTimestamp = getExpiryTimestamp(botConfig.expiry);
    if (Date.now() > botConfig.expiryTimestamp) {
      console.log(chalk.red(`🛑 ${botId} is EXPIRED (${botConfig.expiry}) — skipping startup.`));
      if (botConfig.telegramUserId) {
        try {
          await telegramBot.sendMessage(
            botConfig.telegramUserId,
            `🛑 *${botConfig.botName}* is EXPIRED\n📅 Expiry: ${botConfig.expiry}\n💡 Extend the date in \`settings.js\` and restart the bot.`,
            { parse_mode: 'Markdown' }
          );
        } catch (e) {
          console.error(chalk.red(`❌ Failed to notify owner via Telegram:`), e.message);
        }
      }
      return null;
    }
    console.log(chalk.blue(`🕒 Bot ${botConfig.botName} will expire on: ${botConfig.expiry}`));
  }

  await downloadSession(sessionPath, botConfig.SESSION_ID);
  let { version } = await fetchLatestBaileysVersion();

  const logLevel = process.env.DEBUG === 'true' ? 'debug' : 'silent';
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
  const msgRetryCounterCache = new NodeCache();
  const XeonBotInc = makeWASocket({
    version,
    logger: pino({ level: logLevel }),
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'fatal' }))
    },
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    getMessage: async (key) => {
      const jid = jidNormalizedUser(key.remoteJid);
      const msg = await store.loadMessage(jid, key.id);
      return msg || undefined;
    },
    msgRetryCounterCache,
    defaultQueryTimeoutMs: undefined,
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 30000
  });

  global.botname = botConfig.botName || 'WhatsApp Bot';
  global.themeemoji = botConfig.themeemoji || '•';
  global.owner = [botConfig.ownerNumber];
  store.bind(XeonBotInc.ev);

  XeonBotInc.ev.on('messages.upsert', async (chatUpdate) => {
    if (global.isReloading) return;
    if (botConfig.manuallyStopped) return;
    if (!chatUpdate.messages?.[0]) return;
    try {
      const mek = chatUpdate.messages[0];
      const m = smsg(XeonBotInc, mek, store);

      if (process.env.DEBUG === 'true') {
        console.log(chalk.yellow(`📦 smsg returned: ${m ? 'VALID' : 'NULL'}`));
      }

      if (!m?.message) return;

      await handleMessageWithIsolation(XeonBotInc, m, chatUpdate, botId, botConfig);
    } catch (err) {
      console.error(chalk.red(`💥 Isolated error in ${botId} message handler:`), err.message);
    }
  });

  setupEventHandlers(XeonBotInc, botId, botConfig);
  XeonBotInc.ev.on('connection.update', async (update) => {
    await handleConnectionUpdate(XeonBotInc, update, botConfig, botId);
  });
  XeonBotInc.ev.on('creds.update', saveCreds);

  if (!global.botInstances) global.botInstances = {};
  global.botInstances[botId] = XeonBotInc;
  global.botInstances[botId].botConfig = botConfig; // 👈 FOR SETTINGS WATCHER
  console.log(chalk.green(`✅ ${botId} initialized successfully`));
  return XeonBotInc;
}

// ✅ CRITICAL FIX: Safe message handling with EXPIRY CHECK
async function handleMessageWithIsolation(sock, m, chatUpdate, botId, botConfig) {
  if (!m?.message) return;

  if (typeof handleMessages !== 'function') {
    console.error(chalk.redBright('❌ handleMessages is not a function! Restart required.'));
    return;
  }

  try {
    if (m.key?.remoteJid === 'status@broadcast') {
      await handleStatus(sock, chatUpdate, botId);
      return;
    }
    if (m.key?.id?.startsWith('BAE5') && m.key?.id?.length === 16) return;

    sock.public = true;
    if (!sock.public && !m.key.fromMe && chatUpdate.type === 'notify') return;

    // ✅ SILENT EXPIRY HANDLING — NO USER MESSAGE
    if (botConfig.expiry && botConfig.expiryTimestamp && Date.now() > botConfig.expiryTimestamp) {
      console.log(chalk.red(`🛑 ${botId} has EXPIRED during runtime — stopping bot.`));
      if (botConfig.telegramUserId) {
        try {
          await telegramBot.sendMessage(
            botConfig.telegramUserId,
            `🛑 *${botConfig.botName}* has STOPPED due to expiry\n📅 Expiry: ${new Date(botConfig.expiryTimestamp).toLocaleDateString('en-GB')}\n💡 Update \`expiry\` in settings and restart.`,
            { parse_mode: 'Markdown' }
          );
        } catch (e) {}
      }
      await safeStopBot(botId);
      return;
    }

    await Promise.race([
      handleMessages(sock, chatUpdate, true, botId),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Handler timeout')), 30000))
    ]);
  } catch (err) {
    console.error(chalk.red(`🚨 CRITICAL ERROR in ${botId}:`), err.message);
    console.error(chalk.gray(`📄 Msg ID: ${m?.key?.id}`));

    if (m?.key?.remoteJid) {
      try {
        await sock.sendMessage(m.key.remoteJid, {
          text: '❌ Command failed. Owner has been notified.',
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: '120363387922693296@newsletter',
              newsletterName: 'SEPTORCH',
              serverMessageId: -1
            }
          }
        });
      } catch (e) {}
    }

    const msg = (err.message || '').toLowerCase();
    if (msg.includes('401') || msg.includes('403') || msg.includes('unauthorized')) {
      console.warn(chalk.red(`🛑 Session terminated for ${botId}`));
      const sessionPath = path.join(__dirname, 'session', botId);
      if (fs.existsSync(sessionPath)) {
        fs.rmSync(sessionPath, { recursive: true, force: true });
      }
      const botIndex = parseInt(botId.replace('bot', '')) - 1;
      const config = global.settings.bots[botIndex];
      if (config?.telegramUserId) {
        try {
          await telegramBot.sendMessage(config.telegramUserId, `🛑 *${config.botName}* SESSION TERMINATED
⚠️ WhatsApp rejected your session (Error 401/403).
✅ Follow reset steps in Telegram to reconnect!`, { parse_mode: 'Markdown' });
        } catch (e) {}
      }
      await safeStopBot(botId);
      return;
    }

    try {
      const config = global.settings.bots[parseInt(botId.replace('bot', '')) - 1];
      if (config?.telegramUserId) {
        await telegramBot.sendMessage(config.telegramUserId, 
          `🚨 *${config.botName}* HANDLER CRASHED
Error: ${err.message}
Msg ID: ${m?.key?.id || 'N/A'}`, 
          { parse_mode: 'Markdown' }
        );
      }
    } catch (e) {}
  }
}

// Setup event handlers
function setupEventHandlers(sock, botId, botConfig) {
  sock.decodeJid = (jid) => jidNormalizedUser(jid);

  sock.getName = async (jid, withoutContact = false) => {
    try {
      let id = jidNormalizedUser(jid);
      withoutContact = sock.withoutContact || withoutContact;
      let v;
      if (id.endsWith('@g.us')) {
        v = store.contacts[id] || {};
        if (!(v.name || v.subject)) {
          try {
            v = await sock.groupMetadata(id);
          } catch (e) {
            console.error(`Failed to get group metadata for ${id}:`, e);
          }
        }
        return v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international');
      } else {
        v = id === '0@s.whatsapp.net' ? { id, name: 'WhatsApp' } :
          id === jidNormalizedUser(sock.user?.id) ? sock.user :
          (store.contacts[id] || {});
        return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international');
      }
    } catch (err) {
      console.error(`Error getting name for ${jid}:`, err);
      return jid.split('@')[0];
    }
  };

  sock.public = true;

  sock.ev.on('group-participants.update', async (update) => {
    if (global.isReloading || botConfig.manuallyStopped) return;
    try {
      await handleGroupParticipantUpdate(sock, update, botId);
    } catch (err) {
      console.error(chalk.red(`💥 Error in group participant handler for ${botId}:`), err);
    }
  });

  sock.ev.on('status.update', async (status) => {
    if (global.isReloading || botConfig.manuallyStopped) return;
    try {
      await handleStatus(sock, status, botId);
    } catch (err) {
      console.error(chalk.red(`💥 Error in status handler for ${botId}:`), err);
    }
  });
}

// Handle connection updates
async function handleConnectionUpdate(sock, update, botConfig, botId) {
  const { connection, lastDisconnect } = update;
  const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
  const botIndex = parseInt(botId.replace('bot', '')) - 1;
  if (connection === 'open') {
    console.log(chalk.yellow(`🌿 Connected to => ${JSON.stringify(sock.user, null, 2)}`));
    const botNumber = jidNormalizedUser(sock.user.id);
    const now = new Date();
    const nigerianDate = now.toLocaleDateString('en-NG', {
      timeZone: 'Africa/Lagos',
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    const nigerianTime = now.toLocaleTimeString('en-NG', {
      timeZone: 'Africa/Lagos',
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric',
      hour12: true
    });

    const messageText = `🤖 *${botConfig.botName}* is now online!
📅 *Date:* ${nigerianDate}
⏰ *Time:* ${nigerianTime}
✅ *Status:* Ready to serve!
*Connected on:* ${botNumber.replace('@s.whatsapp.net', '')}
`;

    try {
      await sock.sendMessage(botNumber, { text: messageText });
      console.log(chalk.green(`✅ Connection message sent to bot itself: ${botNumber}`));
    } catch (err) {
      console.error(chalk.red(`❌ Failed to send connection message to itself:`, err.message));
    }

    if (!global.botInstances[botId]) global.botInstances[botId] = {};
    global.botInstances[botId].phoneJid = sock.user.id;
    global.botInstances[botId].retryCount = 0;
    global.botInstances[botId].lastAlive = Date.now();

    if (botConfig.manuallyStopped) {
      console.log(chalk.blue(`✅ Clearing manually stopped flag for ${botId}`));
      delete botConfig.manuallyStopped;
      try {
        const settingsPath = path.join(__dirname, 'settings.js');
        const newSettings = { ...global.settings };
        if (newSettings.bots[botIndex]) {
          delete newSettings.bots[botIndex].manuallyStopped;
          const data = `exports.bots = ${JSON.stringify(newSettings.bots, null, 2)};
exports.userStates = ${JSON.stringify(newSettings.userStates || {}, null, 2)};
exports.blacklistedUsers = ${JSON.stringify(newSettings.blacklistedUsers || [], null, 2)};`;
          fs.writeFileSync(settingsPath, data);
          global.settings = newSettings;
          console.log(chalk.green(`✅ Settings saved after clearing manuallyStopped flag`));
        }
      } catch (saveErr) {
        console.error(chalk.red(`❌ Failed to save settings after clearing manuallyStopped:`), saveErr);
      }
    }

    console.log(chalk.magenta('< ================================================== >'));
    console.log(chalk.green(`${global.themeemoji} 🤖 ${global.botname} Connected Successfully! ✅`));
    console.log(chalk.magenta('< ================================================== >'));

    const lastNotification = global.botInstances[botId]?.lastOnlineNotification || 0;
    const notificationCooldown = 86400000;
    if (botConfig.telegramUserId && !botConfig.silentStart && (Date.now() - lastNotification > notificationCooldown)) {
      try {
        await telegramBot.sendMessage(botConfig.telegramUserId, `✅ *${botConfig.botName}* is now ONLINE!
🟢 Status: Connected successfully
📱 Number: ${botNumber.replace('@s.whatsapp.net', '')}
⏰ Time: ${nigerianTime}
📅 Date: ${nigerianDate}
The bot is ready to serve commands!`, { parse_mode: 'Markdown' });
        console.log(chalk.green(`✅ Online notification sent to Telegram: ${botConfig.telegramUserId}`));
        if (global.botInstances[botId]) {
          global.botInstances[botId].lastOnlineNotification = Date.now();
        }
      } catch (tgErr) {
        console.error(chalk.red(`❌ Failed to send Telegram online notification:`), tgErr.message);
      }
    }
  }
  else if (connection === 'close') {
    if (botConfig.manuallyStopped) {
      console.log(chalk.yellow(`⏸️ ${botConfig.botName} was manually stopped — ignoring close event.`));
      return;
    }

    // ✅ SKIP AUTO-RESTART IF EXPIRED
    if (botConfig.expiry && botConfig.expiryTimestamp && Date.now() > botConfig.expiryTimestamp) {
      console.log(chalk.red(`🛑 ${botId} is expired — skipping auto-restart.`));
      return;
    }

    console.log(chalk.red(`❌ Connection closed for ${botConfig.botName}. Status: ${statusCode || 'Unknown'}`));
    if (!global.botInstances[botId]) global.botInstances[botId] = {};
    global.botInstances[botId].retryCount = global.botInstances[botId].retryCount || 0;
    global.botInstances[botId].retryCount++;

    if (statusCode === 401) {
      console.warn(chalk.red(`🛑 SESSION TERMINATED (401) for ${botConfig.botName}`));
      const sessionPath = path.join(__dirname, 'session', botId);
      try {
        if (fs.existsSync(sessionPath)) {
          fs.rmSync(sessionPath, { recursive: true, force: true });
          console.log(chalk.gray(`🗑️ Session purged: ${sessionPath}`));
        }
      } catch (err) {
        console.error(chalk.red(`⚠️ Cleanup failed: ${err.message}`));
      }
      global.botInstances[botId].loggedOut = true;

      if (botConfig.telegramUserId) {
        try {
          await telegramBot.sendMessage(botConfig.telegramUserId, `📴 Oops! *${botConfig.botName}* got disconnected from WhatsApp.
1️⃣ Tap → /start  
2️⃣ Click “My Bots”  
3️⃣ Tap “Reset” to reconnect with new SESSION_ID`, { parse_mode: 'Markdown' });
          console.log(chalk.green(`✅ Hard logout message sent via Telegram to: ${botConfig.telegramUserId}`));
        } catch (err) {
          console.error(chalk.red(`❌ Failed to send Telegram message:`), err.message);
        }
      }
    }

    const shouldRetry = [408, 420, 500, 502, 503, 404].includes(statusCode) || !statusCode || statusCode === 440 || statusCode === 403;
    if (shouldRetry && global.botInstances[botId].retryCount <= 5) {
      const delayMs = Math.min(5000 * global.botInstances[botId].retryCount, 30000);
      console.log(chalk.yellow(`🔁 Retrying ${botConfig.botName} in ${delayMs/1000}s... (Attempt ${global.botInstances[botId].retryCount}/5)`));
      setTimeout(async () => {
        try {
          console.log(chalk.blue(`🔄 Attempting to restart ${botId} after disconnect...`));
          await startBot(botConfig, botId);
        } catch (restartErr) {
          console.error(chalk.red(`❌ Failed to restart ${botId}: ${restartErr.message}`));
        }
      }, delayMs);
    } else {
      console.warn(chalk.red(`⚠️ Giving up on ${botConfig.botName} after ${global.botInstances[botId].retryCount} attempts.`));
      if (botConfig.telegramUserId) {
        try {
          await telegramBot.sendMessage(botConfig.telegramUserId, `⚠️ *${botConfig.botName}* DISCONNECTED
🔄 Status code: ${statusCode || 'Unknown'}
✅ TO RECONNECT: Tap /start → My Bots → Reset`, { parse_mode: 'Markdown' });
        } catch (tgErr) {
          console.error(chalk.red(`❌ Failed to send Telegram disconnect notice:`), tgErr.message);
        }
      }
    }
  }
  else if (connection === 'connecting') {
    console.log(chalk.blue(`🔄 ${botConfig.botName} is connecting...`));
  }
  else if (connection === 'close' && statusCode === DisconnectReason.restartRequired) {
    console.log(chalk.yellow(`🔄 ${botConfig.botName} requires restart - reconnecting...`));
    setTimeout(() => startBot(botConfig, botId), 1000);
  }
}

// SAFE STOP
async function safeStopBot(botId) {
  console.log(chalk.yellow(`🛑 Attempting safe stop for ${botId}...`));
  try {
    const sock = global.botInstances?.[botId];
    if (!sock) {
      console.log(chalk.gray(`ℹ️ ${botId} is not running.`));
      return true;
    }

    const botIndex = parseInt(botId.replace('bot', '')) - 1;
    if (global.settings.bots[botIndex]) {
      global.settings.bots[botIndex].manuallyStopped = true;
      try {
        const settingsPath = path.join(__dirname, 'settings.js');
        const newSettings = { ...global.settings };
        const data = `exports.bots = ${JSON.stringify(newSettings.bots, null, 2)};
exports.userStates = ${JSON.stringify(newSettings.userStates || {}, null, 2)};
exports.blacklistedUsers = ${JSON.stringify(newSettings.blacklistedUsers || [], null, 2)};`;
        fs.writeFileSync(settingsPath, data);
        global.settings = newSettings;
        console.log(chalk.green(`✅ Settings saved after marking ${botId} as manually stopped`));
      } catch (saveErr) {
        console.error(chalk.red(`❌ Failed to save settings:`), saveErr);
      }
    }

    if (sock.authState?.saveCreds) {
      await sock.authState.saveCreds();
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    sock.ev.removeAllListeners();
    delete global.botInstances[botId];
    console.log(chalk.green(`✅ ${botId} fully stopped and cleaned up.`));
    return true;
  } catch (err) {
    console.error(chalk.red(`💥 Failed to safely stop ${botId}:`), err.message);
    if (global.botInstances?.[botId]) {
      try {
        global.botInstances[botId].ev?.removeAllListeners?.();
        delete global.botInstances[botId];
      } catch (cleanupErr) {
        console.error(chalk.red(`❌ Cleanup after stop failure also failed:`), cleanupErr.message);
      }
    }
    return false;
  }
}

// SAFE RESTART
async function safeRestartBot(botId) {
  console.log(chalk.blue(`🔄 Attempting safe restart for ${botId}...`));
  try {
    const botIndex = parseInt(botId.replace('bot', '')) - 1;
    const botConfig = global.settings?.bots?.[botIndex];
    if (!botConfig || !botConfig.SESSION_ID) {
      throw new Error(`Bot config or SESSION_ID missing for ${botId}`);
    }
    await safeStopBot(botId);
    await new Promise(resolve => setTimeout(resolve, 1000));
    const sock = await startBot(botConfig, botId);
    console.log(chalk.green(`✅ ${botId} restarted successfully!`));
    return sock;
  } catch (err) {
    console.error(chalk.red(`❌ Safe restart failed for ${botId}:`), err.message);
    throw err;
  }
}

// Telegram functions
global.startBotById = async (botId) => {
  const botIndex = parseInt(botId.replace('bot', '')) - 1;
  const botConfig = global.settings?.bots?.[botIndex];
  if (!botConfig) throw new Error(`Bot config not found for ${botId}`);
  const existing = global.botInstances?.[botId];
  if (existing?.user) {
    console.log(chalk.yellow(`⚠️ ${botId} is already running.`));
    return existing;
  }
  return await startBot(botConfig, botId);
};
global.stopBot = async (botId) => {
  return await safeStopBot(botId);
};
global.reconnectBot = async (botId) => {
  return await safeRestartBot(botId);
};

// Start all bots
async function startAllBots() {
  console.log(chalk.cyan('🤖 Starting all WhatsApp bots...'));
  for (let i = 0; i < global.settings.bots.length; i++) {
    const botConfig = global.settings.bots[i];
    const botId = `bot${i + 1}`;
    if (!botConfig.SESSION_ID) {
      console.log(chalk.yellow(`⚠️ Skipping ${botConfig.botName || botId}: SESSION_ID missing.`));
      continue;
    }
    if (botConfig.manuallyStopped) {
      console.log(chalk.blue(`⏸️ Skipping ${botConfig.botName || botId}: manually stopped.`));
      continue;
    }
    console.log(chalk.cyan(`🚀 Starting bot: ${botConfig.botName || botId}`));
    try {
      const sock = await startBot(botConfig, botId);
      if (!global.botInstances) global.botInstances = {};
      if (sock) global.botInstances[botId] = sock;
      if (i < global.settings.bots.length - 1) {
        console.log(chalk.yellow('🕒 Waiting 3 seconds before starting next bot...'));
        await new Promise(resolve => setTimeout(resolve, 3000));
      }
    } catch (err) {
      console.error(chalk.red(`❌ Failed to start ${botConfig.botName || botId}:`), err.message);
      if (botConfig.telegramUserId) {
        try {
          await telegramBot.sendMessage(botConfig.telegramUserId, `❌ *${botConfig.botName || botId}* START FAILED
Error: ${err.message}`, { parse_mode: 'Markdown' });
        } catch (tgErr) {
          console.error(chalk.red(`❌ Failed to send Telegram start failure notice:`), tgErr.message);
        }
      }
    }
  }
  console.log(chalk.green('✅ All bots started successfully!'));
}

// ✅ WATCH settings.js FOR CHANGES
function watchSettingsFile() {
  const settingsPath = path.join(__dirname, 'settings.js');
  if (!fs.existsSync(settingsPath)) {
    console.log(chalk.yellow('⚠️ settings.js not found — auto-reload disabled.'));
    return;
  }

  const watcher = fs.watch(settingsPath, { persistent: true }, async (eventType) => {
    if (eventType !== 'change') return;

    console.log(chalk.blue('🔄 settings.js updated — checking for bot config changes...'));

    delete require.cache[require.resolve('./settings')];
    let newSettings;
    try {
      newSettings = require('./settings');
    } catch (err) {
      console.error(chalk.red('❌ Failed to parse updated settings.js — skipping reload:'), err.message);
      return;
    }

    global.settings = newSettings;

    for (let i = 0; i < newSettings.bots.length; i++) {
      const botConfig = newSettings.bots[i];
      const botId = `bot${i + 1}`;
      const currentSock = global.botInstances?.[botId];

      if (!currentSock?.user) continue;

      const oldConfig = currentSock.botConfig || {};
      const sessionChanged = oldConfig.SESSION_ID !== botConfig.SESSION_ID;
      const expiryChanged = oldConfig.expiry !== botConfig.expiry;

      if (sessionChanged || expiryChanged) {
        console.log(chalk.yellow(`🔄 Detected config change for ${botConfig.botName} — restarting...`));
        try {
          if (global.botInstances[botId]) {
            global.botInstances[botId].botConfig = botConfig;
          }
          await safeRestartBot(botId);
        } catch (err) {
          console.error(chalk.red(`❌ Failed to restart ${botId}:`, err.message));
        }
      }
    }
  });

  process.on('exit', () => watcher.close());
  process.on('SIGINT', () => {
    watcher.close();
    process.exit(0);
  });
}

// Error handling
process.on('uncaughtException', (error) => {
  console.error(chalk.red('🚨 Uncaught Exception:'), error);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error(chalk.red('🚨 Unhandled Rejection at:'), promise, 'reason:', reason);
});

// Graceful shutdown
async function gracefulShutdown(signal) {
  console.log(chalk.yellow(`\n${signal} received - Shutting down gracefully...`));
  const botIds = Object.keys(global.botInstances || {});
  for (const botId of botIds) {
    console.log(chalk.blue(`🛑 Stopping ${botId}...`));
    await safeStopBot(botId);
  }
  console.log(chalk.green('✅ All bots stopped. Goodbye!'));
  process.exit(0);
}
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGQUIT', () => gracefulShutdown('SIGQUIT'));

// Health checks
function setupHealthChecks() {
  setInterval(() => {
    for (const [botId, sock] of Object.entries(global.botInstances || {})) {
      const isOpen = !!sock.user;
      const alive = Date.now() - (global.botInstances[botId]?.lastAlive || 0);
      console.log(chalk.gray(`📊 ${botId} | WS: ${isOpen ? 'OPEN' : 'CLOSED'} | Last msg: ${Math.floor(alive / 1000)}s ago`));
    }
  }, 30000);
}

// Main startup
async function main() {
  try {
    console.log(chalk.cyan('🤖 Starting WhatsApp Bot System...'));
    await startAllBots();
    watchSettingsFile(); // 👈 ENABLED
    setupHealthChecks();
    console.log(chalk.green('\n✅ SYSTEM READY - All bots operational!'));
    console.log(chalk.magenta('============================================'));
  } catch (error) {
    console.error(chalk.red('❌ Fatal error starting bot system:'), error);
    process.exit(1);
  }
}

if (require.main === module) {
  main().catch(err => {
    console.error(chalk.red('💥 Unhandled startup error:'), err);
    process.exit(1);
  });
}

module.exports = { startBot, safeStopBot, safeRestartBot, startAllBots };