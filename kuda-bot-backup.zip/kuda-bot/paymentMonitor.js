// paymentMonitor.js
// Handles Gmail IMAP connection, parsing Kuda emails, saving payments.json
// and notifying waiting users (10-minute watch window).
// Export: startEmailMonitor(bot, userStates)

const Imap = require('imap');
const { simpleParser } = require('mailparser');
const path = require('path');
const fs = require('fs').promises;

const PAYMENTS_FILE = path.join(__dirname, 'payments.json');

async function loadJson(file, fallback = []) {
  try {
    const data = await fs.readFile(file, 'utf8');
    return JSON.parse(data);
  } catch {
    return fallback;
  }
}

async function saveJson(file, data) {
  await fs.writeFile(file, JSON.stringify(data, null, 2));
}

// Flexible name matching (partial words, any order)
function nameMatches(inputName, paymentName) {
  const inputWords = inputName.toLowerCase().split(/\s+/);
  const paymentWords = paymentName.toLowerCase().split(/\s+/);
  return inputWords.every(word => paymentWords.includes(word));
}

/**
 * startEmailMonitor(bot, userStates, options)
 * - bot: TelegramBot instance
 * - userStates: Map of userId => state object (mutated by bot.js)
 * - options: { email, password, imapHost, imapPort, imapTls, adminId }
 */
function startEmailMonitor(bot, userStates, options = {}) {
  const EMAIL = options.email;
  const EMAIL_PASSWORD = options.password;
  const HOST = options.imapHost || 'imap.gmail.com';
  const PORT = options.imapPort || 993;
  const TLS = options.imapTls !== undefined ? options.imapTls : true;
  const ADMIN_ID = options.adminId || null;

  if (!EMAIL || !EMAIL_PASSWORD) {
    console.warn('⚠️ paymentMonitor: Email credentials not provided — email monitor disabled.');
    return;
  }

  const connectImap = () => {
    const imap = new Imap({
      user: EMAIL,
      password: EMAIL_PASSWORD,
      host: HOST,
      port: PORT,
      tls: TLS,
      tlsOptions: { rejectUnauthorized: false }
    });

    const checkEmails = async () => {
      try {
        const payments = await loadJson(PAYMENTS_FILE, []);
        imap.openBox('INBOX', false, (err, box) => {
          if (err) {
            console.error('paymentMonitor: Failed to open INBOX:', err);
            return;
          }

          imap.search(['UNSEEN', ['FROM', 'no-reply@kuda.com']], (err, results) => {
            if (err) {
              console.error('paymentMonitor: IMAP search error:', err);
              return;
            }
            if (!results || results.length === 0) return;

            const f = imap.fetch(results, { bodies: '', markSeen: true });
            f.on('message', (msg) => {
              msg.on('body', async (stream) => {
                try {
                  const parsed = await simpleParser(stream);
                  const body = (parsed.text || parsed.html || '').replace(/\s+/g, ' ').trim();

                  // Try robust matches for Kuda-like emails
                  let m = body.match(/Transaction Notification\s+(.+?)\s+just sent you\s+₦([\d,]+(?:\.\d+)?)/i);
                  if (!m) m = body.match(/from\s+([A-Za-z0-9\s\.\-']+).*?₦([\d,]+(?:\.\d+)?)/i);
                  if (!m) return;

                  const senderRaw = m[1].trim();
                  const amountRaw = m[2];
                  const amount = parseFloat(amountRaw.replace(/,/g, ''));
                  const receivedAt = new Date(parsed.date || Date.now()).toISOString();

                  // Check duplicates
                  const duplicate = payments.some(p =>
                    p.sender === senderRaw &&
                    p.amount === amount &&
                    p.receivedAt === receivedAt
                  );

                  if (!duplicate) {
                    const newPayment = { sender: senderRaw, amount, receivedAt, claimedBy: null };
                    payments.push(newPayment);
                    await saveJson(PAYMENTS_FILE, payments);
                    console.log('paymentMonitor: 🆕 New payment saved:', newPayment);

                    // Notify admin
                    if (ADMIN_ID) {
                      try {
                        await bot.sendMessage(
                          ADMIN_ID,
                          `🆕 *New Payment Received*\n\n👤 ${senderRaw}\n💰 ₦${Number(amount).toFixed(2)}\n🕒 ${new Date(receivedAt).toLocaleString('en-NG', { timeZone: 'Africa/Lagos' })}`,
                          { parse_mode: 'Markdown' }
                        );
                      } catch (e) {
                        console.error('paymentMonitor: Failed to notify admin:', e);
                      }
                    }

                    // Notify waiting users with flexible name match
                    for (const [uid, state] of userStates.entries()) {
                      if (!state) continue;
                      if (state.step === 'waiting_payment') {
                        const waitingName = state.name || '';
                        const expectedAmount = state.expectedAmount;
                        if (nameMatches(waitingName, senderRaw) && Number(expectedAmount) === Number(amount)) {
                          try {
                            const paymentId = `${senderRaw}_${amount}_${receivedAt}`;
                            await bot.sendMessage(
                              uid,
                              `✅ We just detected a payment from *${senderRaw}* for ₦${Number(amount).toFixed(2)}.\n\nPress Confirm to complete the process.`,
                              {
                                parse_mode: 'Markdown',
                                reply_markup: {
                                  inline_keyboard: [
                                    [
                                      { text: '✅ Confirm', callback_data: 'confirm_' + paymentId },
                                      { text: '❌ Cancel', callback_data: 'cancel' }
                                    ]
                                  ]
                                }
                              }
                            );

                            userStates.set(uid, { step: 'awaiting_confirm', payment: newPayment });
                            console.log(`paymentMonitor: Notified waiting user ${uid} about payment from ${senderRaw}`);
                          } catch (e) {
                            console.error('paymentMonitor: failed to notify waiting user', uid, e);
                          }
                        }
                      }
                    }
                  }
                } catch (e) {
                  console.error('paymentMonitor: error parsing email body', e);
                }
              });
            });

            f.once('error', (err) => console.error('paymentMonitor: fetch error', err));
          });
        });
      } catch (e) {
        console.error('paymentMonitor: checkEmails error', e);
      }
    };

    imap.once('ready', () => {
      console.log('paymentMonitor: IMAP connected — starting periodic checks');
      checkEmails();
      const interval = setInterval(() => {
        if (imap.state === 'disconnected') {
          clearInterval(interval);
          try { imap.end(); } catch {}
          setTimeout(connectImap, 5000);
        } else {
          checkEmails();
        }
      }, 30 * 1000);
    });

    imap.once('error', (err) => {
      console.error('paymentMonitor: IMAP error', err);
      setTimeout(connectImap, 10000);
    });
    imap.once('end', () => {
      console.warn('paymentMonitor: IMAP ended — reconnecting in 10s');
      setTimeout(connectImap, 10000);
    });

    imap.connect();
  };

  connectImap();

  // Cleanup stale waiting states every minute
  setInterval(() => {
    const now = Date.now();
    for (const [uid, state] of userStates.entries()) {
      if (state && state.step === 'waiting_payment' && state.startedAt) {
        if (now - state.startedAt > 10 * 60 * 1000) {
          try { bot.sendMessage(uid, '❌ Still no payment detected for the name you provided. Please double-check your transfer or try again later.'); } catch {}
          userStates.delete(uid);
        }
      }
    }
  }, 60 * 1000);
}

module.exports = { startEmailMonitor };
