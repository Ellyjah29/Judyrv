// bot.js
require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const path = require('path');
const fs = require('fs').promises;
const crypto = require('crypto');

const { startEmailMonitor } = require('./paymentMonitor');

// === Partner system module ===
const partnerSystem = require('./partnerSystem');
// convenience destructure
const {
  addPartner,
  removePartnerByCode,
  listPartners,
  getPartnerByCode,
  getPartnerByUserId,
  recordReferral,
  resetPartnerSales,
  generatePayoutSummaryAndSaveSnapshot,
  getPayoutHistory,
  checkAndRunMonthlyResetIfNeeded,
  addSubadmin,
  removeSubadmin,
  listSubadmins,
  notifySubadmins,
  getPartnerStatsByUserId
} = partnerSystem;

// === CONFIG (hardcoded admin ID) ===
const ADMIN_ID = 7738315673;
const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const EMAIL = process.env.EMAIL;
const EMAIL_PASSWORD = process.env.EMAIL_PASSWORD;

const ACCOUNT_INFO = {
  name: 'Abiola Elijah Alalade',
  number: '2077149792',
  bank: 'Kuda'
};

// Files used by payment system
const PAYMENTS_FILE = path.join(__dirname, 'payments.json');
const CONFIRMED_FILE = path.join(__dirname, 'confirmed_payments.json');
const SETTINGS_FILE = path.join(__dirname, 'settings.json');
const KEYS_FILE = path.join(__dirname, 'keys.json');

// Use your bot username for referral links (no @)
const BOT_USERNAME = 'SEPTORCHBOT';
const REFERRAL_BASE_LINK = `https://t.me/${BOT_USERNAME}?start=`;

if (!TOKEN) {
  console.error('❌ TELEGRAM_BOT_TOKEN missing in environment. Exiting.');
  process.exit(1);
}

const bot = new TelegramBot(TOKEN, { polling: true });
const userStates = new Map();

// === Utility helpers ===
async function loadJson(file, fallback = []) {
  try { return JSON.parse(await fs.readFile(file, 'utf8')); }
  catch { return fallback; }
}
async function saveJson(file, data) {
  await fs.writeFile(file, JSON.stringify(data, null, 2));
}
function fmt(dateStr) {
  return new Date(dateStr).toLocaleString('en-NG', { timeZone: 'Africa/Lagos' });
}

// === Flexible name match ===
function nameMatches(inputName, paymentName) {
  const inputWords = inputName.toLowerCase().split(/\s+/);
  const paymentWords = paymentName.toLowerCase().split(/\s+/);
  return inputWords.every(word => paymentWords.includes(word));
}

// === Key assignment ===
async function assignNextKey() {
  const keys = await loadJson(KEYS_FILE, []);
  const idx = keys.findIndex(k => !k.used);
  if (idx === -1) return null;
  const key = keys[idx].key;
  keys[idx].used = true;
  await saveJson(KEYS_FILE, keys);
  return key;
}

// === Keyboards ===
function mainMenuKeyboard(isAdmin = false) {
  const kb = [
    [{ text: '💳 Make Payment', callback_data: 'make_payment' }],
    [{ text: '📋 My Transactions', callback_data: 'my_transactions' }],
    [{ text: '📈 My Partner Dashboard', callback_data: 'partner_dashboard' }],
    [{ text: '🆘 Help / Support', callback_data: 'help_support' }]
  ];
  if (isAdmin) kb.unshift([{ text: '🛠️ Admin Panel', callback_data: 'admin_panel' }]);
  return { inline_keyboard: kb };
}
function backMenuKeyboard() { return { inline_keyboard: [[{ text: '⬅️ Back to Menu', callback_data: 'main_menu' }]] }; }
function confirmKeyboard(paymentId) {
  return {
    inline_keyboard: [[
      { text: '✅ Confirm', callback_data: 'confirm_' + paymentId },
      { text: '❌ Cancel', callback_data: 'cancel' }
    ]]
  };
}

// On startup: check monthly reset (snapshot then reset if month changed)
(async () => {
  try {
    const res = await checkAndRunMonthlyResetIfNeeded();
    if (res.didReset) {
      console.log('Monthly reset performed and snapshot saved.');
    } else {
      console.log('Monthly reset not required on startup.');
    }
  } catch (e) {
    console.error('Error checking monthly reset:', e);
  }
})();

// === /start handler with referral support ===
bot.onText(/\/start(?:\s+(\S+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const firstName = msg.from.first_name || '';
  const refCode = match && match[1] ? match[1].toUpperCase() : null;

  if (refCode) {
    try {
      const partner = await recordReferral(refCode, msg.from);
      if (partner) {
        await bot.sendMessage(chatId, `✅ You were referred by *${partner.name}*.\nWelcome to Septorch!`, { parse_mode: 'Markdown' });
      }
    } catch (err) {
      console.error('recordReferral error', err);
    }
  }

  const isAdmin = userId === ADMIN_ID || (await (async () => { const subs = await listSubadmins(); return subs.includes(Number(userId)); })());
  userStates.set(userId, { step: null });
  await bot.sendMessage(chatId, `👋 Hello ${firstName || ''}! Choose an option:`, {
    reply_markup: mainMenuKeyboard(isAdmin)
  });
});

// === Callback query handler ===
bot.on('callback_query', async (cb) => {
  const data = cb.data, chatId = cb.message.chat.id, userId = cb.from.id;
  const isOwner = userId === ADMIN_ID;
  const subsList = await listSubadmins();
  const isSubadmin = subsList.includes(Number(userId));
  const isAdmin = isOwner || isSubadmin;

  await bot.answerCallbackQuery(cb.id).catch(()=>{});

  if (data === 'main_menu') return bot.editMessageText('🏠 Main Menu', { chat_id: chatId, message_id: cb.message.message_id, reply_markup: mainMenuKeyboard(isAdmin) });

  if (data === 'help_support') return bot.editMessageText(
    '💬 Need help? Please contact [@septorch29](https://t.me/septorch29) directly for support.',
    { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown', reply_markup: backMenuKeyboard() }
  );

  if (data === 'make_payment') {
    const settings = await loadJson(SETTINGS_FILE, {});
    const reason = settings.reason || 'Service', amount = settings.amount || 0;
    const text =
      `💳 *Payment Instructions*\n\n` +
      `Reason: *${reason}*\nAmount: *₦${Number(amount).toFixed(2)}*\n\n` +
      `Account:\n*${ACCOUNT_INFO.name}*\n${ACCOUNT_INFO.number}\n${ACCOUNT_INFO.bank}\n\n` +
      `After sending payment, please reply with your *full name* as it appears on your bank transfer. (If you were referred, include the referral code)`;
    userStates.set(userId, { step: null });
    return bot.editMessageText(text, { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown', reply_markup: backMenuKeyboard() });
  }

  if (data === 'my_transactions') {
    const confirmed = await loadJson(CONFIRMED_FILE, []);
    const mine = confirmed.filter(c => Number(c.telegramUserId) === Number(userId));
    if (mine.length === 0) return bot.editMessageText('📭 You have no confirmed payments.', { chat_id: chatId, message_id: cb.message.message_id, reply_markup: backMenuKeyboard() });
    let text = '📜 *Your Transactions:*\n\n';
    mine.forEach((c,i)=>{ text += `*${i+1}.* ${c.reason || 'N/A'}\n💰 ₦${c.amount}\n🕒 ${fmt(c.receivedAt)}\n`; if(c.keyGiven) text+=`🔑 \`${c.keyGiven}\`\n🔗 ${c.botLink}\n`; text+='\n'; });
    return bot.editMessageText(text, { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown', disable_web_page_preview: true, reply_markup: backMenuKeyboard() });
  }

  if (data === 'cancel') { userStates.delete(userId); return bot.editMessageText('❌ Cancelled. Back to main menu.', { chat_id: chatId, message_id: cb.message.message_id, reply_markup: mainMenuKeyboard(isAdmin) }); }

  // === Partner Dashboard ===
  if (data === 'partner_dashboard') {
    try {
      const stats = await getPartnerStatsByUserId(userId);
      if (!stats) {
        return bot.editMessageText(
          '❌ You are not a registered Septorch Partner.\n\nContact @septorch29 to be added.',
          { chat_id: chatId, message_id: cb.message.message_id, reply_markup: backMenuKeyboard() }
        );
      }
      const refLink = `${REFERRAL_BASE_LINK}${stats.code}`;
      let text = `🏆 *${stats.name}'s Partner Dashboard*\n\n`;
      text += `🔹 Referral Code: \`${stats.code}\`\n`;
      text += `🔗 Referral Link: [Open Link](${refLink})\n\n`;
      text += `📦 Total Sales: *${stats.sales}*\n`;
      text += `⭐ Current Tier: *${stats.tier} (${(stats.rate * 100)}%)*\n`;
      text += `💰 Estimated Commission: *₦${stats.commission.toLocaleString()}*\n\n`;
      text += `Keep promoting your link — each sale counts toward your next tier 🚀`;

      return bot.editMessageText(text, {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: 'Markdown',
        disable_web_page_preview: true,
        reply_markup: backMenuKeyboard()
      });
    } catch (err) {
      console.error('Error partner dashboard', err);
      return bot.editMessageText('⚠️ Failed to open partner dashboard.', { chat_id: chatId, message_id: cb.message.message_id });
    }
  }

  // === ADMIN PANEL ===
  if (data === 'admin_panel' && isAdmin) {
    const kb = { inline_keyboard: [
      [{ text: '🧾 Set Payment Reason & Amount', callback_data: 'admin_set_payment' }],
      [{ text: '🔑 Add Keys (comma separated)', callback_data: 'admin_add_keys' }],
      [{ text: '📜 View Confirmed Payments', callback_data: 'admin_view_confirmed' }],
      [{ text: '👥 Manage Partners', callback_data: 'admin_manage_partners' }],
      [{ text: '🧩 Manage Sub-Admins', callback_data: 'admin_manage_subadmins' }],
      [{ text: '💸 View Payout History', callback_data: 'admin_payout_history' }],
      [{ text: '⬅️ Back', callback_data: 'main_menu' }]
    ]};
    return bot.editMessageText('⚙️ Admin Panel', { chat_id: chatId, message_id: cb.message.message_id, reply_markup: kb });
  }

  // -- Admin: set payment reason & amount
  if (data === 'admin_set_payment' && isOwner) {
    userStates.set(userId,{step:'awaiting_reason'});
    return bot.editMessageText('🧾 Send the *payment reason* (e.g., Premium Access).', { chat_id: chatId, message_id: cb.message.message_id, parse_mode:'Markdown' });
  }
  if (data === 'admin_add_keys' && isOwner) {
    userStates.set(userId,{step:'awaiting_keys'});
    return bot.editMessageText('🔑 Send keys separated by commas (e.g., KEY1,KEY2,KEY3).', { chat_id: chatId, message_id: cb.message.message_id });
  }
  if (data === 'admin_view_confirmed' && isAdmin) {
    const confirmed = await loadJson(CONFIRMED_FILE, []);
    if(!confirmed.length) return bot.editMessageText('📭 No confirmed payments yet.', { chat_id: chatId, message_id: cb.message.message_id });
    let t='📜 Confirmed Payments:\n\n';
    confirmed.forEach((c,i)=>{ t+=`*${i+1}.* ${c.senderName} — ₦${c.amount}\nUser: ${c.telegramUserId}\nKey: ${c.keyGiven||'N/A'}\nReason: ${c.reason||'N/A'}\n\n`; });
    return bot.editMessageText(t, { chat_id: chatId, message_id: cb.message.message_id, parse_mode:'Markdown', reply_markup: backMenuKeyboard() });
  }

  // -- Admin: Manage Partners submenu
  if (data === 'admin_manage_partners' && isAdmin) {
    const kb = { inline_keyboard: [
      [{ text: '➕ Add Partner', callback_data: 'admin_add_partner' }],
      [{ text: '📋 View Partners', callback_data: 'admin_list_partners' }],
      [{ text: '❌ Remove Partner', callback_data: 'admin_remove_partner' }],
      [{ text: '💸 Payout Summary (now)', callback_data: 'admin_payout_now' }],
      [{ text: '⬅️ Back', callback_data: 'admin_panel' }]
    ]};
    return bot.editMessageText('👥 Manage Partners', { chat_id: chatId, message_id: cb.message.message_id, reply_markup: kb });
  }

  // Add Partner
  if (data === 'admin_add_partner' && isOwner) {
    userStates.set(userId, { step: 'awaiting_partner_name' });
    return bot.editMessageText('👤 Send the *partner’s name* (e.g., Michael).', { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown' });
  }

  // List partners
  if (data === 'admin_list_partners' && isAdmin) {
    const partners = await listPartners();
    if (!partners.length) return bot.editMessageText('📭 No partners yet.', { chat_id: chatId, message_id: cb.message.message_id });
    let text = '🏆 *Partners:*\n\n';
    partners.forEach((p,i) => {
      text += `${i+1}. *${p.name}* — ${p.code}\nUserID: ${p.userId}\nSales: ${p.sales || 0}\n\n`;
    });
    return bot.editMessageText(text, { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown', reply_markup: backMenuKeyboard() });
  }

  // Remove partner - ask for code
  if (data === 'admin_remove_partner' && isOwner) {
    userStates.set(userId, { step: 'awaiting_remove_partner' });
    return bot.editMessageText('❌ Send the *referral code* of the partner to remove (e.g., SPT001).', { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown' });
  }

  // Payout now (snapshot but does NOT reset now) - show summary
  if (data === 'admin_payout_now' && isAdmin) {
    try {
      const payload = await generatePayoutSummaryAndSaveSnapshot();
      let txt = '💸 *Partner Payout Summary (snapshot saved)*\n\n';
      payload.summary.forEach((p) => {
        txt += `👤 *${p.name} (${p.code})*\nSales: ${p.sales}\nTier: ${p.tier}\nCommission: ₦${p.commission.toLocaleString()}\n\n`;
      });
      txt += `🧾 *Total Payout:* ₦${payload.total.toLocaleString()}`;
      return bot.editMessageText(txt, { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown', reply_markup: backMenuKeyboard() });
    } catch (err) {
      console.error('payout snapshot error', err);
      return bot.editMessageText('⚠️ Failed to generate payout snapshot.', { chat_id: chatId, message_id: cb.message.message_id, reply_markup: backMenuKeyboard() });
    }
  }

  // Admin: Manage Sub-Admins submenu
  if (data === 'admin_manage_subadmins' && isOwner) {
    const kb = { inline_keyboard: [
      [{ text: '➕ Add Sub-Admin', callback_data: 'admin_add_subadmin' }],
      [{ text: '📋 View Sub-Admins', callback_data: 'admin_list_subadmins' }],
      [{ text: '❌ Remove Sub-Admin', callback_data: 'admin_remove_subadmin' }],
      [{ text: '⬅️ Back', callback_data: 'admin_panel' }]
    ]};
    return bot.editMessageText('🧩 Manage Sub-Admins', { chat_id: chatId, message_id: cb.message.message_id, reply_markup: kb });
  }

  if (data === 'admin_add_subadmin' && isOwner) {
    userStates.set(userId, { step: 'awaiting_subadmin_id' });
    return bot.editMessageText('🔢 Send the *Telegram User ID* of the sub-admin to add.', { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown' });
  }

  if (data === 'admin_list_subadmins' && isOwner) {
    const subs = await listSubadmins();
    if (!subs.length) return bot.editMessageText('📭 No sub-admins yet.', { chat_id: chatId, message_id: cb.message.message_id });
    let text = '🧑‍💼 *Sub-Admins:*\n\n';
    subs.forEach((s,i) => text += `${i+1}. \`${s}\`\n`);
    return bot.editMessageText(text, { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown', reply_markup: backMenuKeyboard() });
  }

  if (data === 'admin_remove_subadmin' && isOwner) {
    userStates.set(userId, { step: 'awaiting_remove_subadmin_id' });
    return bot.editMessageText('❌ Send the *Telegram User ID* of the sub-admin to remove.', { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown' });
  }

  // View payout history (list saved months)
  if (data === 'admin_payout_history' && isAdmin) {
    try {
      const history = await getPayoutHistory();
      if (!history.length) return bot.editMessageText('📭 No payout history available yet.', { chat_id: chatId, message_id: cb.message.message_id });
      let t = '🗂️ *Payout History:*\n\n';
      history.forEach((h) => {
        t += `• ${h.file} — Total: ₦${(h.total || 0).toLocaleString()}\n`;
      });
      return bot.editMessageText(t, { chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'Markdown', reply_markup: backMenuKeyboard() });
    } catch (err) {
      console.error('payout history error', err);
      return bot.editMessageText('⚠️ Failed to read payout history.', { chat_id: chatId, message_id: cb.message.message_id, reply_markup: backMenuKeyboard() });
    }
  }

  // Confirm payment handler (existing flow) - unchanged except notify subadmins
  if (data.startsWith('confirm_')) {
    const paymentId = data.substring('confirm_'.length);
    const payment = global.paymentMap?.[paymentId];

    if (!payment) {
      return bot.editMessageText('❌ Payment not found or expired.', {
        chat_id: chatId,
        message_id: cb.message.message_id
      });
    }

    const payments = await loadJson(PAYMENTS_FILE, []);
    const idx = payments.findIndex(p =>
      p.sender === payment.sender &&
      Number(p.amount) === Number(payment.amount) &&
      p.receivedAt === payment.receivedAt &&
      p.claimedBy === null
    );
    if(idx===-1) return bot.editMessageText('❌ Payment not found or already claimed.', { chat_id: chatId, message_id: cb.message.message_id });

    const confirmedRecords=await loadJson(CONFIRMED_FILE,[]);
    payments[idx].claimedBy=userId;
    await saveJson(PAYMENTS_FILE,payments);

    const assignedKey=await assignNextKey();
    const settings = await loadJson(SETTINGS_FILE,{});
    const reason=settings.reason||'Service';
    const botLink=settings.botLink||`https://t.me/SEPTEMBER\\_MDBOT`;
    const paymentRecord=payments[idx];

    const confirmRecord={ telegramUserId:userId, senderName:paymentRecord.sender, amount:paymentRecord.amount, receivedAt:paymentRecord.receivedAt, confirmedAt:new Date().toISOString(), keyGiven:assignedKey||null, botLink, reason };
    confirmedRecords.push(confirmRecord);
    await saveJson(CONFIRMED_FILE,confirmedRecords);

    // Notify payer
    let userMessage=`✅ Payment confirmed!\n\n👤 ${paymentRecord.sender}\n💰 ₦${Number(paymentRecord.amount).toFixed(2)}\nReason: ${reason}\n\n`;
    if(assignedKey) userMessage+=`🔑 *Your Authorization Key:* \`${assignedKey}\`\n\n🔗 *Connect your bot:* ${botLink}\n`;
    else { userMessage+='⚠️ No keys available. Admin will be notified.'; await bot.sendMessage(ADMIN_ID, `⚠️ No keys remaining for ${paymentRecord.sender} (${userId}). Please add keys.`); }

    await bot.editMessageText(userMessage,{chat_id:chatId,message_id:cb.message.message_id,parse_mode:'Markdown'});
    await bot.sendMessage(ADMIN_ID, `✅ Payment confirmed for ${paymentRecord.sender} (User: ${userId}) — ₦${paymentRecord.amount}\nKey assigned: ${assignedKey?'Yes':'No'}`);

// ✅ Count as successful referral if buyer was referred by a partner
await partnerSystem.markReferralAsPaid(userId);

    // Notify sub-admins (short message)
    const notif = `✅ Payment confirmed: *${paymentRecord.sender}* — ₦${paymentRecord.amount}\nBy: \`${userId}\``;
    await notifySubadmins(bot, notif);

    // If buyer had been recorded via referral (by start link), nothing to do because recordReferral already increments at /start.
    // Optionally: check message text or ask payer for referral code; this can be added later.

    const remainingKeys = (await loadJson(KEYS_FILE,[])).filter(k=>!k.used).length;
    if(remainingKeys<=2) await bot.sendMessage(ADMIN_ID, `⚠️ Keys running low: ${remainingKeys} remaining. Please add more.`,{parse_mode:'Markdown'});
    return;
  }

  // fallback ends here
});

// === TEXT message handler ===
bot.on('message', async (msg) => {
  if(!msg.text) return;
  if(msg.text.startsWith('/')) return; // commands handled elsewhere
  const userId=msg.from.id,text=msg.text.trim();
  const state=userStates.get(userId)||{step:null};

  // Admin flows (owner-only steps)
  if(userId===ADMIN_ID){
    if(state.step==='awaiting_reason'){ state.reason=text; state.step='awaiting_amount'; userStates.set(userId,state); return bot.sendMessage(userId,'💰 Now send the amount in ₦ (e.g., 5000).'); }
    if(state.step==='awaiting_amount'){ const v=parseFloat(text.replace(/,/g,'')); if(isNaN(v)||v<=0) return bot.sendMessage(userId,'❌ Invalid amount. Send a number.'); const settings={reason:state.reason,amount:Math.round(v),botLink:state.botLink||null}; await saveJson(SETTINGS_FILE,settings); userStates.delete(userId); return bot.sendMessage(userId,`✅ Payment settings saved:\nReason: ${settings.reason}\nAmount: ₦${settings.amount}`,{reply_markup:mainMenuKeyboard(true)}); }
    if(state.step==='awaiting_keys'){ const rawKeys=text.split(',').map(k=>k.trim()).filter(Boolean); if(!rawKeys.length) return bot.sendMessage(userId,'❌ No keys detected. Please send comma-separated keys.'); const keys=await loadJson(KEYS_FILE,[]); for(const k of rawKeys) keys.push({key:k,used:false}); await saveJson(KEYS_FILE,keys); userStates.delete(userId); return bot.sendMessage(userId,`✅ ${rawKeys.length} keys added.`,{reply_markup:mainMenuKeyboard(true)}); }

    // Add partner flow - name -> id
    if(state.step === 'awaiting_partner_name') {
      const partnerName = text.trim();
      userStates.set(userId, { step: 'awaiting_partner_id', partnerName });
      return bot.sendMessage(userId, '📱 Send the *Telegram User ID* of this partner.', { parse_mode: 'Markdown' });
    }
    if(state.step === 'awaiting_partner_id') {
      const partnerId = Number(text.trim());
      if (isNaN(partnerId)) return bot.sendMessage(userId, '❌ Invalid Telegram ID. Send a numeric ID.');
      const partnerName = state.partnerName || 'Partner';
      const entry = await addPartner(partnerName, partnerId);
      userStates.delete(userId);
      await bot.sendMessage(userId, `✅ Partner *${entry.name}* added!\nCode: \`${entry.code}\`\nUser ID: \`${entry.userId}\``, { parse_mode: 'Markdown', reply_markup: mainMenuKeyboard(true) });
      return;
    }

    // Remove partner flow
    if(state.step === 'awaiting_remove_partner') {
      const code = text.trim().toUpperCase();
      const removed = await removePartnerByCode(code);
      userStates.delete(userId);
      if (!removed) return bot.sendMessage(userId, `❌ Partner with code ${code} not found.`);
      return bot.sendMessage(userId, `✅ Partner ${removed.name} (${removed.code}) removed.`, { reply_markup: mainMenuKeyboard(true) });
    }

    // Subadmin add/remove flows
    if(state.step === 'awaiting_subadmin_id') {
      const id = Number(text.trim());
      if (isNaN(id)) return bot.sendMessage(userId, '❌ Invalid ID.');
      const added = await addSubadmin(id);
      userStates.delete(userId);
      if (!added) return bot.sendMessage(userId, '⚠️ That user is already a sub-admin.');
      return bot.sendMessage(userId, `✅ Sub-admin ${id} added.`, { reply_markup: mainMenuKeyboard(true) });
    }
    if(state.step === 'awaiting_remove_subadmin_id') {
      const id = Number(text.trim());
      if (isNaN(id)) return bot.sendMessage(userId, '❌ Invalid ID.');
      const removed = await removeSubadmin(id);
      userStates.delete(userId);
      if (!removed) return bot.sendMessage(userId, '❌ That ID is not a sub-admin.');
      return bot.sendMessage(userId, `✅ Sub-admin ${id} removed.`, { reply_markup: mainMenuKeyboard(true) });
    }
  }

  // User sending name after Make Payment (existing flow)
  const settings=await loadJson(SETTINGS_FILE,{});
  const expectedAmount=settings.amount;
  if(!expectedAmount) return bot.sendMessage(userId,'❌ Payment amount not configured by admin yet. Contact support.',{reply_markup:mainMenuKeyboard(false)});

  const payments=await loadJson(PAYMENTS_FILE,[]);
  const confirmed=await loadJson(CONFIRMED_FILE,[]);

  const unclaimed = payments.filter(p =>
    nameMatches(text,p.sender) &&
    Number(p.amount)===Number(expectedAmount) &&
    p.claimedBy===null &&
    !confirmed.some(c=>c.senderName.toLowerCase()===p.sender.toLowerCase() && c.amount===p.amount && c.receivedAt===p.receivedAt)
  );

  if(unclaimed.length>0){
    unclaimed.sort((a,b)=>new Date(b.receivedAt)-new Date(a.receivedAt));
    const match=unclaimed[0];

    // Safe short callback ID
    const paymentId = crypto.createHash('md5').update(`${match.sender}_${match.amount}_${match.receivedAt}`).digest('hex');
    if (!global.paymentMap) global.paymentMap = {};
    global.paymentMap[paymentId] = match;

    userStates.set(userId,{step:'awaiting_confirm',payment:match});
    return bot.sendMessage(userId,`Found payment from *${match.sender}* for ₦${Number(match.amount).toFixed(2)}.\n\nPress Confirm to finish.`,{parse_mode:'Markdown',reply_markup:confirmKeyboard(paymentId)});
  }

  // No immediate match - waiting flow
  const startedAt=Date.now();
  userStates.set(userId,{step:'waiting_payment',name:text,startedAt,expectedAmount:expectedAmount});
  await bot.sendMessage(userId,`⏳ No payment detected yet for *${text}* (₦${expectedAmount}). I will check for the next 10 minutes and notify automatically if it arrives.`,{parse_mode:'Markdown',reply_markup:backMenuKeyboard()});
  setTimeout(async ()=>{
    const st=userStates.get(userId);
    if(st && st.step==='waiting_payment' && st.startedAt===startedAt){
      try{ await bot.sendMessage(userId,'❌ Still no payment detected within 10 minutes. Please double-check your banking transfer and try again later.'); }catch{}
      userStates.delete(userId);
    }
  },10*60*1000);
});

// === Start email monitor ===
startEmailMonitor(bot,userStates,{ email:EMAIL,password:EMAIL_PASSWORD, imapHost:'imap.gmail.com',imapPort:993,imapTls:true,adminId:ADMIN_ID });

// === Crash handling ===
process.on('uncaughtException', err=>console.error('Uncaught Exception:',err));
process.on('unhandledRejection', r=>console.error('Unhandled Rejection:',r));

console.log('🚀 Bot started. Admin ID:',ADMIN_ID);
