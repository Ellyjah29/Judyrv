// partnerSystem.js
// ✅ SEPTORCHBOT Partner System v3
// Fully integrated referral tracking and payout manager

const fs = require('fs').promises;
const path = require('path');

const BOT_PRICE = 1000;
const DATA_DIR = __dirname;
const PARTNERS_FILE = path.join(DATA_DIR, 'partners.json');
const SUBADMINS_FILE = path.join(DATA_DIR, 'subadmins.json');
const REFERRALS_FILE = path.join(DATA_DIR, 'referrals.json');
const LAST_RESET_FILE = path.join(DATA_DIR, 'last_reset.json');

const COMMISSION_TIERS = [
  { name: 'Starter', min: 0, max: 9, rate: 0.15 },
  { name: 'Pro', min: 10, max: 29, rate: 0.20 },
  { name: 'Elite', min: 30, max: Infinity, rate: 0.25 }
];

// === Utility helpers ===
async function ensureFile(file, fallback) {
  try {
    await fs.access(file);
  } catch {
    await fs.writeFile(file, JSON.stringify(fallback, null, 2));
    return fallback;
  }
  try {
    const raw = await fs.readFile(file, 'utf8');
    return JSON.parse(raw || JSON.stringify(fallback));
  } catch {
    await fs.writeFile(file, JSON.stringify(fallback, null, 2));
    return fallback;
  }
}

// === Load/Save ===
async function loadPartners() { return ensureFile(PARTNERS_FILE, []); }
async function savePartners(data) { await fs.writeFile(PARTNERS_FILE, JSON.stringify(data, null, 2)); }

async function loadSubadmins() { return ensureFile(SUBADMINS_FILE, []); }
async function saveSubadmins(list) { await fs.writeFile(SUBADMINS_FILE, JSON.stringify(list, null, 2)); }

async function loadReferrals() { return ensureFile(REFERRALS_FILE, []); }
async function saveReferrals(list) { await fs.writeFile(REFERRALS_FILE, JSON.stringify(list, null, 2)); }

function getTierForSales(sales) {
  return COMMISSION_TIERS.find(t => sales >= t.min && sales <= t.max) || COMMISSION_TIERS[0];
}

// === Partner Management ===
async function addPartner(name, userId) {
  const partners = await loadPartners();
  const seq = partners.length + 1;
  const code = 'SPT' + String(seq).padStart(3, '0');
  const entry = { name, userId: Number(userId), code, sales: 0, buyers: [] };
  partners.push(entry);
  await savePartners(partners);
  return entry;
}

async function removePartnerByCode(code) {
  const partners = await loadPartners();
  const idx = partners.findIndex(p => p.code === code.toUpperCase());
  if (idx === -1) return null;
  const removed = partners.splice(idx, 1)[0];
  await savePartners(partners);
  return removed;
}

async function listPartners() { return await loadPartners(); }
async function getPartnerByCode(code) {
  const partners = await loadPartners();
  return partners.find(p => p.code === (code || '').toUpperCase()) || null;
}
async function getPartnerByUserId(userId) {
  const partners = await loadPartners();
  return partners.find(p => Number(p.userId) === Number(userId)) || null;
}

// === Referrals ===
/**
 * When user joins via referral link, record who referred them (but don't add sales yet)
 */
async function recordReferral(code, buyer) {
  if (!code || !buyer) return false;
  const referrals = await loadReferrals();
  const existing = referrals.find(r => r.buyerId === buyer.id);
  if (existing) return false; // already recorded

  const partner = await getPartnerByCode(code);
  if (!partner) return false;

  referrals.push({ buyerId: buyer.id, refCode: code.toUpperCase() });
  await saveReferrals(referrals);
  return partner;
}

/**
 * When buyer payment is confirmed, record sale for the partner that referred them.
 * Multiple payments from the same buyer will count as separate sales.
 */
async function markReferralAsPaid(userId) {
  const referrals = await loadReferrals();
  const referral = referrals.find(r => r.buyerId === Number(userId));
  if (!referral) return false;

  const partner = await getPartnerByCode(referral.refCode);
  if (!partner) return false;

  partner.sales = (partner.sales || 0) + 1;
  partner.buyers = partner.buyers || [];
  partner.buyers.push({ userId, date: new Date().toISOString() });

  const partners = await loadPartners();
  const idx = partners.findIndex(p => p.code === partner.code);
  if (idx !== -1) partners[idx] = partner;

  await savePartners(partners);
  await saveReferrals(referrals);
  return partner;
}

// === Payout Summary ===
async function generatePayoutSummaryAndSaveSnapshot() {
  const partners = await loadPartners();
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const filename = path.join(DATA_DIR, `payouts_${y}-${m}.json`);

  let total = 0;
  const summary = partners.map(p => {
    const sales = p.sales || 0;
    const tier = getTierForSales(sales);
    const commission = Math.round(sales * BOT_PRICE * tier.rate);
    total += commission;
    return {
      name: p.name,
      code: p.code,
      userId: p.userId,
      sales,
      tier: tier.name,
      rate: tier.rate,
      commission
    };
  });

  const payload = { date: new Date().toISOString(), total, summary };
  await fs.writeFile(filename, JSON.stringify(payload, null, 2));

  // reset sales for next month
  for (const p of partners) {
    p.sales = 0;
    p.buyers = [];
  }
  await savePartners(partners);

  return payload;
}

async function getPayoutHistory() {
  const files = await fs.readdir(DATA_DIR);
  const payouts = [];
  for (const f of files) {
    if (f.startsWith('payouts_') && f.endsWith('.json')) {
      try {
        const raw = await fs.readFile(path.join(DATA_DIR, f), 'utf8');
        const obj = JSON.parse(raw);
        payouts.push({ file: f, ...obj });
      } catch {}
    }
  }
  payouts.sort((a, b) => b.file.localeCompare(a.file));
  return payouts;
}

// === Subadmin Management ===
async function addSubadmin(id) {
  const list = await loadSubadmins();
  const nid = Number(id);
  if (list.includes(nid)) return false;
  list.push(nid);
  await saveSubadmins(list);
  return true;
}
async function removeSubadmin(id) {
  const list = await loadSubadmins();
  const nid = Number(id);
  const idx = list.indexOf(nid);
  if (idx === -1) return false;
  list.splice(idx, 1);
  await saveSubadmins(list);
  return true;
}
async function listSubadmins() { return await loadSubadmins(); }

async function notifySubadmins(bot, messageText) {
  const subs = await loadSubadmins();
  for (const id of subs) {
    try {
      await bot.sendMessage(Number(id), messageText, { parse_mode: 'Markdown' });
    } catch {}
  }
}

// === Partner Stats ===
async function getPartnerStatsByUserId(userId) {
  const p = await getPartnerByUserId(userId);
  if (!p) return null;
  const tier = getTierForSales(p.sales || 0);
  const commission = Math.round((p.sales || 0) * BOT_PRICE * tier.rate);
  return {
    name: p.name,
    code: p.code,
    userId: p.userId,
    sales: p.sales || 0,
    tier: tier.name,
    rate: tier.rate,
    commission
  };
}

module.exports = {
  addPartner,
  removePartnerByCode,
  listPartners,
  getPartnerByCode,
  getPartnerByUserId,
  recordReferral,
  markReferralAsPaid,
  generatePayoutSummaryAndSaveSnapshot,
  getPayoutHistory,
  addSubadmin,
  removeSubadmin,
  listSubadmins,
  notifySubadmins,
  getPartnerStatsByUserId
};
