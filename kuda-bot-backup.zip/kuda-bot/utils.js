// utils.js
const fs = require('fs').promises;

// === JSON HELPERS ===
async function loadJson(file, fallback = []) {
  try {
    const data = await fs.readFile(file, 'utf8');
    return JSON.parse(data);
  } catch {
    return fallback;
  }
}

async function saveJson(file, data) {
  await fs.writeFile(file, JSON.stringify(data, null, 2));
}

// === FORMAT TIME ===
function formatFullTime(dateStr) {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleString('en-NG', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
    timeZone: 'Africa/Lagos'
  });
}

// === NAME MATCHING ===
// Returns true if most words in inputName appear in senderName
function isNameMatch(senderName, inputName) {
  if (!senderName || !inputName) return false;
  const senderParts = senderName.toLowerCase().split(/\s+/);
  const inputParts = inputName.toLowerCase().split(/\s+/);
  let matchCount = 0;
  inputParts.forEach(p => {
    if (senderParts.includes(p)) matchCount++;
  });
  // require at least half of input parts to match
  return matchCount >= Math.ceil(inputParts.length / 2);
}

// === TELEGRAM KEYBOARDS ===
function createConfirmationKeyboard(paymentId) {
  return {
    inline_keyboard: [
      [
        { text: '✅ Confirm', callback_data: 'confirm_' + paymentId },
        { text: '❌ Cancel', callback_data: 'cancel' }
      ]
    ]
  };
}

function createViewPaymentsKeyboard() {
  return {
    inline_keyboard: [
      [{ text: '📋 View My Payments', callback_data: 'view_my_payments' }]
    ]
  };
}

function createPaymentSelectionKeyboard(payments) {
  const buttons = payments.map(p => {
    const timeLabel = new Date(p.receivedAt).toLocaleTimeString('en-NG', { hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Lagos' });
    const label = '₦' + Number(p.amount).toFixed(2) + ' • ' + timeLabel;
    const id = `${p.sender}_${p.amount}_${p.receivedAt}`;
    return [{ text: label, callback_data: 'select_' + id }];
  });
  buttons.push([{ text: '❌ Cancel', callback_data: 'cancel' }]);
  return { inline_keyboard: buttons };
}

module.exports = {
  loadJson,
  saveJson,
  formatFullTime,
  isNameMatch,
  createConfirmationKeyboard,
  createViewPaymentsKeyboard,
  createPaymentSelectionKeyboard
};
