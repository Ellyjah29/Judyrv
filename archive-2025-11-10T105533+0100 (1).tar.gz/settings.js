exports.bots = [
  {
    "botName": "Web3princess",
    "themeemoji": "🦄",
    "ownerNumber": "2349168926553",
    "phoneNumber": "",
    "expiry": "2025-11-17",
    "authKey": "PcnAzZLs7V16VCb1",
    "telegramUserId": 6226678823,
    "expiryTimestamp": 1763359199999,
    "createdAt": "2025-11-03T12:26:55.299Z",
    "SESSION_ID": "zdRXlSZD#pZlz1vXZFZ8qA2IoA0zHdMT03eX-8oMAKYzbmYd5KGo"
  },
  {
    "botName": "Phantom 👻 👽",
    "themeemoji": "🤖",
    "ownerNumber": "2349131037140",
    "phoneNumber": "",
    "expiry": "2025-12-18",
    "authKey": "xF7QpxVsVc5mc62o",
    "telegramUserId": 7034397523,
    "expiryTimestamp": 1766037599999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "expiredAt": "2025-10-19",
    "SESSION_ID": "eBQ1iDrC#GjRhZjul3OqDXm_db0IP-pbZ1u2BMBAPXZYsIkAs4Ig"
  },
  {
    "botName": "Septorch",
    "themeemoji": "⚡",
    "ownerNumber": "2347086044483",
    "phoneNumber": "",
    "expiry": "2025-11-17",
    "authKey": "Quyxs43IY9ZPHvFy",
    "telegramUserId": 7738315673,
    "expiryTimestamp": 1763359199999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "expiredAt": "2025-10-19",
    "SESSION_ID": "nVRmBCgA#bBtDfJ5soU5a4Rc1CIw3HkUiQkkkvPIZtt1LCr9RUgQ"
  },
  {
    "botName": "S_verick",
    "themeemoji": "⚡",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-11-18",
    "authKey": "b4W5TnSI1sXTdch7",
    "telegramUserId": 7720669948,
    "expiryTimestamp": 1763445599999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "expiredAt": "2025-09-19",
    "SESSION_ID": "qII0FKja#d_fGFeYZe7CvTKj7iKaboi8RNyHehnzzptFPxOBI7QQ"
  },
  {
    "botName": "Fâ Mø Üs",
    "themeemoji": "👑",
    "ownerNumber": "2347073108190",
    "phoneNumber": "",
    "expiry": "2025-11-18",
    "authKey": "74ZKrmdmyALLgNTn",
    "telegramUserId": 7189303708,
    "expiryTimestamp": 1763445599999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "SESSION_ID": "nA5GwbyY#PpIawuI3MhNbIXmAYx3A1hPaAbdwGUkUh4yuGyQlcvM"
  },
  {
    "botName": "Ser Bron of the Black water",
    "themeemoji": "🎯",
    "ownerNumber": "2347047919337",
    "phoneNumber": "",
    "expiry": "2025-11-18",
    "authKey": "ZNfOvBK16HhsAFRA",
    "telegramUserId": 6456700552,
    "expiryTimestamp": 1763445599999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "expiredAt": "2025-10-19",
    "SESSION_ID": "TEYyhbCZ#1BDrZzKcRA3ZTIH46ZjYGLqfQqZkr5VwA3XD6HhcThg"
  },
  {
    "botName": "New Bot",
    "themeemoji": "💫",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-10-19",
    "authKey": "ZjTy21HHLwSw0EjX",
    "telegramUserId": null,
    "expiryTimestamp": 1760849999999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "expiredAt": "2025-10-19"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🌟",
    "ownerNumber": "2349013329526",
    "phoneNumber": "",
    "expiry": "2025-10-19",
    "authKey": "BhRHig3DTPkOwqam",
    "telegramUserId": null,
    "expiryTimestamp": 1760849999999,
    "createdAt": "2025-11-03T12:26:55.362Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🔥",
    "ownerNumber": "2349037422164",
    "phoneNumber": "",
    "expiry": "2025-10-19",
    "authKey": "TFEJznvH11is5BUv",
    "telegramUserId": null,
    "expiryTimestamp": 1760849999999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "expiredAt": "2025-10-19"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🛡️",
    "ownerNumber": "2349137421891",
    "phoneNumber": "",
    "expiry": "2025-10-14",
    "authKey": "X3stqCBM2SeBQIV2",
    "telegramUserId": null,
    "expiryTimestamp": 1760417999999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "expiredAt": "2025-10-14"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🚀",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-10-19",
    "authKey": "yx5tS3BvNvr0tYQy",
    "telegramUserId": null,
    "expiryTimestamp": 1760849999999,
    "createdAt": "2025-11-03T12:26:55.362Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "⚙️",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-10-19",
    "authKey": "CrCcnbTollSCO1gF",
    "telegramUserId": null,
    "expiryTimestamp": 1760849999999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "expiredAt": "2025-10-19"
  },
  {
    "botName": "New Bot",
    "themeemoji": "💎",
    "ownerNumber": "2349112131958",
    "phoneNumber": "",
    "expiry": "2025-09-20",
    "authKey": "PEvILtdcSLZa3P1Q",
    "telegramUserId": null,
    "expiryTimestamp": 1758344399999,
    "createdAt": "2025-11-03T12:26:55.362Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "2349064183237",
    "phoneNumber": "",
    "expiry": "2025-11-28",
    "authKey": "pL0UKwEKkdlpxXoZ",
    "telegramUserId": null,
    "expiryTimestamp": 1764309599999,
    "createdAt": "2025-11-03T12:26:55.362Z",
    "expiredAt": "2025-08-30"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "2349034865295",
    "phoneNumber": "",
    "expiry": "2025-09-20",
    "authKey": "4RG5Do9m1XN3l2h2",
    "telegramUserId": null,
    "expiryTimestamp": 1758344399999,
    "createdAt": "2025-11-03T12:26:55.363Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "2349126903697",
    "phoneNumber": "",
    "expiry": "2025-09-05",
    "authKey": "uLDNNIcV8Ge1y5Zr",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-11-03T12:26:55.363Z",
    "expiredAt": "2025-09-05"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "2349021426250",
    "phoneNumber": "",
    "expiry": "2025-10-04",
    "authKey": "7pLZoXofYeuBpiLT",
    "telegramUserId": null,
    "expiryTimestamp": 1759553999999,
    "createdAt": "2025-11-03T12:26:55.363Z",
    "expiredAt": "2025-09-04"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "2348028760978",
    "phoneNumber": "",
    "expiry": "2025-11-03",
    "authKey": "QaewfSWKzGxX9d0X",
    "telegramUserId": null,
    "expiryTimestamp": 1762149599999,
    "createdAt": "2025-11-03T12:26:55.363Z",
    "expiredAt": "2025-09-04"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "2348138118621",
    "phoneNumber": "",
    "expiry": "2025-10-20",
    "authKey": "AQ05PIZqBGg4XYS4",
    "telegramUserId": null,
    "expiryTimestamp": 1760936399999,
    "createdAt": "2025-11-03T12:26:55.363Z",
    "expiredAt": "2025-10-20"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "2349051799728",
    "phoneNumber": "",
    "expiry": "2025-10-20",
    "authKey": "ViTh75rRepwbxVDX",
    "telegramUserId": null,
    "expiryTimestamp": 1760936399999,
    "createdAt": "2025-11-03T12:26:55.363Z",
    "expiredAt": "2025-10-20"
  },
  {
    "authKey": "1FkQj8NxPswjVEXX",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-20",
    "ownerNumber": "2349153883610",
    "expiryTimestamp": 1760936399999,
    "expiredAt": "2025-10-20"
  },
  {
    "authKey": "0O8Uo2pxxpGKgbHr",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-09-30",
    "ownerNumber": "2347012972250",
    "expiryTimestamp": 1759208399999,
    "expiredAt": "2025-09-30"
  },
  {
    "authKey": "a59Rhfcn1BUjhUDW",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-02",
    "ownerNumber": "2349110388960",
    "expiryTimestamp": 1759381199999
  },
  {
    "authKey": "eH4LZxTZnugwrEqk",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-24",
    "expiryTimestamp": 1761281999999,
    "expiredAt": "2025-10-24"
  },
  {
    "authKey": "yVYNdTlmMLqz8GlY",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-05",
    "ownerNumber": "2349096515373",
    "expiryTimestamp": 1759640399999,
    "expiredAt": "2025-10-05"
  },
  {
    "authKey": "ydW263evqFweP5wL",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-06",
    "ownerNumber": "2349164613487",
    "expiryTimestamp": 1759726799999,
    "expiredAt": "2025-10-06"
  },
  {
    "authKey": "UApE337AMJpT5wlA",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-13",
    "expiryTimestamp": 1760331599999,
    "expiredAt": "2025-10-13"
  },
  {
    "authKey": "MlgzsIsGuLBskAl7",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-12",
    "ownerNumber": "2349078366461",
    "expiryTimestamp": 1760245199999,
    "expiredAt": "2025-10-12"
  },
  {
    "authKey": "v6yNNYu3KJ698Erq",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-14",
    "ownerNumber": "2349028209002",
    "expiryTimestamp": 1760417999999,
    "expiredAt": "2025-10-14"
  },
  {
    "authKey": "V2Pcsla84e9EF4od",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-15",
    "expiryTimestamp": 1760504399999
  },
  {
    "authKey": "5WkVMVXDTx5pMQhE",
    "createdAt": "2025-11-03T12:26:55.363Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-10-15",
    "expiryTimestamp": 1760504399999,
    "expiredAt": "2025-10-15"
  },
  {
    "authKey": "exL9kQSNPOxURGtY",
    "createdAt": "2025-11-03T12:26:55.364Z",
    "botName": "New Bot",
    "telegramUserId": null,
    "expiry": "2025-11-17",
    "ownerNumber": "2349020880503",
    "expiryTimestamp": 1763359199999,
    "expiredAt": "2025-10-18"
  }
];
exports.userStates = {
  "568650363": {
    "step": "awaiting_session_id",
    "authKey": "3yvmUw3n3dVwXulW",
    "lastRestart": 1760736039107,
    "promptMessageId": 6392
  },
  "1386202919": {
    "step": "awaiting_auth_key",
    "promptMessageId": 6498
  },
  "1872222884": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8797
  },
  "1984959557": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3602
  },
  "2020269818": {
    "step": "awaiting_auth_key",
    "promptMessageId": 4657
  },
  "2044779114": {
    "step": "awaiting_auth_key",
    "promptMessageId": 4541
  },
  "2046598405": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8170
  },
  "8135871264": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7828
  },
  "6834525619": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7904
  },
  "6178610094": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8106
  },
  "6582804562": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8122
  },
  "7179979536": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "lastRestart": 1753722572914,
    "promptMessageId": 8165
  },
  "7569969378": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8197
  },
  "5603889826": {
    "step": "awaiting_session_id",
    "authKey": "lNNXjvoQoMHUEFMz",
    "promptMessageId": 8265
  },
  "5613886154": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8335
  },
  "8454766080": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8372
  },
  "6936711750": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8386
  },
  "7013483934": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8411
  },
  "6318304090": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8454
  },
  "7698997438": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7584
  },
  "7561987171": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8338
  },
  "7262422290": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8504
  },
  "6952558480": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8547
  },
  "7417554225": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8706
  },
  "7614436302": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8713
  },
  "6334060350": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8730
  },
  "7567588756": {
    "step": "awaiting_session_id",
    "authKey": "ENQQwj0TUy2pbIpY",
    "promptMessageId": 8799
  },
  "7705270175": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8039
  },
  "6813072183": {
    "step": "awaiting_auth_key",
    "promptMessageId": 50
  },
  "7010272965": {
    "step": "awaiting_session_id",
    "authKey": "27gL9EbHDnbYRll6",
    "promptMessageId": 88
  },
  "7367522697": {
    "step": "awaiting_session_id",
    "authKey": "KRqnz7i7ppbBHLAn",
    "promptMessageId": 104
  },
  "7880561946": {
    "step": "awaiting_auth_key",
    "promptMessageId": 209
  },
  "7606320322": {
    "step": "awaiting_session_id",
    "authKey": "aw8b9UpfelDxUJJw",
    "promptMessageId": 214
  },
  "7964668501": {
    "step": "awaiting_session_id",
    "authKey": "KRqnz7i7ppbBHLAn",
    "promptMessageId": 232
  },
  "6746195729": {
    "step": "awaiting_session_id",
    "authKey": "aw8b9UpfelDxUJJw",
    "promptMessageId": 236
  },
  "7626907045": {
    "step": "awaiting_auth_key",
    "promptMessageId": 239
  },
  "6320159318": {
    "step": "awaiting_auth_key",
    "promptMessageId": 489
  },
  "7281510964": {
    "step": "awaiting_auth_key",
    "promptMessageId": 385
  },
  "5820307848": {
    "step": "awaiting_auth_key",
    "promptMessageId": 390
  },
  "7402220403": {
    "step": "awaiting_auth_key",
    "promptMessageId": 398
  },
  "7685257379": {
    "step": "awaiting_auth_key",
    "promptMessageId": 404
  },
  "7757310500": {
    "step": "awaiting_auth_key",
    "promptMessageId": 407
  },
  "6350199182": {
    "step": "awaiting_auth_key",
    "promptMessageId": 501
  },
  "7793904410": {
    "step": "awaiting_auth_key",
    "promptMessageId": 507
  },
  "7493472286": {
    "step": "awaiting_auth_key",
    "promptMessageId": 515
  },
  "7542327654": {
    "step": "awaiting_auth_key",
    "promptMessageId": 522
  },
  "7781501579": {
    "step": "awaiting_auth_key",
    "promptMessageId": 526
  },
  "7314201855": {
    "step": "awaiting_auth_key",
    "promptMessageId": 554
  },
  "7325374825": {
    "step": "awaiting_auth_key",
    "promptMessageId": 573
  },
  "6433972653": {
    "step": "awaiting_session_id",
    "authKey": "8sppHUISLXPvqSvk",
    "promptMessageId": 2901
  },
  "7038050948": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3143
  },
  "6231469327": {
    "step": "awaiting_session_id",
    "authKey": "LLpoMIKXghQyZ9kf",
    "promptMessageId": 3154
  },
  "6301352948": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3207
  },
  "8327116502": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3294
  },
  "7016457254": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3562
  },
  "5822071400": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3594
  },
  "7112344347": {
    "step": "awaiting_auth_key",
    "promptMessageId": 4209
  },
  "6817161756": {
    "step": "awaiting_auth_key",
    "promptMessageId": 4430
  },
  "5094043688": {
    "step": "awaiting_session_id",
    "authKey": "rlsTXQPNp2sgOO3o",
    "promptMessageId": 4697
  },
  "5620223174": {
    "step": "awaiting_session_id",
    "authKey": "ant2160ku8rmedia",
    "lastRestart": 1758721024991,
    "promptMessageId": 5547
  },
  "6224324098": {
    "step": "awaiting_auth_key",
    "promptMessageId": 5867
  },
  "8183170030": {
    "step": "awaiting_auth_key",
    "promptMessageId": 6097
  },
  "7486768415": {
    "step": "awaiting_auth_key",
    "promptMessageId": 6655
  },
  "7268979077": {
    "step": "awaiting_auth_key",
    "promptMessageId": 6842
  },
  "6529386699": {
    "step": "awaiting_auth_key",
    "promptMessageId": 6908
  },
  "6925181794": {
    "step": "awaiting_auth_key",
    "promptMessageId": 6918
  }
};
exports.blacklistedUsers = [];