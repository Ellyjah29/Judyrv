const { handleGoodbye } = require('../lib/welcome');

async function goodbyeCommand(sock, chatId, message, botId) {
    // Check if it's a group
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: 'This command can only be used in groups.' });
        return;
    }

    // Extract the command arguments
    const text = message.message?.conversation || 
                 message.message?.extendedTextMessage?.text || '';
    const args = text.trim().split(' ').slice(1).join(' ') || '';

    // Pass botId to handleGoodbye
    await handleGoodbye(sock, chatId, args, botId);
}

module.exports = goodbyeCommand;