// commands/antibadword.js
const { handleAntiBadwordCommand } = require('../lib/antibadword');
const isAdminHelper = require('../lib/isAdmin');

// 🔰 Bot-style boxed message helper
const box = (title, lines) => [
  `╭━━━[ *🔰 ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

const sendBox = (sock, chatId, title, lines) =>
  sock.sendMessage(chatId, { text: box(title, lines) });

/**
 * Handle .antibadword command
 * @param {object} sock - Baileys socket
 * @param {string} chatId - Group JID
 * @param {object} message - Message object
 * @param {string} senderId - User JID
 * @param {boolean} isSenderAdmin - Admin check
 * @param {string} botId - Unique bot identifier
 */
async function antibadwordCommand(sock, chatId, message, senderId, isSenderAdmin, botId) {
    try {
        if (!isSenderAdmin) {
            return sendBox(sock, chatId, 'Antibadword', [
                '❌  *For Group Admins Only!*'
            ]);
        }

        // Extract command args
        const text = message.message?.conversation || 
                     message.message?.extendedTextMessage?.text || '';
        const args = text.trim().split(/\s+/).slice(1).join(' ') || '';

        // ✅ Pass botId to handler
        await handleAntiBadwordCommand(sock, chatId, args, botId);
    } catch (error) {
        console.error(`Antibadword command error [${botId}]:`, error);
        await sendBox(sock, chatId, 'Antibadword', [
            '❌  *Error processing antibadword command.*'
        ]);
    }
}

module.exports = antibadwordCommand;