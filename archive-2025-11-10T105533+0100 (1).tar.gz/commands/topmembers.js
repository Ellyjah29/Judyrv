const fs = require('fs');
const path = require('path');

const dataFilePath = path.join(__dirname, '..', 'data', 'messageCount.json');

// Load message counts from file (returns {} if file doesn't exist or is broken)
function loadMessageCounts() {
    try {
        if (!fs.existsSync(dataFilePath)) return { isPublic: true, messages: {} };
        const data = fs.readFileSync(dataFilePath, 'utf-8');
        return JSON.parse(data || '{"isPublic": true, "messages": {}}');
    } catch (error) {
        console.error("⚠️ Failed to load message counts:", error);
        return { isPublic: true, messages: {} };
    }
}

// Save updated counts to file
function saveMessageCounts(counts) {
    try {
        fs.writeFileSync(dataFilePath, JSON.stringify(counts, null, 2));
    } catch (error) {
        console.error("❌ Failed to save message counts:", error);
    }
}

// Helper function to get current week identifier (ISO week format)
function getCurrentWeekIdentifier() {
    const now = new Date();
    const startOfYear = new Date(now.getFullYear(), 0, 1);
    const days = Math.floor((now - startOfYear) / (24 * 60 * 60 * 1000));
    const weekNumber = Math.ceil((days + startOfYear.getDay() + 1) / 7);
    return `${now.getFullYear()}-W${weekNumber.toString().padStart(2, '0')}`;
}

// Helper function to get current month identifier
function getCurrentMonthIdentifier() {
    const now = new Date();
    return `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}`;
}

// Increments message count per user in a group with timestamps
function incrementMessageCount(groupId, userId, botId) {
    if (!groupId?.endsWith('@g.us')) return; // Only track in groups
    
    const counts = loadMessageCounts();
    const now = Date.now();
    const currentWeek = getCurrentWeekIdentifier();
    const currentMonth = getCurrentMonthIdentifier();

    if (!counts.messages[groupId]) counts.messages[groupId] = {};
    if (!counts.messages[groupId][userId]) {
        counts.messages[groupId][userId] = {
            total: 0,
            weekly: {},
            monthly: {},
            lastActive: now
        };
    }

    // Update total count
    counts.messages[groupId][userId].total += 1;
    
    // Update weekly count
    if (!counts.messages[groupId][userId].weekly[currentWeek]) {
        counts.messages[groupId][userId].weekly[currentWeek] = 0;
    }
    counts.messages[groupId][userId].weekly[currentWeek] += 1;
    
    // Update monthly count
    if (!counts.messages[groupId][userId].monthly[currentMonth]) {
        counts.messages[groupId][userId].monthly[currentMonth] = 0;
    }
    counts.messages[groupId][userId].monthly[currentMonth] += 1;
    
    // Update last active timestamp
    counts.messages[groupId][userId].lastActive = now;

    saveMessageCounts(counts);
}

// Get active members based on time period
function getActiveMembers(groupId, period = 'total') {
    const counts = loadMessageCounts();
    const groupData = counts.messages[groupId] || {};
    const currentWeek = getCurrentWeekIdentifier();
    const currentMonth = getCurrentMonthIdentifier();
    
    return Object.entries(groupData)
        .map(([userId, userData]) => {
            let count = 0;
            
            if (period === 'total') {
                count = userData.total || 0;
            } else if (period === 'weekly') {
                count = userData.weekly?.[currentWeek] || 0;
            } else if (period === 'monthly') {
                count = userData.monthly?.[currentMonth] || 0;
            }
            
            return { 
                userId, 
                count,
                lastActive: userData.lastActive || 0
            };
        })
        .filter(member => member.count > 0)
        .sort((a, b) => b.count - a.count);
}

// Get inactive members based on days parameter
function getInactiveMembers(groupId, days = 30) {
    const counts = loadMessageCounts();
    const groupData = counts.messages[groupId] || {};
    const cutoffTime = Date.now() - (days * 24 * 60 * 60 * 1000); // days ago
    
    return Object.entries(groupData)
        .filter(([, userData]) => (userData.lastActive || 0) < cutoffTime)
        .map(([userId, userData]) => ({ 
            userId, 
            lastActive: new Date(userData.lastActive).toLocaleDateString(),
            totalMessages: userData.total || 0
        }))
        .sort((a, b) => a.lastActive.localeCompare(b.lastActive));
}

// Command: Display top active members based on period
async function topMembers(sock, chatId, isGroup, period = 'total') {
    if (!isGroup) {
        await sock.sendMessage(chatId, { text: '❌ This command only works in groups.' });
        return;
    }

    const validPeriods = ['total', 'weekly', 'monthly'];
    if (!validPeriods.includes(period)) {
        await sock.sendMessage(chatId, { 
            text: '❌ Invalid period. Use: total, weekly, or monthly' 
        });
        return;
    }

    // Get the period label for display
    const periodLabels = {
        'total': 'All Time',
        'weekly': 'This Week',
        'monthly': 'This Month'
    };
    
    const periodLabel = periodLabels[period];
    const activeMembers = getActiveMembers(chatId, period);
    
    if (activeMembers.length === 0) {
        await sock.sendMessage(chatId, { 
            text: `No message activity tracked for ${periodLabel.toLowerCase()} yet.` 
        });
        return;
    }

    const mentionList = activeMembers.slice(0, 9).map(member => member.userId);
    const topCount = Math.min(activeMembers.length, 9);
    
    const message = [
        '*📊 SEPTORCH Activity Tracker*',
        `🏆 *Top ${topCount} Most Active Members (${periodLabel})*:\n`,
        ...activeMembers.slice(0, 9).map(({ userId, count }, i) =>
            `${i + 1}. @${userId.split('@')[0]} - *${count}* messages`
        ),
        `\n📊 Use: *.topmembers total/weekly/monthly*`
    ].join('\n');

    await sock.sendMessage(chatId, {
        text: message,
        mentions: mentionList
    });
}

// Command: List inactive members
async function listInactiveMembers(sock, chatId, isGroup, days = 30) {
    if (!isGroup) {
        await sock.sendMessage(chatId, { text: '❌ This command only works in groups.' });
        return;
    }

    const inactiveMembers = getInactiveMembers(chatId, days);
    
    if (inactiveMembers.length === 0) {
        await sock.sendMessage(chatId, { 
            text: `✅ No inactive members found! Everyone has been active in the last ${days} day${days === 1 ? '' : 's'}.`
        });
        return;
    }

    const mentionList = inactiveMembers.map(member => member.userId);
    const message = [
        '*📊 SEPTORCH Activity Tracker*',
        `😴 *Inactive Members* (no activity in last ${days} day${days === 1 ? '' : 's'}):\n`,
        ...inactiveMembers.slice(0, 10).map(({ userId, lastActive, totalMessages }, i) =>
            `${i + 1}. @${userId.split('@')[0]} - Last: *${lastActive}* (${totalMessages} msgs)`
        ),
        inactiveMembers.length > 10 ? `\n+ ${inactiveMembers.length - 10} more...` : '',
        `\n💡 Use: *.inactive ${days}* or *.removeinactive ${days}*`
    ].filter(Boolean).join('\n');

    await sock.sendMessage(chatId, {
        text: message,
        mentions: mentionList.slice(0, 10)
    });
}

// Command: List active members (recent activity)
async function listActiveMembers(sock, chatId, isGroup, days = 7) {
    if (!isGroup) {
        await sock.sendMessage(chatId, { text: '❌ This command only works in groups.' });
        return;
    }

    const counts = loadMessageCounts();
    const groupData = counts.messages[chatId] || {};
    const cutoffTime = Date.now() - (days * 24 * 60 * 60 * 1000); // days ago
    
    const activeMembers = Object.entries(groupData)
        .filter(([, userData]) => (userData.lastActive || 0) >= cutoffTime)
        .map(([userId, userData]) => ({ 
            userId, 
            count: userData.total || 0,
            lastActive: new Date(userData.lastActive).toLocaleDateString()
        }))
        .sort((a, b) => b.count - a.count);

    if (activeMembers.length === 0) {
        await sock.sendMessage(chatId, { 
            text: `📭 No recently active members found. No one has messaged in the last ${days} day${days === 1 ? '' : 's'}.`
        });
        return;
    }

    const mentionList = activeMembers.map(member => member.userId);
    const message = [
        '*📊 SEPTORCH Activity Tracker*',
        `🚀 *Recently Active Members* (active in last ${days} day${days === 1 ? '' : 's'}):\n`,
        ...activeMembers.slice(0, 10).map(({ userId, count, lastActive }, i) =>
            `${i + 1}. @${userId.split('@')[0]} - *${count}* messages (Last: ${lastActive})`
        ),
        activeMembers.length > 10 ? `\n+ ${activeMembers.length - 10} more...` : '',
        `\n💡 Use: *.active ${days}*`
    ].filter(Boolean).join('\n');

    await sock.sendMessage(chatId, {
        text: message,
        mentions: mentionList.slice(0, 10)
    });
}

// Command: Remove inactive members (with confirmation and custom days)
async function removeInactiveMembers(sock, chatId, isGroup, senderId, isAdmin, days = 30) {
    if (!isGroup) {
        await sock.sendMessage(chatId, { text: '❌ This command only works in groups.' });
        return;
    }

    if (!isAdmin) {
        await sock.sendMessage(chatId, { text: '❌ Only admins can use this command.' });
        return;
    }

    // Validate days parameter
    if (days < 1 || days > 365) {
        await sock.sendMessage(chatId, { 
            text: '❌ Invalid number of days. Please specify between 1-365 days.' 
        });
        return;
    }

    const inactiveMembers = getInactiveMembers(chatId, days);
    
    if (inactiveMembers.length === 0) {
        await sock.sendMessage(chatId, { 
            text: `✅ No inactive members to remove! Everyone has been active in the last ${days} day${days === 1 ? '' : 's'}.`
        });
        return;
    }

    // Store pending removal in memory (not in file)
    global.pendingRemovals = global.pendingRemovals || {};
    global.pendingRemovals[chatId] = {
        members: inactiveMembers.map(m => m.userId),
        initiator: senderId,
        timestamp: Date.now(),
        days: days
    };

    const confirmationMessage = [
        `⚠️ *CONFIRM INACTIVE MEMBER REMOVAL*`,
        `Found ${inactiveMembers.length} inactive member(s) with no activity in the last ${days} day${days === 1 ? '' : 's'}:`,
        ...inactiveMembers.slice(0, 10).map(({ userId }, i) => 
            `${i + 1}. @${userId.split('@')[0]}`),
        inactiveMembers.length > 10 ? `\n+ ${inactiveMembers.length - 10} more...` : '',
        '',
        '✅ Reply with *.confirmremove* to proceed',
        '❌ Reply with *.cancelremove* to abort',
        '',
        'ℹ️ This action cannot be undone. Bot must be admin to remove members.'
    ].filter(Boolean).join('\n');

    await sock.sendMessage(chatId, {
        text: confirmationMessage,
        mentions: inactiveMembers.slice(0, 10).map(m => m.userId)
    });
}

// Handle confirmation of removal
async function confirmRemoveInactive(sock, chatId, senderId, isAdmin) {
    if (!global.pendingRemovals?.[chatId]) {
        await sock.sendMessage(chatId, { text: '❌ No pending removal to confirm.' });
        return;
    }

    if (global.pendingRemovals[chatId].initiator !== senderId) {
        await sock.sendMessage(chatId, { 
            text: '❌ Only the person who initiated the removal can confirm it.' 
        });
        return;
    }

    if (!isAdmin) {
        await sock.sendMessage(chatId, { text: '❌ You need to be admin to confirm removal.' });
        return;
    }

    const { members, days = 30 } = global.pendingRemovals[chatId];
    delete global.pendingRemovals[chatId];

    try {
        // Attempt to remove members
        const result = await sock.groupParticipantsUpdate(chatId, members, 'remove');
        
        const successCount = result.filter(r => r.status === '200').length;
        const failCount = members.length - successCount;
        
        let resultMessage = `✅ Successfully removed ${successCount} inactive member(s) who hadn't been active for ${days} day${days === 1 ? '' : 's'}!\n`;
        if (failCount > 0) {
            resultMessage += `❌ Failed to remove ${failCount} member(s) - they may have left already or bot lacks permissions.`;
        }
        
        await sock.sendMessage(chatId, { text: resultMessage });
        
    } catch (error) {
        console.error('Error removing members:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Failed to remove members. Make sure the bot is an admin with removal permissions.' 
        });
    }
}

// Cancel pending removal
async function cancelRemoveInactive(sock, chatId, senderId) {
    if (!global.pendingRemovals?.[chatId]) {
        await sock.sendMessage(chatId, { text: '❌ No pending removal to cancel.' });
        return;
    }

    if (global.pendingRemovals[chatId].initiator !== senderId) {
        await sock.sendMessage(chatId, { 
            text: '❌ Only the person who initiated the removal can cancel it.' 
        });
        return;
    }

    delete global.pendingRemovals[chatId];
    await sock.sendMessage(chatId, { text: '🚫 Inactive member removal cancelled.' });
}

module.exports = {
    incrementMessageCount,
    topMembers,
    listInactiveMembers,
    listActiveMembers,
    removeInactiveMembers,
    confirmRemoveInactive,
    cancelRemoveInactive
};