// commands/antilink.js
const { setAntilink, getAntilink, removeAntilink } = require('../lib/index');
const isAdmin = require('../lib/isAdmin');

const prefix = '.';
const icons = {
    header: '🛡️',
    on: '✅',
    off: '🛑',
    set: '⚙️',
    warn: '⚠️',
    kick: '🚫',
    delete: '🗑️',
    error: '❌',
    info: 'ℹ️'
};

function box(title, lines) {
    return [
        `╭━━━[ *${icons.header} ${title.toUpperCase()}* ]━━━╮`,
        ...lines.map(l => `┃ ${l}`),
        '╰━━━━━━━━━━━━━━━━━━━━━━╯'
    ].join('\n');
}

async function send(sock, chatId, title, lines, mentions = []) {
    await sock.sendMessage(chatId, {
        text: box(title, lines),
        mentions
    });
}

async function handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, botId) {
    try {
        if (!isSenderAdmin) {
            return send(sock, chatId, 'Admins Only', [
                `${icons.error} This command is restricted to *group admins*.`
            ]);
        }

        const args = userMessage.slice(9).trim().toLowerCase().split(/\s+/);
        const action = args[0];

        if (!action) {
            return send(sock, chatId, 'Antilink Setup', [
                `${icons.info} Usage:`,
                `${prefix}antilink on`,
                `${prefix}antilink off`,
                `${prefix}antilink set <delete|kick|warn>`,
                `${prefix}antilink get`
            ]);
        }

        switch (action) {
            case 'on': {
                const cfg = await getAntilink(chatId, 'on', botId);
                if (cfg?.enabled) {
                    return send(sock, chatId, 'Antilink', [
                        `${icons.info} Antilink is *already ON*.`
                    ]);
                }
                const ok = await setAntilink(chatId, 'on', 'delete', botId);
                return send(sock, chatId, 'Antilink', [
                    ok ? `${icons.on} Antilink has been *enabled*.` 
                       : `${icons.error} Failed to enable Antilink.`
                ]);
            }

            case 'off': {
                await removeAntilink(chatId, botId);
                return send(sock, chatId, 'Antilink', [
                    `${icons.off} Antilink has been *disabled*.`
                ]);
            }

            case 'set': {
                const option = args[1];
                if (!['delete', 'kick', 'warn'].includes(option)) {
                    return send(sock, chatId, 'Antilink', [
                        `${icons.error} Invalid option. Use *delete*, *kick*, or *warn*.`
                    ]);
                }
                const ok = await setAntilink(chatId, 'on', option, botId);
                return send(sock, chatId, 'Antilink', [
                    ok ? `${icons.set} Action set to *${option}*.` 
                       : `${icons.error} Failed to update action.`
                ]);
            }

            case 'get': {
                const cfg = await getAntilink(chatId, 'on', botId) || {};
                return send(sock, chatId, 'Antilink Status', [
                    `Status : ${cfg.enabled ? 'ON' : 'OFF'}`,
                    `Action : ${cfg.action || 'delete'}`
                ]);
            }

            default:
                return send(sock, chatId, 'Antilink', [
                    `${icons.error} Unknown sub-command. Type *${prefix}antilink* for help.`
                ]);
        }
    } catch (err) {
        console.error(`Antilink error [${botId}]`, err);
        await send(sock, chatId, 'Antilink', [
            `${icons.error} An unexpected error occurred.`
        ]);
    }
}

// ========== Link Detection ==========
async function handleLinkDetection(sock, chatId, message, userMessage, senderId, botId) {
    const cfg = await getAntilink(chatId, 'on', botId);
    if (!cfg?.enabled) return;

    // Detect any http/https link (you can expand this later)
    const hasLink = /https?:\/\/\S+/.test(userMessage);
    if (!hasLink) return;

    // Delete message
    try {
        await sock.sendMessage(chatId, {
            delete: {
                remoteJid: chatId,
                fromMe: false,
                id: message.key.id,
                participant: message.key.participant || senderId
            }
        });
    } catch (e) {
        console.error(`[${botId}] Failed to delete message:`, e.message);
    }

    const nameTag = `@${senderId.split('@')[0]}`;
    const mentions = [senderId];

    switch (cfg.action || 'delete') {
        case 'warn':
            await send(sock, chatId, 'Antilink Warning', [
                `${icons.warn} ${nameTag}, posting links is not allowed in this group.`
            ], mentions);
            break;

        case 'kick':
            try {
                await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
                await send(sock, chatId, 'Antilink Kick', [
                    `${icons.kick} ${nameTag} was removed for sharing a link.`
                ], mentions);
            } catch (e) {
                console.error(`[${botId}] Kick failed:`, e.message);
                await send(sock, chatId, 'Antilink', [
                    `${icons.error} Could not kick — is the bot an admin?`
                ]);
            }
            break;

        default: // 'delete' or fallback
            await send(sock, chatId, 'Antilink', [
                `${icons.delete} A link was removed.`
            ]);
    }
}

module.exports = { handleAntilinkCommand, handleLinkDetection };