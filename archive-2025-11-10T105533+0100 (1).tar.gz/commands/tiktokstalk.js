import fg from 'api-dylux';

async function tikTokStalkCommand(sock, chatId, message, userMessage, botId) {
    const args = userMessage.slice(1).split(' ').filter(Boolean);
    const usedPrefix = '.';
    const command = args[0];

    if (!args[1]) {
        return sock.sendMessage(chatId, {
            text: `✳️ Please enter a TikTok username. Example: ${usedPrefix + command} zuck`
        });
    }

    const username = args[1];
    message.react("⏳");

    try {
        const apiUrl = `${info.apis}/tools/tiktokstalk?q=${encodeURIComponent(username)}`;
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (!data || !data.result || !data.result.users) {
            throw new Error('No profile data found.');
        }

        const profile = data.result.users;
        const stats = data.result.stats;

        const txt = `👤 *TikTok Profile*:
*• Username:* ${profile.username}
*• Nickname:* ${profile.nickname}
*• Verified:* ${profile.verified ? 'Yes' : 'No'}
*• Followers:* ${stats.followerCount.toLocaleString()}
*• Following:* ${stats.followingCount.toLocaleString()}
*• Total Likes:* ${stats.heartCount.toLocaleString()}
*• Videos:* ${stats.videoCount.toLocaleString()}
*• Bio:* ${profile.signature || 'None'}
*• URL:* ${profile.url}`;

        await sock.sendFile(chatId, profile.avatarLarger, 'tt.png', txt, message);
        message.react("✅");

    } catch (e2) {
        try {
            const res = await fg.ttStalk(username);

            const txt = `👤 *TikTok Profile*:
*• Name:* ${res.name}
*• Username:* ${res.username}
*• Followers:* ${res.followers}
*• Following:* ${res.following}
*• Description:* ${res.desc || 'None'}
*• Link:* https://tiktok.com/ @${res.username}`;

            await sock.sendFile(chatId, res.profile, 'tt.png', txt, message);
            message.react("✅");

        } catch (e) {
            console.error('Error fetching TikTok profile:', e);
            message.react("❌");
            await sock.sendMessage(chatId, {
                text: `\`\`\`⚠️ AN ERROR OCCURRED ⚠️\`\`\`\n\nReport this error to my creator using: #report\n\n>>> ${e.message}`
            });
        }
    }
}

export default tikTokStalkCommand;