// commands/livescore.js
const axios = require("axios");
const moment = require("moment-timezone");
const { sendButtons } = require("gifted-btns");

module.exports = async function livescoreCommand(sock, chatId, message) {
  try {
    await sock.sendPresenceUpdate("composing", chatId);

    // Extract message text with support for button replies
    const text =
      message.message?.conversation?.toLowerCase() ||
      message.message?.extendedTextMessage?.text?.toLowerCase() ||
      message.message?.buttonsResponseMessage?.selectedButtonId?.toLowerCase() ||
      message.message?.templateButtonReplyMessage?.selectedId?.toLowerCase() ||
      "";

    const args = text.split(" ");
    const sport = args[1];
    const league = args[2]; // optional (e.g., .livescore football epl)

    // Show sport options if none provided
    if (!sport) {
      await sendButtons(sock, chatId, {
        title: "🎮 Live Sports",
        text: "*Select a sport to view live scores:*",
        buttons: [
          { id: ".livescore football", text: "⚽ Football" },
          { id: ".livescore basketball", text: "🏀 Basketball (NBA)" },
          { id: ".livescore baseball", text: "⚾ Baseball (MLB)" },
          { id: ".livescore nfl", text: "🏈 NFL" },
          { id: ".livescore hockey", text: "🏒 Hockey (NHL)" },
          { id: ".livescore rugby", text: "🏉 Rugby" },
        ],
      });
      return;
    }

    // Football leagues map
    const footballLeagues = {
      epl: "soccer/eng.1",
      laliga: "soccer/esp.1",
      ucl: "soccer/uefa.champions",
      afcon: "soccer/africa.cup",
      seriea: "soccer/ita.1",
    };

    // Main sport map
    const sportMap = {
      football: null, // handled separately
      basketball: "basketball/nba",
      baseball: "baseball/mlb",
      nfl: "football/nfl",
      hockey: "hockey/nhl",
      rugby: "rugby/eur.1",
    };

    let apiLeague = null;

    if (sport === "football") {
      if (!league) {
        // Show football league options
        await sendButtons(sock, chatId, {
          title: "⚽ Football Leagues",
          text: "*Select a football league:*",
          buttons: [
            { id: ".livescore football epl", text: "🏟 EPL" },
            { id: ".livescore football laliga", text: "🇪🇸 La Liga" },
            { id: ".livescore football ucl", text: "🏆 UCL" },
            { id: ".livescore football afcon", text: "🌍 AFCON" },
            { id: ".livescore football seriea", text: "🇮🇹 Serie A" },
          ],
        });
        return;
      }

      apiLeague = footballLeagues[league];
      if (!apiLeague) {
        await sock.sendMessage(chatId, {
          text: "❌ Unsupported football league.\n\n✅ Try: epl, laliga, ucl, afcon, seriea",
        });
        return;
      }
    } else {
      apiLeague = sportMap[sport];
    }

    if (!apiLeague) {
      await sock.sendMessage(chatId, {
        text: "❌ Unsupported sport.\n\n✅ Try: football, basketball, baseball, nfl, hockey, rugby",
      });
      return;
    }

    // Fixed URL (no extra spaces)
    const apiUrl = `https://site.api.espn.com/apis/site/v2/sports/${apiLeague}/scoreboard`;

    const response = await axios.get(apiUrl);
    const events = response.data.events || [];

    if (!events.length) {
      await sock.sendMessage(chatId, {
        text: `📭 No live ${sport} matches right now.`,
      });
      return;
    }

    let responseText = `🏟️ *Live ${sport.toUpperCase()} Scores*\n\n`;

    events.slice(0, 9).forEach((event, i) => {
      // League name fallback
      let leagueName = event.leagues?.[0]?.name;
      if (!leagueName) {
        if (sport === "football") {
          const leagueNames = {
            epl: "Premier League",
            laliga: "La Liga",
            ucl: "Champions League",
            afcon: "AFCON",
            seriea: "Serie A",
          };
          leagueName = leagueNames[league] || "Football";
        } else {
          leagueName = sport.toUpperCase();
        }
      }

      const home = event.competitions?.[0]?.competitors?.find((c) => c.homeAway === "home")?.team?.displayName || "Home";
      const away = event.competitions?.[0]?.competitors?.find((c) => c.homeAway === "away")?.team?.displayName || "Away";
      const homeScore = event.competitions?.[0]?.competitors?.find((c) => c.homeAway === "home")?.score || "0";
      const awayScore = event.competitions?.[0]?.competitors?.find((c) => c.homeAway === "away")?.score || "0";
      const status = event.status?.type?.description || "LIVE";

      const startTime = event.date
        ? moment(event.date).tz("Africa/Lagos").format("DD MMM, HH:mm")
        : "TBD";

      responseText += `${i + 1}. *${leagueName}*\n`;
      responseText += `   ${home} vs ${away}\n`;
      responseText += `   🕒 ${startTime}\n`;
      responseText += `   🔢 Score: ${homeScore} - ${awayScore} (${status})\n\n`;
    });

    // Refresh button
    await sendButtons(sock, chatId, {
      text: responseText,
      buttons: [
        {
          id: `.livescore ${sport}${league ? " " + league : ""}`,
          text: "🔄 Refresh",
        },
      ],
    });
  } catch (error) {
    console.error("LiveScore Error:", error.message);
    await sock.sendMessage(chatId, {
      text: "⚠️ Error fetching scores. Please try again later.",
    });
  } finally {
    await sock.sendPresenceUpdate("paused", chatId);
  }
};