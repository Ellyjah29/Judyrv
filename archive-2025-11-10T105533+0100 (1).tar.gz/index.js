/**
 * WhatsApp Bot - Multi-Account Support with AUTO-RELOAD + SESSION LIFECYCLE
 * Fully compatible with Telegram Admin Bot
 * 
 * Copyright (c) 2025 Septorch 
 * AUTO-RELOAD + CLEANUP + AUTO-START + ERROR DETAIL
 */

const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const telegramBot = require('./telegrambot.js').bot;
const { promises: fsp } = fs;
const readline = require('readline');
const axios = require('axios');
const FileType = require('file-type');
const { Boom } = require('@hapi/boom');
const PhoneNumber = require('awesome-phonenumber');
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif');
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, await, sleep, reSize } = require('./lib/myfunc');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  jidDecode,
  proto,
  jidNormalizedUser,
  makeCacheableSignalKeyStore,
  delay
} = require("baileys");
const NodeCache = require("node-cache");
const pino = require("pino");
const chokidar = require('chokidar');

// Load handlers — will be reloaded automatically
let { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('./main');

// Global store for bots
global.botInstances = {};
global.settings = require('./settings');

// Store for messages, contacts, chats
const store = {
  messages: {},
  contacts: {},
  chats: {},
  groupMetadata: async (jid) => {
    return {};
  },
  bind: function (ev) {
    ev.on('messages.upsert', ({ messages }) => {
      messages.forEach(msg => {
        if (msg.key && msg.key.remoteJid) {
          this.messages[msg.key.remoteJid] = this.messages[msg.key.remoteJid] || {};
          this.messages[msg.key.remoteJid][msg.key.id] = msg;
        }
      });
    });
    ev.on('contacts.update', (contacts) => {
      contacts.forEach(contact => {
        if (contact.id) {
          this.contacts[contact.id] = contact;
        }
      });
    });
    ev.on('chats.set', (chats) => {
      this.chats = chats;
    });
  },
  loadMessage: async (jid, id) => {
    return this.messages[jid]?.[id] || null;
  }
};

// rmSync added here
const { rmSync } = require('fs');

// ✅ FIXED: MEGA URL — no extra spaces
async function downloadSession(sessionPath, sessionId) {
  const sessionFile = path.join(sessionPath, 'creds.json');
  if (!fs.existsSync(sessionFile)) {
    if (!sessionId) {
      console.log(chalk.yellow(`⚠️ SESSION_ID not provided for ${sessionPath}`));
      return;
    }
    try {
      console.log(chalk.blue(`📥 Downloading session for ${sessionPath}...`));
      const file = require('megajs').File.fromURL(`https://mega.nz/file/${sessionId}`);
      const data = await new Promise((resolve, reject) => {
        file.download((err, data) => (err ? reject(err) : resolve(data)));
      });
      fs.mkdirSync(sessionPath, { recursive: true });
      fs.writeFileSync(sessionFile, data);
      console.log(chalk.green(`✅ Session downloaded for ${sessionPath}.`));
    } catch (error) {
      console.error(
        chalk.red(`❌ Session download failed for ${sessionPath}:`, error.message)
      );
    }
  }
}

function getExpiryTimestamp(expiryDateStr) {
  const date = new Date(expiryDateStr);
  if (isNaN(date.getTime())) {
    throw new Error(`Invalid expiry date: ${expiryDateStr}`);
  }
  return date.setHours(23, 59, 59, 999);
}

// Start each bot dynamically
async function startBot(botConfig, botId) {
  const sessionPath = path.join(__dirname, 'session', botId);

  if (botConfig.expiry) {
    botConfig.expiryTimestamp = getExpiryTimestamp(botConfig.expiry);
    console.log(chalk.blue(`🕒 Bot ${botConfig.botName} will expire on: ${botConfig.expiry}`));
  }

  await downloadSession(sessionPath, botConfig.SESSION_ID);

  let { version } = await fetchLatestBaileysVersion();
  const pairingCode = !!botConfig.phoneNumber || process.argv.includes("--pairing-code");
  const useMobile = process.argv.includes("--mobile");
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
  const msgRetryCounterCache = new NodeCache();

  const XeonBotInc = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'fatal' }))
    },
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    getMessage: async key => {
      let jid = jidNormalizedUser(key.remoteJid);
      let msg = await store.loadMessage(jid, key.id);
      return msg?.message || '';
    },
    msgRetryCounterCache,
    defaultQueryTimeoutMs: undefined
  });

  global.botname = botConfig.botName;
  global.themeemoji = botConfig.themeemoji || '•';
  global.owner = [botConfig.ownerNumber];

  store.bind(XeonBotInc.ev);

  // ✅ CRITICAL: Early exit if manually stopped
  XeonBotInc.ev.on('messages.upsert', async chatUpdate => {
    if (botConfig.manuallyStopped) {
      console.log(chalk.gray(`⏸️ Ignoring message for manually stopped bot ${botConfig.botName}`));
      return;
    }
    try {
      const mek = chatUpdate.messages[0];
      if (!mek.message) return;
      mek.message =
        Object.keys(mek.message)[0] === 'ephemeralMessage'
          ? mek.message.ephemeralMessage.message
          : mek.message;

      if (mek.key?.remoteJid === 'status@broadcast') {
        await handleStatus(XeonBotInc, chatUpdate, botId);
        return;
      }

      if (!XeonBotInc.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
      if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;

      const senderId = mek.key.participant || mek.key.remoteJid;
      const senderBase = senderId.split(':')[0].split('@')[0];
      const phoneBase = senderId.split('@')[0].replace(/\D/g, '');
      if (!global.botInstances[botId].senderLids) {
        global.botInstances[botId].senderLids = {};
      }
      global.botInstances[botId].senderLids[phoneBase] = senderBase;

      if (botConfig.expiryTimestamp && Date.now() > botConfig.expiryTimestamp) {
        const nigeriaExpiry = new Date(botConfig.expiryTimestamp).toLocaleString('en-GB', {
          timeZone: 'Africa/Lagos',
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        });
        console.warn(chalk.yellow(`⏰ Bot ${botConfig.botName} expired on ${nigeriaExpiry}.`));
        if (mek.key.remoteJid && !mek.key.fromMe) {
          await XeonBotInc.sendMessage(mek.key.remoteJid, {
            text: `⏳ This bot expired on ${nigeriaExpiry}. Please contact admin for renewal.`,
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: '120363387922693296@newsletter',
                newsletterName: 'SEPTORCH',
                serverMessageId: -1
              }
            }
          });
        }
        return;
      }

      await handleMessages(XeonBotInc, chatUpdate, true, botId);
    } catch (err) {
      console.error('Error in messages.upsert:', err);
    }
  });

  XeonBotInc.decodeJid = jid => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {};
      return decode.user && decode.server && decode.user + '@' + decode.server || jid;
    } else return jid;
  };

  XeonBotInc.getName = (jid, withoutContact = false) => {
    let id = XeonBotInc.decodeJid(jid);
    withoutContact = XeonBotInc.withoutContact || withoutContact;
    let v;
    if (id.endsWith('@g.us')) {
      return new Promise(async resolve => {
        v = store.contacts[id] || {};
        if (!(v.name || v.subject)) v = await XeonBotInc.groupMetadata(id).catch(() => { });
        resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'));
      });
    } else {
      v = id === '0@s.whatsapp.net' ? { id, name: 'WhatsApp' } :
        id === XeonBotInc.decodeJid(XeonBotInc.user.id) ? XeonBotInc.user :
          (store.contacts[id] || {});
      return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international');
    }
  };

  XeonBotInc.public = true;
  XeonBotInc.serializeM = m => require('./lib/myfunc').smsg(XeonBotInc, m, store);

  // Connection update
  XeonBotInc.ev.on('connection.update', async s => {
    const { connection, lastDisconnect } = s;
    const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;

    if (connection === 'open') {
      console.log(chalk.yellow(`🌿 Connected to => ${JSON.stringify(XeonBotInc.user, null, 2)}`));

      const botNumber = XeonBotInc.user.id.split(':')[0] + '@s.whatsapp.net';
      const now = new Date();
      const nigerianDate = now.toLocaleDateString('en-NG', {
        timeZone: 'Africa/Lagos',
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
      const nigerianTime = now.toLocaleTimeString('en-NG', {
        timeZone: 'Africa/Lagos',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric',
        hour12: true
      });

      const messageText = `🤖 *${botConfig.botName}* is now online!

📅 *Date:* ${nigerianDate}
⏰ *Time:* ${nigerianTime}
✅ *Status:* Ready to serve!

*Connected on:* ${botNumber.replace('@s.whatsapp.net', '')}
`;

      try {
        await XeonBotInc.sendMessage(botNumber, {
          text: messageText,
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: '120363387922693296@newsletter',
              newsletterName: 'SEPTORCH',
              serverMessageId: -1
            }
          }
        });
        console.log(chalk.green(`✅ Connection message sent to bot itself: ${botNumber}`));
      } catch (err) {
        console.error(chalk.red(`❌ Failed to send connection message to itself:`, err.message));
      }

      if (!global.botInstances[botId]) global.botInstances[botId] = {};
      global.botInstances[botId].phoneJid = XeonBotInc.user.id;
      global.botInstances[botId].lidJid = XeonBotInc.user.lid;
      global.botInstances[botId].senderLids = {};
      global.botInstances[botId].retryCount = 0;

      try {
        const chats = Object.keys(store.chats).filter(j => j.endsWith('@g.us'));
        for (const groupId of chats) {
          const meta = await XeonBotInc.groupMetadata(groupId).catch(() => null);
          if (meta?.participants) {
            meta.participants.forEach(p => {
              const pure = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
              global.botInstances[botId].senderLids[pure] = pure;
            });
          }
        }
      } catch (err) {
        console.error(chalk.red(`❌ Failed to preload LID mappings for ${botId}:`), err);
      }

      console.log(chalk.magenta('< ================================================== >'));
      console.log(chalk.green(`${global.themeemoji} 🤖 ${global.botname} Connected Successfully! ✅`));
    }

    else if (connection === 'close') {
      // ✅ EARLY EXIT: If manually stopped, do nothing
      if (botConfig.manuallyStopped) {
        console.log(chalk.yellow(`⏸️ ${botConfig.botName} was manually stopped — ignoring close event.`));
        return;
      }

      console.log(chalk.red(`❌ Connection closed for ${botConfig.botName}. Status: ${statusCode}`));

      if (!global.botInstances[botId]) global.botInstances[botId] = {};
      global.botInstances[botId].retryCount = global.botInstances[botId]?.retryCount || 0;

      if ([408, 420, 500, 502, 503, 404, 440].includes(statusCode) || !statusCode) {
        if (statusCode === 440) {
          if (global.botInstances[botId].retryCount >= 2) {
            console.warn(chalk.red(`🛑 440 error persisted after 2 retries — assuming session expired.`));
            const sessionPath = path.join(__dirname, 'session', botId);
            try {
              rmSync(sessionPath, { recursive: true, force: true });
              console.log(chalk.gray(`🗑️ Session deleted: ${sessionPath}`));
            } catch (err) {
              console.error(chalk.red(`⚠️ Cleanup failed: ${err.message}`));
            }
            global.botInstances[botId].loggedOut = true;

            if (botConfig.telegramUserId) {
              try {
                await telegramBot.sendMessage(botConfig.telegramUserId, `📴 Oops! *${botConfig.botName}* got disconnected from WhatsApp.

Don’t worry — here’s how to fix it:

1️⃣ Tap → /start  
2️⃣ Click the “My Bots” button  
3️⃣ Find your bot and tap “Restart” to reconnect with a new session ID

⏱️ We’ll get it back online in seconds!

Need help? Just click the “Help” button after /start.`, {
                  parse_mode: 'Markdown'
                });
                console.log(chalk.green(`✅ 440 logout message sent via Telegram to: ${botConfig.telegramUserId}`));
              } catch (err) {
                console.error(chalk.red(`❌ Failed to send Telegram message:`), err.message);
              }
            }
            return;
          } else {
            global.botInstances[botId].retryCount++;
            console.log(chalk.yellow(`🔁 440 detected — Retry #${global.botInstances[botId].retryCount} for ${botConfig.botName} in 5s...`));
          }
        } else {
          console.log(chalk.yellow(`🔁 Retrying ${botConfig.botName} in 5 seconds...`));
        }

        setTimeout(() => startBot(botConfig, botId), 5000);
      }

      else if (statusCode === 401 || statusCode === 403) {
        console.warn(chalk.yellow(`🛑 Session ${statusCode === 401 ? 'Unauthorized (401)' : 'Forbidden (403)'} — stopping reconnect.`));
        const sessionPath = path.join(__dirname, 'session', botId);
        try {
          rmSync(sessionPath, { recursive: true, force: true });
          console.log(chalk.gray(`🗑️ Session deleted: ${sessionPath}`));
        } catch (err) {
          console.error(chalk.red(`⚠️ Cleanup failed: ${err.message}`));
        }

        global.botInstances[botId].loggedOut = true;

        if (botConfig.telegramUserId) {
          try {
            await telegramBot.sendMessage(botConfig.telegramUserId, `📴 Oops! *${botConfig.botName}* got disconnected from WhatsApp.

Don’t worry — here’s how to fix it:

1️⃣ Tap → /start  
2️⃣ Click the “My Bots” button  
3️⃣ Find your bot and tap “Restart” to reconnect with a new session ID

⏱️ We’ll get it back online in seconds!

Need help? Just click the “Help” button after /start.`, {
              parse_mode: 'Markdown'
            });
            console.log(chalk.green(`✅ Hard logout message sent via Telegram to: ${botConfig.telegramUserId}`));
          } catch (err) {
            console.error(chalk.red(`❌ Failed to send Telegram message:`), err.message);
          }
        }
      }

      else {
        console.warn(chalk.red(`⚠️ Unexpected close code: ${statusCode}. Retrying in 10 seconds...`));
        setTimeout(() => startBot(botConfig, botId), 10000);
      }
    }
  });

  XeonBotInc.ev.on('creds.update', saveCreds);
  XeonBotInc.ev.on('group-participants.update', async update => {
    try {
      const meta = await XeonBotInc.groupMetadata(update.id).catch(() => null);
      if (meta?.participants) {
        if (!global.botInstances[botId].senderLids) {
          global.botInstances[botId].senderLids = {};
        }
        meta.participants.forEach(p => {
          const pure = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
          global.botInstances[botId].senderLids[pure] = pure;
        });
      }
    } catch (err) {
      console.error(chalk.red(`❌ Failed to update LID map for ${update.id}:`), err);
    }
    await handleGroupParticipantUpdate(XeonBotInc, update, botId);
  });
  XeonBotInc.ev.on('status.update', async status => {
    await handleStatus(XeonBotInc, status, botId);
  });

  if (pairingCode && !XeonBotInc.authState.creds.registered) {
    if (useMobile) throw new Error('Cannot use pairing code with mobile api');
    let phoneNumber = botConfig.phoneNumber;
    if (!phoneNumber) {
      phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Enter WhatsApp number for ${botConfig.botName} 😍\nFormat: 23481376552730 (without + or spaces): `)));
    }
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (!phoneNumber.startsWith('234')) {
      phoneNumber = '234' + phoneNumber.replace(/^0+/, '');
    }
    setTimeout(async () => {
      try {
        let code = await XeonBotInc.requestPairingCode(phoneNumber);
        code = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log(chalk.black(chalk.bgGreen(`Your Pairing Code : `)), chalk.black(chalk.white(code)));
        console.log(chalk.yellow(`

Please enter this code in your WhatsApp app:

1. Open WhatsApp
2. Go to Settings > Linked Devices
3. Tap "Link a Device"
4. Enter the code shown above`));
      } catch (error) {
        console.error('Error requesting pairing code:', error);
      }
    }, 3000);
  }

  return XeonBotInc;
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise(resolve => rl.question(text, resolve));

// ✅ SAFE STOP: Full disconnect + flag
async function stopBot(botId) {
  if (!global.botInstances?.[botId]) {
    console.log(chalk.gray(`ℹ️ ${botId} is not running.`));
    return false;
  }
  try {
    const sock = global.botInstances[botId];
    // Force close
    if (sock.ws?.terminate) sock.ws.terminate();
    if (sock.end) await sock.end(null);
    // Remove listeners
    sock.ev.removeAllListeners();
    delete global.botInstances[botId];
    // Set flag
    const botIndex = parseInt(botId.replace('bot', '')) - 1;
    if (global.settings.bots[botIndex]) {
      global.settings.bots[botIndex].manuallyStopped = true;
    }
    console.log(chalk.green(`✅ ${botId} fully stopped. Session preserved.`));
    return true;
  } catch (err) {
    console.error(chalk.red(`💥 Failed to stop ${botId}:`), err.message);
    return false;
  }
}

// Start with flag cleared
async function startBotById(botId) {
  const botIndex = parseInt(botId.replace('bot', '')) - 1;
  const botConfig = global.settings?.bots?.[botIndex];
  if (!botConfig || !botConfig.SESSION_ID) {
    throw new Error(`Bot config or SESSION_ID missing for ${botId}`);
  }
  if (global.botInstances?.[botId]?.user) {
    console.log(chalk.yellow(`⚠️ ${botId} is already running.`));
    return global.botInstances[botId];
  }
  delete botConfig.manuallyStopped;
  const sock = await startBot(botConfig, botId);
  global.botInstances[botId] = sock;
  return sock;
}

// Reconnect with flag cleared
async function reconnectBot(botId) {
  const botIndex = parseInt(botId.replace('bot', '')) - 1;
  const botConfig = global.settings?.bots?.[botIndex];
  if (!botConfig || !botConfig.SESSION_ID) {
    throw new Error('No session found for this bot.');
  }
  if (global.botInstances?.[botId]) {
    const sock = global.botInstances[botId];
    if (sock.ws?.terminate) sock.ws.terminate();
    if (sock.end) await sock.end(null);
    sock.ev.removeAllListeners();
    delete global.botInstances[botId];
  }
  delete botConfig.manuallyStopped;
  const sock = await startBot(botConfig, botId);
  global.botInstances[botId] = sock;
  return sock;
}

global.startBotById = startBotById;
global.stopBot = stopBot;
global.reconnectBot = reconnectBot;

async function startAllBots() {
  for (let i = 0; i < global.settings.bots.length; i++) {
    const botConfig = global.settings.bots[i];
    const botId = `bot${i + 1}`;
    if (!botConfig.SESSION_ID) {
      console.log(chalk.yellow(`⚠️ Skipping ${botConfig.botName}: SESSION_ID missing.`));
      continue;
    }
    console.log(chalk.cyan(`🚀 Starting bot: ${botConfig.botName} [${botId}]`));
    const sock = await startBot(botConfig, botId);
    if (!global.botInstances) global.botInstances = {};
    global.botInstances[botId] = sock;
    if (i < global.settings.bots.length - 1) {
      console.log(chalk.yellow('🕒 Waiting 5 seconds before starting next bot...'));
      await delay(5000);
    }
  }
}

function setupHotReload() {
  const watchPaths = [
    './main.js',
    './settings.js',
    './commands/**/*.js',
    './lib/**/*.js'
  ];

  console.log(chalk.blue('🔁 Auto-Reload System Activated — Editing files will auto-update bot!'));

  const watcher = chokidar.watch(watchPaths, {
    ignored: /(^|[\/\\])\../,
    persistent: true
  });

  watcher.on('change', async (filePath) => {
    const absPath = path.resolve(filePath);
    console.log(chalk.yellow(`\n🔄 File changed: ${filePath}`));

    Object.keys(require.cache).forEach(key => {
      if (key === absPath || key.includes(absPath)) {
        delete require.cache[key];
        console.log(chalk.gray(`🗑️  Cleared cache: ${key}`));
      }
    });

    if (filePath.includes('settings.js')) {
      try {
        const oldSettings = global.settings || { bots: [] };
        global.settings = require('./settings');
        console.log(chalk.green(`✅ Global settings reloaded!`));

        for (let i = 0; i < oldSettings.bots.length; i++) {
          const oldBot = oldSettings.bots[i];
          const newBot = global.settings.bots[i];
          const botId = `bot${i + 1}`;
          const oldSession = oldBot?.SESSION_ID;
          const newSession = newBot?.SESSION_ID;

          if (oldSession && (!newSession || newSession !== oldSession)) {
            console.log(chalk.yellow(`🗑️ SESSION_ID removed or changed for ${oldBot.botName} — cleaning up...`));
            if (global.botInstances?.[botId]) {
              try {
                const sock = global.botInstances[botId];
                if (sock.ws?.terminate) sock.ws.terminate();
                if (sock.end) await sock.end(null);
                sock.ev.removeAllListeners();
                console.log(chalk.gray(`🔌 Stopped ${botId}`));
              } catch (err) {
                console.warn(chalk.yellow(`⚠️ Stop failed for ${botId}:`, err.message));
              }
              delete global.botInstances[botId];
            }
            const sessionPath = path.join(__dirname, 'session', botId);
            if (fs.existsSync(sessionPath)) {
              try {
                fs.rmSync(sessionPath, { recursive: true, force: true });
                console.log(chalk.gray(`🗑️ Session folder deleted: ${sessionPath}`));
              } catch (err) {
                console.error(chalk.red(`❌ Failed to delete session folder:`, err.message));
              }
            }
            if (oldBot.telegramUserId) {
              try {
                await telegramBot.sendMessage(oldBot.telegramUserId, `✅ *${oldBot.botName}* cleanup complete.

You can now:
1️⃣ Tap → /start
2️⃣ Click the “My Bots” button
3️⃣ Tap “Restart” to reconnect with a new session ID

✨ No old data left behind!`, {
                  parse_mode: 'Markdown'
                });
                console.log(chalk.green(`✅ Cleanup notice sent via Telegram to: ${oldBot.telegramUserId}`));
              } catch (err) {
                console.error(chalk.red(`❌ Failed to send Telegram cleanup message:`), err.message);
              }
            }
          }
        }

        if (global.settings.bots.length < oldSettings.bots.length) {
          for (let i = global.settings.bots.length; i < oldSettings.bots.length; i++) {
            const botId = `bot${i + 1}`;
            const oldBot = oldSettings.bots[i];
            if (global.botInstances?.[botId]) {
              try {
                const sock = global.botInstances[botId];
                if (sock.ws?.terminate) sock.ws.terminate();
                if (sock.end) await sock.end(null);
                sock.ev.removeAllListeners();
                console.log(chalk.gray(`🔌 Stopped extra ${botId}`));
              } catch (err) {
                console.warn(chalk.yellow(`⚠️ Stop failed for ${botId}:`, err.message));
              }
              delete global.botInstances[botId];
            }
            const sessionPath = path.join(__dirname, 'session', botId);
            if (fs.existsSync(sessionPath)) {
              try {
                fs.rmSync(sessionPath, { recursive: true, force: true });
                console.log(chalk.gray(`🗑️ Deleted extra session: ${sessionPath}`));
              } catch (err) {
                console.error(chalk.red(`❌ Failed to delete extra session:`, err.message));
              }
            }
            if (oldBot?.telegramUserId) {
              try {
                await telegramBot.sendMessage(oldBot.telegramUserId, `✅ Extra bot slot *${botId}* cleaned up.

You removed this bot from settings.js — all data deleted.`, {
                  parse_mode: 'Markdown'
                });
                console.log(chalk.green(`✅ Extra bot cleanup notice sent via Telegram to: ${oldBot.telegramUserId}`));
              } catch (err) {
                console.error(chalk.red(`❌ Failed to send extra bot Telegram notice:`), err.message);
              }
            }
          }
        }

        for (let i = 0; i < global.settings.bots.length; i++) {
          const newBot = global.settings.bots[i];
          const botId = `bot${i + 1}`;
          const oldBot = oldSettings.bots[i];
          const oldSession = oldBot?.SESSION_ID;
          const newSession = newBot?.SESSION_ID;

          if ((!oldSession || oldSession === "") && newSession && newSession !== "") {
            console.log(chalk.green(`🚀 NEW SESSION_ID detected for ${newBot.botName} — auto-starting bot...`));
            if (global.botInstances[botId]?.user) {
              console.log(chalk.yellow(`⚠️ ${botId} is already connected — skipping auto-start.`));
              continue;
            }
            delete newBot.manuallyStopped;
            try {
              const sock = await startBot(newBot, botId);
              if (!global.botInstances) global.botInstances = {};
              global.botInstances[botId] = sock;
              console.log(chalk.green(`✅ ${newBot.botName} started successfully with new SESSION_ID!`));
              if (newBot.telegramUserId) {
                try {
                  await telegramBot.sendMessage(newBot.telegramUserId, `✅ *${newBot.botName}* is now reconnecting!

✨ New SESSION_ID detected — bot is starting up automatically.

You’ll get a confirmation message here once it’s online. No manual restart needed!`, {
                    parse_mode: 'Markdown'
                  });
                  console.log(chalk.green(`✅ Auto-start notice sent via Telegram to: ${newBot.telegramUserId}`));
                } catch (err) {
                  console.error(chalk.red(`❌ Failed to send Telegram auto-start message:`), err.message);
                }
              }
            } catch (err) {
              console.error(chalk.red(`❌ Failed to auto-start ${newBot.botName}:`, err.message));
              if (newBot.telegramUserId) {
                try {
                  await telegramBot.sendMessage(newBot.telegramUserId, `❌ *${newBot.botName}* auto-start FAILED.

Error: \`${err.message}\`

Please check your SESSION_ID or contact support.`, {
                    parse_mode: 'Markdown'
                  });
                } catch (e) {
                  console.error("Failed to send failure notice:", e.message);
                }
              }
            }
          }
        }
      } catch (err) {
        console.error(chalk.red(`\n❌ HOT-RELOAD FAILED FOR: ./settings.js\n`));
        console.log(chalk.yellow(`\n⚠️  Fix syntax error in settings.js and save again.\n`));
        return;
      }
    }

    try {
      const mainModule = require('./main');
      if (!mainModule.handleMessages || !mainModule.handleGroupParticipantUpdate || !mainModule.handleStatus) {
        throw new Error("Handlers missing in main.js");
      }
      handleMessages = mainModule.handleMessages;
      handleGroupParticipantUpdate = mainModule.handleGroupParticipantUpdate;
      handleStatus = mainModule.handleStatus;
      console.log(chalk.green(`✅ Reloaded handlers from ./main.js`));
    } catch (err) {
      console.error(chalk.red(`\n❌ HOT-RELOAD FAILED FOR: ./main.js\n`));
      console.log(chalk.yellow(`🔁 Fix the error and SAVE again — hot-reload will retry automatically.\n`));
    }

    // Re-bind events for all active bots
    for (const [botId, sock] of Object.entries(global.botInstances || {})) {
      if (!sock || !sock.user) continue;
      const botConfig = global.settings.bots[parseInt(botId.replace('bot', '')) - 1];
      // ✅ Skip if manually stopped
      if (botConfig?.manuallyStopped) {
        console.log(chalk.gray(`⏸️ Skipping hot-reload for manually stopped ${botId}`));
        continue;
      }

      sock.ev.removeAllListeners('messages.upsert');
      sock.ev.on('messages.upsert', async (chatUpdate) => {
        if (botConfig?.manuallyStopped) return; // Extra safety
        try {
          const mek = chatUpdate.messages[0];
          if (!mek?.message) return;
          mek.message = Object.keys(mek.message)[0] === 'ephemeralMessage'
            ? mek.message.ephemeralMessage.message
            : mek.message;
          if (mek.key?.remoteJid === 'status@broadcast') {
            await handleStatus(sock, chatUpdate, botId);
            return;
          }
          if (!sock.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
          if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;

          const senderId = mek.key.participant || mek.key.remoteJid;
          const senderBase = senderId.split(':')[0].split('@')[0];
          const phoneBase = senderId.split('@')[0].replace(/\D/g, '');
          if (!global.botInstances[botId].senderLids) {
            global.botInstances[botId].senderLids = {};
          }
          global.botInstances[botId].senderLids[phoneBase] = senderBase;

          if (botConfig?.expiryTimestamp && Date.now() > botConfig.expiryTimestamp) {
            const nigeriaExpiry = new Date(botConfig.expiryTimestamp).toLocaleString('en-GB', {
              timeZone: 'Africa/Lagos',
              day: '2-digit',
              month: '2-digit',
              year: 'numeric'
            });
            if (mek.key.remoteJid && !mek.key.fromMe) {
              await sock.sendMessage(mek.key.remoteJid, {
                text: `⏳ This bot expired on ${nigeriaExpiry}. Please contact admin for renewal.`,
                contextInfo: {
                  forwardingScore: 1,
                  isForwarded: true,
                  forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363387922693296@newsletter',
                    newsletterName: 'SEPTORCH',
                    serverMessageId: -1
                  }
                }
              });
            }
            return;
          }

          await handleMessages(sock, chatUpdate, true, botId);
        } catch (err) {
          console.error(`💥 Error in hot-reloaded handler for ${botId}:`, err);
        }
      });

      sock.ev.removeAllListeners('group-participants.update');
      sock.ev.on('group-participants.update', async (update) => {
        try {
          const meta = await sock.groupMetadata(update.id).catch(() => null);
          if (meta?.participants) {
            if (!global.botInstances[botId].senderLids) {
              global.botInstances[botId].senderLids = {};
            }
            meta.participants.forEach(p => {
              const pure = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
              global.botInstances[botId].senderLids[pure] = pure;
            });
          }
          await handleGroupParticipantUpdate(sock, update, botId);
        } catch (err) {
          console.error(`💥 Error in group handler for ${botId}:`, err);
        }
      });

      sock.ev.removeAllListeners('status.update');
      sock.ev.on('status.update', async (status) => {
        await handleStatus(sock, status, botId);
      });

      console.log(chalk.green(`🔁 Re-bound events for ${botId}`));
    }

    console.log(chalk.greenBright(`\n🎉 Hot-Reload Complete — No Restart Needed! 🎉\n`));
  });
}

(async () => {
  try {
    await startAllBots();
    console.log(chalk.greenBright('\n✅ All bots started!'));

    setTimeout(() => {
      setupHotReload();
    }, 5000);

    const foldersToClear = ["./temp", "./tmp", "./.cache"];
    const clearFolder = (folderPath) => {
      if (fs.existsSync(folderPath)) {
        fs.readdirSync(folderPath).forEach(file => {
          const curPath = path.join(folderPath, file);
          try {
            if (fs.lstatSync(curPath).isDirectory()) {
              fs.rmSync(curPath, { recursive: true, force: true });
            } else {
              fs.unlinkSync(curPath);
            }
          } catch (err) {
            console.error(`⚠️ Failed to remove ${curPath}:`, err.message);
          }
        });
      }
    };
    foldersToClear.forEach(clearFolder);
    setInterval(() => foldersToClear.forEach(clearFolder), 10 * 60 * 1000);

  } catch (err) {
    console.error(chalk.red('❌ Startup error:'), err);
  }
})();

process.on('uncaughtException', err => {
  console.error(chalk.red('💥 Uncaught Exception:'), err);
});
process.on('unhandledRejection', err => {
  console.error(chalk.red('💥 Unhandled Rejection:'), err);
});

console.log(chalk.greenBright('\n🚀 WhatsApp Bot with Full Auto-Reload + Session Lifecycle Management is Running!'));
console.log(chalk.greenBright('✅ Edit files → changes apply instantly'));
console.log(chalk.greenBright('✅ Remove SESSION_ID → auto cleanup'));
console.log(chalk.greenBright('✅ Add SESSION_ID → auto reconnect'));
console.log(chalk.greenBright('✅ Start / Stop / Reconnect without session loss!'));