// song.js

const playCommand = require('./play');

module.exports = playCommand;