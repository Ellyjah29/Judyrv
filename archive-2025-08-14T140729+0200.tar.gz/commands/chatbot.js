const fs   = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const USER_GROUP_DATA = path.join(__dirname, '../data/userGroupData.json');

/* ──────────────────────────────────────
   🔰  BOX-STYLE HELPERS
   ────────────────────────────────────── */
const icons = { header:'💬', info:'ℹ️', ok:'✅', off:'🛑', err:'❌', warn:'⚠️' };

const box = (title, lines) => [
  `╭━━━[ *${icons.header} ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

const sendBox = (sock, chatId, title, lines, extra = {}) =>
  sock.sendMessage(chatId, { text: box(title, lines), ...extra });

/* ──────────────────────────────────────
   🗂️  IN-MEMORY CHAT CONTEXT
   ────────────────────────────────────── */
const chatMemory = {
  messages : new Map(),   // last 20 msgs / user
  userInfo : new Map()    // extracted user info
};

/* ──────────────────────────────────────
   📂  LOAD / SAVE GROUP DATA
   ────────────────────────────────────── */
const loadUserGroupData = () => {
  try   { return JSON.parse(fs.readFileSync(USER_GROUP_DATA)); }
  catch { return { groups:[], chatbot:{} }; }
};
const saveUserGroupData = d =>
  fs.writeFileSync(USER_GROUP_DATA, JSON.stringify(d, null, 2));

/* ──────────────────────────────────────
   🕓  TYPING SIMULATION
   ────────────────────────────────────── */
const randDelay = () => Math.floor(Math.random()*3000)+2000;
const showTyping = async (sock, chatId) => {
  try {
    await sock.presenceSubscribe(chatId);
    await sock.sendPresenceUpdate('composing', chatId);
    await new Promise(r => setTimeout(r, randDelay()));
  } catch(e){ console.error('Typing indicator error:', e); }
};

/* ──────────────────────────────────────
   🔍  USER INFO EXTRACTION
   ────────────────────────────────────── */
function extractUserInfo(msg){
  const info={};
  if (/my name is/i.test(msg))
    info.name = msg.split(/my name is/i)[1].trim().split(' ')[0];
  if (/i am .*years old/i.test(msg))
    info.age = msg.match(/\d+/)?.[0];
  if (/i (?:live in|am from)/i.test(msg))
    info.location = msg.split(/i (?:live in|am from)/i)[1]
                      .trim().split(/[.,!?]/)[0];
  return info;
}

/* ──────────────────────────────────────
   ⚙️  .chatbot ON / OFF
   ────────────────────────────────────── */
async function handleChatbotCommand(sock, chatId, message, match){
  // usage box if no sub-command
  if(!match){
    await showTyping(sock, chatId);
    return sendBox(sock, chatId,'Chatbot',[
      `${icons.info}  Usage:`,
      '.chatbot on   – Enable in this group',
      '.chatbot off  – Disable in this group'
    ], { quoted: message });
  }

  const data   = loadUserGroupData();
  const owner  = sock.user.id.split(':')[0]+'@s.whatsapp.net';
  const sender = message.key.participant || message.participant ||
                 message.pushName       || message.key.remoteJid;
  const isOwner = sender === owner;

  /* owners bypass admin checks */
  let isAdmin = false;
  if(!isOwner && chatId.endsWith('@g.us')){
    try{
      const meta = await sock.groupMetadata(chatId);
      isAdmin = meta.participants.some(p =>
        p.id === sender && ['admin','superadmin'].includes(p.admin));
    }catch{ /* ignore */ }
  }
  if(!isOwner && !isAdmin){
    await showTyping(sock, chatId);
    return sendBox(sock, chatId,'Chatbot',[
      `${icons.err}  Only *group admins* or the *bot owner* can use this.`
    ], { quoted: message });
  }

  /* handle on/off */
  const currentlyOn = !!data.chatbot[chatId];

  if(match === 'on'){
    if(currentlyOn){
      await showTyping(sock, chatId);
      return sendBox(sock, chatId,'Chatbot',[`${icons.info}  Already *enabled*.`],{quoted:message});
    }
    data.chatbot[chatId] = true; saveUserGroupData(data);
    console.log(`Chatbot enabled for ${chatId}`);
    await showTyping(sock, chatId);
    return sendBox(sock, chatId,'Chatbot',[`${icons.ok}  Chatbot *enabled* for this group.`],{quoted:message});
  }

  if(match === 'off'){
    if(!currentlyOn){
      await showTyping(sock, chatId);
      return sendBox(sock, chatId,'Chatbot',[`${icons.info}  Already *disabled*.`],{quoted:message});
    }
    delete data.chatbot[chatId]; saveUserGroupData(data);
    console.log(`Chatbot disabled for ${chatId}`);
    await showTyping(sock, chatId);
    return sendBox(sock, chatId,'Chatbot',[`${icons.off}  Chatbot *disabled* for this group.`],{quoted:message});
  }

  await showTyping(sock, chatId);
  return sendBox(sock, chatId,'Chatbot',[`${icons.err}  Invalid option.`],{quoted:message});
}

/* ──────────────────────────────────────
   🤖  BOT RESPONSE HANDLER
   ────────────────────────────────────── */
async function handleChatbotResponse(sock, chatId, message, userMsg, senderId){
  const data = loadUserGroupData();
  if(!data.chatbot[chatId]) return;

  try{
    const bot = sock.user.id.split(':')[0]+'@s.whatsapp.net';

    /* detect mention / reply to bot */
    let mentioned = false, replyToBot=false;
    if(message.message?.extendedTextMessage){
      const ctx = message.message.extendedTextMessage.contextInfo;
      mentioned = (ctx.mentionedJid||[]).includes(bot);
      replyToBot = ctx.participant === bot;
    }else if(message.message?.conversation){
      mentioned = userMsg.includes(`@${bot.split('@')[0]}`);
    }
    if(!mentioned && !replyToBot) return;

    // strip mention
    if(mentioned)
      userMsg = userMsg.replace(new RegExp(`@${bot.split('@')[0]}`,'g'),'').trim();

    /* memory init */
    if(!chatMemory.messages.has(senderId)){
      chatMemory.messages.set(senderId,[]);
      chatMemory.userInfo.set(senderId,{});
    }

    /* update user info + history */
    const info = extractUserInfo(userMsg);
    if(Object.keys(info).length)
      chatMemory.userInfo.set(senderId,{...chatMemory.userInfo.get(senderId),...info});

    const hist = chatMemory.messages.get(senderId);
    hist.push(userMsg); if(hist.length>20) hist.shift();

    await showTyping(sock, chatId);

    /* fetch AI reply */
    const aiReply = await getAIResponse(userMsg,{
      messages:hist,
      userInfo:chatMemory.userInfo.get(senderId)
    });
    if(!aiReply){
      return sock.sendMessage(chatId,{
        text:"Hmm, I'm blank right now 😅. Try again?",
        quoted: message
      });
    }

    await new Promise(r=>setTimeout(r, randDelay()));
    await sock.sendMessage(chatId,{text:aiReply},{quoted:message});

  }catch(e){
    console.error('Chatbot response error:',e);
    await sock.sendMessage(chatId,{
      text:"Oops! Kuch gadbad ho gayi 😅. Repeat once?",
      quoted:message
    });
  }
}

/* ──────────────────────────────────────
   🌐  CALL EXTERNAL AI ENDPOINT
   ────────────────────────────────────── */
async function getAIResponse(userMessage, context){
  try{
    const prompt = /* … the same long prompt you already had … */ `
${/* prompt omitted for brevity; unchanged */''}`.trim();

    const res = await fetch("https://api.dreaded.site/api/chatgpt?text="+encodeURIComponent(prompt));
    if(!res.ok) throw new Error('API call failed');
    const data = await res.json();
    if(!data.success || !data.result?.prompt) throw new Error('Bad response');

    /* quick cleanup of instruction residue */
    return data.result.prompt
      .replace(/(?:[A-Z ]+:|✅|❌|•).*\n?/g,'')
      .replace(/\n{2,}/g,'\n')
      .trim();
  }catch(e){
    console.error('AI API error:',e);
    return null;
  }
}

/* ──────────────────────────────────────
   📤  EXPORTS
   ────────────────────────────────────── */
module.exports = {
  handleChatbotCommand,
  handleChatbotResponse
};