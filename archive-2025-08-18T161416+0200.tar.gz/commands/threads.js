// threads.js

const axios = require('axios');
const { get } = require('threads-api');

async function threadsCommand(sock, chatId, message, userMessage, botId) {
    const url = userMessage.split(' ')[1];

    if (!url || !url.includes('threads.net')) {
        await sock.sendMessage(chatId, {
            text: '❌ Please provide a valid Threads URL.',
            ...botId
        });
        return;
    }

    try {
        const post = await get(url);
        const videoUrl = post.media?.url;

        if (!videoUrl) {
            await sock.sendMessage(chatId, {
                text: '❌ No video found in this post.',
                ...botId
            });
            return;
        }

        await sock.sendMessage(chatId, {
            video: { url: videoUrl },
            caption: '📹 Thread Video',
            mimetype: 'video/mp4',
            fileName: `thread_video.mp4`,
            ...botId
        });
    } catch (err) {
        console.error(err);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to download thread video.',
            ...botId
        });
    }
}

module.exports = threadsCommand;