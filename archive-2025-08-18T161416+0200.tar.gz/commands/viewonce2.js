// commands/viewonce.js

const { downloadContentFromMessage } = require('baileys');
const fs = require('fs');
const path = require('path');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH',
            serverMessageId: -1
        }
    }
};

async function getMediaBuffer(mediaMessage, type) {
    const stream = await downloadContentFromMessage(mediaMessage, type);
    const chunks = [];

    for await (const chunk of stream) {
        chunks.push(chunk);
    }

    return Buffer.concat(chunks);
}

async function viewOnceCommand(sock, chatId, message) {
    try {
        const botJid = `${sock.user.id.split(':')[0]}@s.whatsapp.net`;

        const ctxInfo = message.message?.extendedTextMessage?.contextInfo;
        const quoted = ctxInfo?.quotedMessage || message.message?.viewOnceMessage?.message;

        const mediaMessage =
            quoted?.imageMessage ||
            quoted?.videoMessage ||
            quoted?.viewOnceMessage?.message?.imageMessage ||
            quoted?.viewOnceMessage?.message?.videoMessage;

        if (!mediaMessage) {
            await sock.sendMessage(chatId, {
                text: '❌ Please reply to a *view once* image or video.',
                ...channelInfo
            });
            return;
        }

        const isImage = !!mediaMessage.mimetype?.includes('image');
        const isVideo = !!mediaMessage.mimetype?.includes('video');

        const caption = mediaMessage.caption ? `\n📝 *Caption:* ${mediaMessage.caption}` : '';
        const header = `*💀 SeptorchBot Anti ViewOnce 💀*\n\n*Type:* ${isImage ? '📸 Image' : '📹 Video'}${caption}`;

        if (isImage) {
            try {
                const buffer = await getMediaBuffer(mediaMessage, 'image');

                await sock.sendMessage(botJid, {
                    image: buffer,
                    caption: header,
                    ...channelInfo
                });

                console.log('✅ View once image sent to bot.');
            } catch (error) {
                console.error('❌ Image handling error:', error);
                await sock.sendMessage(chatId, {
                    text: '❌ Could not process the view once image.\n' + error.message,
                    ...channelInfo
                });
            }
        } else if (isVideo) {
            try {
                const tempDir = path.join(__dirname, '../temp');
                if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);

                const tempPath = path.join(tempDir, `vo_${Date.now()}.mp4`);
                const stream = await downloadContentFromMessage(mediaMessage, 'video');
                const writeStream = fs.createWriteStream(tempPath);

                for await (const chunk of stream) {
                    writeStream.write(chunk);
                }

                writeStream.end();
                await new Promise(resolve => writeStream.on('finish', resolve));

                await sock.sendMessage(botJid, {
                    video: fs.readFileSync(tempPath),
                    caption: header,
                    ...channelInfo
                });

                fs.unlinkSync(tempPath);
                console.log('✅ View once video sent to bot.');
            } catch (error) {
                console.error('❌ Video handling error:', error);
                await sock.sendMessage(chatId, {
                    text: '❌ Could not process the view once video.\n' + error.message,
                    ...channelInfo
                });
            }
        } else {
            await sock.sendMessage(chatId, {
                text: '❌ Unsupported or non-view-once media. Please reply to a view once image/video.',
                ...channelInfo
            });
        }

    } catch (err) {
        console.error('❌ Fatal error in viewOnceCommand:', err);
        await sock.sendMessage(chatId, {
            text: '❌ An unexpected error occurred!\n' + err.message,
            ...channelInfo
        });
    }
}

module.exports = viewOnceCommand;