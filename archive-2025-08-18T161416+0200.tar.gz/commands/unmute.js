async function unmuteCommand(sock, chatId, senderId, botId) {
    // ✅ NO ADMIN CHECK NEEDED - ALREADY DONE IN MAIN.JS
    
    try {
        await sock.groupSettingUpdate(chatId, 'not_announcement');
        await sock.sendMessage(chatId, { text: 'The group has been unmuted.' });
    } catch (error) {
        console.error('Error unmuting group:', error);
        await sock.sendMessage(chatId, { text: 'Failed to unmute the group. Please try again.' });
    }
}

module.exports = unmuteCommand;