exports.bots = [
  {
    "botName": "SEPTORCH",
    "themeemoji": "🦄",
    "ownerNumber": "2349047943737",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "drZS7X3oEH7WoJZY",
    "telegramUserId": 7738315673,
    "expiryTimestamp": 1753786696977,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "aMY0FCiS#3jKsHjzlRz3TImy9YlMHfTCI4qV3IoL9jJyknY8fIlc"
  },
  {
    "botName": "My choice",
    "themeemoji": "🤖",
    "ownerNumber": "2349047943737",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "hUmxVKUGK3FOkCX6",
    "telegramUserId": 7021106990,
    "expiryTimestamp": 1753810236437,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "bUhRHDaK#X6JFJcEbpsbE10sZhUv54whi8BHbq2n5BUGhT-d9rqk"
  },
  {
    "botName": "Dr. Haliya PA",
    "themeemoji": "⚡",
    "ownerNumber": "2349051799728",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "pbqRGgofDDYdYgJW",
    "telegramUserId": 7471519118,
    "expiryTimestamp": 1751324399000,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "zMwwmQxC#cjZtJneairhWSpQl2thHYUPinO3V1_99EURrVxtJUSg"
  },
  {
    "botName": "*ꜱɢ ꜰᴏʀᴛᴜɴᴇ 神*",
    "themeemoji": "⚡",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "a6CnsFeZV6uHAwPP",
    "telegramUserId": 7550438586,
    "expiryTimestamp": 1752188399000,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "CMpTUJZL#r3h6N-EYKynsgJq_tj_rPaOSAqMo7MX5_l_oWC0OE0U"
  },
  {
    "botName": "Dr. Haliya PA",
    "themeemoji": "👑",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "nGDUHKEtcH2i8QY9",
    "telegramUserId": 7471519118,
    "expiryTimestamp": 1752361199000,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "mVY1HThK#sl41FBUuUmJxxmsQnsX3-8g4slc6gtJ4XmcsqFiMeDE"
  },
  {
    "botName": "P3tr",
    "themeemoji": "🎯",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "VvIFMx8zSKxr949I",
    "telegramUserId": 8305013620,
    "expiryTimestamp": 1752361199000,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "yRhyHTTT#0j5leWMCELBzsn_QstXeuevIoTTMR22peFF5qZI-Q1A"
  },
  {
    "botName": "£mpir€☠️",
    "themeemoji": "💫",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "akvhwVsoIYUllTo5",
    "telegramUserId": 7288391514,
    "expiryTimestamp": 1753788399409,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "eIJREZbT#2vapeCCllKjezkBYtAF4eoaHZ-EYRCmra01KvlAX_pU"
  },
  {
    "botName": "Savage",
    "themeemoji": "🌟",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "iV7vCTwgX5YMR0Su",
    "telegramUserId": 6963412484,
    "expiryTimestamp": 1754175599000,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "KNZlARyI#KTgfa6Xl6Wr-_EypxBqWQMVhGh5i0Gp0lZAMGUjd1CI"
  },
  {
    "botName": "Chibueze bot",
    "themeemoji": "🔥",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "8jXukOYR4FcIXlok",
    "telegramUserId": 6963412484,
    "expiryTimestamp": 1753796135547,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "qRpFwIDQ#SGZRnlC0W7cu02IERy2ty_ZLWPjUjd2f8A40Uqz2s3g"
  },
  {
    "botName": "smart jboy🧠",
    "themeemoji": "🛡️",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "cTspKxVpgUxmzui1",
    "telegramUserId": 7495509281,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "XcQjWAQJ#VETU0TFF3QPjzt--zNZ8q6sRPX0TQDPk5vV1nn_l0_c"
  },
  {
    "botName": "WILSON99",
    "themeemoji": "🚀",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "NifRL9bwaLZhBIjv",
    "telegramUserId": 7493329475,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "eARwEYDR#JVRX6tu3TOr1ZB6HT9P0BERquNVjLcgqBFEUPYHzbko"
  },
  {
    "botName": "Don",
    "themeemoji": "⚙️",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "FRRtbZWUMMrZ3ybl",
    "telegramUserId": 8105030287,
    "expiryTimestamp": 1753869068620,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "7Z5zXRgb#lxLXzlQLBYPUF9aw_b1gsYtvdmJ-4sTlbASEBIpwSdk"
  },
  {
    "botName": "*ꜱɢ ꜰᴏʀᴛᴜɴᴇ 神*",
    "themeemoji": "💎",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "uOSwqaDBkciEETaF",
    "telegramUserId": 7550438586,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "KEpiHQwR#WjUCJPgVqbC06CWPT7Snx4AxGs5ivkMrYkwLtMC5QvA"
  },
  {
    "botName": "$HÄK€$🖤",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "rxxxUdjLhYWLhk1s",
    "telegramUserId": 6339309206,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "vFhHEBZQ#BMeP8XOYt3UptmpeX9dljXNPXrNLZ7uu5UdsAxgHefc"
  },
  {
    "botName": "LEO AUTOMATING",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "FTCPAqiNO0YUc5D1",
    "telegramUserId": 7741541162,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "mY4m3b7L#L5aApIbtoyePdxvEkLhtnF-SN1L36mNiZw2oHVRvEcU"
  },
  {
    "botName": "P3tr",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "imEjYKJEkgoOKdmR",
    "telegramUserId": 8305013620,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "CUxBXJzQ#86uEwsF3hNMJr5fkmgDVnJLjXSItPzhwZFC5kpuKkIc"
  },
  {
    "botName": "WEC",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "lV7rYXrJv5qdBMA2",
    "telegramUserId": 1114526988,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "aARWxSbK#KwPMS6ZhBVfY_Yzb9Vuagq-wdv-QWbb1SD7-RYnFU90"
  },
  {
    "botName": "𝗟𝝨𝝝 𝝙𝗨𝝩𝝝𝝮𝝙𝝩𝝝𝝥 🔥",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "PFECviiY7yw2t02d",
    "telegramUserId": 7311911583,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "3VA0wAyC#8zouw7LrdPJch6aa0bTzoG6xWgKz_RIw8XKAsOfKFLA"
  },
  {
    "botName": "Joker 1 95",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "FbfAPo5UcZ0Iyiyn",
    "telegramUserId": 6817161756,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "uMolwS7A#sF0NLTaC4YQ5p1K3DL07GYPZqUbSxqi041oFyOqigV8"
  },
  {
    "botName": "Joker 2 51",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "JNm14SnK3sYlk6JS",
    "telegramUserId": 7358203263,
    "expiryTimestamp": null,
    "createdAt": "2025-08-17T18:13:35.686Z",
    "SESSION_ID": "DQRGBTJA#9z2mLjZBlPe6Ia_LljpBfIL0_x0rBnzLXe3PKmaELlw"
  }
];
exports.userStates = {
  "1208243019": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9603
  },
  "1691883937": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7949
  },
  "1974108270": {
    "step": "awaiting_session_id",
    "authKey": "7MgMCN9SUwNJSUA1",
    "promptMessageId": 9067
  },
  "1984959557": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3602
  },
  "2046598405": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8170
  },
  "8135871264": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7828
  },
  "6834525619": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7904
  },
  "6178610094": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8106
  },
  "6582804562": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8122
  },
  "7179979536": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "lastRestart": 1753722572914,
    "promptMessageId": 8165
  },
  "7569969378": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8197
  },
  "5603889826": {
    "step": "awaiting_session_id",
    "authKey": "lNNXjvoQoMHUEFMz",
    "promptMessageId": 8265
  },
  "5613886154": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8335
  },
  "8454766080": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8372
  },
  "6318304090": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8454
  },
  "7698997438": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7584
  },
  "7561987171": {
    "step": "awaiting_session_id",
    "authKey": "JNm14SnK3sYlk6JS",
    "promptMessageId": 11281
  },
  "7262422290": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8504
  },
  "6952558480": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8547
  },
  "7417554225": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8706
  },
  "7705270175": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8039
  },
  "6533592280": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7348
  },
  "7489934782": {
    "step": "awaiting_session_id",
    "authKey": "jNIabtkeCERNjf6f",
    "promptMessageId": 8922
  },
  "7651849479": {
    "step": "awaiting_session_id",
    "authKey": "h9xCz2VdscUlRWt4",
    "promptMessageId": 8942
  },
  "6446529359": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9117
  },
  "7995698204": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9319
  },
  "8230335047": {
    "step": "awaiting_session_id",
    "authKey": "TKfoNBe71Z3OnTJY",
    "promptMessageId": 9332
  },
  "7543401844": {
    "step": "awaiting_session_id",
    "authKey": "TKfoNBe71Z3OnTJY",
    "promptMessageId": 9330
  },
  "7640425412": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9374
  },
  "6936711750": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9422
  },
  "7210517032": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9518
  },
  "5920552777": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9520
  },
  "7567588756": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9545
  },
  "7705529700": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9573
  },
  "5445162970": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9578
  },
  "6468630089": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9584
  },
  "7405226005": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9599
  },
  "5032528012": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9607
  },
  "6743991616": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9617
  },
  "7490089479": {
    "step": "awaiting_auth_key",
    "promptMessageId": 6790
  },
  "6914462600": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9660
  },
  "7467159978": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9297
  },
  "7169588332": {
    "step": "awaiting_auth_key",
    "promptMessageId": 5879
  },
  "7821198502": {
    "step": "awaiting_stop_auth_key",
    "promptMessageId": 11106
  },
  "6777244790": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9822
  },
  "7880561946": {
    "step": "awaiting_auth_key",
    "promptMessageId": 10631
  },
  "8389072721": {
    "step": "awaiting_auth_key",
    "promptMessageId": 10857
  },
  "6127139212": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11088
  },
  "6505939301": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11091
  },
  "7270537170": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11094
  },
  "6661104825": {
    "step": "awaiting_session_id",
    "authKey": "FbfAPo5UcZ0Iyiyn",
    "promptMessageId": 11189
  },
  "6072756403": {
    "step": "awaiting_session_id",
    "authKey": "lV7rYXrJv5qdBMA2",
    "promptMessageId": 11228
  },
  "7358203263": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11316
  },
  "7187358479": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11318
  },
  "7664278052": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11396
  },
  "7738315673": {
    "step": null
  },
  "7685257379": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11571
  },
  "7493329475": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11596
  },
  "8305013620": {
    "step": "awaiting_auth_key",
    "promptMessageId": 11610
  }
};
exports.blacklistedUsers = [];