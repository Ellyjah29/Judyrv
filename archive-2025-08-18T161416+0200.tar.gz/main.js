const settings = require('./settings');
require('dotenv').config();
const { isBanned } = require('./lib/isBanned');
const yts = require('yt-search');
const { fetchBuffer } = require('./lib/myfunc');
const fs = require('fs');
const fetch = require('node-fetch');
const ytdl = require('ytdl-core');
const path = require('path');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const { addWelcome, delWelcome, isWelcomeOn, addGoodbye, delGoodBye, isGoodByeOn } = require('./lib/index');
const { isOwner } = require('./lib/isOwner');

// Command imports
const livescoreCommand = require('./commands/livescore');
const { mathGameCommand, mathAnswerHandler } = require('./commands/mathgame');
const tikTokStalkCommand = require('./commands/tiktokstalk');
const spotifyCommand = require('./commands/spotify');
const threadsCommand = require('./commands/threads');
const toMp3Command = require('./commands/tomp3');
const { saveNote, loadChatHistory, listTopics, summarizeChat } = require('./commands/ai_notes');
const { sendGptQuery } = require('./commands/notesai');
const { setAiMode, getAiMode, handleAiToggle } = require('./commands/ai_toggle');
const { handleAutoStatusReply } = require('./commands/autostatusreply');
const { handleFakeCommand, handleFakeModeCommand, triggerAutoFakePresence } = require('./commands/fake');
const { handleAutoReplyCommand, checkAutoReply, checkPrivateAutoReply } = require('./commands/autoreply');
const { getProfileCommand } = require('./commands/getprofile');
const { ocrCommand } = require('./commands/ocr');
const { bibleCommand } = require('./commands/bible');
const tagAllCommand = require('./commands/tagall');
const { sendRiddle, checkAnswer } = require('./commands/riddle');
const menuCommand = require('./commands/menu');
const helpCommand = require('./commands/help');
const banCommand = require('./commands/ban');
const { shellCommand } = require('./commands/shell');
const muteCommand = require('./commands/mute');
const unmuteCommand = require('./commands/unmute');
const stickerCommand = require('./commands/sticker');
const { uploadCommand } = require('./commands/upload');
const isAdmin = require('./lib/isAdmin');
const { qrCommand } = require('./commands/qr');
const warnCommand = require('./commands/warn');
const warningsCommand = require('./commands/warnings');
const ttsCommand = require('./commands/tts');
const { tictactoeCommand, handleTicTacToeMove } = require('./commands/tictactoe');
const { incrementMessageCount, topMembers } = require('./commands/topmembers');
const ownerCommand = require('./commands/owner');
const deleteCommand = require('./commands/delete');
const { handleAntilinkCommand, handleLinkDetection } = require('./commands/antilink');
const { Antilink } = require('./lib/antilink');
const memeCommand = require('./commands/meme');
const tagCommand = require('./commands/tag');
const jokeCommand = require('./commands/joke');
const { sendQuoteOfDay } = require('./commands/quoteofday');
const { urlShortCommand } = require('./commands/urlshort');
const factCommand = require('./commands/fact');
const weatherCommand = require('./commands/weather');
const newsCommand = require('./commands/news');
const kickCommand = require('./commands/kick');
const simageCommand = require('./commands/simage');
const attpCommand = require('./commands/attp');
const { startHangman, guessLetter } = require('./commands/hangman');
const { startTrivia, answerTrivia } = require('./commands/trivia');
const { complimentCommand } = require('./commands/compliment');
const { insultCommand } = require('./commands/insult');
const { eightBallCommand } = require('./commands/eightball');
const { lyricsCommand } = require('./commands/lyrics');
const { sendDare } = require('./commands/dare');
const { sendTruth } = require('./commands/truth');
const { clearCommand } = require('./commands/clear');
const pingCommand = require('./commands/ping');
const aliveCommand = require('./commands/alive');
const blurCommand = require('./commands/img-blur');
const welcomeCommand = require('./commands/welcome');
const goodbyeCommand = require('./commands/goodbye');
const githubCommand = require('./commands/github');
const { handleAntiBadwordCommand, handleBadwordDetection } = require('./lib/antibadword');
const antibadwordCommand = require('./commands/antibadword');
const { handleChatbotCommand, handleChatbotResponse } = require('./commands/chatbot');
const takeCommand = require('./commands/take');
const { flirtCommand } = require('./commands/flirt');
const characterCommand = require('./commands/character');
const wastedCommand = require('./commands/wasted');
const shipCommand = require('./commands/ship');
const groupInfoCommand = require('./commands/groupinfo');
const resetlinkCommand = require('./commands/resetlink');
const staffCommand = require('./commands/staff');
const unbanCommand = require('./commands/unban');
const emojimixCommand = require('./commands/emojimix');
const viewOnceCommand = require('./commands/viewonce');
const viewOnceCommand2 = require('./commands/viewonce2');
const clearSessionCommand = require('./commands/clearsession');
const { autoStatusCommand, handleStatusUpdate } = require('./commands/autostatus');
const { simpCommand } = require('./commands/simp');
const { stupidCommand } = require('./commands/stupid');
const pairCommand = require('./commands/pair');
const stickerTelegramCommand = require('./commands/stickertelegram');
const textmakerCommand = require('./commands/textmaker');
const { handleAntideleteCommand, handleMessageRevocation, storeMessage } = require('./commands/antidelete');
const clearTmpCommand = require('./commands/cleartmp');
const setProfilePicture = require('./commands/setpp');
const instagramCommand = require('./commands/instagram');
const facebookCommand = require('./commands/facebook');
const playCommand = require('./commands/play');
const tiktokCommand = require('./commands/tiktok');
const songCommand = require('./commands/song');
const aiCommand = require('./commands/ai');
const { handleTranslateCommand } = require('./commands/translate');
const { handleSsCommand } = require('./commands/ss');
const { addCommandReaction, handleAreactCommand } = require('./lib/reactions');
const { goodnightCommand } = require('./commands/goodnight');
const { shayariCommand } = require('./commands/shayari');
const { rosedayCommand } = require('./commands/roseday');
const imagineCommand = require('./commands/imagine');
const videoCommand = require('./commands/video');
const videoCommand2 = require('./commands/video2');

// Global settings
global.packname = settings.packname;
global.author = settings.author;
global.channelLink = ""; 
global.ytch = "SEPTORCH";

// Channel info for forwarding
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH_BOT MD',
            serverMessageId: -1
        }
    }
};

// Function to get bot-specific data path
function getBotDataPath(botId, filename) {
    if (!botId || typeof botId !== 'string') {
        throw new Error(`Invalid botId: ${botId}. Expected string.`);
    }
    const dataDir = path.join(__dirname, 'data', botId);
    try {
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
    } catch (err) {
        console.error(`❌ Failed to create directory: ${dataDir}`, err);
        return null;
    }

    const filePath = path.join(dataDir, filename);

    // Initialize default data if file doesn't exist
    const defaults = {
        'messageCount.json': JSON.stringify({ isPublic: true, messages: {} }, null, 2),
        'banned.json': JSON.stringify([], null, 2),
        'warnings.json': JSON.stringify({}, null, 2),
        'userGroupData.json': JSON.stringify({ welcome: {}, goodbye: {} }, null, 2),
        'owner.json': JSON.stringify([], null, 2),
        'premium.json': JSON.stringify([], null, 2)
    };

    if (!fs.existsSync(filePath) && defaults[filename]) {
        try {
            fs.writeFileSync(filePath, defaults[filename]);
        } catch (err) {
            console.error(`❌ Failed to write default file: ${filePath}`, err);
            return null;
        }
    }

    return filePath;
}

async function handleMessages(sock, messageUpdate, printLog, botId) {
    try {
        const { messages, type } = messageUpdate;
        if (type !== 'notify') return;
        const message = messages[0];
        if (!message?.message) return;
        await handleAutoStatusReply(sock, message, botId);

        // Store message for antidelete feature
        await storeMessage(message, botId);

        // Handle message revocation
        if (message.message?.protocolMessage?.type === 0) {
            await handleMessageRevocation(sock, message, botId);
            return;
        }

        const chatId = message.key.remoteJid;
        const senderId = message.key.participant || message.key.remoteJid;

        // Identify chat type
        const isGroup = chatId.endsWith('@g.us');
        const isChannel = chatId.endsWith('@newsletter');
        const isPrivate = chatId.endsWith('@s.whatsapp.net');
        const isBroadcast = chatId === 'status@broadcast';
		
        // Specific group restriction
const restrictedGroupId = '120363302678069315@g.us';
if (chatId === restrictedGroupId) {
    const adminStatus = await isAdmin(sock, chatId, senderId, botId);
    const isOwner = message.key.fromMe;

    // Even the owner must be an admin in this group
    if (!adminStatus.isSenderAdmin && !isOwner) {
        return; // Non-admins cannot use the bot
    }

    // Optional: Prevent owner from using commands if not an admin
    if (isOwner && !adminStatus.isSenderAdmin) {
        return; // Owner is not admin, don't allow command
    }
}
        
        // Skip ephemeral messages
        if (message.key.id.startsWith('BAE5') && message.key.id.length === 16) return;
		
// Skip ephemeral messages
if (message.key.id.startsWith('BAE5') && message.key.id.length === 16) return;

// ✅ Correct userMessage extraction (now with button support)
let userMessage = '';
if (message.message?.buttonsResponseMessage?.selectedButtonId) {
    userMessage = message.message.buttonsResponseMessage.selectedButtonId.trim().toLowerCase();
} else if (message.message?.conversation) {
    userMessage = message.message.conversation.trim().toLowerCase();
} else if (message.message?.extendedTextMessage?.text) {
    userMessage = message.message.extendedTextMessage.text.trim().toLowerCase();
}

// Save to AI Notes
if (!message.key.fromMe && userMessage.trim()) {
    await saveNote(sock, chatId, senderId, userMessage, botId);
}

// Normalize dots and spacing
userMessage = userMessage.replace(/\.\s+/g, '.').trim();

// Handle math input
await mathAnswerHandler(sock, chatId, message, userMessage, botId);

// Raw message (unprocessed) – optional use
const rawText = message.message?.conversation?.trim() ||
                message.message?.extendedTextMessage?.text?.trim() ||
                message.message?.buttonsResponseMessage?.selectedButtonId?.trim() || '';

        // Only log command usage
        if (userMessage.startsWith('.')) {
            console.log(`📝 Command used in ${isGroup ? 'group' : isChannel ? 'channel' : isPrivate ? 'private' : 'broadcast'}: ${userMessage}`);
        }

        // Check if user is banned (skip ban check for .unban)
        if (isBanned(senderId, botId) && !userMessage.startsWith('.unban')) {
            if (Math.random() < 0.1) {
                await sock.sendMessage(chatId, {
                    text: '❌ You are banned from using the bot. Contact an admin to get unbanned.',
                    ...channelInfo
                });
            }
            return;
        }

        // First check if it's a game move
        if (/^[1-9]$/.test(userMessage) || userMessage.toLowerCase() === 'surrender') {
            await handleTicTacToeMove(sock, chatId, senderId, userMessage, botId);
            return;
        }

if (!message.key.fromMe) incrementMessageCount(chatId, senderId, botId);

// Check for bad words FIRST
if ((isGroup || isChannel) && userMessage) {
    await handleBadwordDetection(sock, chatId, message, userMessage, senderId, botId);
}

        // Auto Reply in Private Chat
if (isPrivate && !userMessage.startsWith('.') && userMessage.trim() !== '') {
    const replied = await checkPrivateAutoReply(sock, chatId, message, userMessage, botId);
    if (replied) return;
}
        
        // Auto fake presence (typing/recording/etc)
await triggerAutoFakePresence(sock, chatId, botId);

        // Auto Reply in Groups/Channels
if ((isGroup || isChannel) && !userMessage.startsWith('.') && userMessage.trim() !== '') {
    const replied = await checkAutoReply(sock, chatId, message, userMessage, botId);
    if (replied) return;
}
        
// Then check for command prefix
if (!userMessage.startsWith('.')) {
    if (isGroup || isChannel) {
        await handleChatbotResponse(sock, chatId, message, userMessage, senderId, botId);
        await Antilink(message, sock, botId);
        await handleBadwordDetection(sock, chatId, message, userMessage, senderId, botId);
    }
    return;
}
        // List of admin & owner commands
        const adminCommands = ['.mute', '.unmute', '.ban', '.unban', '.promote', '.demote', '.kick', '.tagall', '.antilink'];
        const ownerCommands = ['.mode', '.autostatus', '.antidelete', '.cleartmp', '.setpp', '.clearsession', '.areact', '.autoreact'];

        const isAdminCommand = adminCommands.some(cmd => userMessage.startsWith(cmd));
        const isOwnerCommand = ownerCommands.some(cmd => userMessage.startsWith(cmd));

        let isSenderAdmin = false;
        let isBotAdmin = false;

        // Check admin status only for admin commands in groups or channels
        if ((isGroup || isChannel) && isAdminCommand) {
            const adminStatus = await isAdmin(sock, chatId, senderId, botId);
            isSenderAdmin = adminStatus.isSenderAdmin;
            isBotAdmin = adminStatus.isBotAdmin;
            if (!isBotAdmin) {
                await sock.sendMessage(chatId, { text: 'Please make the bot an admin to use admin commands.', ...channelInfo });
                return;
            }
            if (
                userMessage.startsWith('.mute') ||
                userMessage === '.unmute' ||
                userMessage.startsWith('.ban') ||
                userMessage.startsWith('.unban') ||
                userMessage.startsWith('.promote') ||
                userMessage.startsWith('.demote')
            ) {
                if (!isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, {
                        text: 'Sorry, only admins can use this command.',
                        ...channelInfo
                    });
                    return;
                }
            }
        }

        // Check owner status for owner commands
        if (isOwnerCommand) {
            if (!message.key.fromMe && !isOwner(senderId, botId)) {                await sock.sendMessage(chatId, {
                    text: '❌ This command is only available for the owner!',
                    ...channelInfo
                });
                return;
            }
        }

        // Access mode check
        try {
            const modePath = getBotDataPath(botId, 'messageCount.json');
            const data = JSON.parse(fs.readFileSync(modePath));
            if (!data.isPublic && !message.key.fromMe) {
                return; // Silently ignore non-owner in private mode
            }
        } catch (error) {
            console.error('Error checking access mode:', error);
        }

        // Command Handlers
        switch (true) {
            case userMessage === '.simage': {
                const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                if (quotedMessage?.stickerMessage) {
                    await simageCommand(sock, quotedMessage, chatId, botId);
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'Please reply to a sticker with the .simage command to convert it.',
                        ...channelInfo
                    });
                }
                break;
            }
            case userMessage.startsWith('.kick'):
                const mentionedJidListKick = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await kickCommand(sock, chatId, senderId, mentionedJidListKick, message, botId);
                break;
            case userMessage === '.setpp':
    			await setProfilePicture(sock, chatId, message, botId);
    			break;
            case userMessage.startsWith('.mute'):
                const muteDuration = parseInt(userMessage.split(' ')[1]);
                if (isNaN(muteDuration)) {
                    await sock.sendMessage(chatId, {
                        text: 'Please provide a valid number of minutes.\neg to mute for 10 minutes\n.mute 10',
                        ...channelInfo
                    });
                } else {
                    await muteCommand(sock, chatId, senderId, muteDuration, botId);
                }
                break;
            case userMessage.startsWith('.shell'):
    			if (message.key.fromMe) {
        		await shellCommand(sock, chatId, userMessage, botId);
    			} else {
        		await sock.sendMessage(chatId, {
          		  text: '❌ This command is only available for the owner!',
        			});
   				 }
   			  	break;
            case userMessage.startsWith('.video') || userMessage.startsWith('.ytmp4'):
                await videoCommand(sock, chatId, message);
                break;
             case userMessage.startsWith('.qvideo') || userMessage.startsWith('.yt2mp4'):
                await videoCommand2(sock, chatId, message);
                break;
            case userMessage === '.unmute':
                await unmuteCommand(sock, chatId, senderId, botId);
                break;
            case userMessage.startsWith('.ban'):
                await banCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.unban'):
                await unbanCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.getprofile'):
			case userMessage.startsWith('.profile'):
    			await getProfileCommand(sock, chatId, message, botId);
    			break;
            case userMessage === '.help' || userMessage === '.guide' || userMessage === '.bot' || userMessage === '.list':
                await helpCommand(sock, chatId, global.channelLink, botId);
                break;
            case userMessage.startsWith('.menu'):
    let menuCategory = null;
    let menuPage = 0;

    if (userMessage.startsWith('.🧰 General')) {
        menuCategory = 'general';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+general\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage.startsWith('.menu admin')) {
        menuCategory = 'admin';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+admin\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage.startsWith('.menu ai')) {
        menuCategory = 'ai';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+ai\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage.startsWith('.menu downloads')) {
        menuCategory = 'downloads';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+downloads\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage.startsWith('.menu games')) {
        menuCategory = 'games';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+games\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage.startsWith('.menu stickers')) {
        menuCategory = 'stickers';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+stickers\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage.startsWith('.menu fun')) {
        menuCategory = 'fun';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+fun\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage.startsWith('.menu utility')) {
        menuCategory = 'utility';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+utility\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage.startsWith('.menu owner')) {
        menuCategory = 'owner';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+owner\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage.startsWith('.menu credits')) {
        menuCategory = 'credits';
        menuPage = 0;
        const pageMatch = userMessage.match(/^\.menu\s+credits\s+(\d+)$/);
        if (pageMatch) {
            menuPage = parseInt(pageMatch[1], 10);
        }
    } else if (userMessage === '.menu') {
        menuCategory = null;
        menuPage = 0;
    } else {
        const menuArgs = userMessage.trim().split(/\s+/);
        menuCategory = menuArgs[1] ? menuArgs[1].toLowerCase() : null;
        menuPage = menuArgs[2] !== undefined ? parseInt(menuArgs[2], 10) : 0;
    }

    await menuCommand(sock, chatId, menuCategory, menuPage);
    break;
            case userMessage === '.sticker' || userMessage === '.s':
                await stickerCommand(sock, chatId, message, botId);
                break;
            case userMessage === '.riddle':
    			await sendRiddle(sock, chatId);
    			break;
            case userMessage.startsWith('.warnings'):
                const mentionedJidListWarnings = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await warningsCommand(sock, chatId, mentionedJidListWarnings, botId);
                break;
            case userMessage.startsWith('.warn'):
                const mentionedJidListWarn = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await warnCommand(sock, chatId, senderId, mentionedJidListWarn, message, botId);
                break;
            case userMessage.startsWith('.ocr'):
    			await ocrCommand(sock, chatId, message, botId);
    			break;
            case userMessage.startsWith('.tts'):
                const text = userMessage.slice(4).trim();
                await ttsCommand(sock, chatId, text, botId);
                break;
            case userMessage === '.delete' || userMessage === '.del':
                await deleteCommand(sock, chatId, message, senderId, botId);
                break;
                    case userMessage.startsWith('.tomp3'):
case userMessage.startsWith('.toaudio'):
    await toMp3Command(sock, chatId, message, userMessage, botId);
    break;
                case userMessage.startsWith('.fake'):
    if (!message.key.fromMe && !isOwner(senderId, botId)) {        await sock.sendMessage(chatId, {
            text: '❌ This command is only available for the owner!',
            ...channelInfo
        });
        return;
    }

    const fakeArgs = userMessage.split(' ');
    const fakeType = fakeArgs[1];

    await handleFakeCommand(sock, chatId, fakeType, botId);
    break;
                case userMessage.startsWith('.switchfake'):
    if (!message.key.fromMe && !isOwner(senderId, botId)) {        await sock.sendMessage(chatId, {
            text: '❌ This command is only available for the owner!',
            ...channelInfo
        });
        return;
    }

    const fakemodeArgs = userMessage.split(' ');
    await handleFakeModeCommand(sock, chatId, message, botId);
    break;
           case userMessage.startsWith('.livescore'):
  await livescoreCommand(sock, chatId, message, botId);
  break;
            case userMessage.startsWith('.attp'):
                await attpCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.mode'):
                const modeMatch = userMessage.slice(5).trim().toLowerCase();
                const modePath = getBotDataPath(botId, 'messageCount.json');
                const data = JSON.parse(fs.readFileSync(modePath));
                if (!modeMatch) {
                    const currentMode = data.isPublic ? 'public' : 'private';
                    await sock.sendMessage(chatId, {
                        text: `Current bot mode: *${currentMode}*\nUsage: .mode public/private`,
                        ...channelInfo
                    });
                    return;
                }
                if (modeMatch !== 'public' && modeMatch !== 'private') {
                    await sock.sendMessage(chatId, {
                        text: 'Usage: .mode public/private',
                        ...channelInfo
                    });
                    return;
                }
                data.isPublic = modeMatch === 'public';
                fs.writeFileSync(modePath, JSON.stringify(data, null, 2));
                await sock.sendMessage(chatId, {
                    text: `Bot is now in *${modeMatch}* mode`,
                    ...channelInfo
                });
                break;
            case userMessage.startsWith('.autoreply'):
    // Allow command only if used by owner
    if (!message.key.fromMe && !isOwner(senderId, botId)) {        await sock.sendMessage(chatId, {
            text: '❌ This command is only available for the bot owner!',
            ...channelInfo
        });
        return;
    }

        // Owner can use .autoreply anywhere
    await handleAutoReplyCommand(sock, chatId, message, botId);
    break;
                case userMessage.startsWith('.notes on') || userMessage.startsWith('.notes off'):
    if (!message.key.fromMe && !isOwner(senderId, botId)) {        await sock.sendMessage(chatId, {
            text: '❌ This command is only available for the owner!',
            ...channelInfo
        });
        return;
    }

    const args = userMessage.split(' ');
    await handleAiToggle(sock, chatId, args, botId);
    break;
            case userMessage.startsWith('.qr'):
    			await qrCommand(sock, chatId, userMessage, botId);
    			break;
            case userMessage === '.owner':
                await ownerCommand(sock, chatId, botId);
                break;
            case userMessage === '.tagall':
                const adminStatusTagAll = await isAdmin(sock, chatId, senderId, botId);
                isSenderAdmin = adminStatusTagAll.isSenderAdmin;
                isBotAdmin = adminStatusTagAll.isBotAdmin;
                if (isSenderAdmin || message.key.fromMe) {
                    await tagAllCommand(sock, chatId, senderId, botId);
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'Sorry, only admins can use the .tagall command.',
                        ...channelInfo
                    });
                }
                break;
            case userMessage.startsWith('.hidetag'):    
            case userMessage.startsWith('.tag'):
            case userMessage.startsWith('.🔊'):
                const messageText = rawText.slice(4).trim();
                const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
                await tagCommand(sock, chatId, senderId, messageText, replyMessage, botId);
                break;
            case userMessage.startsWith('.antilink'):
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                    return;
                }
                const linkAdminStatus = await isAdmin(sock, chatId, senderId, botId);
                isBotAdmin = linkAdminStatus.isBotAdmin;
                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, {
                        text: 'Please make the bot an admin first.',
                        ...channelInfo
                    });
                    return;
                }
                await handleAntilinkCommand(sock, chatId, userMessage, senderId, linkAdminStatus.isSenderAdmin, botId);
                break;
           case userMessage.startsWith('.short'):
				case userMessage.startsWith('.urlshort'):
   			 await urlShortCommand(sock, chatId, userMessage, botId);
    			break;
            case userMessage.startsWith('.upload'):
    			await uploadCommand(sock, chatId, message, botId);
    			break;
                case userMessage.startsWith('.ttstalk'):
case userMessage.startsWith('.tiktokstalk'):
case userMessage.startsWith('.tiktoksearch'):
case userMessage.startsWith('.tsearch'):
    await tikTokStalkCommand(sock, chatId, message, userMessage, botId);
    break;
            case userMessage === '.meme':
                await memeCommand(sock, chatId, botId);
                break;
            case userMessage === '.joke':
                await jokeCommand(sock, chatId, botId);
                break;
            case userMessage === '.quote':
    			await sendQuoteOfDay(sock, chatId, senderId);
    			break;
            case userMessage === '.fact':
                await factCommand(sock, chatId, botId);
                break;
                case userMessage.startsWith('.acertijo'):
case userMessage.startsWith('.acert'):
case userMessage.startsWith('.pelicula'):
case userMessage.startsWith('.adv'):
    await gameCommand(sock, chatId, message, userMessage, botId);
    break;
          case userMessage.startsWith('.notes'):
    if (!(isGroup || isPrivate || isChannel)) {
        await sock.sendMessage(chatId, {
            text: '❌ This command can only be used in groups, channels, or private chats!',
            ...channelInfo
        });
        return;
    }

    const prompt = userMessage.slice(5).trim(); // ".notes" is 5 characters

    if (!prompt) {
        await sock.sendMessage(chatId, {
            text: "Usage: .notes [your question]",
            ...channelInfo
        });
        return;
    }

    if (!getAiMode(botId)) {
        await sock.sendMessage(chatId, {
            text: "❌ Notes AI is currently OFF. Use .notes on to enable.",
            ...channelInfo
        });
        return;
    }

    await sendGptQuery(sock, chatId, prompt, botId);
    break;
            case userMessage.startsWith('.weather'):
                const city = userMessage.slice(9).trim();
                if (city) {
                    await weatherCommand(sock, chatId, city, botId);
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'Please specify a city, e.g., .weather London',
                        ...channelInfo
                    });
                }
                break;
                case userMessage.startsWith('.thread'):
case userMessage.startsWith('.threads'):
case userMessage.startsWith('.threaddl'):
    await threadsCommand(sock, chatId, message, userMessage, botId);
    break;
            case userMessage === '.news':
                await newsCommand(sock, chatId, botId);
                break;
            case userMessage.startsWith('.ttt') || userMessage.startsWith('.tictactoe'):
                const tttText = userMessage.split(' ').slice(1).join(' ');
                await tictactoeCommand(sock, chatId, senderId, tttText, botId);
                break;
            case userMessage.startsWith('.move'):
                const position = parseInt(userMessage.split(' ')[1]);
                if (isNaN(position)) {
                    await sock.sendMessage(chatId, {
                        text: 'Please provide a valid position number for Tic-Tac-Toe move.',
                        ...channelInfo
                    });
                } else {
                    await handleTicTacToeMove(sock, chatId, senderId, position, botId);
                }
                break;
                case userMessage.startsWith('.math'):
case userMessage.startsWith('.mates'):
case userMessage.startsWith('.matemáticas'):
    await mathGameCommand(sock, chatId, message, userMessage, botId);
    break;
                case userMessage === '.summary':
    if (!message.key.fromMe && !isOwner(senderId, botId)) {        await sock.sendMessage(chatId, {
            text: '❌ This command is only available for the owner!',
            ...channelInfo
        });
        return;
    }
    await summarizeChat(sock, chatId, botId);
    break;
            case userMessage === '.topmembers':
                await topMembers(sock, chatId, isGroup || isChannel, botId);
                break;
            case userMessage.startsWith('.hangman'):
                await startHangman(sock, chatId, botId);
                break;
            case userMessage.startsWith('.guess'):
                const guessedLetter = userMessage.split(' ')[1];
                if (guessedLetter) {
                    await guessLetter(sock, chatId, guessedLetter, botId);
                } else {
                    sock.sendMessage(chatId, {
                        text: 'Please guess a letter using .guess <letter>',
                        ...channelInfo
                    });
                }
                break;
                case userMessage === '.topics':
    if (!message.key.fromMe && !isOwner(senderId, botId)) {        await sock.sendMessage(chatId, {
            text: '❌ This command is only available for the owner!',
            ...channelInfo
        });
        return;
    }
    await listTopics(sock, chatId, botId);
    break;
            case userMessage.startsWith('.trivia'):
                await startTrivia(sock, chatId, botId);
                break;
            case userMessage.startsWith('.answer'):
                const answer = userMessage.split(' ').slice(1).join(' ');
                if (answer) {
                    await answerTrivia(sock, chatId, answer, botId);
                } else {
                    sock.sendMessage(chatId, {
                        text: 'Please provide an answer using .answer <answer>',
                        ...channelInfo
                    });
                }
                break;
            case userMessage.startsWith('.compliment'):
                await complimentCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.insult'):
                await insultCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.8ball'):
                const question = userMessage.split(' ').slice(1).join(' ');
                await eightBallCommand(sock, chatId, question, botId);
                break;
            case userMessage.startsWith('.lyrics'):
                const songTitle = userMessage.split(' ').slice(1).join(' ');
                await lyricsCommand(sock, chatId, songTitle, botId);
                break;
            case userMessage.startsWith('.simp'):
                const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await simpCommand(sock, chatId, quotedMsg, mentionedJid, senderId, botId);
                break;
            case userMessage.startsWith('.stupid') || userMessage.startsWith('.itssostupid') || userMessage.startsWith('.iss'):
                const stupidQuotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                const stupidMentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                const stupidArgs = userMessage.split(' ').slice(1);
                await stupidCommand(sock, chatId, stupidQuotedMsg, stupidMentionedJid, senderId, stupidArgs, botId);
                break;
            case userMessage === '.dare':
    			await sendDare(sock, chatId, senderId);
    			break;
            case userMessage === '.truth':
			    await sendTruth(sock, chatId, senderId);
    			break;
            case userMessage === '.clear':
                if (isGroup || isChannel) await clearCommand(sock, chatId, botId);
                break;
            case userMessage.startsWith('.promote'):
                const mentionedJidListPromote = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await promoteCommand(sock, chatId, mentionedJidListPromote, message, botId);
                break;
            case userMessage.startsWith('.demote'):
                const mentionedJidListDemote = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await demoteCommand(sock, chatId, mentionedJidListDemote, message, botId);
                break;
            case userMessage === '.ping':
                await pingCommand(sock, chatId, botId);
                break;
            case userMessage === '.alive':
                await aliveCommand(sock, chatId, botId);
                break;
            case userMessage.startsWith('.blur'):
                const quotedMessageBlur = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                await blurCommand(sock, chatId, message, quotedMessageBlur, botId);
                break;
            case userMessage.startsWith('.welcome'):
                if (isGroup || isChannel) {
                    const adminStatus = await isAdmin(sock, chatId, senderId, botId);
                    const isSenderAdmin = adminStatus.isSenderAdmin;
                    if (isSenderAdmin || message.key.fromMe) {
                        await welcomeCommand(sock, chatId, message, botId);
                    } else {
                        await sock.sendMessage(chatId, {
                            text: 'Sorry, only admins can use this command.',
                            ...channelInfo
                        });
                    }
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                }
                break;
            case userMessage.startsWith('.goodbye'):
                if (isGroup || isChannel) {
                    const adminStatus = await isAdmin(sock, chatId, senderId, botId);
                    const isSenderAdmin = adminStatus.isSenderAdmin;
                    if (isSenderAdmin || message.key.fromMe) {
                        await goodbyeCommand(sock, chatId, message, botId);
                    } else {
                        await sock.sendMessage(chatId, {
                            text: 'Sorry, only admins can use this command.',
                            ...channelInfo
                        });
                    }
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                }
                break;
            case userMessage === '.git' || userMessage === '.github' || userMessage === '.sc' || userMessage === '.script' || userMessage === '.repo':
                await githubCommand(sock, chatId, botId);
                break;
            case userMessage.startsWith('.antibadword'):
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                    return;
                }
                const abAdminStatus = await isAdmin(sock, chatId, senderId, botId);
                if (!abAdminStatus.isBotAdmin) {
                    await sock.sendMessage(chatId, {
                        text: '*Bot must be admin to use this feature*',
                        ...channelInfo
                    });
                    return;
                }
                await antibadwordCommand(sock, chatId, message, senderId, abAdminStatus.isSenderAdmin, botId);
                break;
            case userMessage.startsWith('.chatbot'):
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                    return;
                }
                const chatbotAdminStatus = await isAdmin(sock, chatId, senderId, botId);
                if (!chatbotAdminStatus.isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, {
                        text: '*Only admins or bot owner can use this command*',
                        ...channelInfo
                    });
                    return;
                }
                const match = userMessage.slice(8).trim();
                await handleChatbotCommand(sock, chatId, message, match, botId);
                break;
            case userMessage.startsWith('.take'):
                const takeArgs = userMessage.slice(5).trim().split(' ');
                await takeCommand(sock, chatId, message, takeArgs, botId);
                break;
            case userMessage === '.flirt':
                await flirtCommand(sock, chatId, botId);
                break;
            case userMessage.startsWith('.character'):
                await characterCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.waste'):
                await wastedCommand(sock, chatId, message, botId);
                break;
            case userMessage === '.ship':
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels!',
                        ...channelInfo
                    });
                    return;
                }
                await shipCommand(sock, chatId, message, botId);
                break;
            case userMessage === '.groupinfo' || userMessage === '.infogp' || userMessage === '.infogrupo':
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels!',
                        ...channelInfo
                    });
                    return;
                }
                await groupInfoCommand(sock, chatId, message, botId);
                break;
            case userMessage === '.resetlink' || userMessage === '.revoke' || userMessage === '.anularlink':
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels!',
                        ...channelInfo
                    });
                    return;
                }
                await resetlinkCommand(sock, chatId, senderId, botId);
                break;
            case userMessage === '.staff' || userMessage === '.admins' || userMessage === '.listadmin':
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels!',
                        ...channelInfo
                    });
                    return;
                }
                await staffCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.emojimix') || userMessage.startsWith('.emix'):
                await emojimixCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.tg') || userMessage.startsWith('.stickertelegram') || userMessage.startsWith('.tgsticker') || userMessage.startsWith('.telesticker'):
                await stickerTelegramCommand(sock, chatId, message, botId);
                break;
            case userMessage === '.vv':
                await viewOnceCommand(sock, chatId, message, botId);
                break;
            case userMessage === '.vv2':
            case userMessage === '.🫣':
                await viewOnceCommand2(sock, chatId, message, botId);
                break;
            case userMessage === '.clearsession' || userMessage === '.clearsesi':
                await clearSessionCommand(sock, chatId, message, botId);
                break;
           case userMessage.startsWith('.bible'):
    			await bibleCommand(sock, chatId, userMessage, botId);
    			break;
             case userMessage.startsWith('.forcesurrender'):
    await forceSurrenderCommand(sock, chatId, message);
    break;
            case userMessage.startsWith('.autostatus'):
                const autoStatusArgs = userMessage.split(' ').slice(1);
                await autoStatusCommand(sock, chatId, message, autoStatusArgs, botId);
                break;
            case userMessage.startsWith('.pair') || userMessage.startsWith('.rent'): {
                const q = userMessage.split(' ').slice(1).join(' ');
                await pairCommand(sock, chatId, message, q, botId);
                break;
            }
            case userMessage.startsWith('.metallic'):
                await textmakerCommand(sock, chatId, message, userMessage, 'metallic', botId);
                break;
            case userMessage.startsWith('.ice'):
                await textmakerCommand(sock, chatId, message, userMessage, 'ice', botId);
                break;
            case userMessage.startsWith('.snow'):
                await textmakerCommand(sock, chatId, message, userMessage, 'snow', botId);
                break;
            case userMessage.startsWith('.impressive'):
                await textmakerCommand(sock, chatId, message, userMessage, 'impressive', botId);
                break;
            case userMessage.startsWith('.matrix'):
                await textmakerCommand(sock, chatId, message, userMessage, 'matrix', botId);
                break;
            case userMessage.startsWith('.light'):
                await textmakerCommand(sock, chatId, message, userMessage, 'light', botId);
                break;
            case userMessage.startsWith('.neon'):
                await textmakerCommand(sock, chatId, message, userMessage, 'neon', botId);
                break;
            case userMessage.startsWith('.devil'):
                await textmakerCommand(sock, chatId, message, userMessage, 'devil', botId);
                break;
            case userMessage.startsWith('.purple'):
                await textmakerCommand(sock, chatId, message, userMessage, 'purple', botId);
                break;
            case userMessage.startsWith('.thunder'):
                await textmakerCommand(sock, chatId, message, userMessage, 'thunder', botId);
                break;
            case userMessage.startsWith('.leaves'):
                await textmakerCommand(sock, chatId, message, userMessage, 'leaves', botId);
                break;
            case userMessage.startsWith('.1917'):
                await textmakerCommand(sock, chatId, message, userMessage, '1917', botId);
                break;
            case userMessage.startsWith('.arena'):
                await textmakerCommand(sock, chatId, message, userMessage, 'arena', botId);
                break;
            case userMessage.startsWith('.hacker'):
                await textmakerCommand(sock, chatId, message, userMessage, 'hacker', botId);
                break;
            case userMessage.startsWith('.sand'):
                await textmakerCommand(sock, chatId, message, userMessage, 'sand', botId);
                break;
            case userMessage.startsWith('.blackpink'):
                await textmakerCommand(sock, chatId, message, userMessage, 'blackpink', botId);
                break;
            case userMessage.startsWith('.glitch'):
                await textmakerCommand(sock, chatId, message, userMessage, 'glitch', botId);
                break;
            case userMessage.startsWith('.fire'):
                await textmakerCommand(sock, chatId, message, userMessage, 'fire', botId);
                break;
            case userMessage.startsWith('.antidelete'):
                const antideleteMatch = userMessage.slice(11).trim();
                await handleAntideleteCommand(sock, chatId, message, antideleteMatch, botId);
                break;
            case userMessage === '.surrender':
                await handleTicTacToeMove(sock, chatId, senderId, 'surrender', botId);
                break;
            case userMessage === '.cleartmp':
                await clearTmpCommand(sock, chatId, message, botId);
                break;
            case userMessage === '.setpp':
                await setProfilePicture(sock, chatId, message, botId);
                break;
                case userMessage.startsWith('.spotify'):
case userMessage.startsWith('.music'):
    await spotifyCommand(sock, chatId, message, userMessage, botId);
    break;
            case userMessage.startsWith('.instagram') || userMessage.startsWith('.insta') || userMessage.startsWith('.ig'):
                await instagramCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.fb') || userMessage.startsWith('.facebook'):
                await facebookCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.song') || userMessage.startsWith('.music'):
                await playCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.play') || userMessage.startsWith('.mp3') || userMessage.startsWith('.ytmp3') || userMessage.startsWith('.yts'):
                await songCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.tiktok') || userMessage.startsWith('.tt'):
                await tiktokCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.gpt') || userMessage.startsWith('.gemini'):
                await aiCommand(sock, chatId, message, botId);
                break;
            case userMessage.startsWith('.translate') || userMessage.startsWith('.trt'):
                const commandLength = userMessage.startsWith('.translate') ? 10 : 4;
                await handleTranslateCommand(sock, chatId, message, userMessage.slice(commandLength), botId);
                break;
            case userMessage.startsWith('.ss') || userMessage.startsWith('.ssweb') || userMessage.startsWith('.screenshot'):
                const ssCommandLength = userMessage.startsWith('.screenshot') ? 11 : userMessage.startsWith('.ssweb') ? 6 : 3;
                await handleSsCommand(sock, chatId, message, userMessage.slice(ssCommandLength).trim(), botId);
                break;
            case userMessage.startsWith('.areact') || userMessage.startsWith('.autoreact') || userMessage.startsWith('.autoreaction'):
                const isOwner = message.key.fromMe;
                await handleAreactCommand(sock, chatId, message, isOwner, botId);
                break;
            case userMessage === '.goodnight' || userMessage === '.lovenight' || userMessage === '.gn':
                await goodnightCommand(sock, chatId, botId);
                break;
            case userMessage === '.shayari' || userMessage === '.shayri':
                await shayariCommand(sock, chatId, botId);
                break;
            case userMessage === '.roseday':
                await rosedayCommand(sock, chatId, botId);
                break;
            case userMessage.startsWith('.imagine') || userMessage.startsWith('.flux') || userMessage.startsWith('.dalle'):
                await imagineCommand(sock, chatId, message, botId);
                break;
            default:
                // Check if user is answering a riddle
    		await checkAnswer(sock, chatId, userMessage, senderId);
                if (isGroup || isChannel) {
                    if (userMessage) {
                        await handleChatbotResponse(sock, chatId, message, userMessage, senderId, botId);
                    }
                    await Antilink(message, sock, botId);
                    await handleBadwordDetection(sock, chatId, message, userMessage, senderId, botId);
                }
                break;
                
        }

        if (userMessage.startsWith('.')) {
            await addCommandReaction(sock, message, botId);
        }

    } catch (error) {
        console.error(`❌ Error in message handler for bot ${botId}:`, error.message);
        const chatId = message.key.remoteJid;
        if (chatId) {
            await sock.sendMessage(chatId, {
                text: '❌ Failed to process command!',
                ...channelInfo
            });
        }
    }
}

async function handleGroupParticipantUpdate(sock, update, botId) {
    try {
        const { id, participants, action, author } = update;
        const isGroup = id.endsWith('@g.us');
        const isChannel = id.endsWith('@newsletter');
        if (!isGroup && !isChannel) return;
        if (action === 'add') {
            const isWelcomeEnabled = await isWelcomeOn(id, botId);
            if (!isWelcomeEnabled) return;
            const userDataPath = getBotDataPath(botId, 'userGroupData.json');
            const data = JSON.parse(fs.readFileSync(userDataPath));
            const welcomeData = data.welcome[id];
            const welcomeMessage = welcomeData?.message || 'Welcome {user} to the group! 🎉';
            for (const participant of participants) {
                const user = participant.split('@')[0];
                const formattedMessage = welcomeMessage.replace('{user}', `@${user}`);
                await sock.sendMessage(id, {
                    text: formattedMessage,
                    mentions: [participant]
                });
            }
        }

        if (action === 'remove') {
            const isGoodbyeEnabled = await isGoodByeOn(id, botId);
            if (!isGoodbyeEnabled) return;
            const userDataPath = getBotDataPath(botId, 'userGroupData.json');
            const data = JSON.parse(fs.readFileSync(userDataPath));
            const goodbyeData = data.goodbye[id];
            const goodbyeMessage = goodbyeData?.message || 'Goodbye {user} 👋';
            for (const participant of participants) {
                const user = participant.split('@')[0];
                const formattedMessage = goodbyeMessage.replace('{user}', `@${user}`);
                await sock.sendMessage(id, {
                    text: formattedMessage,
                    mentions: [participant]
                });
            }
        }

        if (action === 'promote') {
            await handlePromotionEvent(sock, id, participants, author, botId);
        }

        if (action === 'demote') {
            await handleDemotionEvent(sock, id, participants, author, botId);
        }

    } catch (error) {
        console.error(`Error in handleGroupParticipantUpdate for bot ${botId}:`, error);
    }
}

module.exports = {
    handleMessages,
    handleGroupParticipantUpdate,
    handleStatus: async (sock, status, botId) => {
        await handleStatusUpdate(sock, status, botId);
    }
};