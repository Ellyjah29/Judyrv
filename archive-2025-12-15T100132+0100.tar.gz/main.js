const settings = require('./settings');
require('dotenv').config();
const { sendButtons } = require('gifted-btns');
const { isBanned } = require('./lib/isBanned');
const yts = require('yt-search');
const { fetchBuffer } = require('./lib/myfunc');
const fs = require('fs');
const fetch = require('node-fetch');
const ytdl = require('ytdl-core');
const path = require('path');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys'); // ✅ Added for Auto-Ears
const { transcribeAudio } = require('./lib/transcribe-module'); // ✅ Added for Auto-Ears
const { addWelcome, delWelcome, isWelcomeOn, addGoodbye, delGoodBye, isGoodByeOn } = require('./lib/index');
const { isOwner } = require('./lib/isOwner');
const { loadPlugins } = require('./lib/plugins'); 

// Use Nigerian Time (WAT) system-wide
process.env.TZ = 'Africa/Lagos';

// Load plugins immediately when bot starts
loadPlugins();

// Command imports
const {
    scheduleCommand,
    myschedulesCommand,
    unscheduleCommand,
    clearScheduleCommand
} = require('./commands/schedule');
const visionCommand = require('./commands/vision');
const sttCommand = require('./commands/stt');
const imagineCommand = require('./commands/imagine');
const { dmallCommand } = require('./commands/dmall');
const { animeCommand } = require('./commands/anime');
const { sendBotAiQuery } = require('./commands/botAI');
const livescoreCommand = require('./commands/livescore');
const { mathGameCommand, mathAnswerHandler } = require('./commands/mathgame');
const tikTokStalkCommand = require('./commands/tiktokstalk');
const spotifyCommand = require('./commands/spotify');
const threadsCommand = require('./commands/threads');
const toMp3Command = require('./commands/tomp3');
const { saveNote, loadChatHistory, listTopics, summarizeChat } = require('./commands/ai_notes');
const { sendGptQuery } = require('./commands/notesai');
const { setAiMode, getAiMode, handleAiToggle } = require('./commands/ai_toggle');
const { handleAutoStatusReply } = require('./commands/autostatusreply');
const { handleFakeCommand, handleFakeModeCommand, triggerAutoFakePresence } = require('./commands/fake');
const { handleAutoReplyCommand, checkAutoReply, checkPrivateAutoReply } = require('./commands/autoreply');
const { getProfileCommand } = require('./commands/getprofile');
const { ocrCommand } = require('./commands/ocr');
const { bibleCommand } = require('./commands/bible');
const tagAllCommand = require('./commands/tagall');
const { sendRiddle, checkAnswer } = require('./commands/riddle');
const { menuCommand } = require('./commands/menu');
const helpCommand = require('./commands/help');
const banCommand = require('./commands/ban');
const { shellCommand } = require('./commands/shell');
const muteCommand = require('./commands/mute');
const unmuteCommand = require('./commands/unmute');
const stickerCommand = require('./commands/sticker');
const { uploadCommand } = require('./commands/upload');
const isAdmin = require('./lib/isAdmin');
const { qrCommand } = require('./commands/qr');
const warnCommand = require('./commands/warn');
const warningsCommand = require('./commands/warnings');
const ttsCommand = require('./commands/tts');
const { tictactoeCommand, handleTicTacToeMove } = require('./commands/tictactoe');
const { incrementMessageCount, topMembers } = require('./commands/topmembers');
const ownerCommand = require('./commands/owner');
const deleteCommand = require('./commands/delete');
const { handleAntilinkCommand, handleLinkDetection } = require('./commands/antilink');
const { Antilink } = require('./lib/antilink');
const memeCommand = require('./commands/meme');
const tagCommand = require('./commands/tag');
const jokeCommand = require('./commands/joke');
const { sendQuoteOfDay } = require('./commands/quoteofday');
const { urlShortCommand } = require('./commands/urlshort');
const factCommand = require('./commands/fact');
const weatherCommand = require('./commands/weather');
const newsCommand = require('./commands/news');
const kickCommand = require('./commands/kick');
const simageCommand = require('./commands/simage');
const attpCommand = require('./commands/attp');
const { startHangman, guessLetter } = require('./commands/hangman');
const { startTrivia, answerTrivia } = require('./commands/trivia');
const { complimentCommand } = require('./commands/compliment');
const { insultCommand } = require('./commands/insult');
const { eightBallCommand } = require('./commands/eightball');
const { lyricsCommand } = require('./commands/lyrics');
const { sendDare } = require('./commands/dare');
const { sendTruth } = require('./commands/truth');
const { clearCommand } = require('./commands/clear');
const pingCommand = require('./commands/ping');
const aliveCommand = require('./commands/alive');
const blurCommand = require('./commands/img-blur');
const welcomeCommand = require('./commands/welcome');
const goodbyeCommand = require('./commands/goodbye');
const githubCommand = require('./commands/github');
const { handleAntiBadwordCommand, handleBadwordDetection } = require('./lib/antibadword');
const antibadwordCommand = require('./commands/antibadword');
const { handleChatbotCommand, handleChatbotResponse } = require('./commands/chatbot');
const takeCommand = require('./commands/take');
const { flirtCommand } = require('./commands/flirt');
const characterCommand = require('./commands/character');
const wastedCommand = require('./commands/wasted');
const shipCommand = require('./commands/ship');
const groupInfoCommand = require('./commands/groupinfo');
const resetlinkCommand = require('./commands/resetlink');
const staffCommand = require('./commands/staff');
const unbanCommand = require('./commands/unban');
const emojimixCommand = require('./commands/emojimix');
const viewOnceCommand = require('./commands/viewonce');
const viewOnceCommand2 = require('./commands/viewonce2');
const clearSessionCommand = require('./commands/clearsession');
const { autoStatusCommand, handleStatusUpdate } = require('./commands/autostatus');
const { simpCommand } = require('./commands/simp');
const { stupidCommand } = require('./commands/stupid');
const pairCommand = require('./commands/pair');
const stickerTelegramCommand = require('./commands/stickertelegram');
const textmakerCommand = require('./commands/textmaker');
const { handleAntideleteCommand, handleMessageRevocation, storeMessage } = require('./commands/antidelete');
const clearTmpCommand = require('./commands/cleartmp');
const setProfilePicture = require('./commands/setpp');
const instagramCommand = require('./commands/instagram');
const facebookCommand = require('./commands/facebook');
const playCommand = require('./commands/play');
const tiktokCommand = require('./commands/tiktok');
const songCommand = require('./commands/song');
const aiCommand = require('./commands/ai');
const { handleTranslateCommand } = require('./commands/translate');
const { handleSsCommand } = require('./commands/ss');
const { addCommandReaction, handleAreactCommand } = require('./lib/reactions');
const { goodnightCommand } = require('./commands/goodnight');
const { shayariCommand } = require('./commands/shayari');
const { rosedayCommand } = require('./commands/roseday');
const videoCommand = require('./commands/video');
const videoCommand2 = require('./commands/video2');

// Global settings
global.packname = settings.packname;
global.author = settings.author;
global.channelLink = ""; 
global.ytch = "SEPTORCH";

// Channel info for forwarding
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH_BOT MD',
            serverMessageId: -1
        }
    }
};

// SAFE ACCESS FUNCTION
function safeAccess(obj, path, defaultValue = null) {
    try {
        return path.split('.').reduce((o, p) => o?.[p], obj) || defaultValue;
    } catch (e) {
        console.warn(`Safe access failed for path: ${path}`, e);
        return defaultValue;
    }
}

// Function to get bot-specific data path
function getBotDataPath(botId, filename) {
    if (!botId || typeof botId !== 'string') {
        console.error(`Invalid botId: ${botId}. Expected string.`);
        return null;
    }
    
    const dataDir = path.join(__dirname, 'data', botId);
    try {
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
    } catch (err) {
        console.error(`❌ Failed to create directory: ${dataDir}`, err);
        return null;
    }
    
    const filePath = path.join(dataDir, filename);
    
    // Initialize default data if file doesn't exist
    const defaults = {
        'messageCount.json': JSON.stringify({ isPublic: true, messages: {} }, null, 2),
        'banned.json': JSON.stringify([], null, 2),
        'warnings.json': JSON.stringify({}, null, 2),
        'userGroupData.json': JSON.stringify({ welcome: {}, goodbye: {} }, null, 2),
        'owner.json': JSON.stringify([], null, 2),
        'premium.json': JSON.stringify([], null, 2)
    };
    
    if (!fs.existsSync(filePath) && defaults[filename]) {
        try {
            fs.writeFileSync(filePath, defaults[filename]);
        } catch (err) {
            console.error(`❌ Failed to write default file: ${filePath}`, err);
            return null;
        }
    }
    
    return filePath;
}

// SAFE MESSAGE EXTRACTION
function extractUserMessage(message) {
    try {
        // 1️⃣ Interactive buttons
        const interactiveMsg = safeAccess(message, 'message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson');
        if (interactiveMsg) {
            try {
                const params = JSON.parse(interactiveMsg);
                if (safeAccess(params, 'id')) {
                    return String(params.id).trim().toLowerCase();
                }
            } catch (e) {
                console.error('Error parsing interactive button params:', e);
            }
        }
        
        // 2️⃣ Template buttons
        const templateMsg = safeAccess(message, 'message.templateButtonReplyMessage.selectedId');
        if (templateMsg) {
            return String(templateMsg).trim().toLowerCase();
        }
        
        // 3️⃣ Legacy buttons
        const buttonMsg = safeAccess(message, 'message.buttonsResponseMessage.selectedButtonId');
        if (buttonMsg) {
            return String(buttonMsg).trim().toLowerCase();
        }
        
        // 4️⃣ Text messages
        const conversation = safeAccess(message, 'message.conversation');
        if (conversation) {
            return String(conversation).trim().toLowerCase();
        }
        
        const extendedText = safeAccess(message, 'message.extendedTextMessage.text');
        if (extendedText) {
            return String(extendedText).trim().toLowerCase();
        }
        
        return '';
    } catch (e) {
        console.error('Error extracting user message:', e);
        return '';
    }
}

// SAFE RAW TEXT EXTRACTION
function extractRawText(message) {
    try {
        return safeAccess(message, 'message.conversation', '').trim() ||
               safeAccess(message, 'message.extendedTextMessage.text', '').trim() ||
               safeAccess(message, 'message.buttonsResponseMessage.selectedButtonId', '').trim() ||
               '';
    } catch (e) {
        console.error('Error extracting raw text:', e);
        return '';
    }
}

// SAFE MESSAGE HANDLER
async function handleMessages(sock, messageUpdate, printLog, botId) {
    try {
        // EARLY EXIT: Invalid message update
        if (!messageUpdate || !messageUpdate.messages || messageUpdate.messages.length === 0 || !messageUpdate.type) {
            return;
        }
        
        const { messages, type } = messageUpdate;
        if (type !== 'notify') return;
        
        const message = messages[0];
        if (!message || !message.message) return;
        
        // EARLY EXIT: Status broadcasts
        const chatId = safeAccess(message, 'key.remoteJid');
        if (!chatId || chatId === 'status@broadcast') {
            return;
        }
        
        // Store message for antidelete feature
        try {
            await storeMessage(message, botId);
        } catch (storeErr) {
            console.error(`❌ Message store failed for ${botId}:`, storeErr);
        }
        
        // Handle message revocation (antidelete)
        if (message.message?.protocolMessage?.type === 0) {
            await handleMessageRevocation(sock, message, botId);
            return;
        }
        
        // Handle auto status replies
        try {
            await handleAutoStatusReply(sock, message, botId);
        } catch (statusErr) {
            console.error(`❌ Auto status reply failed for ${botId}:`, statusErr);
        }
        
        // Identify chat type safely
        const isGroup = chatId.endsWith('@g.us');
        const isChannel = chatId.endsWith('@newsletter');
        const isPrivate = chatId.endsWith('@s.whatsapp.net');
        
        // Get sender ID safely
        const senderId = safeAccess(message, 'key.participant') || safeAccess(message, 'key.remoteJid') || '';
        if (!senderId) {
            console.warn(`Missing sender ID for message in ${botId}`);
            return;
        }
        
        // Skip ephemeral messages
        const messageId = safeAccess(message, 'key.id', '');
        if (messageId.startsWith('BAE5') && messageId.length === 16) {
            return;
        }
        
        // Specific group restriction
        const restrictedGroupId = '120363302678069315@g.us';
        if (chatId === restrictedGroupId) {
            try {
                const adminStatus = await isAdmin(sock, chatId, senderId, botId);
                const isOwner = safeAccess(message, 'key.fromMe', false);
                if (!adminStatus.isSenderAdmin && !isOwner) {
                    return; // Non-admins cannot use the bot
                }
                if (isOwner && !adminStatus.isSenderAdmin) {
                    return; // Owner is not admin, don't allow command
                }
            } catch (adminErr) {
                console.error(`❌ Admin check failed in restricted group:`, adminErr);
                return;
            }
        }
        
        // Extract user message with safety checks
        let userMessage = extractUserMessage(message);
        const rawText = extractRawText(message);

        // ============================================================
        // 👂 INTELLIGENT EARS: Auto-Transcribe Voice Notes
        // ============================================================
        // If message is Audio/PTT and it's not a command yet, try to listen
        const isAudio = message.message?.audioMessage || message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.audioMessage;
        
        if (!userMessage && isAudio) {
            try {
                // 1. Check if Septorch AI is enabled for this chat
                let septorchPlugin = global.plugins?.get('septorch') || global.plugins?.get('ai');
                // Auto-load if missing
                if (!septorchPlugin) {
                     const p = path.join(__dirname, 'plugins', 'septorch-ai.js');
                     if (fs.existsSync(p)) septorchPlugin = require(p);
                }

                // If Plugin exists AND AI is enabled OR tagged
                if (septorchPlugin && typeof septorchPlugin.checkEnabled === 'function') {
                    const isEnabled = septorchPlugin.checkEnabled(botId, chatId);
                    const isTagged = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.includes(safeAccess(sock, 'user.id')?.split(':')[0] + '@s.whatsapp.net');

                    if (isEnabled || isTagged) {
                        await sock.sendPresenceUpdate('recording', chatId);
                        
                        // 2. Download Audio
                        const stream = await downloadContentFromMessage(message.message?.audioMessage || isAudio, 'audio');
                        let buffer = Buffer.from([]);
                        for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                        
                        // 3. Save & Convert to MP3
                        const tempInput = path.join(__dirname, `temp/ear_${Date.now()}.ogg`);
                        const tempOutput = path.join(__dirname, `temp/ear_${Date.now()}.mp3`);
                        if (!fs.existsSync(path.join(__dirname, 'temp'))) fs.mkdirSync(path.join(__dirname, 'temp'));
                        fs.writeFileSync(tempInput, buffer);

                        await new Promise((resolve, reject) => {
                            ffmpeg(tempInput).toFormat('mp3').save(tempOutput).on('end', resolve).on('error', reject);
                        });

                        // 4. Transcribe
                        const heardText = await transcribeAudio(tempOutput);
                        
                        // 5. INJECT AS TEXT
                        userMessage = heardText; 
                        console.log(`👂 [Auto-Ear] Heard: "${userMessage}"`);

                        // Cleanup
                        fs.unlinkSync(tempInput);
                        fs.unlinkSync(tempOutput);
                    }
                }
            } catch (e) {
                console.error("Auto-Ear Error:", e.message);
            }
        }
        // ============================================================
        
        // ============================================================
        // 👁️ INTELLIGENT EYES: Auto-Analyze Images
        // ============================================================
        // Check if message is an image (Direct or Quoted)
        const isImage = message.message?.imageMessage || message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;

        // Run if it's an image (Even if it has a caption/userMessage)
        if (isImage) {
            try {
                // 1. Check if Septorch AI is enabled for this chat
                let septorchPlugin = global.plugins?.get('septorch') || global.plugins?.get('ai');
                
                // Auto-load if missing (Safety check)
                if (!septorchPlugin) {
                     const p = path.join(__dirname, 'plugins', 'septorch-ai.js');
                     if (fs.existsSync(p)) septorchPlugin = require(p);
                }

                // If Plugin exists AND AI is enabled OR tagged
                if (septorchPlugin && typeof septorchPlugin.checkEnabled === 'function') {
                    const isEnabled = septorchPlugin.checkEnabled(botId, chatId);
                    const isTagged = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.includes(safeAccess(sock, 'user.id')?.split(':')[0] + '@s.whatsapp.net');

                    if (isEnabled || isTagged) {
                        // Notify user we are "looking"
                        await sock.sendPresenceUpdate('composing', chatId);
                        
                        // 2. Download Image
                        const imgMsg = message.message?.imageMessage || message.message?.extendedTextMessage?.contextInfo?.quotedMessage.imageMessage;
                        const stream = await downloadContentFromMessage(imgMsg, 'image');
                        let buffer = Buffer.from([]);
                        for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }

                        // 3. Prepare Prompt (Caption is the prompt, or default to "Describe")
                        const visualPrompt = userMessage || "Describe this image in detail and solve any text inside it.";
                        const base64Image = buffer.toString('base64');

                        // 4. Call Groq Vision API (Llama 3.2 Vision / Llama 4 Scout)
                        // Note: Ensure axios is required at top of file
                        const visionResponse = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
                            model: 'meta-llama/llama-4-scout-17b-16e-instruct', // or llama-3.2-11b-vision-preview
                            messages: [
                                {
                                    role: 'user',
                                    content: [
                                        { type: 'text', text: visualPrompt },
                                        { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${base64Image}` } }
                                    ]
                                }
                            ],
                            temperature: 0.5,
                            max_tokens: 1024
                        }, {
                            headers: { 
                                'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
                                'Content-Type': 'application/json' 
                            }
                        });

                        const analysis = visionResponse.data.choices[0].message.content;

                        // 5. INJECT AS TEXT CONTEXT
                        // We replace/augment the userMessage so the Main AI thinks the user sent this text.
                        // Format: [User's Caption] + [The AI's Vision Analysis]
                        userMessage = `[SYSTEM: User sent an image.]\n\n🗣️ USER CAPTION: "${userMessage || ''}"\n\n👁️ VISION ANALYSIS:\n${analysis}`;
                        
                        console.log(`👁️ [Auto-Eye] Saw: "${analysis.substring(0, 50)}..."`);
                    }
                }
            } catch (e) {
                console.error("Auto-Eye Error:", e.response?.data || e.message);
            }
        }
        // ============================================================
        
        // Skip if no message content
        if (!userMessage && !rawText) {
            return;
        }
        
        // Save to AI Notes
        if (!safeAccess(message, 'key.fromMe', false) && userMessage.trim()) {
            try {
                await saveNote(sock, chatId, senderId, userMessage, botId);
            } catch (saveErr) {
                console.warn(`⚠️ Failed to save note for ${botId}:`, saveErr);
            }
        }
        
        // Normalize dots and spacing
        userMessage = userMessage.replace(/\.\s+/g, '.').trim();
        
        // Handle math input early
        try {
            await mathAnswerHandler(sock, chatId, message, userMessage, botId);
        } catch (mathErr) {
            console.error(`❌ Math answer handler failed for ${botId}:`, mathErr);
        }
        
        // Only log command usage
        if (userMessage.startsWith('.')) {
            console.log(`📝 Command used in ${isGroup ? 'group' : isChannel ? 'channel' : isPrivate ? 'private' : 'broadcast'}: ${userMessage}`);
        }
        
        // Check if user is banned (skip ban check for .unban)
        if (isBanned(senderId, botId) && !userMessage.startsWith('.unban')) {
            if (Math.random() < 0.1) { // 10% chance to respond
                try {
                    await sock.sendMessage(chatId, {
                        text: '❌ You are banned from using the bot. Contact an admin to get unbanned.',
                        ...channelInfo
                    });
                } catch (banErr) {
                    console.error(`❌ Failed to send ban message:`, banErr);
                }
            }
            return;
        }
        
        // First check if it's a game move
        if (/^[1-9]$/.test(userMessage) || userMessage.toLowerCase() === 'surrender') {
            try {
                await handleTicTacToeMove(sock, chatId, senderId, userMessage, botId);
            } catch (gameErr) {
                console.error(`❌ TTT move handler failed for ${botId}:`, gameErr);
            }
            return;
        }
        
        // Increment message count (skip for bot messages)
        if (!safeAccess(message, 'key.fromMe', false)) {
            try {
                if (!message.key.fromMe) incrementMessageCount(chatId, senderId, botId);
            } catch (countErr) {
                console.warn(`⚠️ Message count increment failed:`, countErr);
            }
        }
        
        // Auto fake presence (typing/recording/etc)
        try {
            await triggerAutoFakePresence(sock, chatId, botId);
        } catch (fakeErr) {
            console.warn(`⚠️ Auto fake presence failed:`, fakeErr);
        }
        
        // Auto Reply in Private Chat
        if (isPrivate && !userMessage.startsWith('.') && userMessage.trim() !== '') {
            try {
                const replied = await checkPrivateAutoReply(sock, chatId, message, userMessage, botId);
                if (replied) return;
            } catch (autoReplyErr) {
                console.error(`❌ Private auto reply failed:`, autoReplyErr);
            }
        }
        
        // Check for bad words FIRST
        if ((isGroup || isChannel) && userMessage) {
            try {
                await handleBadwordDetection(sock, chatId, message, userMessage, senderId, botId);
            } catch (badwordErr) {
                console.error(`❌ Badword detection failed:`, badwordErr);
            }
        }
        
        // Auto Reply in Groups/Channels
        if ((isGroup || isChannel) && !userMessage.startsWith('.') && userMessage.trim() !== '') {
            try {
                const replied = await checkAutoReply(sock, chatId, message, userMessage, botId);
                if (replied) return;
            } catch (autoReplyErr) {
                console.error(`❌ Group auto reply failed:`, autoReplyErr);
            }
        }

        // ============================================================
        // 🧠 SEPTORCH AI: ADVANCED AGENT BRIDGE (UNIVERSAL EXECUTION)
        // ============================================================
        try {
            // 1. Try finding plugin via global loader
            let septorchPlugin = global.plugins?.get('septorch') || global.plugins?.get('ai') || global.plugins?.get('vision');
            
            // 2. Fallback: Load file directly if global lookup fails
            if (!septorchPlugin || typeof septorchPlugin.checkEnabled !== 'function') {
                try {
                    const possiblePaths = [
                        path.join(__dirname, 'plugins', 'septorch-ai.js'),
                        path.join(__dirname, 'lib', 'plugins', 'septorch-ai.js')
                    ];
                    
                    for (const p of possiblePaths) {
                        if (fs.existsSync(p)) {
                            septorchPlugin = require(p);
                            break;
                        }
                    }
                } catch (e) {
                    console.log('Septorch direct load failed:', e.message);
                }
            }

            // 3. Execution Logic
            if (septorchPlugin && typeof septorchPlugin.checkEnabled === 'function' && userMessage) {
                
                const wakeWords = ['septorch', 'vision', 'hey septorch', 'bot']; // Added 'bot'
                const lowerMsg = userMessage.toLowerCase();
                const isWakeWord = wakeWords.some(w => lowerMsg.startsWith(w));
                const isVisionModeOn = septorchPlugin.checkEnabled(botId, chatId);
                
                // Trigger if: (Mode ON OR WakeWord) AND (Not already a command)
                if ((isVisionModeOn || isWakeWord) && !userMessage.startsWith('.')) {
                    
                    let cleanText = userMessage;
                    if (isWakeWord) {
                        cleanText = userMessage.replace(new RegExp(`^(${wakeWords.join('|')})`, 'i'), '').trim();
                    }

                    if (cleanText) {
                        // 🔍 Check Admin Status for AI Context (so AI knows if user is admin)
                        let isSenderAdmin = false;
                        if (isGroup || isChannel) {
                             try {
                                const adminData = await isAdmin(sock, chatId, senderId, botId);
                                isSenderAdmin = adminData.isSenderAdmin;
                             } catch(e){}
                        }

                        // 🤖 CALL THE AI AGENT
                        // We capture the result (agentResult) to see if it wants to execute a command
                        const agentResult = await septorchPlugin.handleConversation(
                            sock, 
                            chatId, 
                            cleanText, 
                            senderId, 
                            botId, 
                            (text) => sock.sendMessage(chatId, { text: text }),
                            message, // Pass message for context/quoting
                            isSenderAdmin // Pass admin status
                        );

                        // ⚡ UNIVERSAL EXECUTION BRIDGE ⚡
                        // If the AI says "EXECUTE: .command", we run it here!
                        if (agentResult && agentResult.type === 'EXECUTE') {
                            const commandToRun = agentResult.command; // e.g., ".play faded"
                            
                            // Create a "Mock" Message Object
                            // This tricks the bot into thinking the user typed the command directly
                            const mockMessage = {
                                ...message,
                                message: {
                                    ...message.message,
                                    conversation: commandToRun, // Fake the text
                                    extendedTextMessage: { 
                                        text: commandToRun,
                                        // CRITICAL: Keep reply context so commands like .sticker work!
                                        contextInfo: message.message?.extendedTextMessage?.contextInfo 
                                    }
                                }
                            };

                            // RECURSIVE CALL: Run the command immediately
                            await executeCommandWithSafety(
                                sock, 
                                chatId, 
                                mockMessage, // The Fake Message
                                commandToRun, // userMessage (.play faded)
                                commandToRun, // rawText
                                senderId, 
                                isGroup, 
                                isChannel, 
                                isPrivate, 
                                botId
                            );
                        }

                        return; // Stop processing further (The AI handled it)
                    }
                }
            }
        } catch (aiErr) {
            console.error('Septorch Agent Error:', aiErr);
        }
        // ============================================================
        
        // Then check for command prefix
        if (!userMessage.startsWith('.')) {
            if (isGroup || isChannel) {
                // Chatbot Check
                try {
                    await handleChatbotResponse(sock, chatId, message, userMessage, senderId, botId);
                } catch (chatbotErr) {
                    console.error(`❌ Chatbot error:`, chatbotErr);
                }
                
                // NEW ANTILINK CHECK
                try {
                    // Check if sender is admin first
                    const adminStatus = await isAdmin(sock, chatId, senderId, botId);
                    
                    // Call the new detection function
                    await handleLinkDetection(sock, chatId, message, userMessage, senderId, adminStatus.isSenderAdmin, botId);
                } catch (antilinkErr) {
                    console.error(`❌ Antilink error:`, antilinkErr);
                }
            }
            return;
        }
        
        // List of admin & owner commands
        const adminCommands = ['.mute', '.unmute', '.ban', '.unban', '.promote', '.demote', '.kick', '.tagall', '.antilink'];
        const ownerCommands = ['.mode', '.autostatus', '.antidelete', '.cleartmp', '.setpp', '.clearsession', '.areact', '.autoreact', '.dmall'];
        
        const isAdminCommand = adminCommands.some(cmd => userMessage.startsWith(cmd));
        const isOwnerCommand = ownerCommands.some(cmd => userMessage.startsWith(cmd));
        
        let isSenderAdmin = false;
        let isBotAdmin = false;
        
        // Check admin status only for admin commands in groups or channels
        if ((isGroup || isChannel) && (isAdminCommand || isOwnerCommand)) {
            try {
                const adminStatus = await isAdmin(sock, chatId, senderId, botId);
                isSenderAdmin = adminStatus.isSenderAdmin;
                isBotAdmin = adminStatus.isBotAdmin;
                
                if (isAdminCommand && !isBotAdmin) {
                    await sock.sendMessage(chatId, { 
                        text: 'Please make the bot an admin to use admin commands.', 
                        ...channelInfo 
                    });
                    return;
                }
                
                if (userMessage.startsWith('.mute') ||
                    userMessage === '.unmute' ||
                    userMessage.startsWith('.ban') ||
                    userMessage.startsWith('.unban') ||
                    userMessage.startsWith('.promote') ||
                    userMessage.startsWith('.demote')) {
                    if (!isSenderAdmin && !safeAccess(message, 'key.fromMe', false)) {
                        await sock.sendMessage(chatId, {
                            text: 'Sorry, only admins can use this command.',
                            ...channelInfo
                        });
                        return;
                    }
                }
                
                if (isOwnerCommand && !safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the owner!',
                        ...channelInfo
                    });
                    return;
                }
            } catch (adminCheckErr) {
                console.error(`❌ Admin status check failed:`, adminCheckErr);
                await sock.sendMessage(chatId, {
                    text: '⚠️ Failed to check admin status. Please try again later.',
                    ...channelInfo
                });
                return;
            }
        }
        
        // Access mode check
        try {
            const modePath = getBotDataPath(botId, 'messageCount.json');
            if (modePath && fs.existsSync(modePath)) {
                const data = JSON.parse(fs.readFileSync(modePath));
                if (!data.isPublic && !safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    return; // Silently ignore non-owner in private mode
                }
            }
        } catch (modeErr) {
            console.error(`❌ Mode check failed:`, modeErr);
        }
        
        // ALL YOUR COMMANDS - WITH ERROR BOUNDARIES
        await executeCommandWithSafety(sock, chatId, message, userMessage, rawText, senderId, isGroup, isChannel, isPrivate, botId);
        
        // Add command reaction if applicable
        if (userMessage.startsWith('.')) {
            try {
                await addCommandReaction(sock, message, botId);
            } catch (reactErr) {
                console.warn(`⚠️ Command reaction failed:`, reactErr);
            }
        }
        
    } catch (error) {
        console.error(`🚨 CRITICAL ERROR in message handler for bot ${botId}:`, error.message);
        console.error(`Stack trace:`, error.stack);
        
        // Try to send error message if possible
        const chatId = safeAccess(messageUpdate, 'messages[0].key.remoteJid');
        if (chatId) {
            try {
                await sock.sendMessage(chatId, {
                    text: '❌ Failed to process command! Please try again later.',
                    ...channelInfo
                });
            } catch (sendErr) {
                console.error(`❌ Failed to send error message:`, sendErr);
            }
        }
    }
}

// EXECUTE COMMAND WITH SAFETY - ALL YOUR COMMANDS INCLUDED
async function executeCommandWithSafety(sock, chatId, message, userMessage, rawText, senderId, isGroup, isChannel, isPrivate, botId) {
    try {
        switch (true) {
            case userMessage === '.simage': {
                const quotedMessage = safeAccess(message, 'message.extendedTextMessage.contextInfo.quotedMessage');
                if (quotedMessage?.stickerMessage) {
                    await simageCommand(sock, quotedMessage, chatId, botId);
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'Please reply to a sticker with the .simage command to convert it.',
                        ...channelInfo
                    });
                }
                break;
            }
            
            case userMessage.startsWith('.kick'):
                const mentionedJidListKick = safeAccess(message, 'message.extendedTextMessage.contextInfo.mentionedJid', []);
                await kickCommand(sock, chatId, senderId, mentionedJidListKick, message, botId);
                break;
                
            case userMessage === '.stt' || userMessage === '.transcribe':
                await sttCommand(sock, chatId, message, botId);
                break;
                
            case userMessage === '.schedule clear':
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the bot owner!',
                        ...channelInfo
                    });
                    return;
                }
                await clearScheduleCommand(sock, chatId, senderId, botId);
                break;

            case userMessage === '.myschedules':
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the bot owner!',
                        ...channelInfo
                    });
                    return;
                }
                await myschedulesCommand(sock, chatId, senderId, botId);
                break;
                
            case userMessage.startsWith('.vision') || userMessage.startsWith('.see'):
                // Get the text after the command (e.g. ".vision what is this?")
                const visionPrompt = userMessage.trim().split(/\s+/).slice(1).join(' ');
                await visionCommand(sock, chatId, message, visionPrompt, botId);
                break;

            case userMessage.startsWith('.unschedule'):
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the bot owner!',
                        ...channelInfo
                    });
                    return;
                }
                await unscheduleCommand(sock, chatId, userMessage, senderId, botId);
                break;

            case userMessage.startsWith('.schedule'):
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the bot owner!',
                        ...channelInfo
                    });
                    return;
                }
                await scheduleCommand(sock, chatId, message, userMessage, senderId, botId);
                break;
                
            case userMessage === '.setpp':
                await setProfilePicture(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.mute'):
                const muteDuration = parseInt(userMessage.split(' ')[1]);
                if (isNaN(muteDuration)) {
                    await sock.sendMessage(chatId, {
                        text: 'Please provide a valid number of minutes.\neg to mute for 10 minutes\n.mute 10',
                        ...channelInfo
                    });
                } else {
                    await muteCommand(sock, chatId, senderId, muteDuration, botId);
                }
                break;
                
            case userMessage.startsWith('.shell'):
                if (safeAccess(message, 'key.fromMe', false)) {
                    await shellCommand(sock, chatId, userMessage, botId);
                } else {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the owner!',
                    });
                }
                break;
                
            case userMessage.startsWith('.video') || userMessage.startsWith('.ytmp4'):
                await videoCommand(sock, chatId, message);
                break;
                
            case userMessage.startsWith('.qvideo') || userMessage.startsWith('.yt2mp4'):
                await videoCommand2(sock, chatId, message);
                break;
                
            case userMessage === '.unmute':
                await unmuteCommand(sock, chatId, senderId, botId);
                break;
                
            case userMessage.startsWith('.ban'):
                await banCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.unban'):
                await unbanCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.getprofile') || userMessage.startsWith('.profile'):
                await getProfileCommand(sock, chatId, message, botId);
                break;
                
            // 🟢 FIXED: Help & List Logic (Uses helpCommand)
            case userMessage === '.help' || userMessage === '.list':
                await helpCommand(sock, chatId, message, botId);
                break;

            // 🟢 FIXED: Menu Logic (Remains using menuCommand)
            case userMessage === '.guide' || userMessage.startsWith('.menu'):
                let pushName = "User";
                try { pushName = message.pushName || "User"; } catch(e){}
                
                const menuArgs = userMessage.trim().split(/\s+/);
                const menuCat = menuArgs[1] ? menuArgs[1].toLowerCase() : null;
                const menuPage = menuArgs[2] ? parseInt(menuArgs[2], 10) : 0;
                await menuCommand(sock, chatId, menuCat, menuPage, pushName);
                break;
                
            case userMessage.startsWith('.bot'):
                const botQuery = userMessage.slice(4).trim();
                await sendBotAiQuery(sock, chatId, botQuery, senderId, botId);
                break;
                
            case userMessage === '.sticker' || userMessage === '.s':
                await stickerCommand(sock, chatId, message, botId);
                break;
                
            case userMessage === '.riddle':
                await sendRiddle(sock, chatId);
                break;
                
            case userMessage.startsWith('.warnings'):
                const mentionedJidListWarnings = safeAccess(message, 'message.extendedTextMessage.contextInfo.mentionedJid', []);
                await warningsCommand(sock, chatId, mentionedJidListWarnings, botId);
                break;
                
            case userMessage.startsWith('.warn'):
                const mentionedJidListWarn = safeAccess(message, 'message.extendedTextMessage.contextInfo.mentionedJid', []);
                await warnCommand(sock, chatId, senderId, mentionedJidListWarn, message, botId);
                break;
                
            // animu aliases
            case userMessage.startsWith('.nom'):
            case userMessage.startsWith('.poke'):
            case userMessage.startsWith('.cry'):
            case userMessage.startsWith('.kiss'):
            case userMessage.startsWith('.pat'):
            case userMessage.startsWith('.hug'):
            case userMessage.startsWith('.wink'):
            case userMessage.startsWith('.facepalm'):
            case userMessage.startsWith('.face-palm'):
            case userMessage.startsWith('.animuquote'):
            case userMessage.startsWith('.quote'):
            case userMessage.startsWith('.neko'):
            case userMessage.startsWith('.waifu'):
            case userMessage.startsWith('.loli'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    let sub = parts[0].slice(1);
                    if (sub === 'facepalm') sub = 'face-palm';
                    if (sub === 'quote' || sub === 'animuquote') sub = 'quote';
                    await animeCommand(sock, chatId, message, [sub]);
                }
                break;
                
            case userMessage.startsWith('.ocr'):
                await ocrCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.tts'):
                const text = userMessage.slice(4).trim();
                await ttsCommand(sock, chatId, text, botId);
                break;
                
            case userMessage === '.delete' || userMessage === '.del':
                await deleteCommand(sock, chatId, message, senderId, botId);
                break;
                
            case userMessage.startsWith('.tomp3') || userMessage.startsWith('.toaudio'):
                await toMp3Command(sock, chatId, message, userMessage, botId);
                break;
                
            case userMessage.startsWith('.fake'):
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the owner!',
                        ...channelInfo
                    });
                    return;
                }
                const fakeArgs = userMessage.split(' ');
                const fakeType = fakeArgs[1];
                await handleFakeCommand(sock, chatId, fakeType, botId);
                break;
                
            case userMessage.startsWith('.switchfake'):
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the owner!',
                        ...channelInfo
                    });
                    return;
                }
                await handleFakeModeCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.livescore'):
                await livescoreCommand(sock, chatId, message, [], senderId, botId);
                break;
                
            case userMessage.startsWith('.attp'):
                await attpCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.mode'):
                const modeMatch = userMessage.slice(5).trim().toLowerCase();
                const modePath = getBotDataPath(botId, 'messageCount.json');
                const data = JSON.parse(fs.readFileSync(modePath));
                if (!modeMatch) {
                    const currentMode = data.isPublic ? 'public' : 'private';
                    await sock.sendMessage(chatId, {
                        text: `Current bot mode: *${currentMode}*\nUsage: .mode public/private`,
                        ...channelInfo
                    });
                    return;
                }
                if (modeMatch !== 'public' && modeMatch !== 'private') {
                    await sock.sendMessage(chatId, {
                        text: 'Usage: .mode public/private',
                        ...channelInfo
                    });
                    return;
                }
                data.isPublic = modeMatch === 'public';
                fs.writeFileSync(modePath, JSON.stringify(data, null, 2));
                await sock.sendMessage(chatId, {
                    text: `Bot is now in *${modeMatch}* mode`,
                    ...channelInfo
                });
                break;
                
            case userMessage.startsWith('.autoreply'):
                // Allow command only if used by owner
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the bot owner!',
                        ...channelInfo
                    });
                    return;
                }
                // Owner can use .autoreply anywhere
                await handleAutoReplyCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.notes on') || userMessage.startsWith('.notes off'):
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the owner!',
                        ...channelInfo
                    });
                    return;
                }
                const args = userMessage.split(' ');
                await handleAiToggle(sock, chatId, args, botId);
                break;
                
            case userMessage.startsWith('.qr'):
                await qrCommand(sock, chatId, userMessage, botId);
                break;
                
            case userMessage === '.owner':
                await ownerCommand(sock, chatId, botId);
                break;
                
            case userMessage === '.tagall':
                const adminStatusTagAll = await isAdmin(sock, chatId, senderId, botId);
                const isSenderAdminTagAll = adminStatusTagAll.isSenderAdmin;
                if (isSenderAdminTagAll || safeAccess(message, 'key.fromMe', false)) {
                    await tagAllCommand(sock, chatId, senderId, botId);
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'Sorry, only admins can use the .tagall command.',
                        ...channelInfo
                    });
                }
                break;
                
            case userMessage.startsWith('.hidetag'):      
            case userMessage.startsWith('.tag'):
            case userMessage.startsWith('.🔊'):
                const messageText = rawText.slice(4).trim();
                const replyMessage = safeAccess(message, 'message.extendedTextMessage.contextInfo.quotedMessage') || null;
                await tagCommand(sock, chatId, senderId, messageText, replyMessage, botId);
                break;
                
            case userMessage.startsWith('.antilink'):
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                    return;
                }
                const linkAdminStatus = await isAdmin(sock, chatId, senderId, botId);
                const isBotAdminLink = linkAdminStatus.isBotAdmin;
                if (!isBotAdminLink) {
                    await sock.sendMessage(chatId, {
                        text: 'Please make the bot an admin first.',
                        ...channelInfo
                    });
                    return;
                }
                await handleAntilinkCommand(sock, chatId, userMessage, senderId, linkAdminStatus.isSenderAdmin, message, botId);
                break;
                
            case userMessage.startsWith('.short') || userMessage.startsWith('.urlshort'):
                await urlShortCommand(sock, chatId, userMessage, botId);
                break;
                
            case userMessage.startsWith('.upload'):
                await uploadCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.ttstalk') || userMessage.startsWith('.tiktokstalk') || userMessage.startsWith('.tiktoksearch') || userMessage.startsWith('.tsearch'):
                await tikTokStalkCommand(sock, chatId, message, userMessage, botId);
                break;
                
            case userMessage === '.meme':
                await memeCommand(sock, chatId, botId);
                break;
                
            case userMessage === '.joke':
                await jokeCommand(sock, chatId, botId);
                break;
                
            case userMessage === '.quote':
                await sendQuoteOfDay(sock, chatId, senderId);
                break;
                
            case userMessage === '.fact':
                await factCommand(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.acertijo') || userMessage.startsWith('.acert') || userMessage.startsWith('.pelicula') || userMessage.startsWith('.adv'):
                // Placeholder if you have a gameCommand not imported, otherwise remove
                // await gameCommand(sock, chatId, message, userMessage, botId);
                break;
                
            case userMessage.startsWith('.notes'):
                if (!(isGroup || isPrivate || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command can only be used in groups, channels, or private chats!',
                        ...channelInfo
                    });
                    return;
                }
                const prompt = userMessage.slice(5).trim(); // ".notes" is 5 characters
                if (!prompt) {
                    await sock.sendMessage(chatId, {
                        text: "Usage: .notes [your question]",
                        ...channelInfo
                    });
                    return;
                }
                if (!getAiMode(botId)) {
                    await sock.sendMessage(chatId, {
                        text: "❌ Notes AI is currently OFF. Use .notes on to enable.",
                        ...channelInfo
                    });
                    return;
                }
                await sendGptQuery(sock, chatId, prompt, botId);
                break;
                
            case userMessage.startsWith('.weather'):
                const city = userMessage.slice(9).trim();
                if (city) {
                    await weatherCommand(sock, chatId, city, botId);
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'Please specify a city, e.g., .weather London',
                        ...channelInfo
                    });
                }
                break;
                
            case userMessage.startsWith('.thread') || userMessage.startsWith('.threads') || userMessage.startsWith('.threaddl'):
                await threadsCommand(sock, chatId, message, userMessage, botId);
                break;
                
            case userMessage === '.news':
                await newsCommand(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.ttt') || userMessage.startsWith('.tictactoe'):
                const tttText = userMessage.split(' ').slice(1).join(' ');
                await tictactoeCommand(sock, chatId, senderId, tttText, botId);
                break;
                
            case userMessage.startsWith('.move'):
                const position = parseInt(userMessage.split(' ')[1]);
                if (isNaN(position)) {
                    await sock.sendMessage(chatId, {
                        text: 'Please provide a valid position number for Tic-Tac-Toe move.',
                        ...channelInfo
                    });
                } else {
                    await handleTicTacToeMove(sock, chatId, senderId, position, botId);
                }
                break;
                
            case userMessage.startsWith('.math') || userMessage.startsWith('.mates') || userMessage.startsWith('.matemáticas'):
                await mathGameCommand(sock, chatId, message, userMessage, botId);
                break;
                
            case userMessage === '.summary':
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the owner!',
                        ...channelInfo
                    });
                    return;
                }
                await summarizeChat(sock, chatId, botId);
                break;
                
            case userMessage === '.topmembers':
                await topMembers(sock, chatId, isGroup || isChannel, botId);
                break;
                
            case userMessage.startsWith('.hangman'):
                await startHangman(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.guess'):
                const guessedLetter = userMessage.split(' ')[1];
                if (guessedLetter) {
                    await guessLetter(sock, chatId, guessedLetter, botId);
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'Please guess a letter using .guess <letter>',
                        ...channelInfo
                    });
                }
                break;
                
            case userMessage === '.topics':
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the owner!',
                        ...channelInfo
                    });
                    return;
                }
                await listTopics(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.trivia'):
                await startTrivia(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.answer'):
                const answer = userMessage.split(' ').slice(1).join(' ');
                if (answer) {
                    await answerTrivia(sock, chatId, answer, botId);
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'Please provide an answer using .answer <answer>',
                        ...channelInfo
                    });
                }
                break;
                
            case userMessage.startsWith('.compliment'):
                await complimentCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.insult'):
                await insultCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.8ball'):
                const question = userMessage.split(' ').slice(1).join(' ');
                await eightBallCommand(sock, chatId, question, botId);
                break;
                
            case userMessage.startsWith('.lyrics'):
                const songTitle = userMessage.split(' ').slice(1).join(' ');
                await lyricsCommand(sock, chatId, songTitle, botId);
                break;
                
            case userMessage.startsWith('.simp'):
                const quotedMsg = safeAccess(message, 'message.extendedTextMessage.contextInfo.quotedMessage');
                const mentionedJid = safeAccess(message, 'message.extendedTextMessage.contextInfo.mentionedJid', []);
                await simpCommand(sock, chatId, quotedMsg, mentionedJid, senderId, botId);
                break;
                
            case userMessage.startsWith('.stupid') || userMessage.startsWith('.itssostupid') || userMessage.startsWith('.iss'):
                const stupidQuotedMsg = safeAccess(message, 'message.extendedTextMessage.contextInfo.quotedMessage');
                const stupidMentionedJid = safeAccess(message, 'message.extendedTextMessage.contextInfo.mentionedJid', []);
                const stupidArgs = userMessage.split(' ').slice(1);
                await stupidCommand(sock, chatId, stupidQuotedMsg, stupidMentionedJid, senderId, stupidArgs, botId);
                break;
                
            case userMessage === '.dare':
                await sendDare(sock, chatId, senderId);
                break;
                
            case userMessage === '.truth':
                await sendTruth(sock, chatId, senderId);
                break;
                
            case userMessage === '.clear':
                if (isGroup || isChannel) await clearCommand(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.promote'):
                const mentionedJidListPromote = safeAccess(message, 'message.extendedTextMessage.contextInfo.mentionedJid', []);
                await promoteCommand(sock, chatId, mentionedJidListPromote, message, botId);
                break;
                
            case userMessage.startsWith('.dmall'):
                // Ensure it's only run by the owner
                if (!safeAccess(message, 'key.fromMe', false) && !isOwner(senderId, botId)) {
                    await sock.sendMessage(chatId, {
                        text: '❌ This command is only available for the bot owner!',
                        ...channelInfo
                    });
                    return;
                }
                await dmallCommand(sock, chatId, message, botId); // Call the new command handler
                break;
                
            case userMessage.startsWith('.demote'):
                const mentionedJidListDemote = safeAccess(message, 'message.extendedTextMessage.contextInfo.mentionedJid', []);
                await demoteCommand(sock, chatId, mentionedJidListDemote, message, botId);
                break;
                
            case userMessage === '.ping':
                await pingCommand(sock, chatId, botId);
                break;
                
            case userMessage === '.alive':
                await aliveCommand(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.blur'):
                const quotedMessageBlur = safeAccess(message, 'message.extendedTextMessage.contextInfo.quotedMessage');
                await blurCommand(sock, chatId, message, quotedMessageBlur, botId);
                break;
                
            case userMessage.startsWith('.welcome'):
                if (isGroup || isChannel) {
                    const adminStatus = await isAdmin(sock, chatId, senderId, botId);
                    const isSenderAdmin = adminStatus.isSenderAdmin;
                    if (isSenderAdmin || safeAccess(message, 'key.fromMe', false)) {
                        await welcomeCommand(sock, chatId, message, botId);
                    } else {
                        await sock.sendMessage(chatId, {
                            text: 'Sorry, only admins can use this command.',
                            ...channelInfo
                        });
                    }
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                }
                break;
                
            case userMessage.startsWith('.goodbye'):
                if (isGroup || isChannel) {
                    const adminStatus = await isAdmin(sock, chatId, senderId, botId);
                    const isSenderAdmin = adminStatus.isSenderAdmin;
                    if (isSenderAdmin || safeAccess(message, 'key.fromMe', false)) {
                        await goodbyeCommand(sock, chatId, message, botId);
                    } else {
                        await sock.sendMessage(chatId, {
                            text: 'Sorry, only admins can use this command.',
                            ...channelInfo
                        });
                    }
                } else {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                }
                break;
                
            case userMessage === '.git' || userMessage === '.github' || userMessage === '.sc' || userMessage === '.script' || userMessage === '.repo':
                await githubCommand(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.antibadword'):
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                    return;
                }
                const abAdminStatus = await isAdmin(sock, chatId, senderId, botId);
                if (!abAdminStatus.isBotAdmin) {
                    await sock.sendMessage(chatId, {
                        text: '*Bot must be admin to use this feature*',
                        ...channelInfo
                    });
                    return;
                }
                await antibadwordCommand(sock, chatId, message, senderId, abAdminStatus.isSenderAdmin, botId);
                break;
                
            case userMessage.startsWith('.chatbot'):
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels.',
                        ...channelInfo
                    });
                    return;
                }
                const chatbotAdminStatus = await isAdmin(sock, chatId, senderId, botId);
                if (!chatbotAdminStatus.isSenderAdmin && !safeAccess(message, 'key.fromMe', false)) {
                    await sock.sendMessage(chatId, {
                        text: '*Only admins or bot owner can use this command*',
                        ...channelInfo
                    });
                    return;
                }
                const match = userMessage.slice(8).trim();
                await handleChatbotCommand(sock, chatId, message, match, botId);
                break;
                
            case userMessage.startsWith('.take'):
                const takeArgs = userMessage.slice(5).trim().split(' ');
                await takeCommand(sock, chatId, message, takeArgs, botId);
                break;
                
            case userMessage === '.flirt':
                await flirtCommand(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.character'):
                await characterCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.waste'):
                await wastedCommand(sock, chatId, message, botId);
                break;
                
            case userMessage === '.ship':
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels!',
                        ...channelInfo
                    });
                    return;
                }
                await shipCommand(sock, chatId, message, botId);
                break;
                
            case userMessage === '.groupinfo' || userMessage === '.infogp' || userMessage === '.infogrupo':
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels!',
                        ...channelInfo
                    });
                    return;
                }
                await groupInfoCommand(sock, chatId, message, botId);
                break;
                
            case userMessage === '.resetlink' || userMessage === '.revoke' || userMessage === '.anularlink':
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels!',
                        ...channelInfo
                    });
                    return;
                }
                await resetlinkCommand(sock, chatId, senderId, botId);
                break;
                
            case userMessage === '.staff' || userMessage === '.admins' || userMessage === '.listadmin':
                if (!(isGroup || isChannel)) {
                    await sock.sendMessage(chatId, {
                        text: 'This command can only be used in groups or channels!',
                        ...channelInfo
                    });
                    return;
                }
                await staffCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.emojimix') || userMessage.startsWith('.emix'):
                await emojimixCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.tg') || userMessage.startsWith('.stickertelegram') || userMessage.startsWith('.tgsticker') || userMessage.startsWith('.telesticker'):
                await stickerTelegramCommand(sock, chatId, message, botId);
                break;
                
            case userMessage === '.vv':
                await viewOnceCommand(sock, chatId, message, botId);
                break;
                
            case userMessage === '.vv2':
                await viewOnceCommand2(sock, chatId, message, botId);
                break;
                
             case userMessage === '.🫣':
                await viewOnceCommand2(sock, chatId, message, botId);
                break;
                
            case userMessage === '.clearsession' || userMessage === '.clearsesi':
                await clearSessionCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.bible'):
                await bibleCommand(sock, chatId, userMessage, botId);
                break;
                
            case userMessage.startsWith('.forcesurrender'):
                await forceSurrenderCommand(sock, chatId, message);
                break;
                
            case userMessage.startsWith('.autostatus'):
                const autoStatusArgs = userMessage.split(' ').slice(1);
                await autoStatusCommand(sock, chatId, message, autoStatusArgs, botId);
                break;
                
            case userMessage.startsWith('.pair') || userMessage.startsWith('.rent'): {
                const q = userMessage.split(' ').slice(1).join(' ');
                await pairCommand(sock, chatId, message, q, botId);
                break;
            }
            
            case userMessage.startsWith('.metallic'):
                await textmakerCommand(sock, chatId, message, userMessage, 'metallic', botId);
                break;
                
            case userMessage.startsWith('.ice'):
                await textmakerCommand(sock, chatId, message, userMessage, 'ice', botId);
                break;
                
            case userMessage.startsWith('.snow'):
                await textmakerCommand(sock, chatId, message, userMessage, 'snow', botId);
                break;
                
            case userMessage.startsWith('.impressive'):
                await textmakerCommand(sock, chatId, message, userMessage, 'impressive', botId);
                break;
                
            case userMessage.startsWith('.matrix'):
                await textmakerCommand(sock, chatId, message, userMessage, 'matrix', botId);
                break;
                
            case userMessage.startsWith('.light'):
                await textmakerCommand(sock, chatId, message, userMessage, 'light', botId);
                break;
                
            case userMessage.startsWith('.neon'):
                await textmakerCommand(sock, chatId, message, userMessage, 'neon', botId);
                break;
                
            case userMessage.startsWith('.devil'):
                await textmakerCommand(sock, chatId, message, userMessage, 'devil', botId);
                break;
                
            case userMessage.startsWith('.purple'):
                await textmakerCommand(sock, chatId, message, userMessage, 'purple', botId);
                break;
                
            case userMessage.startsWith('.thunder'):
                await textmakerCommand(sock, chatId, message, userMessage, 'thunder', botId);
                break;
                
            case userMessage.startsWith('.leaves'):
                await textmakerCommand(sock, chatId, message, userMessage, 'leaves', botId);
                break;
                
            case userMessage.startsWith('.1917'):
                await textmakerCommand(sock, chatId, message, userMessage, '1917', botId);
                break;
                
            case userMessage.startsWith('.arena'):
                await textmakerCommand(sock, chatId, message, userMessage, 'arena', botId);
                break;
                
            case userMessage.startsWith('.hacker'):
                await textmakerCommand(sock, chatId, message, userMessage, 'hacker', botId);
                break;
                
            case userMessage.startsWith('.sand'):
                await textmakerCommand(sock, chatId, message, userMessage, 'sand', botId);
                break;
                
            case userMessage.startsWith('.blackpink'):
                await textmakerCommand(sock, chatId, message, userMessage, 'blackpink', botId);
                break;
                
            case userMessage.startsWith('.glitch'):
                await textmakerCommand(sock, chatId, message, userMessage, 'glitch', botId);
                break;
                
            case userMessage.startsWith('.fire'):
                await textmakerCommand(sock, chatId, message, userMessage, 'fire', botId);
                break;
                
            case userMessage.startsWith('.antidelete'):
                const antideleteMatch = userMessage.slice(11).trim();
                await handleAntideleteCommand(sock, chatId, message, antideleteMatch, botId);
                break;
                
            case userMessage === '.surrender':
                await handleTicTacToeMove(sock, chatId, senderId, 'surrender', botId);
                break;
                
            case userMessage === '.cleartmp':
                await clearTmpCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.spotify') || userMessage.startsWith('.music'):
                await spotifyCommand(sock, chatId, message, userMessage, botId);
                break;
                
            case userMessage.startsWith('.instagram') || userMessage.startsWith('.insta') || userMessage.startsWith('.ig'):
                await instagramCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.facebook'):
                await facebookCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.song') || userMessage.startsWith('.play'):
                await songCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.tiktok'):
                await tiktokCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.gpt') || userMessage.startsWith('.gemini'):
                await aiCommand(sock, chatId, message, botId);
                break;
                
            case userMessage.startsWith('.translate'):
                await handleTranslateCommand(sock, chatId, message, userMessage.slice(10), botId);
                break;
                
            case userMessage.startsWith('.ss'):
                await handleSsCommand(sock, chatId, message, userMessage.slice(3).trim(), botId);
                break;
                
            case userMessage.startsWith('.areact'):
                await handleAreactCommand(sock, chatId, message, isOwner(senderId, botId), botId);
                break;
                
            case userMessage === '.goodnight':
                await goodnightCommand(sock, chatId, botId);
                break;
                
            case userMessage === '.shayari':
                await shayariCommand(sock, chatId, botId);
                break;
                
            case userMessage === '.roseday':
                await rosedayCommand(sock, chatId, botId);
                break;
                
            case userMessage.startsWith('.imagine'):
                await imagineCommand(sock, chatId, message, botId);
                break;

            // ============================================================
            // 🧩 PLUGIN SYSTEM INTEGRATION (DEFAULT FALLBACK)
            // ============================================================
            default:
                if (userMessage.startsWith('.')) {
                    // 1. Parse
                    const commandName = userMessage.trim().split(/\s+/)[0].slice(1).toLowerCase();
                    const args = userMessage.trim().split(/\s+/).slice(1);
                    const text = args.join(' ');

                    // 2. Lookup Plugin
                    const realCommand = global.cmdAliases.get(commandName);

                    if (realCommand) {
                        const plugin = global.plugins.get(realCommand);
                        if (plugin && typeof plugin.handler === 'function') {
                            try {
                                // 3. Admin Check ONLY if Plugin Needed
                                let isSenderAdmin = false;
                                let isBotAdmin = false;
                                if (isGroup) {
                                    try {
                                        const adminData = await isAdmin(sock, chatId, senderId, botId);
                                        isSenderAdmin = adminData.isSenderAdmin;
                                        isBotAdmin = adminData.isBotAdmin;
                                    } catch(e){}
                                }

                                // 4. Execute Plugin
                                await plugin.handler({
                                    sock, chatId, message, userMessage, senderId, botId, args, text,
                                    isGroup, isChannel, isPrivate,
                                    isOwner: isOwner(senderId, botId),
                                    isAdmin: isSenderAdmin,
                                    isBotAdmin,
                                    reply: (txt) => sock.sendMessage(chatId, { text: txt, ...channelInfo })
                                });
                                return; // Stop if plugin ran
                            } catch (pluginErr) {
                                console.error(`❌ Plugin error (${realCommand}):`, pluginErr);
                                await sock.sendMessage(chatId, { 
                                    text: `❌ Error in plugin: ${pluginErr.message}`, 
                                    ...channelInfo 
                                });
                                return;
                            }
                        }
                    }
                }

                // Fallback Logic
                await checkAnswer(sock, chatId, userMessage, senderId);
                if (isGroup || isChannel) {
                    if (userMessage) await handleChatbotResponse(sock, chatId, message, userMessage, senderId, botId);
                    await Antilink(message, sock, botId);
                    await handleBadwordDetection(sock, chatId, message, userMessage, senderId, botId);
                }
                break;
        }
    } catch (error) {
        console.error(`❌ Command execution error:`, error.message);
        await sock.sendMessage(chatId, { text: '❌ Error processing command.', ...channelInfo });
    }
}

// GROUP HANDLER
async function handleGroupParticipantUpdate(sock, update, botId) {
    try {
        if (!update || !update.id) return;
        const { id, participants, action, author } = update;
        
        if (action === 'add') {
            const isWel = await isWelcomeOn(id, botId);
            if (isWel) await welcomeCommand(sock, id, { participants }, botId);
        } else if (action === 'remove') {
            const isBye = await isGoodByeOn(id, botId);
            if (isBye) await goodbyeCommand(sock, id, { participants }, botId);
        }
    } catch (error) {
        console.error(`Group Participant Error:`, error);
    }
}

module.exports = {
    handleMessages,
    handleGroupParticipantUpdate,
    handleStatus: async (sock, status, botId) => {
        try { await handleStatusUpdate(sock, status, botId); } catch (e) {}
    }
};