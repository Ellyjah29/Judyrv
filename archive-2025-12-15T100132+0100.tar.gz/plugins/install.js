const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
    // ✅ Renamed Command Triggers
    cmd: ['externalplugin', 'extplugin', 'installplugin'],
    
    // Description
    desc: 'Install a new plugin from a raw code URL',
    
    // Category
    category: 'owner',
    
    // The Logic
    handler: async ({ sock, chatId, args, reply, isOwner, botId }) => {
        // 1. Security Check
        if (!isOwner) return reply('❌ *Access Denied:* Only the Bot Owner can install plugins.');
        
        // 2. Validate Input
        const url = args[0];
        if (!url || !url.startsWith('http')) {
            return reply(`❌ *Usage Error*
Please provide a raw URL containing the plugin code.

*Example:*
.externalplugin https://raw.githubusercontent.com/.../code.js`);
        }

        try {
            await reply('⏳ *Downloading plugin...*');
            
            // 3. Download the code
            const { data } = await axios.get(url);
            
            // 4. Safety Check: Ensure it looks like a valid plugin
            if (typeof data !== 'string' || !data.includes('module.exports') || !data.includes('handler:')) {
                return reply('⚠️ *Invalid Code:* The link does not appear to contain a valid plugin structure.');
            }

            // 5. Determine Filename
            let fileName = url.split('/').pop();
            // Remove any query parameters like ?token=...
            fileName = fileName.split('?')[0]; 
            // Ensure .js extension
            if (!fileName.endsWith('.js')) fileName += '.js';

            // 6. Save to plugins folder
            const pluginDir = path.join(__dirname, '../plugins');
            const filePath = path.join(pluginDir, fileName);
            fs.writeFileSync(filePath, data);
            
            // 7. Reload System
            const { loadPlugins } = require('../lib/plugins');
            loadPlugins(botId);

            await reply(`✅ *Success!*
📄 Plugin Saved: *${fileName}*
⚡ System Reloaded automatically.

_Try using the command inside the plugin now._`);

        } catch (e) {
            console.error(e);
            await reply(`❌ *Installation Failed:*\n${e.message}`);
        }
    }
};