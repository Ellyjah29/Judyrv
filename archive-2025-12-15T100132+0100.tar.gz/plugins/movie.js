const axios = require('axios');

module.exports = {
    // Command Triggers
    cmd: ['movie', 'film', 'imdb'],
    
    // Category for Menu
    category: 'downloads',
    
    // Description for Help Menu
    desc: 'Search for movie details and ratings',

    // The Logic
    handler: async ({ sock, chatId, args, text, reply }) => {
        if (!text) {
            return reply('❌ Please provide a movie name.\n*Example:* .movie Inception');
        }

        try {
            await reply('🎬 *Searching for movie...*');

            // 1. Call the API
            const apiUrl = `https://movieapi.giftedtech.co.ke/api/search?q=${encodeURIComponent(text)}`;
            const { data } = await axios.get(apiUrl);

            // 2. Validate Response
            // The API might return an array (search results) or a single object (direct hit)
            // We check for success flag or empty array
            if (!data || (Array.isArray(data) && data.length === 0) || data.success === false) {
                return reply(`❌ No movie found for: *${text}*`);
            }

            // 3. Extract Data (Handle different possible API structures)
            // Sometimes it's data[0], sometimes data.result, sometimes direct object
            const movie = Array.isArray(data) ? data[0] : (data.result || data);

            // 4. Build Caption safely
            const title = movie.title || movie.Title || text;
            const year = movie.year || movie.Year || 'N/A';
            const rating = movie.rating || movie.imdbRating || 'N/A';
            const runtime = movie.runtime || movie.Runtime || 'N/A';
            const genre = movie.genre || movie.Genre || 'N/A';
            const plot = movie.plot || movie.Plot || movie.overview || 'No description available.';
            
            // Fallback image if poster is missing or "N/A"
            let poster = movie.poster || movie.Poster;
            if (!poster || poster === 'N/A') {
                poster = 'https://i.imgur.com/1c88X6p.png'; 
            }

            const caption = `🎬 *MOVIE INFO* 🎬
            
🎥 *Title:* ${title}
📅 *Year:* ${year}
⭐ *Rating:* ${rating}
⏱️ *Runtime:* ${runtime}
🎭 *Genre:* ${genre}

📝 *Plot:*
${plot}

_Powered by Septorch Bot_`;

            // 5. Send Image with Caption
            await sock.sendMessage(chatId, {
                image: { url: poster },
                caption: caption
            });

        } catch (e) {
            console.error("Movie Plugin Error:", e);
            await reply('❌ Error fetching movie data. The API might be down or limited.');
        }
    }
};