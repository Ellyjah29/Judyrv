const os = require('os');
const process = require('process');

module.exports = {
    // Commands that trigger this plugin
    cmd: ['sys', 'system', 'info', 'ping2'],
    
    // Description for help menu (optional)
    desc: 'Displays server system information',
    
    // The Category
    category: 'utility',

    // The Logic
    handler: async ({ sock, chatId, reply }) => {
        // Calculate Uptime
        const uptimeSeconds = process.uptime();
        const days = Math.floor(uptimeSeconds / (3600 * 24));
        const hours = Math.floor(uptimeSeconds % (3600 * 24) / 3600);
        const minutes = Math.floor(uptimeSeconds % 3600 / 60);
        const seconds = Math.floor(uptimeSeconds % 60);
        const uptimeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

        // Calculate RAM
        const ramUsed = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
        const totalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
        const platform = os.platform();

        // Build Message
        const text = `🖥️ *SYSTEM DASHBOARD*
        
⚡ *RAM Usage:* ${ramUsed} MB / ${totalRam} GB
⏳ *Uptime:* ${uptimeStr}
💻 *Platform:* ${platform.toUpperCase()}
🚀 *NodeJS:* ${process.version}
        
_Powered by Septorch Plugins_ 🔌`;

        // Send Reply
        await reply(text);
    }
};