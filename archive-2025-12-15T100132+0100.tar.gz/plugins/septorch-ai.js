const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { GoogleGenerativeAI } = require("@google/generative-ai"); 
require('dotenv').config();
const globalSettings = require('../settings');
const { synthesize } = require('../lib/gtts-modules'); 

// =======================================================
// 🛠️ HELPER FUNCTIONS
// =======================================================

const getBotDir = (botId) => {
    const dir = path.join(__dirname, '../data', botId);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return dir;
};

// 1. DYNAMICALLY READ COMMANDS
const getBotCapabilities = () => {
    try {
        const helpPath = path.join(__dirname, '../commands/help.js');
        if (!fs.existsSync(helpPath)) return "Basic AI Chat available.";
        const content = fs.readFileSync(helpPath, 'utf8');
        const rowMatches = content.match(/rows:\s*\[([\s\S]*?)\]/g);
        if (!rowMatches) return "Commands: .help, .menu";
        let capabilities = "AVAILABLE TOOLS:\n";
        rowMatches.forEach(block => {
            const lines = block.match(/"(.*?)"/g) || [];
            lines.forEach(line => {
                const clean = line.replace(/"/g, '').trim();
                if (clean && clean.startsWith('.')) capabilities += `- ${clean}\n`;
            });
        });
        return capabilities;
    } catch (e) { return "Commands: .help, .menu"; }
};

const getBotIdentity = (botId) => {
    const dir = getBotDir(botId);
    let identity = { botName: 'Septorch', ownerName: 'The Owner' };
    const memoryPath = path.join(dir, 'septorch_memory.json');
    if (fs.existsSync(memoryPath)) {
        try {
            const mem = JSON.parse(fs.readFileSync(memoryPath, 'utf8'));
            if (mem.config?.ownerName) identity.ownerName = mem.config.ownerName;
            if (mem.config?.botName) identity.botName = mem.config.botName;
        } catch (e) {}
    }
    return identity;
};

// 🧠 MEMORY MANAGER (Handles History, Config, Models, & Personas)
const manageMemory = (botId, action, chatId, payload = null) => {
    const memoryPath = path.join(getBotDir(botId), 'septorch_memory.json');
    let data = { history: {}, config: { aiModel: 'groq' }, enabledChats: [], voiceModeChats: [], personas: {} };

    if (fs.existsSync(memoryPath)) { try { data = JSON.parse(fs.readFileSync(memoryPath, 'utf8')); } catch (e) {} }
    
    // Ensure data structures exist
    if (!data.history) data.history = {};
    if (!data.config) data.config = { aiModel: 'groq' };
    if (!data.enabledChats) data.enabledChats = [];
    if (!data.voiceModeChats) data.voiceModeChats = [];
    if (!data.personas) data.personas = {}; // ✅ Stores custom personalities per chat

    // Getters
    if (action === 'check_enabled') return data.enabledChats.includes(chatId);
    if (action === 'check_voice') return data.voiceModeChats.includes(chatId);
    if (action === 'get_model') return data.config.aiModel || 'groq';
    if (action === 'get_persona') return data.personas[chatId] || null;

    // Setters
    if (action === 'set_persona') {
        data.personas[chatId] = payload;
        fs.writeFileSync(memoryPath, JSON.stringify(data, null, 2));
        return;
    }

    if (action === 'toggle') {
        if (payload) { if (!data.enabledChats.includes(chatId)) data.enabledChats.push(chatId); }
        else { data.enabledChats = data.enabledChats.filter(id => id !== chatId); }
        fs.writeFileSync(memoryPath, JSON.stringify(data, null, 2));
        return payload;
    }
    if (action === 'toggle_voice') {
        if (payload) { if (!data.voiceModeChats.includes(chatId)) data.voiceModeChats.push(chatId); }
        else { data.voiceModeChats = data.voiceModeChats.filter(id => id !== chatId); }
        fs.writeFileSync(memoryPath, JSON.stringify(data, null, 2));
        return payload;
    }
    if (action === 'clear') { delete data.history[chatId]; fs.writeFileSync(memoryPath, JSON.stringify(data, null, 2)); return; }
    
    if (action === 'history') {
        let history = data.history[chatId] || [];
        if (payload?.newMsg) history.push({ role: 'user', content: payload.newMsg });
        if (payload?.aiMsg) history.push({ role: 'assistant', content: payload.aiMsg });
        if (history.length > 10) history = history.slice(history.length - 10);
        data.history[chatId] = history;
        fs.writeFileSync(memoryPath, JSON.stringify(data, null, 2));
        return history;
    }
    
    if (action === 'set_config') {
        data.config = { ...data.config, ...payload };
        fs.writeFileSync(memoryPath, JSON.stringify(data, null, 2));
    }
};

// =======================================================
// 🔌 API CONNECTORS (DUAL BRAIN)
// =======================================================

// 1. GROQ (Llama) - Fast & Strict
async function callGroq(messages) {
    if (!process.env.GROQ_API_KEY) throw new Error('GROQ_API_KEY missing');
    const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
        model: process.env.GROQ_MODEL || 'llama-3.1-8b-instant',
        messages: messages,
        temperature: 0.5, 
        max_tokens: 800
    }, { headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${process.env.GROQ_API_KEY}` } });
    return response.data.choices[0].message.content;
}

// 2. GEMINI (Google) - Smart & Creative
async function callGemini(messages, systemInstruction) {
    if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY missing');
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash", systemInstruction: systemInstruction });
    
    // Format history
    const history = messages
        .filter(m => m.role !== 'system') 
        .map(m => ({
            role: m.role === 'user' ? 'user' : 'model',
            parts: [{ text: m.content }]
        }));

    const lastMessage = history.pop(); 
    const chat = model.startChat({ history: history });
    const result = await chat.sendMessage(lastMessage.parts[0].text);
    return result.response.text();
}

// =======================================================
// 🧠 MAIN AI HANDLER (PERSONALITY + EXECUTION)
// =======================================================
async function handleAIConversation(sock, chatId, text, senderId, botId, replyFunc, messageObject, isSenderAdmin) {
    try {
        const identity = getBotIdentity(botId);
        const commandList = getBotCapabilities();
        const userRole = isSenderAdmin ? "Admin/Owner" : "User";
        const hasQuoted = messageObject?.message?.extendedTextMessage?.contextInfo?.quotedMessage ? "YES" : "NO";
        const isVoiceMode = manageMemory(botId, 'check_voice', chatId);
        const currentModel = manageMemory(botId, 'get_model', chatId);
        
        // 🎭 1. CHECK FOR CUSTOM PERSONA
        const customPersona = manageMemory(botId, 'get_persona', chatId);
        
        // Default Identity
        let coreIdentity = `You are ${identity.botName}, an automated agent created by Abiola Elijah Alalade.
👨‍💻 **DEVELOPER PROFILE:**
- Name: Abiola Elijah Alalade
- Role: Mechatronics Engineer & Developer.
- Philosophy: "Experiment, break, fix, improve."`;

        // Override if Persona exists
        if (customPersona) {
            coreIdentity = `🎭 **ROLEPLAY MODE ACTIVE:**
You are now acting as: "${customPersona}"
(Note: Even in this persona, you MUST execute commands if asked).`;
        }

        // 🧠 2. CONSTRUCT SYSTEM PROMPT
        const systemPrompt = `${coreIdentity}

**CONTEXT:**
- User Role: ${userRole}
- Quoted Msg: ${hasQuoted}
- Mode: ${isVoiceMode ? "Voice (Spoken)" : "Text"}
- Engine: ${currentModel.toUpperCase()}

**AVAILABLE COMMANDS:**
${commandList}

**🧠 TRAINING DATA (LEARN FROM THESE EXAMPLES):**
User: "Kick this guy" -> You: EXECUTE: .kick
User: "Play Faded" -> You: EXECUTE: .play Faded
User: "Show Menu" -> You: EXECUTE: .help
User: "Make sticker" (Quoted: YES) -> You: EXECUTE: .sticker
User: "How do I kick?" -> You: Reply with explanation (do not execute).

**PROTOCOL:**
1. **ACTION REQUEST:** If the user wants to run a command, START your reply with "EXECUTE: .command". This rule OVERRIDES your persona.
2. **QUESTION:** If it's just a chat, stay in character (Persona).
3. **VOICE:** If Voice Mode is on, keep text replies concise.

User Input: "${text}"`;

        let chatHistory = manageMemory(botId, 'history', chatId, { newMsg: text });
        
        // Status Update
        if (isVoiceMode) await sock.sendPresenceUpdate('recording', chatId);
        else await sock.sendPresenceUpdate('composing', chatId);

        let aiResponse = "";

        // 🔀 3. CALL SELECTED BRAIN
        if (currentModel === 'gemini') {
            const fullHistory = [{ role: 'system', content: systemPrompt }, ...chatHistory];
            aiResponse = await callGemini(fullHistory, systemPrompt);
        } else {
            const messagesPayload = [{ role: 'system', content: systemPrompt }, ...chatHistory];
            aiResponse = await callGroq(messagesPayload);
        }

        // ⚡ 4. EXECUTION BRIDGE
        if (aiResponse.includes('EXECUTE:')) {
            const rawCommand = aiResponse.split('EXECUTE:')[1].trim(); 
            await replyFunc(`_⚡ [${currentModel}] Executing: ${rawCommand}..._`);
            return { type: 'EXECUTE', command: rawCommand }; 
        } 
        
        // 💬 5. REPLY HANDLING
        manageMemory(botId, 'history', chatId, { aiMsg: aiResponse });

        if (isVoiceMode) {
            try {
                const audioBuffer = await synthesize(aiResponse, 'en'); 
                await sock.sendMessage(chatId, { audio: audioBuffer, mimetype: 'audio/mp4', ptt: true }, { quoted: messageObject });
            } catch (e) {
                await replyFunc(aiResponse); // Fallback
            }
        } else {
            await replyFunc(aiResponse);
        }

        return { type: 'CHAT' };

    } catch (err) {
        console.error(`[Septorch AI] Error:`, err.message);
        // Auto-fallback
        if (err.message.includes('403') || err.message.includes('Not Found')) {
             await replyFunc(`⚠️ Error with ${manageMemory(botId, 'get_model', chatId)}. Switching to Groq.`);
             manageMemory(botId, 'set_config', chatId, { aiModel: 'groq' });
        }
        return { type: 'ERROR' };
    }
}

module.exports = {
    cmd: ['septorch', 'ai', 'vision'],
    category: 'ai',
    checkEnabled: (botId, chatId) => manageMemory(botId, 'check_enabled', chatId),
    handleConversation: handleAIConversation,

    handler: async ({ sock, chatId, message, args, text, reply, senderId, botId, isOwner, isAdmin }) => {
        const command = args[0]?.toLowerCase();

        // 1. TOGGLE CHAT
        if (command === 'on') {
            manageMemory(botId, 'toggle', chatId, true);
            return reply('✅ *Vision Mode Enabled.*');
        }
        if (command === 'off') {
            manageMemory(botId, 'toggle', chatId, false);
            return reply('❌ *Vision Mode Disabled.*');
        }

        // 2. TOGGLE VOICE
        if (command === 'voice') {
            if (args[1] === 'on') {
                manageMemory(botId, 'toggle_voice', chatId, true);
                return reply('🎙️ *Voice Mode Enabled.*');
            }
            if (args[1] === 'off') {
                manageMemory(botId, 'toggle_voice', chatId, false);
                return reply('📝 *Voice Mode Disabled.*');
            }
        }

        // 3. SWITCH MODEL
        if (command === 'model') {
            const modelName = args[1]?.toLowerCase();
            if (modelName === 'gemini') {
                manageMemory(botId, 'set_config', chatId, { aiModel: 'gemini' });
                return reply('🧠 *Switched to Gemini (Google).*');
            }
            if (modelName === 'groq') {
                manageMemory(botId, 'set_config', chatId, { aiModel: 'groq' });
                return reply('⚡ *Switched to Groq (Llama).*');
            }
            return reply(`Current Model: *${manageMemory(botId, 'get_model', chatId)}*`);
        }

        // 4. PERSONA TRAINING (NEW!)
        if (command === 'persona' || command === 'train') {
            const newPersona = args.slice(1).join(' ');
            if (!newPersona) return reply('❌ Usage: .septorch persona You are a rude pirate\nReset: .septorch persona reset');
            
            if (newPersona === 'reset' || newPersona === 'default') {
                manageMemory(botId, 'set_persona', chatId, null); 
                return reply('✅ *Persona Reset.* Back to default professional mode.');
            }

            manageMemory(botId, 'set_persona', chatId, newPersona);
            return reply(`🎭 *Persona Updated!* I will now act as:\n"${newPersona}"`);
        }

        if (command === 'clear') {
            manageMemory(botId, 'clear', chatId);
            return reply('🧠 *Memory cleared.*');
        }
        if ((command === 'setname' || command === 'setowner') && isOwner) {
            const newName = args.slice(1).join(' ');
            manageMemory(botId, 'set_config', chatId, { ownerName: newName });
            return reply(`✅ Identity updated! Owner: *${newName}*`);
        }

        if (!text) return reply(`👋 *Septorch AI*\n\n*.septorch on* - Auto Chat\n*.septorch voice on* - Voice Mode\n*.septorch model gemini* - Switch Brain\n*.septorch persona <text>* - Train Personality`);
        
        await handleAIConversation(sock, chatId, text, senderId, botId, reply, message, isAdmin || isOwner);
    }
};