/**
 * WhatsApp Bot - STABLE PRODUCTION EDITION
 * Features: Auto-Reconnect, Hot-Reload, Video Startup, Advanced Links
 * Library: @whiskeysockets/baileys (Stable)
 * Copyright (c) 2025 Septorch
 */
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const telegramBot = require('./telegrambot.js').bot;
const { promises: fsp } = fs;
const { Boom } = require('@hapi/boom');
const PhoneNumber = require('awesome-phonenumber');
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, await, sleep, reSize } = require('./lib/myfunc');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  jidDecode,
  proto,
  jidNormalizedUser,
  makeCacheableSignalKeyStore,
  delay
} = require("@whiskeysockets/baileys"); // ✅ Stable Library
const NodeCache = require("node-cache");
const pino = require("pino");
const chokidar = require('chokidar');
const WebSocket = require('ws');
const { File } = require('megajs'); 
const yauzl = require('yauzl');      

// Load handlers
let handlers = require('./main');
let handleMessages = handlers.handleMessages;
let handleGroupParticipantUpdate = handlers.handleGroupParticipantUpdate;
let handleStatus = handlers.handleStatus;

// Global store for bots
global.botInstances = {};
global.settings = require('./settings');
global.isReloading = false; 
global.lastInternalSave = 0; 

// Deduplication Cache
const processedMsgCache = new NodeCache({ stdTTL: 120, checkperiod: 150 });

const store = {
  messages: {},
  contacts: {},
  chats: {},
  groupMetadata: async (jid) => { return {}; },
  bind: function (ev) {
    ev.on('messages.upsert', ({ messages }) => {
      messages.forEach(msg => {
        if (msg.key && msg.key.remoteJid) {
          this.messages[msg.key.remoteJid] = this.messages[msg.key.remoteJid] || {};
          this.messages[msg.key.remoteJid][msg.key.id] = msg;
        }
      });
    });
    ev.on('contacts.update', (contacts) => {
      contacts.forEach(contact => {
        if (contact.id) this.contacts[contact.id] = contact;
      });
    });
    ev.on('chats.set', (chats) => { this.chats = chats; });
  },
  loadMessage: async (jid, id) => { return this.messages[jid]?.[id] || null; }
};

// --- [HELPER FUNCTIONS] ---

async function downloadSession(sessionPath, sessionId) {
  const zipPath = path.join(sessionPath, 'session.zip');
  if (fs.existsSync(path.join(sessionPath, 'creds.json'))) {
    console.log(chalk.gray(`📁 Session exists in ${sessionPath} — skipping download.`));
    return;
  }
  if (!sessionId) {
    console.log(chalk.yellow(`⚠️ SESSION_ID not provided for ${sessionPath}`));
    return;
  }
  try {
    console.log(chalk.blue(`📥 Downloading session ZIP...`));
    await fs.promises.mkdir(sessionPath, { recursive: true });
    const file = File.fromURL(`https://mega.nz/file/${sessionId}`);
    const buffer = await new Promise((resolve, reject) => {
      file.download((err, data) => err ? reject(err) : resolve(data));
    });
    fs.writeFileSync(zipPath, buffer);
    await new Promise((resolve, reject) => {
      yauzl.open(zipPath, { lazyEntries: true }, (err, zipfile) => {
        if (err) return reject(err);
        zipfile.readEntry();
        zipfile.on('entry', (entry) => {
          if (/\/$/.test(entry.fileName)) {
            fs.mkdirSync(path.join(sessionPath, entry.fileName), { recursive: true });
            zipfile.readEntry();
          } else {
            zipfile.openReadStream(entry, (err, readStream) => {
              if (err) return reject(err);
              const filePath = path.join(sessionPath, entry.fileName);
              fs.mkdirSync(path.dirname(filePath), { recursive: true });
              readStream.pipe(fs.createWriteStream(filePath)).on('close', () => zipfile.readEntry());
            });
          }
        });
        zipfile.once('end', () => {
          if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);
          console.log(chalk.green(`✅ Session unzipped successfully.`));
          resolve();
        });
      });
    });
  } catch (error) {
    console.error(chalk.red(`❌ Download failed:`), error.message);
    if (fs.existsSync(sessionPath)) fs.rmSync(sessionPath, { recursive: true, force: true });
  }
}

function getExpiryTimestamp(expiryDateStr) {
  const date = new Date(expiryDateStr);
  return isNaN(date.getTime()) ? null : date.setHours(23, 59, 59, 999);
}

// --- [CORE BOT LOGIC] ---

async function startBot(botConfig, botId) {
  console.log(chalk.cyan(`🚀 Starting ${botId}...`));
  await safeStopBot(botId);
  const sessionPath = path.join(__dirname, 'session', botId);
  if (botConfig.expiry) botConfig.expiryTimestamp = getExpiryTimestamp(botConfig.expiry);
  
  await downloadSession(sessionPath, botConfig.SESSION_ID);
  let { version } = await fetchLatestBaileysVersion();
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
  
  const XeonBotInc = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'fatal' }))
    },
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    getMessage: async key => {
      let jid = jidNormalizedUser(key.remoteJid);
      let msg = await store.loadMessage(jid, key.id);
      return msg?.message || '';
    },
    defaultQueryTimeoutMs: undefined,
    connectTimeoutMs: 20000, // Fast timeout for stability
    keepAliveIntervalMs: 10000, // Aggressive Keep-Alive
    syncFullHistory: false, // Save RAM
    emitOwnEvents: true, 
    retryRequestDelayMs: 2000 
  });

  if (!global.botInstances) global.botInstances = {};
  global.botInstances[botId] = XeonBotInc;

  const originalSendMessage = XeonBotInc.sendMessage;
  XeonBotInc.sendMessage = async (jid, content, options = {}) => {
    if (options.skipHumanize) return await originalSendMessage(jid, content, options);
    try {
      await XeonBotInc.sendPresenceUpdate('composing', jid);
      await delay(500); 
      const result = await originalSendMessage(jid, content, options);
      if (jid.endsWith('@s.whatsapp.net') || jid.endsWith('@g.us')) {
        await XeonBotInc.readMessages([{
          remoteJid: jid,
          id: result.key.id,
          participant: result.key.participant || jid
        }]);
      }
      return result;
    } catch (error) {
      return await originalSendMessage(jid, content, options);
    }
  };

  global.owner = [botConfig.ownerNumber];
  store.bind(XeonBotInc.ev);
  
  setupEventHandlers(XeonBotInc, botId, botConfig);
  
  XeonBotInc.ev.on('connection.update', async (update) => {
    await handleConnectionUpdate(XeonBotInc, update, botConfig, botId);
  });
  
  XeonBotInc.ev.on('creds.update', saveCreds);
  return XeonBotInc;
}

// --- [CONNECTION HANDLER WITH ADVANCED STARTUP] ---

async function handleConnectionUpdate(sock, update, botConfig, botId) {
  const { connection, lastDisconnect } = update;
  // Use Boom to extract status code safely
  const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
  const botIndex = parseInt(botId.replace('bot', '')) - 1;
  
  if (connection === 'open') {
    console.log(chalk.green(`✅ ${botId} Connected! ID: ${sock.user.id.split(':')[0]}`));
    
    // Config Updates
    if (!global.botInstances[botId]) global.botInstances[botId] = {};
    global.botInstances[botId].phoneJid = sock.user.id;
    global.botInstances[botId].retryCount = 0;
    global.botInstances[botId].lastMessageTime = Date.now();

    if (global.expiryAlertSent) delete global.expiryAlertSent;

    // Clear Manual Stop Flag
    if (botConfig.manuallyStopped) {
      delete botConfig.manuallyStopped;
      try {
        const settingsPath = path.join(__dirname, 'settings.js');
        const newSettings = { ...global.settings };
        if (newSettings.bots[botIndex]) {
          delete newSettings.bots[botIndex].manuallyStopped;
          const data = `exports.bots = ${JSON.stringify(newSettings.bots, null, 2)};
exports.userStates = ${JSON.stringify(newSettings.userStates || {}, null, 2)};
exports.blacklistedUsers = ${JSON.stringify(newSettings.blacklistedUsers || [], null, 2)};`;
          
          global.lastInternalSave = Date.now();
          fs.writeFileSync(settingsPath, data);
          global.settings = newSettings;
        }
      } catch (e) {}
    }
    
    // --- [ADVANCED STARTUP MESSAGE] ---
    const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    
    const startupCaption = `
🤖 *${botConfig.botName} IS NOW ONLINE*

✅ *System Status:* Stable
⚡ *Response Speed:* Ultra Fast
🛡️ *Security:* Active

📢 *STAY UPDATED:*
Join our official channels for updates, giveaways, and support!

👥 *Official Group:*
https://chat.whatsapp.com/GGBjhgrxiAS1Xf5shqiGXH

📰 *Official Channel:*
https://whatsapp.com/channel/0029Vb1ydGk8qIzkvps0nZ04

_Power up your WhatsApp experience!_ 🚀
`;

    try {
        const lastNotification = global.botInstances[botId]?.lastOnlineNotification || 0;
        const notificationCooldown = 86400000;
        if (botConfig.telegramUserId && !botConfig.silentStart && 
            (Date.now() - lastNotification > notificationCooldown)) {
                await telegramBot.sendMessage(botConfig.telegramUserId, `✅ *${botConfig.botName}* is ONLINE!`, { parse_mode: 'Markdown' });
                if (global.botInstances[botId]) global.botInstances[botId].lastOnlineNotification = Date.now();
        }

        // Check for 'assets/bot_startup.mp4'
        const videoPath = path.join(__dirname, 'assets', 'bot_startup.mp4');
        
        if (fs.existsSync(videoPath)) {
            await sock.sendMessage(botNumber, { 
                video: fs.readFileSync(videoPath),
                caption: startupCaption,
                gifPlayback: false, 
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363387922693296@newsletter',
                        newsletterName: 'SEPTORCH',
                        serverMessageId: -1
                    }
                },
                skipHumanize: true 
            });
        } else {
            await sock.sendMessage(botNumber, { 
                text: startupCaption,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363387922693296@newsletter',
                        newsletterName: 'SEPTORCH',
                        serverMessageId: -1
                    }
                },
                skipHumanize: true 
            });
        }
    } catch (e) {
        console.error("Startup Msg Error:", e.message);
    }

  } else if (connection === 'close') {
    if (botConfig.manuallyStopped) return;
    console.log(chalk.red(`❌ Connection Closed: ${statusCode}`));

    // 🔴 HANDLE 403 (FORBIDDEN) AND LOGGED OUT
    if (statusCode === DisconnectReason.loggedOut || statusCode === 403) {
      console.log(chalk.red(`🛑 ${botId} Session Invalid (Logged Out or 403). Cleaning session...`));
      
      const sessionPath = path.join(__dirname, 'session', botId);
      try { 
          if (fs.existsSync(sessionPath)) fs.rmSync(sessionPath, { recursive: true, force: true }); 
      } catch (e) {}
      
      if (global.botInstances[botId]) global.botInstances[botId].loggedOut = true;
      
      // Send Telegram Alert
      if (botConfig.telegramUserId) {
        try { 
            await telegramBot.sendMessage(botConfig.telegramUserId, `🛑 *${botConfig.botName}* Access Denied/Logged Out! Please Rescan.`, { parse_mode: 'Markdown' }); 
        } catch (e) {}
      }
      return; // Stop here, do not reconnect
    }
    
    // Normal Reconnection
    console.log(chalk.yellow(`🔄 Reconnecting ${botId}...`));
    await safeStopBot(botId);
    await startBot(botConfig, botId);
  }
}

// --- [EVENT SETUP] ---

function setupEventHandlers(sock, botId, botConfig) {
  sock.public = true;
  sock.serializeM = (m) => require('./lib/myfunc').smsg(sock, m, store);
  sock.decodeJid = (jid) => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {};
      return decode.user && decode.server && decode.user + '@' + decode.server || jid;
    } else return jid;
  };
  sock.ev.on('messages.upsert', async (chatUpdate) => {
    if (global.isReloading || botConfig.manuallyStopped) return;
    try {
        await handleMessageWithIsolation(sock, chatUpdate, botId, botConfig);
    } catch (e) { console.error('Msg Error:', e.message); }
  });
  sock.ev.on('group-participants.update', async (update) => {
    if (!global.isReloading) await handleGroupParticipantUpdate(sock, update, botId);
  });
  sock.ev.on('status.update', async (status) => {
    if (!global.isReloading) await handleStatus(sock, status, botId);
  });
}

// SAFE MESSAGE HANDLING
async function handleMessageWithIsolation(sock, chatUpdate, botId, initialBotConfig) {
  try {
    const mek = chatUpdate.messages[0];
    if (!mek?.message) return;

    if (global.botInstances[botId]) {
        global.botInstances[botId].lastMessageTime = Date.now();
    }

    // --- [TIMESTAMP CHECK] ---
    const msgTimestamp = typeof mek.messageTimestamp === "number" ? mek.messageTimestamp : mek.messageTimestamp?.low || (Date.now() / 1000);
    const msgAge = (Date.now() / 1000) - msgTimestamp;
    if (msgAge > 120) return; 

    // --- [DEDUPLICATION CHECK FIX] ---
    // 🔴 OLD: const msgId = mek.key.id;
    // 🟢 NEW: Combine BotID + MessageID to create a unique key per bot
    // This allows multiple bots in the same group to ALL process the same message
    const uniqueId = `${botId}-${mek.key.id}`;
    if (processedMsgCache.get(uniqueId)) return; 
    processedMsgCache.set(uniqueId, true); 

    // Refresh Config
    const botIndex = parseInt(botId.replace('bot', '')) - 1;
    const botConfig = global.settings?.bots?.[botIndex] || initialBotConfig;
    if (botConfig.expiry) {
        try { botConfig.expiryTimestamp = getExpiryTimestamp(botConfig.expiry); } catch (e) {}
    }

    const message = JSON.parse(JSON.stringify(mek));
    if (message.key?.remoteJid === 'status@broadcast') {
      await handleStatus(sock, chatUpdate, botId);
      return;
    }
    
    if (message.key?.id?.startsWith('BAE5') && message.key?.id?.length === 16) return;
    if (!sock.public && !message.key.fromMe && chatUpdate.type === 'notify') return;
    
    // --- [PRIVATE EXPIRY ALERT] ---
    if (botConfig.expiryTimestamp && Date.now() > botConfig.expiryTimestamp) {
      if (!global.expiryAlertSent) {
          const botSelfJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
          await sock.sendMessage(botSelfJid, { 
              text: `⏳ *EXPIRATION ALERT*\n\nYour bot *${botConfig.botName}* has expired.\nUsers in groups are being ignored.` 
          });
          global.expiryAlertSent = true;
      }
      return;
    }

    await handleMessages(sock, chatUpdate, true, botId);

  } catch (err) {
      const errorMsg = err.message?.toLowerCase() || '';
      if (errorMsg.includes('bad mac') || errorMsg.includes('prekey') || errorMsg.includes('notauthorized')) {
          console.log(chalk.red(`🛑 ${botId} Session Corrupted. Resetting...`));
          const sessionPath = path.join(__dirname, 'session', botId);
          if (fs.existsSync(sessionPath)) fs.rmSync(sessionPath, { recursive: true, force: true });
          
          if (botConfig.telegramUserId) {
             try { await telegramBot.sendMessage(botConfig.telegramUserId, `🛑 *${botConfig.botName}* Session Corrupted. Restarting...`, { parse_mode: 'Markdown' }); } catch (e) {}
          }
          await safeStopBot(botId);
      }
  }
}

// --- [SYSTEM MANAGEMENT] ---

async function safeStopBot(botId) {
    if (global.botInstances[botId]) {
        try {
            if(global.botInstances[botId].end) {
                global.botInstances[botId].end(undefined);
            }
            global.botInstances[botId].ev.removeAllListeners();
            delete global.botInstances[botId];
        } catch (e) {}
    }
    return true;
}

async function safeRestartBot(botId) {
    const botIndex = parseInt(botId.replace('bot', '')) - 1;
    await safeStopBot(botId);
    await startBot(global.settings.bots[botIndex], botId);
}

// Telegram Hooks
global.startBotById = async (id) => startBot(global.settings.bots[parseInt(id.replace('bot',''))-1], id);
global.stopBot = safeStopBot;
global.reconnectBot = safeRestartBot;

// Startup
async function startAllBots() {
    for (let i = 0; i < global.settings.bots.length; i++) {
        const conf = global.settings.bots[i];
        if (conf.SESSION_ID && !conf.manuallyStopped) {
            await startBot(conf, `bot${i+1}`);
            await new Promise(r => setTimeout(r, 2000));
        }
    }
}

// Hot-reload system
function setupHotReload() {
    const watcher = chokidar.watch(['./main.js', './settings.js', './commands/**/*.js'], { ignored: /(^|[\/\\])\../ });
    watcher.on('change', (filePath) => {
        if (filePath.includes('settings.js') && Date.now() - global.lastInternalSave < 5000) return;
        
        console.log(chalk.blue(`🔄 Reloading: ${filePath}`));
        global.isReloading = true;
        Object.keys(require.cache).forEach(key => {
            if (key.includes('/commands/') || key.includes('main.js') || key.includes('settings.js')) delete require.cache[key];
        });
        
        if (filePath.includes('settings.js')) {
            global.settings = require('./settings');
            checkForNewSessions(global.settings, require('./settings')); 
        } else {
            handlers = require('./main');
            handleMessages = handlers.handleMessages;
        }
        setTimeout(() => global.isReloading = false, 1000);
    });
}

function checkForNewSessions(oldSettings, newSettings) {
    for (let i = 0; i < newSettings.bots.length; i++) {
        const botId = `bot${i + 1}`;
        if (!global.botInstances[botId] && newSettings.bots[i].SESSION_ID && !newSettings.bots[i].manuallyStopped) {
            startBot(newSettings.bots[i], botId);
        }
    }
}

// Main
(async () => {
    await startAllBots();
    setupHotReload();
    
    // RAM Cleaner
    setInterval(() => {
      store.messages = {};
      console.log(chalk.gray('🧹 Cleared message store to free RAM'));
    }, 60 * 60 * 1000);
    
    console.log(chalk.green('✅ SYSTEM READY'));
})();

module.exports = { startBot, safeStopBot, safeRestartBot, startAllBots };