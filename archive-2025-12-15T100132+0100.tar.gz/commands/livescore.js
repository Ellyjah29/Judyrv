const axios = require("axios");
const moment = require("moment-timezone");
const fs = require('fs');
const path = require('path');
const { sendButtons } = require("gifted-btns");

// =========================================
// 🎨 DESIGN & THEME CONFIGURATION
// =========================================
const icons = {
    trophy : '🏆',   clock : '⏰',   vs    : '🆚',
    goal   : '⚽',   score : '🔢',   live  : '🔴',
    red    : '🟥',   whistle: '🏁',  sub   : '🔄',
    boot   : '👟',   shirt : '👕',   date  : '📅',
    sport  : '🏅',   refresh: '🔄'
};

const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.trophy} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

// =========================================
// 🗂️ DATA MANAGEMENT (AUTO UPDATES)
// =========================================
function getAutoFile(botId) {
    const dir = path.join(__dirname, '../data', botId);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return path.join(dir, 'livescore_auto.json');
}

function loadAutoConfig(botId) {
    const file = getAutoFile(botId);
    if (!fs.existsSync(file)) return {};
    return JSON.parse(fs.readFileSync(file));
}

function saveAutoConfig(botId, data) {
    fs.writeFileSync(getAutoFile(botId), JSON.stringify(data, null, 2));
}

// Memory Cache to track match states
let matchCache = {}; 
let monitorInterval = null;

// =========================================
// 🚀 COMMAND HANDLER
// =========================================
module.exports = async function livescoreCommand(sock, chatId, message, args, senderId, botId) {
    const safeBotId = botId || sock.user.id.split(':')[0];

    try {
        await sock.sendPresenceUpdate("composing", chatId);

        // 1. PARSE INPUT
        const fullText = 
            message.message?.conversation?.toLowerCase() ||
            message.message?.extendedTextMessage?.text?.toLowerCase() ||
            message.message?.buttonsResponseMessage?.selectedButtonId?.toLowerCase() ||
            message.message?.templateButtonReplyMessage?.selectedId?.toLowerCase() ||
            "";

        const cleanArgs = fullText.split(" ");
        const arg1 = cleanArgs[1];    // 'football', 'auto'
        const arg2 = cleanArgs[2];    // 'epl', league name
        const arg3 = cleanArgs[3];    // 'on', 'off'

        const footballLeagues = {
            epl: "soccer/eng.1", laliga: "soccer/esp.1", ucl: "soccer/uefa.champions",
            afcon: "soccer/africa.cup", seriea: "soccer/ita.1", bundesliga: "soccer/ger.1",
            ligue1: "soccer/fra.1", npfl: "soccer/nga.1"
        };

        const sportMap = {
            football: null, basketball: "basketball/nba", baseball: "baseball/mlb",
            nfl: "football/nfl", hockey: "hockey/nhl", rugby: "rugby/eur.1",
        };

        // =====================================
        // 🔄 PART 1: AUTO UPDATES CONFIG
        // =====================================
        if (arg1 === "auto") {
            if (!arg2 || !footballLeagues[arg2] || !['on', 'off'].includes(arg3)) {
                return await sock.sendMessage(chatId, {
                    text: makeCard("Auto Match Updates", [
                        " Get professional alerts",
                        " for Goals & Red Cards.",
                        "---",
                        " Usage:",
                        " .livescore auto epl on",
                        " .livescore auto laliga off",
                        "---",
                        " *Supported Leagues:*",
                        " epl, laliga, ucl, seriea,",
                        " afcon, bundesliga, npfl"
                    ])
                });
            }

            const config = loadAutoConfig(safeBotId);
            if (!config[chatId]) config[chatId] = [];

            if (arg3 === 'on') {
                if (!config[chatId].includes(arg2)) config[chatId].push(arg2);
                saveAutoConfig(safeBotId, config);
                startLiveMonitor(sock, safeBotId); 
                return await sock.sendMessage(chatId, { text: `✅ *Auto Updates Enabled* for ${arg2.toUpperCase()}` });
            } else {
                config[chatId] = config[chatId].filter(l => l !== arg2);
                saveAutoConfig(safeBotId, config);
                return await sock.sendMessage(chatId, { text: `❌ *Auto Updates Disabled* for ${arg2.toUpperCase()}` });
            }
        }

        // =====================================
        // 🎮 PART 2: MANUAL FETCH
        // =====================================
        
        // 2. SHOW SPORT SELECTION
        if (!arg1) {
            return await sendButtons(sock, chatId, {
                title: "🎮 Live Score Center",
                text: makeCard("Select Sport", [
                    " Select a sport below to",
                    " view real-time scores.",
                    "---",
                    ` ${icons.sport}  *Available:*`,
                    " Football, Basketball, NFL",
                    " Baseball, Hockey, Rugby"
                ]),
                footer: "🕊 Powered by Septorch",
                buttons: [
                    { id: ".livescore football", text: "⚽ Football" },
                    { id: ".livescore basketball", text: "🏀 Basketball" },
                    { id: ".livescore baseball", text: "⚾ Baseball" },
                    { id: ".livescore nfl", text: "🏈 NFL" },
                    { id: ".livescore hockey", text: "🏒 Hockey" },
                    { id: ".livescore rugby", text: "🏉 Rugby" },
                    { id: ".livescore auto", text: "🔔 Auto Setup" }
                ],
            });
        }

        let apiLeague = null;

        // 4. HANDLE FOOTBALL SPECIFICS
        if (arg1 === "football") {
            if (!arg2) {
                return await sendButtons(sock, chatId, {
                    title: "⚽ Football Center",
                    text: makeCard("Select League", [
                        " Choose a league to view",
                        " upcoming matches.",
                        "---",
                        " • EPL, La Liga, UCL",
                        " • Serie A, Bundesliga, NPFL"
                    ]),
                    footer: "🕊 Powered by Septorch",
                    buttons: [
                        { id: ".livescore football epl", text: "🇬🇧 EPL" },
                        { id: ".livescore football laliga", text: "🇪🇸 La Liga" },
                        { id: ".livescore football ucl", text: "🇪🇺 UCL" },
                        { id: ".livescore football seriea", text: "🇮🇹 Serie A" },
                        { id: ".livescore football bundesliga", text: "🇩🇪 Bundesliga" },
                        { id: ".livescore football ligue1", text: "🇫🇷 Ligue 1" },
                        { id: ".livescore football afcon", text: "🌍 AFCON" },
                        { id: ".livescore football npfl", text: "🇳🇬 NPFL" },
                    ],
                });
            }

            apiLeague = footballLeagues[arg2];
            if (!apiLeague) {
                return await sock.sendMessage(chatId, {
                    text: "❌ *Unsupported League.*\nTry: epl, laliga, ucl, afcon, seriea, bundesliga, ligue1, npfl",
                });
            }
        } else {
            apiLeague = sportMap[arg1];
        }

        if (!apiLeague) {
            return await sock.sendMessage(chatId, {
                text: "❌ *Unsupported Sport.*\nTry: football, basketball, baseball, hockey, nfl, rugby",
            });
        }

        // 5. FETCH DATA FROM ESPN
        const apiUrl = `https://site.api.espn.com/apis/site/v2/sports/${apiLeague}/scoreboard`;
        const response = await axios.get(apiUrl);
        const events = response.data.events || [];

        if (!events.length) {
            return await sock.sendMessage(chatId, {
                text: `📭 No matches found for *${arg1.toUpperCase()}*.`,
            });
        }

        // 6. BUILD MATCH LIST CARD
        let matchLines = [];
        const updateTime = moment().tz("Africa/Lagos").format("h:mm A"); // Updated to 12h format

        events.slice(0, 8).forEach((event) => {
            const home = event.competitions?.[0]?.competitors?.find((c) => c.homeAway === "home")?.team?.abbreviation || "Home";
            const away = event.competitions?.[0]?.competitors?.find((c) => c.homeAway === "away")?.team?.abbreviation || "Away";
            const homeScore = event.competitions?.[0]?.competitors?.find((c) => c.homeAway === "home")?.score || "0";
            const awayScore = event.competitions?.[0]?.competitors?.find((c) => c.homeAway === "away")?.score || "0";
            
            const rawStatus = event.status?.type?.description || "Scheduled";
            let status = rawStatus;

            // --- 🟢 NEW DATE/TIME LOGIC ---
            if (rawStatus === "In Progress") status = `${icons.live} LIVE`;
            else if (rawStatus === "Halftime") status = "HT";
            else if (rawStatus === "Full Time") status = "FT";
            else if (rawStatus === "Scheduled") {
                const matchDate = moment(event.date).tz("Africa/Lagos");
                const today = moment().tz("Africa/Lagos");
                const tomorrow = moment().tz("Africa/Lagos").add(1, 'days');
                
                const timeStr = matchDate.format("h:mm A"); // 12-hour format

                if (matchDate.isSame(today, 'day')) {
                    status = `🕒 Today, ${timeStr}`;
                } else if (matchDate.isSame(tomorrow, 'day')) {
                    status = `📅 Tomorrow, ${timeStr}`;
                } else {
                    status = `📅 ${matchDate.format("DD MMM")}, ${timeStr}`;
                }
            }
            // -----------------------------

            matchLines.push(`*${home} ${icons.vs} ${away}*`);
            
            if (status.includes("Today") || status.includes("Tomorrow") || status.includes("📅")) {
                matchLines.push(`   ${status}`);
            } else {
                matchLines.push(`   ${icons.score} ${homeScore} - ${awayScore} (${status})`);
            }
            matchLines.push(""); // Spacer
        });

        matchLines.push("---");
        matchLines.push(` ${icons.refresh} Updated: ${updateTime}`);

        // 7. SEND RESPONSE
        const cardTitle = `${arg1.toUpperCase()} ${arg2 ? arg2.toUpperCase() : ''}`;
        
        await sendButtons(sock, chatId, {
            text: makeCard(cardTitle, matchLines),
            footer: "🕊 Powered by Septorch",
            buttons: [
                {
                    id: `.livescore ${arg1}${arg2 ? " " + arg2 : ""}`,
                    text: "🔄 Refresh Scores",
                },
            ],
        });

    } catch (error) {
        console.error("LiveScore Error:", error.message);
        await sock.sendMessage(chatId, {
            text: "⚠️ *Error fetching scores.* API unavailable.",
        });
    } finally {
        await sock.sendPresenceUpdate("paused", chatId);
    }
};

// =========================================
// 🔄 PROFESSIONAL BACKGROUND MONITOR
// =========================================
function startLiveMonitor(sock, botId) {
    if (monitorInterval) return; 
    console.log("⚽ Starting Professional Live Monitor...");

    monitorInterval = setInterval(async () => {
        const config = loadAutoConfig(botId);
        const activeLeagues = new Set();
        Object.values(config).forEach(leagues => leagues.forEach(l => activeLeagues.add(l)));
        
        if (activeLeagues.size === 0) return;

        const footballLeagues = {
            epl: "soccer/eng.1", laliga: "soccer/esp.1", ucl: "soccer/uefa.champions",
            afcon: "soccer/africa.cup", seriea: "soccer/ita.1", bundesliga: "soccer/ger.1",
            ligue1: "soccer/fra.1", npfl: "soccer/nga.1"
        };

        for (const leagueKey of activeLeagues) {
            const apiLeague = footballLeagues[leagueKey];
            if (!apiLeague) continue;

            try {
                // 1. Get Scoreboard to find live matches
                const sbUrl = `https://site.api.espn.com/apis/site/v2/sports/${apiLeague}/scoreboard`;
                const { data: sbData } = await axios.get(sbUrl);

                if (!sbData.events) continue;

                for (const event of sbData.events) {
                    const matchId = event.id;
                    const statusState = event.status.type.state; // pre, in, post
                    const homeComp = event.competitions[0].competitors.find(c => c.homeAway === 'home');
                    const awayComp = event.competitions[0].competitors.find(c => c.homeAway === 'away');

                    const currentData = {
                        state: statusState,
                        homeScore: parseInt(homeComp.score),
                        awayScore: parseInt(awayComp.score),
                        clock: event.status.displayClock
                    };

                    // Initialize Cache
                    if (!matchCache[matchId]) {
                        matchCache[matchId] = currentData;
                        continue;
                    }

                    const prev = matchCache[matchId];
                    let alerts = [];

                    // --- A. DETECT KICKOFF ---
                    if (prev.state === 'pre' && statusState === 'in') {
                         alerts.push({
                             type: 'text',
                             title: 'KICKOFF ⏰',
                             msg: `Match Started!\n*${homeComp.team.displayName}* vs *${awayComp.team.displayName}*`
                         });
                    }

                    // --- B. DETECT GOALS & RED CARDS ---
                    if (statusState === 'in') {
                        // Check Summary for new Events
                        const summaryUrl = `https://site.api.espn.com/apis/site/v2/sports/${apiLeague}/summary?event=${matchId}`;
                        const { data: sumData } = await axios.get(summaryUrl);
                        
                        const details = sumData.header?.competitions?.[0]?.details || [];
                        const lastEvent = details[details.length - 1];

                        if (lastEvent) {
                            const eventType = lastEvent.type?.text?.toLowerCase() || "";
                            const eventTime = lastEvent.clock?.displayValue || currentData.clock;
                            const eventId = lastEvent.id; 

                            if (prev.lastEventId !== eventId) {
                                
                                // 1. GOAL
                                if (eventType.includes('goal')) {
                                    const scorerName = lastEvent.participants?.[0]?.athlete?.displayName || "Player";
                                    const athleteId = lastEvent.participants?.[0]?.athlete?.id;
                                    const teamName = lastEvent.team?.displayName || "";
                                    
                                    const imageUrl = athleteId 
                                        ? `https://a.espncdn.com/combiner/i?img=/i/headshots/soccer/players/full/${athleteId}.png&w=350&h=254` 
                                        : 'https://cdn-icons-png.flaticon.com/512/53/53283.png';

                                    const scoreLine = `${homeComp.team.abbreviation} ${currentData.homeScore} - ${currentData.awayScore} ${awayComp.team.abbreviation}`;
                                    
                                    alerts.push({
                                        type: 'image',
                                        url: imageUrl,
                                        caption: makeCard("GOAL!!! ⚽", [
                                            ` ${icons.boot} *${scorerName.toUpperCase()}*`,
                                            ` ${icons.shirt} ${teamName}`,
                                            ` ${icons.clock} ${eventTime}'`,
                                            "---",
                                            ` ${icons.score} ${scoreLine}`
                                        ])
                                    });
                                }

                                // 2. RED CARD
                                if (eventType.includes('red card')) {
                                    const playerName = lastEvent.participants?.[0]?.athlete?.displayName || "Player";
                                    const athleteId = lastEvent.participants?.[0]?.athlete?.id;
                                    const teamName = lastEvent.team?.displayName || "";
                                    
                                    const imageUrl = athleteId 
                                        ? `https://a.espncdn.com/combiner/i?img=/i/headshots/soccer/players/full/${athleteId}.png&w=350&h=254` 
                                        : 'https://cdn-icons-png.flaticon.com/512/595/595005.png';

                                    alerts.push({
                                        type: 'image',
                                        url: imageUrl,
                                        caption: makeCard("RED CARD 🟥", [
                                            ` ${icons.red} *${playerName.toUpperCase()}*`,
                                            ` ${icons.shirt} ${teamName} (Sent Off)`,
                                            ` ${icons.clock} ${eventTime}'`,
                                            "---",
                                            ` ${icons.vs} ${homeComp.team.abbreviation} vs ${awayComp.team.abbreviation}`
                                        ])
                                    });
                                }

                                currentData.lastEventId = eventId;
                            } else {
                                currentData.lastEventId = prev.lastEventId;
                            }
                        }
                    }

                    // --- C. DETECT FULL TIME ---
                    if (prev.state === 'in' && statusState === 'post') {
                        alerts.push({
                            type: 'text',
                            title: 'FULL TIME 🏁',
                            msg: `Match Ended.\n${homeComp.team.displayName} ${currentData.homeScore} - ${currentData.awayScore} ${awayComp.team.displayName}`
                        });
                    }

                    // --- SEND ALERTS ---
                    if (alerts.length > 0) {
                        for (const [groupId, subscribedLeagues] of Object.entries(config)) {
                            if (subscribedLeagues.includes(leagueKey)) {
                                for (const alert of alerts) {
                                    try {
                                        if (alert.type === 'image') {
                                            await sock.sendMessage(groupId, { 
                                                image: { url: alert.url }, 
                                                caption: alert.caption 
                                            });
                                        } else {
                                            await sock.sendMessage(groupId, { 
                                                text: makeCard(alert.title, [alert.msg]) 
                                            });
                                        }
                                    } catch(e) { /* Ignore send errors for specific groups */ }
                                }
                            }
                        }
                    }

                    // Update Cache
                    matchCache[matchId] = currentData;
                }

            } catch (e) {
                // Silent catch
            }
        }
    }, 60000); // Check every 60 seconds
}