const settings = require('../settings');
const fs = require('fs');
const path = require('path');
const os = require('os');
const process = require('process');
const ffmpeg = require('fluent-ffmpeg');

// =================================================================
// 0. 🛠️ HELPER: AUTO-RESIZE VIDEO
// =================================================================
const resizeVideo = (inputPath, outputPath) => {
    return new Promise((resolve, reject) => {
        console.log("⚙️  Resizing video... please wait.");
        ffmpeg(inputPath)
            .size('640x640')            // Force square size
            .autoPad(true, 'black')     // Add black bars if needed
            .fps(25)                    // Standard FPS
            .duration(10)               // Cut to max 10 seconds
            .noAudio()                  // Remove audio
            .outputOptions('-preset', 'ultrafast') 
            .on('end', () => {
                console.log("✅ Video resized successfully!");
                resolve(outputPath);
            })
            .on('error', (err) => {
                console.error("❌ Error resizing video:", err);
                reject(err);
            })
            .save(outputPath);
    });
};

// =================================================================
// 1. 📂 COMMAND CONFIGURATION
// =================================================================
const commandCategories = [
    {
        title: "GENERAL",
        emoji: "🌐",
        rows: [
            ".help / .menu - Show this help menu",
            ".ping - Check bot response time",
            ".alive - Verify if bot is active",
            ".tts <text> - Convert text to speech",
            '.stt - Reply to a voice note to transcribe it to text',
            ".joke / .fact - Get a random joke or fact",
            ".quote - Get quote of the day",
            ".weather <city> - Weather info",
            ".news - Latest news",
            ".attp <text> - Animated text sticker",
            ".lyrics <song> - Song lyrics",
            ".8ball <question> - Magic 8-ball",
            ".groupinfo / .staff - Group details & admins",
            ".pair / .rent <query> - Link WhatsApp session",
            ".trt / .translate <lang> - Translate text",
            ".ss / .ssweb <url> - Screenshot website"
        ]
    },
    {
        title: "ADMINISTRATION",
        emoji: "👮‍♂️",
        rows: [
            ".ban / .unban @user - Ban/Unban member",
            ".kick @user - Remove member",
            ".promote / .demote @user - Manage admin roles",
            ".mute / .unmute - Control group chat",
            ".delete / .del - Delete bot message",
            ".warn / .warnings - Manage user warnings",
            ".antilink on/off - Auto-remove link senders",
            ".antibadword on/off - Bad word filter",
            ".clear - Clear chat history",
            ".tagall / .🔊 - Tag all members",
            ".chatbot on/off - AI Chat toggle",
            ".resetlink - Reset group invite link"
        ]
    },
    {
        title: "OWNER CONTROLS",
        emoji: "👑",
        rows: [
            ".mode public/private - Set bot mode",
            ".autostatus on/off - Auto status view/reply",
            ".clearsession - Clear session data",
            ".antidelete on/off - Catch deleted messages",
            ".cleartmp - Clear temp files",
            ".setpp - Set bot profile picture",
            ".autoreact / .areact - Auto reaction mode",
            ".autoreply <add/remove> - Manage auto-replies",
            ".fake typing/recording - Fake presence",
            ".switchfake - Toggle fake presence",
            "", // Empty line for spacing
            "🧾 *SCHEDULER*", // Sub-Header
            ".schedule <time> <target> <msg> - Schedule message",
            ".myschedules - View scheduled messages",
            ".unschedule <id> - Cancel a message",
            ".schedule clear - Cancel all"
        ]
    },
    {
        title: "UTILITY",
        emoji: "🛠️",
        rows: [
            ".ocr - Extract text from image",
            ".bible <verse> - Bible verses",
            ".profile / .getprofile - Show user info",
            ".welcome on/off - Welcome messages",
            ".goodbye on/off - Goodbye messages",
            ".urlshort / .short - Shorten URLs",
            ".upload - Upload file to cloud",
            ".notes on/off - AI Note taking mode"
        ]
    },
    {
        title: "STICKERS & REACTION",
        emoji: "🎨",
        rows: [
            ".sticker - Convert media to sticker",
            ".simage - Convert sticker to image",
            ".tgsticker <url> - Telegram stickers",
            ".meme - Send random meme",
            ".take <name> - Change sticker metadata",
            ".emojimix - Mix emojis (e.g. 😄+😍)",
            ".nom / .poke / .cry - Anime reactions",
            ".kiss / .pat / .hug - Anime reactions",
            ".wink / .facepalm - Anime reactions",
            ".neko / .waifu / .loli - Random Anime Images"
        ]
    },
    {
        title: "AI TOOLS",
        emoji: "🤖",
        rows: [
            ".gpt / .gemini <text> - AI Assistant",
            '.vision <text> - Analyze an image (Reply to image)',
            ".imagine / .dalle <idea> - AI Image Gen",
            ".flux <idea> - High quality AI Images"
        ]
    },
    {
        title: "FUN ZONE",
        emoji: "🎉",
        rows: [
            ".compliment / .insult @user - Fun interactions",
            ".flirt / .shayari - Romantic lines",
            ".goodnight / .roseday - Wishes",
            ".character <name> - Character sticker",
            ".wasted - Wasted effect on DP",
            ".ship - Relationship calculator",
            ".simp / .stupid @user - Rate a user"
        ]
    },
    {
        title: "GAMES",
        emoji: "🎮",
        rows: [
            ".tictactoe / .ttt @user - Play Tic-Tac-Toe",
            ".move <1-9> - Make a move",
            ".surrender / .forcesurrender - End game",
            ".hangman - Guess the word",
            ".guess <letter> - Guess character",
            ".trivia / .answer - General knowledge",
            ".riddle - Solve riddles",
            ".mathgame / .mates - Math puzzles",
            ".pelicula - Movie guessing game",
            ".adv - Adventure game"
        ]
    },
    {
        title: "DOWNLOADS",
        emoji: "⬇️",
        rows: [
            ".play / .song <name> - Download Audio",
            ".ytmp3 <url> - YouTube Audio",
            ".spotify / .music - Spotify DL",
            ".instagram / .facebook <link> - Social DL",
            ".tiktok / .tt <url> - TikTok DL (No Watermark)",
            ".threads / .thread <url> - Threads DL",
            ".video / .ytmp4 <url> - YouTube Video",
            ".qvideo / .yt2mp4 - High Quality Video",
            ".tiktoksearch <user> - Search TikTok"
        ]
    },
    {
        title: "MEDIA TOOLS",
        emoji: "📼",
        rows: [
            ".toMp3 / .toaudio - Video to Audio",
            ".viewonce / .vv - Send as View Once",
            ".vv2 / .🫣 - Alternative View Once"
        ]
    },
    {
        title: "TEXT MAKER",
        emoji: "✍️",
        rows: [
            ".metallic / .ice / .snow - 3D Text",
            ".impressive / .matrix - Sci-Fi Text",
            ".neon / .glitch / .fire - Glowing Text",
            ".devil / .thunder / .blackpink - Stylish Text"
        ]
    },
    {
        title: "EXTRA",
        emoji: "📌",
        rows: [
            ".topmembers - Activity ranking",
            ".notes / .summary - Chat notes",
            ".github / .repo - Source code",
            ".owner / .credits - Bot details"
        ]
    }
];

// =================================================================
// 2. 🎨 DESIGN & LOGIC
// =================================================================

const formatRuntime = (seconds) => {
    seconds = Number(seconds);
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor(seconds % (3600 * 24) / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    return `${d > 0 ? d + 'd ' : ''}${h}h ${m}m ${s}s`;
};

const getGreeting = () => {
    const hrs = new Date().getHours();
    if (hrs < 12) return 'Good Morning 🌄';
    if (hrs < 18) return 'Good Afternoon ☀️';
    return 'Good Evening 🌙';
};

function formatMenu(categories) {
    const uptime = formatRuntime(process.uptime());
    const date = new Date().toLocaleDateString('en-GB');
    const botName = settings.botName ? settings.botName.toUpperCase() : 'SEPTORCH BOT';
    
    let menu = `╭───⟪ ✦ ${botName} ✦ ⟫───╮\n`;
    menu += `│ ⚡ *Status:* Online\n`;
    menu += `│ ⏳ *Server Uptime:* ${uptime}\n`;
    menu += `│ 📅 *Date:* ${date}\n`;
    menu += `│ 👑 *Owner:* ${settings.botOwner || 'SEPTORCH'}\n`;
    menu += `╰──────────────────────╯\n\n`;
    
    menu += `✨ _${getGreeting()}! Here is the full command list:_\n\n`;

    categories.forEach(cat => {
        menu += `╭───『 *${cat.emoji} ${cat.title}* 』───༓\n`;
        const rows = cat.rows.map(row => `│ ⌬ ${row}`).join('\n');
        menu += `${rows}\n`;
        menu += `╰──────────────────────༓\n\n`;
    });

    menu += `╭───⟪ 💡 *HELP* ⟫───╮\n`;
    menu += `│ Use commands with prefix\n`;
    menu += `│ Example: .sticker\n`;
    menu += `╰──────────────────╯`;

    return menu;
}

// =================================================================
// 3. 🚀 MAIN FUNCTION
// =================================================================

// Note: Signature updated to match main.js -> (sock, chatId, message, botId)
async function helpCommand(sock, chatId, message, botId) {
    try {
        const helpMessage = formatMenu(commandCategories);

        // 🟢 PATH CONFIGURATION
        // Ensure you have a 'assets' folder in your project root with a 'bot_video.mp4'
        const assetsDir = path.join(__dirname, '../assets');
        const rawVideoPath = path.join(assetsDir, 'bot_video.mp4'); 
        const resizedVideoPath = path.join(assetsDir, 'bot_menu_resized.mp4');
        
        // Ensure assets directory exists
        if (!fs.existsSync(assetsDir)) {
            try { fs.mkdirSync(assetsDir, { recursive: true }); } catch (e) {}
        }
        
        const channelJid = '120363387922693296@newsletter';

        // 1. VIDEO HANDLING
        let finalVideoBuffer = null;

        if (fs.existsSync(resizedVideoPath)) {
            finalVideoBuffer = fs.readFileSync(resizedVideoPath);
        } else if (fs.existsSync(rawVideoPath)) {
            try {
                // Inform user only if we are about to process a resize
                await sock.sendMessage(chatId, { text: '_🎨 Optimizing menu video for the first time..._' }, { quoted: message });
                await resizeVideo(rawVideoPath, resizedVideoPath);
                finalVideoBuffer = fs.readFileSync(resizedVideoPath);
            } catch (e) {
                console.log("Resize failed, using raw video.");
                finalVideoBuffer = fs.readFileSync(rawVideoPath);
            }
        } else {
            console.log("⚠️ No video file found (bot_video.mp4). Sending text menu.");
        }

        // 2. CONTEXT INFO
        const contextInfo = {
            isForwarded: true, 
            forwardedNewsletterMessageInfo: {
                newsletterJid: channelJid, 
                newsletterName: `${settings.botName || 'SEPTORCH'} Updates`,
                serverMessageId: -1
            }
        };

        // 3. SEND MESSAGE
        if (finalVideoBuffer) {
            await sock.sendMessage(chatId, {
                video: finalVideoBuffer,
                caption: helpMessage,
                gifPlayback: true,
                contextInfo: contextInfo
            }, { quoted: message });
        } else {
            // Fallback to text if video is missing
            await sock.sendMessage(chatId, {
                text: helpMessage,
                contextInfo: contextInfo
            }, { quoted: message });
        }

    } catch (err) {
        console.error('Error generating menu:', err);
        await sock.sendMessage(chatId, { text: '*⚠️ Error loading menu.*' }, { quoted: message });
    }
}

module.exports = helpCommand;