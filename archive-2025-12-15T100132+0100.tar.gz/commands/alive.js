const settings = require("../settings");
const process = require('process');
const os = require('os');

// =========================================
// 🎨 DESIGN & THEME CONFIGURATION
// =========================================
const icons = {
    bot   : '🤖',   time  : '⏳',    chip  : '💾',
    wifi  : '📡',   crown : '👑',    check : '✅',
    globe : '🌍',   menu  : '📜'
};

// Helper: Format Uptime (Seconds -> d h m s)
const formatRuntime = (seconds) => {
    seconds = Number(seconds);
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor(seconds % (3600 * 24) / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    return `${d > 0 ? d + 'd ' : ''}${h}h ${m}m ${s}s`;
};

// Helper: Create Card Design
const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.bot} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

// =========================================
// 🚀 COMMAND HANDLER
// =========================================
async function aliveCommand(sock, chatId) {
    try {
        const uptime = formatRuntime(process.uptime());
        const platform = os.platform() === 'win32' ? 'Windows' : 'Linux';
        const botName = settings.botName || 'SEPTORCH BOT';
        const version = settings.version || '2.0.0';

        const messageLines = [
            ` ${icons.time}  *Last Updated:* ${uptime} ago`, // 👈 Changed Label
            ` ${icons.chip}  *Host:* ${platform}`,
            ` ${icons.wifi}  *Status:* Online & Ready`,
            ` ${icons.globe}  *Mode:* Public`,
            '---',
            ` ${icons.crown}  *Owner:* ${settings.botOwner || 'SEPTORCH'}`,
            ` ${icons.check}  *Version:* ${version}`,
            '---',
            ` ${icons.menu}  Type *.menu* for commands`
        ];

        await sock.sendMessage(chatId, {
            text: makeCard(botName, messageLines),
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363387922693296@newsletter',
                    newsletterName: 'SEPTORCH_BOT MD',
                    serverMessageId: -1
                }
            }
        });

    } catch (error) {
        console.error('Error in alive command:', error);
        await sock.sendMessage(chatId, { text: '✅ SEPTORCH Bot is online and ready!' });
    }
}

module.exports = aliveCommand;