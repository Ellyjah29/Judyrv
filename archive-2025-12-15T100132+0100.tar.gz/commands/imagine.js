const axios = require('axios');

const imagineCommand = async (sock, chatId, text, botId) => {
    try {
        // 1. Validation
        if (!text) {
            await sock.sendMessage(chatId, { text: '❌ Please provide a prompt.\nExample: .imagine cyberpunk cat' });
            return;
        }

        await sock.sendMessage(chatId, { text: '🎨 _Generating image..._' });

        // 2. Construct API URL (Pollinations AI)
        // We use encodeURIComponent to handle spaces and special characters safely
        const prompt = encodeURIComponent(text);
        // "nologo=true" removes the watermark
        // "width=1024&height=1024" ensures high quality
        // "model=flux" uses the new, realistic Flux model
        const url = `https://image.pollinations.ai/prompt/${prompt}?width=1024&height=1024&nologo=true&model=flux`;

        // 3. Fetch Image Buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data, 'binary');

        // 4. Send Image
        await sock.sendMessage(chatId, { 
            image: buffer, 
            caption: `🎨 *Generated:* ${text}\n🤖 *Model:* Flux` 
        });

    } catch (error) {
        console.error('Imagine Command Error:', error);
        await sock.sendMessage(chatId, { text: '❌ Failed to generate image. Please try again.' });
    }
};

module.exports = imagineCommand;