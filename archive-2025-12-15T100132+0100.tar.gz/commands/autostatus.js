const fs = require('fs');
const path = require('path');

// =========================================
// 🎨 DESIGN & THEME CONFIGURATION
// =========================================
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH_BOT',
            serverMessageId: -1
        }
    }
};

const icons = {
    gear  : '⚙️',   eye   : '👁️',    face  : '🎭',
    on    : '🟢',   off   : '🔴',    warn  : '⚠️',
    err   : '⛔',   info  : 'ℹ️',    check : '✅',
    list  : '📜',   arrow : '➔',    dot   : '◈',
    dice  : '🎲'
};

// New "Card" Design Function
const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.gear} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

const sendCard = (sock, chatId, title, lines) =>
    sock.sendMessage(chatId, { text: makeCard(title, lines), ...channelInfo });

// =========================================
// 🗂️ FILE & STATE MANAGEMENT
// =========================================
const configPath = path.join(__dirname, '../data/autoStatus.json');

// Ensure config exists
if (!fs.existsSync(configPath)) {
    fs.writeFileSync(configPath, JSON.stringify({}));
}

// === CONFIG HELPERS ===
function loadConfig() {
    return JSON.parse(fs.readFileSync(configPath));
}
function saveConfig(config) {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
}

// === REACTED STORAGE PER BOT ===
function getReactedFile(botId) {
    const botDir = path.join(__dirname, '../data', botId);
    if (!fs.existsSync(botDir)) fs.mkdirSync(botDir, { recursive: true });
    return path.join(botDir, 'reacted.json');
}

function loadReacted(botId) {
    const file = getReactedFile(botId);
    if (!fs.existsSync(file)) return {};
    try {
        return JSON.parse(fs.readFileSync(file));
    } catch { return {}; }
}

function saveReacted(botId, reactedMap) {
    const file = getReactedFile(botId);
    fs.writeFileSync(file, JSON.stringify(reactedMap, null, 2));
}

// Cleanup expired reacted entries every hour
setInterval(() => {
    const config = loadConfig();
    for (const botId of Object.keys(config)) {
        let reacted = loadReacted(botId);
        const now = Date.now();
        let changed = false;
        for (const [id, time] of Object.entries(reacted)) {
            if (now - time > 24 * 60 * 60 * 1000) {
                delete reacted[id];
                changed = true;
            }
        }
        if (changed) saveReacted(botId, reacted);
    }
}, 60 * 60 * 1000);

// === BOT CONFIG HELPERS ===
const defaultEmojis = ['😂', '❤️', '🔥', '😍', '💯', '😎', '👍', '😢', '👏', '🤩', '💚', '✨'];

function pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function getBotConfig(botId) {
    const config = loadConfig();
    if (!config[botId]) {
        config[botId] = { 
            enabled: false, 
            reactOn: false, 
            random: false, 
            emoji: '💚',
            chance: 100,
            emojiList: [...defaultEmojis]
        };
        saveConfig(config);
    }
    return config[botId];
}

function setBotConfig(botId, newConfig) {
    const config = loadConfig();
    config[botId] = { ...getBotConfig(botId), ...newConfig };
    saveConfig(config);
}

// =========================================
// 📜 COMMAND HANDLER
// =========================================
async function autoStatusCommand(sock, chatId, msg, args, botId) {
    try {
        if (!msg.key.fromMe) {
            return sendCard(sock, chatId, 'ACCESS DENIED', [
                ` ${icons.err}  *Only the Bot Owner can use this.*`
            ]);
        }

        let botConfig = getBotConfig(botId);

        if (!args || args.length === 0) {
            const statusIcon = botConfig.enabled ? icons.on : icons.off;
            const reactIcon  = botConfig.reactOn ? icons.on : icons.off;
            const modeText   = botConfig.random ? `Random (${botConfig.chance}%)` : `Fixed: ${botConfig.emoji}`;

            return sendCard(sock, chatId, 'STATUS SETTINGS', [
                ` ${icons.eye}  *Auto View:* ${statusIcon}`,
                ` ${icons.face}  *Auto React:* ${reactIcon}`,
                ` ${icons.dice}  *Mode:* ${modeText}`,
                '---',
                ` ${icons.dot}  *.autostatus on/off*`,
                ` ${icons.dot}  *.autostatus react on/off*`,
                ` ${icons.dot}  *.autostatus react emoji 😂*`,
                ` ${icons.dot}  *.autostatus react chance 50*`,
                ` ${icons.dot}  *.autostatus react add/remove 😂*`,
                ` ${icons.dot}  *.autostatus react list*`
            ]);
        }

        const command = args[0].toLowerCase();

        if (command === 'on') {
            setBotConfig(botId, { enabled: true });
            return sendCard(sock, chatId, 'SYSTEM UPDATE', [` ${icons.check}  Auto Status View *ENABLED*`]);
        } else if (command === 'off') {
            setBotConfig(botId, { enabled: false });
            return sendCard(sock, chatId, 'SYSTEM UPDATE', [` ${icons.off}  Auto Status View *DISABLED*`]);
        } else if (command === 'react') {
            if (!args[1]) {
                return sendCard(sock, chatId, 'USAGE ERROR', [
                    ` ${icons.warn}  Missing parameter.`,
                    ` Try: *.autostatus react on*`
                ]);
            }
            const sub = args[1].toLowerCase();

            if (sub === 'on') {
                setBotConfig(botId, { reactOn: true, random: true });
                return sendCard(sock, chatId, 'REACTION UPDATE', [` ${icons.check}  Reactions *ENABLED* (Random Mode)`]);
            } else if (sub === 'off') {
                setBotConfig(botId, { reactOn: false });
                return sendCard(sock, chatId, 'REACTION UPDATE', [` ${icons.off}  Reactions *DISABLED*`]);
            } else if (sub === 'emoji') {
                if (!args[2]) return sendCard(sock, chatId, 'ERROR', [` ${icons.warn}  Please provide an emoji.`]);
                setBotConfig(botId, { reactOn: true, random: false, emoji: args[2] });
                return sendCard(sock, chatId, 'CONFIG SAVED', [` ${icons.face}  Fixed Emoji set to: ${args[2]}`]);
            } else if (sub === 'chance') {
                const val = parseInt(args[2]);
                if (isNaN(val) || val < 0 || val > 100) return sendCard(sock, chatId, 'ERROR', [` ${icons.warn}  Value must be 0-100.`]);
                setBotConfig(botId, { chance: val });
                return sendCard(sock, chatId, 'CONFIG SAVED', [` ${icons.dice}  Reaction Chance: *${val}%*`]);
            } else if (sub === 'add') {
                if (!args[2]) return sendCard(sock, chatId, 'ERROR', [` ${icons.warn}  Provide emoji(s) to add.`]);
                let newEmojis = args.slice(2);
                botConfig.emojiList.push(...newEmojis);
                setBotConfig(botId, { emojiList: [...new Set(botConfig.emojiList)] });
                return sendCard(sock, chatId, 'POOL UPDATED', [` ${icons.check}  Added: ${newEmojis.join(' ')}`]);
            } else if (sub === 'remove') {
                if (!args[2]) return sendCard(sock, chatId, 'ERROR', [` ${icons.warn}  Provide emoji(s) to remove.`]);
                let remove = args.slice(2);
                botConfig.emojiList = botConfig.emojiList.filter(e => !remove.includes(e));
                setBotConfig(botId, { emojiList: botConfig.emojiList });
                return sendCard(sock, chatId, 'POOL UPDATED', [` ${icons.off}  Removed: ${remove.join(' ')}`]);
            } else if (sub === 'list') {
                return sendCard(sock, chatId, 'EMOJI POOL', [
                    ` ${icons.list}  *Current Reaction List:*`,
                    '---',
                    botConfig.emojiList.join('  ')
                ]);
            } else {
                return sendCard(sock, chatId, 'ERROR', [` ${icons.err}  Invalid subcommand.`]);
            }
        }

    } catch (error) {
        console.error('Error in autostatus command:', error);
        await sock.sendMessage(chatId, { text: '❌ Critical Error: ' + error.message });
    }
}

// =========================================
// 🚀 STATUS EVENT LOGIC (Logic Unchanged)
// =========================================
async function reactToStatus(sock, statusKey, botId) {
    try {
        const uniqueId = `${statusKey.id}-${statusKey.participant || statusKey.remoteJid}`;
        const now = Date.now();

        let reacted = loadReacted(botId);
        if (reacted[uniqueId] && now - reacted[uniqueId] < 24 * 60 * 60 * 1000) return;

        const botConfig = getBotConfig(botId);
        if (!botConfig.reactOn) return;

        if (Math.random() * 100 > botConfig.chance) return;

        let emoji;
        if (botConfig.random) {
            emoji = pickRandom(botConfig.emojiList.length ? botConfig.emojiList : defaultEmojis);
        } else {
            emoji = botConfig.emoji || '💚';
        }

        await sock.relayMessage(
            'status@broadcast',
            {
                reactionMessage: {
                    key: {
                        remoteJid: 'status@broadcast',
                        id: statusKey.id,
                        participant: statusKey.participant || statusKey.remoteJid,
                        fromMe: false
                    },
                    text: emoji
                }
            },
            {
                messageId: statusKey.id,
                statusJidList: [statusKey.remoteJid, statusKey.participant || statusKey.remoteJid]
            }
        );

        reacted[uniqueId] = now;
        saveReacted(botId, reacted);

    } catch (error) {
        console.error(`❌ Error reacting to status for botId: ${botId}`, error.message);
    }
}

async function handleStatusUpdate(sock, status, botId) {
    try {
        const botConfig = getBotConfig(botId);
        if (!botConfig.enabled) return;

        await new Promise(resolve => setTimeout(resolve, 1000));

        if (status.messages && status.messages.length > 0) {
            const msg = status.messages[0];
            if (msg.key && msg.key.remoteJid === 'status@broadcast') {
                await sock.readMessages([msg.key]);
                await reactToStatus(sock, msg.key, botId);
                return;
            }
        }

        if (status.key && status.key.remoteJid === 'status@broadcast') {
            await sock.readMessages([status.key]);
            await reactToStatus(sock, status.key, botId);
            return;
        }

    } catch (error) {
        console.error('❌ Error in auto status view:', error.message);
    }
}

module.exports = {
    autoStatusCommand,
    handleStatusUpdate
};