const fetch = require("node-fetch");
const { sendButtons } = require("gifted-btns");

// =========================================
// 🎨 DESIGN & THEME CONFIGURATION
// =========================================
const icons = {
    book  : '📖',   cross : '✝️',    arrow : '➡️',
    warn  : '⚠️',   quote : '📜',    check : '✅',
    list  : '📝',   trans : '🌐'
};

// New "Card" Design Function
const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.book} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        // Handle wrapping nicely if needed, or just pad
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

/**
 * Handle .bible [reference] command
 */
async function bibleCommand(sock, chatId, message, botId) {
    try {
        await sock.sendPresenceUpdate("composing", chatId);

        const input = message.trim().split(" ").slice(1).join(" ");

        // 1. INPUT CHECK (Usage Menu)
        if (!input) {
            return await sendButtons(sock, chatId, {
                title: "📖 Holy Bible",
                text: makeCard("Bible Search", [
                    ` ${icons.warn}  *Missing Reference*`,
                    "---",
                    " Please provide a book & verse.",
                    "",
                    ` ${icons.list}  *Examples:*`,
                    " • .bible John 3:16",
                    " • .bible Psalm 23:1-4",
                    " • .bible Gen 1:1 --trans niv"
                ]),
                footer: "🕊 Powered by Septorch",
                buttons: [
                    { id: ".bible John 3:16", text: "📘 Read John 3:16" },
                    { id: ".bible Psalm 23", text: "📗 Read Psalm 23" },
                ],
            });
        }

        // 2. PARSE ARGUMENTS
        const match = input.match(/(.*?)\s*--trans\s*(\w+)/i);
        const ref = match ? match[1].trim() : input;
        const translation = match ? match[2].trim().toLowerCase() : "kjv";

        const formattedRef = encodeURIComponent(ref.replace(/\s+/g, " "));
        const apiUrl = `https://bible-api.com/${formattedRef}?translation=${translation}`;

        // 3. FETCH DATA
        const response = await fetch(apiUrl);
        const data = await response.json();

        // 4. ERROR HANDLING
        if (!data || !data.verses || data.verses.length === 0 || data.error) {
            return await sendButtons(sock, chatId, {
                title: "📖 Holy Bible",
                text: makeCard("Search Failed", [
                    ` ${icons.warn}  *Verse Not Found*`,
                    "---",
                    ` Query: "${ref}"`,
                    "",
                    " Please check spelling or chapter."
                ]),
                footer: "🕊 Powered by Septorch",
                buttons: [
                    { id: ".bible John 3:16", text: "📘 Try Example" },
                ],
            });
        }

        // 5. FORMAT SUCCESSFUL RESPONSE
        const verseLines = [];
        
        // Header Line: "John 3:16 (KJV)"
        verseLines.push(` ${icons.cross}  *${data.reference}*`);
        verseLines.push(` ${icons.trans}  *Ver:* ${data.translation_id.toUpperCase()}`);
        verseLines.push("---");

        // Format Verses
        for (const v of data.verses) {
            verseLines.push(` *[${v.verse}]* ${v.text.trim()}`);
            verseLines.push(""); // Spacer
        }

        // Navigation Logic
        const lastVerse = data.verses[data.verses.length - 1];
        const firstVerse = data.verses[0];
        
        // Calculate Next/Prev logic
        const nextVerse = `${lastVerse.book_name} ${lastVerse.chapter}:${lastVerse.verse + 1}`;
        
        // Logic to prevent going to verse 0
        const prevVerseNum = Math.max(1, firstVerse.verse - 1);
        const prevVerse = `${firstVerse.book_name} ${firstVerse.chapter}:${prevVerseNum}`;
        
        // Next Range (e.g. read next 3 verses)
        const nextRange = `${lastVerse.book_name} ${lastVerse.chapter}:${lastVerse.verse + 1}-${lastVerse.verse + 3}`;

        // 6. SEND MAIN CARD WITH BUTTONS
        await sendButtons(sock, chatId, {
            title: "📖 Holy Bible",
            text: makeCard("Scripture", verseLines),
            footer: "🕊 Powered by Septorch",
            buttons: [
                { id: `.bible ${prevVerse} --trans ${translation}`, text: "⏮️ Previous" },
                { id: `.bible ${nextVerse} --trans ${translation}`, text: "➡️ Next" },
                { id: `.bible ${nextRange} --trans ${translation}`, text: "📜 Next 3 Verses" },
            ],
        });

        // 7. SEND TRANSLATION LIST
        // (Kept as standard message since lists are specific)
        const translationList = {
            title: "🌐 Translation Options",
            text: "Tap 'View List' to change Bible version", // Description
            buttonText: "📘 Change Version",
            listType: 1,
            sections: [
                {
                    title: "📖 Common Versions",
                    rows: [
                        { title: "King James Version (KJV)", rowId: `.bible ${ref} --trans kjv`, description: "Traditional English" },
                        { title: "English Standard Version (ESV)", rowId: `.bible ${ref} --trans esv`, description: "Literal word-for-word" },
                        { title: "New International Version (NIV)", rowId: `.bible ${ref} --trans niv`, description: "Modern balance" },
                        { title: "World English Bible (WEB)", rowId: `.bible ${ref} --trans web`, description: "Public domain modern" },
                    ],
                },
            ],
        };

        await sock.sendMessage(chatId, translationList);

    } catch (error) {
        console.error("Bible verse fetch error:", error);
    } finally {
        await sock.sendPresenceUpdate("paused", chatId);
    }
}

module.exports = { bibleCommand };