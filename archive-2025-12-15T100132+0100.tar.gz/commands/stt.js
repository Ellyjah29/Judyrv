const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { transcribeAudio } = require('../lib/transcribe-module');
const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');
const { exec } = require('child_process');

// Helper to download media from a message
const downloadMedia = async (message, type) => {
    const stream = await downloadContentFromMessage(message, type);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
};

const sttCommand = async (sock, chatId, message, botId) => {
    try {
        // 1. Get Quoted Message (The Voice Note)
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        
        if (!quoted || (!quoted.audioMessage && !quoted.pttMessage)) {
            await sock.sendMessage(chatId, { text: '❌ Please reply to a Voice Note or Audio file with .stt' });
            return;
        }

        await sock.sendMessage(chatId, { text: '👂 _Listening & Transcribing..._' });

        // 2. Download the Audio
        const audioBuffer = await downloadMedia(quoted.audioMessage, 'audio');
        const tempInput = path.join(__dirname, `../temp/input_${Date.now()}.ogg`);
        const tempOutput = path.join(__dirname, `../temp/stt_${Date.now()}.mp3`);

        // Ensure temp folder exists
        if (!fs.existsSync(path.join(__dirname, '../temp'))) {
            fs.mkdirSync(path.join(__dirname, '../temp'), { recursive: true });
        }

        fs.writeFileSync(tempInput, audioBuffer);

        // 3. Convert OGG (WhatsApp format) to MP3 (Groq format)
        // Note: WhatsApp voice notes are Opus/OGG which some APIs struggle with.
        // We convert to MP3 for maximum compatibility.
        ffmpeg(tempInput)
            .toFormat('mp3')
            .on('error', (err) => {
                console.error('FFmpeg Conversion Error:', err);
                sock.sendMessage(chatId, { text: '❌ Error processing audio file.' });
            })
            .on('end', async () => {
                try {
                    // 4. Send to Groq for Transcription
                    const text = await transcribeAudio(tempOutput);

                    // 5. Reply with Text
                    await sock.sendMessage(chatId, { 
                        text: `📝 *Transcription:*\n\n${text}` 
                    }, { quoted: message });

                } catch (err) {
                    await sock.sendMessage(chatId, { text: '❌ Failed to transcribe.' });
                } finally {
                    // 6. Clean up
                    if (fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
                    if (fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
                }
            })
            .save(tempOutput);

    } catch (error) {
        console.error('STT Command Error:', error);
        await sock.sendMessage(chatId, { text: '❌ Error executing command.' });
    }
};

module.exports = sttCommand;