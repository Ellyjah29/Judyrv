const settings = require('../settings.js');

// =========================================
// 🎨 DESIGN & THEME CONFIGURATION
// =========================================
const icons = {
    bot   : '🤖',   ping  : '🏓',    fast  : '🚀',
    good  : '⚡',   slow  : '🐢',    tag   : '🔖',
    gear  : '⚙️'
};

// New "Card" Design Function
const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.bot} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

// =========================================
// 🚀 COMMAND HANDLER
// =========================================
async function pingCommand(sock, chatId, message) {
    try {
        const start = Date.now();
        
        // 1. Send initial placeholder
        const tmpMsg = await sock.sendMessage(chatId, { text: '_🏓 Testing Network Speed..._' });
        
        // 2. Calculate Latency
        const end = Date.now();
        const latencyMs = end - start;
        
        // 🟢 Convert to Seconds with 3 decimals (The "0.000" format)
        const latencySec = (latencyMs / 1000).toFixed(3); 

        // 3. Determine Speed Icon
        let speedIcon = icons.slow;
        if (latencyMs < 100) speedIcon = icons.fast;
        else if (latencyMs < 400) speedIcon = icons.good;

        // 4. Build the Card
        const summary = makeCard('System Status', [
            ` ${speedIcon}  *Response:* ${latencySec} s`, // Shows as 0.120 s
            ` ${icons.tag}  *Version:* v 2.0.0 `,
            '---',
            ` ${icons.gear}  *Condition:* ${latencyMs < 200 ? 'Excellent' : 'Stable'}`
        ]);

        // 5. Edit the message with the final result
        await sock.sendMessage(chatId, {
            text: summary,
            edit: tmpMsg.key
        });

    } catch (e) {
        console.error('pingCommand error:', e);
        await sock.sendMessage(chatId, {
            text: '❌ *Error:* Could not calculate ping.'
        });
    }
}

module.exports = pingCommand;