// commands/botAI.js
const axios = require('axios');
const { loadChatHistory, saveNote } = require('./ai_notes');
const categories = require('./menu').categories;

// Import ALL commands from main.js
const playCommand = require('./play');
const songCommand = require('./song');
const stickerCommand = require('./sticker');
const memeCommand = require('./meme');
const ttsCommand = require('./tts');
const imagineCommand = require('./imagine');
const weatherCommand = require('./weather');
const lyricsCommand = require('./lyrics');
const tiktokCommand = require('./tiktok');
const instagramCommand = require('./instagram');
const facebookCommand = require('./facebook');
const spotifyCommand = require('./spotify');
const videoCommand = require('./video');
const videoCommand2 = require('./video2');
const livescoreCommand = require('./livescore');
const { mathGameCommand, mathAnswerHandler } = require('./mathgame');
const tikTokStalkCommand = require('./tiktokstalk');
const threadsCommand = require('./threads');
const toMp3Command = require('./tomp3');
const { getProfileCommand } = require('./getprofile');
const { ocrCommand } = require('./ocr');
const { bibleCommand } = require('./bible');
const tagAllCommand = require('./tagall');
const { sendRiddle, checkAnswer } = require('./riddle');
const menuCommand = require('./menu');
const helpCommand = require('./help');
const banCommand = require('./ban');
const { shellCommand } = require('./shell');
const { promoteCommand } = require('./promote');
const { demoteCommand } = require('./demote');
const muteCommand = require('./mute');
const unmuteCommand = require('./unmute');
const { uploadCommand } = require('./upload');
const { qrCommand } = require('./qr');
const warnCommand = require('./warn');
const warningsCommand = require('./warnings');
const { tictactoeCommand, handleTicTacToeMove } = require('./tictactoe');
const { incrementMessageCount, topMembers } = require('./topmembers');
const ownerCommand = require('./owner');
const deleteCommand = require('./delete');
const jokeCommand = require('./joke');
const { sendQuoteOfDay } = require('./quoteofday');
const { urlShortCommand } = require('./urlshort');
const factCommand = require('./fact');
const newsCommand = require('./news');
const kickCommand = require('./kick');
const simageCommand = require('./simage');
const attpCommand = require('./attp');
const { startHangman, guessLetter } = require('./hangman');
const { startTrivia, answerTrivia } = require('./trivia');
const { complimentCommand } = require('./compliment');
const { insultCommand } = require('./insult');
const { eightBallCommand } = require('./eightball');
const { sendDare } = require('./dare');
const { sendTruth } = require('./truth');
const { clearCommand } = require('./clear');
const pingCommand = require('./ping');
const aliveCommand = require('./alive');
const blurCommand = require('./img-blur');
const welcomeCommand = require('./welcome');
const goodbyeCommand = require('./goodbye');
const githubCommand = require('./github');
const antibadwordCommand = require('./antibadword');
const { handleChatbotCommand } = require('./chatbot');
const takeCommand = require('./take');
const { flirtCommand } = require('./flirt');
const characterCommand = require('./character');
const wastedCommand = require('./wasted');
const shipCommand = require('./ship');
const groupInfoCommand = require('./groupinfo');
const resetlinkCommand = require('./resetlink');
const staffCommand = require('./staff');
const unbanCommand = require('./unban');
const emojimixCommand = require('./emojimix');
const viewOnceCommand = require('./viewonce');
const viewOnceCommand2 = require('./viewonce2');
const clearSessionCommand = require('./clearsession');
const { autoStatusCommand } = require('./autostatus');
const { simpCommand } = require('./simp');
const { stupidCommand } = require('./stupid');
const pairCommand = require('./pair');
const stickerTelegramCommand = require('./stickertelegram');
const textmakerCommand = require('./textmaker');
const clearTmpCommand = require('./cleartmp');
const setProfilePicture = require('./setpp');
const aiCommand = require('./ai');
const { handleTranslateCommand } = require('./translate');
const { handleSsCommand } = require('./ss');
const { goodnightCommand } = require('./goodnight');
const { shayariCommand } = require('./shayari');
const { rosedayCommand } = require('./roseday');

// --- Execute Commands (Kept for internal use) ---
async function executeCommand(intent, sock, chatId, senderId, botId) {
    const { command, args } = intent;
    const fakeMessage = {
        key: { remoteJid: chatId, participant: senderId },
        message: { conversation: args ? `.${command} ${args}` : `.${command}` },
        pushName: 'User'
    };

    try {
        switch (command) {
            case 'play': case 'song': await playCommand(sock, chatId, fakeMessage, botId); break;
            case 'spotify': await spotifyCommand(sock, chatId, fakeMessage, botId); break;
            case 'sticker': await stickerCommand(sock, chatId, fakeMessage, botId); break;
            case 'meme': await memeCommand(sock, chatId, botId); break;
            case 'tts': await ttsCommand(sock, chatId, args || 'Hello', botId); break;
            case 'imagine': await imagineCommand(sock, chatId, fakeMessage, botId); break;
            case 'weather': await weatherCommand(sock, chatId, args, botId); break;
            case 'lyrics': await lyricsCommand(sock, chatId, args, botId); break;
            case 'tiktok': await tiktokCommand(sock, chatId, fakeMessage, botId); break;
            case 'instagram': await instagramCommand(sock, chatId, fakeMessage, botId); break;
            case 'facebook': await facebookCommand(sock, chatId, fakeMessage, botId); break;
            case 'video': case 'ytmp4': await videoCommand(sock, chatId, fakeMessage); break;
            case 'qvideo': case 'yt2mp4': await videoCommand2(sock, chatId, fakeMessage); break;
            case 'joke': await jokeCommand(sock, chatId, botId); break;
            case 'fact': await factCommand(sock, chatId, botId); break;
            case 'quote': await sendQuoteOfDay(sock, chatId, senderId); break;
            case 'news': await newsCommand(sock, chatId, botId); break;
            case 'bible': await bibleCommand(sock, chatId, args, botId); break;
            case 'riddle': await sendRiddle(sock, chatId); break;
            case 'dare': await sendDare(sock, chatId, senderId); break;
            case 'truth': await sendTruth(sock, chatId, senderId); break;
            case 'alive': await aliveCommand(sock, chatId, botId); break;
            case 'ping': await pingCommand(sock, chatId, botId); break;
            case 'help': case 'menu': await helpCommand(sock, chatId, global.channelLink, botId); break;
            case 'github': await githubCommand(sock, chatId, botId); break;
            case 'clear': await clearCommand(sock, chatId, botId); break;
            case 'compliment': await complimentCommand(sock, chatId, fakeMessage, botId); break;
            case 'insult': await insultCommand(sock, chatId, fakeMessage, botId); break;
            case '8ball': await eightBallCommand(sock, chatId, args, botId); break;
            case 'hangman': await startHangman(sock, chatId, botId); break;
            case 'guess': await guessLetter(sock, chatId, args, botId); break;
            case 'trivia': await startTrivia(sock, chatId, botId); break;
            case 'answer': await answerTrivia(sock, chatId, args, botId); break;
            case 'math': await mathGameCommand(sock, chatId, fakeMessage, args, botId); break;
            case 'tictactoe': case 'ttt': await tictactoeCommand(sock, chatId, senderId, args, botId); break;
            case 'move': await handleTicTacToeMove(sock, chatId, senderId, args, botId); break;
            case 'surrender': await handleTicTacToeMove(sock, chatId, senderId, 'surrender', botId); break;
            case 'ban': await banCommand(sock, chatId, fakeMessage, botId); break;
            case 'unban': await unbanCommand(sock, chatId, fakeMessage, botId); break;
            case 'kick': await kickCommand(sock, chatId, senderId, [], fakeMessage, botId); break;
            case 'mute': await muteCommand(sock, chatId, senderId, parseInt(args) || 5, botId); break;
            case 'unmute': await unmuteCommand(sock, chatId, senderId, botId); break;
            case 'promote': await promoteCommand(sock, chatId, [], fakeMessage, botId); break;
            case 'demote': await demoteCommand(sock, chatId, [], fakeMessage, botId); break;
            case 'tagall': await tagAllCommand(sock, chatId, senderId, botId); break;
            case 'warn': await warnCommand(sock, chatId, senderId, [], fakeMessage, botId); break;
            case 'warnings': await warningsCommand(sock, chatId, [], botId); break;
            case 'welcome': await welcomeCommand(sock, chatId, fakeMessage, botId); break;
            case 'goodbye': await goodbyeCommand(sock, chatId, fakeMessage, botId); break;
            case 'staff': await staffCommand(sock, chatId, fakeMessage, botId); break;
            case 'groupinfo': await groupInfoCommand(sock, chatId, fakeMessage, botId); break;
            case 'resetlink': await resetlinkCommand(sock, chatId, senderId, botId); break;
            case 'owner': await ownerCommand(sock, chatId, botId); break;

            default:
                await sock.sendMessage(chatId, { text: `❌ Unknown command: ${command}` });
        }
    } catch (err) {
        console.error(`Failed to execute: ${command}`, err);
        await sock.sendMessage(chatId, { text: `❌ Failed to run: ${command}` });
    }
}

// --- UPDATED AI Query Handler ---
async function sendBotAiQuery(sock, chatId, query, senderId, botId) {
    // ⚠️ Deprecation Notice
    await sock.sendMessage(chatId, { 
        text: `⚠️ *Update Notice:*\n\nThe *.bot* command is no longer supported.\n\n✅ Please use *.septorch* instead.\n\nExample:\n> *.septorch on* (Enables Auto Chat & Vision)` 
    });
}

module.exports = { sendBotAiQuery, executeCommand };