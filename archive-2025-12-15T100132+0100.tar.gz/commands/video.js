const axios = require('axios');
const yts = require('yt-search');

// =========================================
// 🎨 DESIGN & THEME CONFIGURATION
// =========================================
const icons = {
    video : '🎥',   search: '🔎',    time  : '⏱️',
    down  : '⬇️',   check : '✅',    err   : '❌',
    play  : '▶️',   bot   : '🤖'
};

const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.video} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

// =========================================
// 🌐 API HELPERS
// =========================================
const izumi = { baseURL: "https://izumiiiiiiii.dpdns.org" };
const AXIOS_DEFAULTS = {
    timeout: 60000,
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
};

async function tryRequest(getter, attempts = 3) {
    let lastError;
    for (let attempt = 1; attempt <= attempts; attempt++) {
        try { return await getter(); } catch (err) {
            lastError = err;
            if (attempt < attempts) await new Promise(r => setTimeout(r, 1000 * attempt));
        }
    }
    throw lastError;
}

async function getIzumiVideoByUrl(youtubeUrl) {
    const apiUrl = `${izumi.baseURL}/downloader/youtube?url=${encodeURIComponent(youtubeUrl)}&format=720`;
    const res = await tryRequest(() => axios.get(apiUrl, AXIOS_DEFAULTS));
    if (res?.data?.result?.download) return res.data.result;
    throw new Error('Izumi returned no download');
}

async function getOkatsuVideoByUrl(youtubeUrl) {
    const apiUrl = `https://okatsu-rolezapiiz.vercel.app/downloader/ytmp4?url=${encodeURIComponent(youtubeUrl)}`;
    const res = await tryRequest(() => axios.get(apiUrl, AXIOS_DEFAULTS));
    if (res?.data?.result?.mp4) return { download: res.data.result.mp4, title: res.data.result.title };
    throw new Error('Okatsu returned no mp4');
}

// =========================================
// 🚀 COMMAND HANDLER
// =========================================
async function videoCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text || "";
        const searchQuery = text.split(' ').slice(1).join(' ').trim();
        
        if (!searchQuery) {
            const usage = makeCard("Video Downloader", [` ${icons.search}  *Missing Query*`, "---", " Please provide a title or link."]);
            await sock.sendMessage(chatId, { text: usage }, { quoted: message });
            return;
        }

        // Search Video
        let videoUrl = '', videoTitle = 'YouTube Video', videoThumbnail = '', timestamp = 'Unknown';

        if (searchQuery.startsWith('http://') || searchQuery.startsWith('https://')) {
            videoUrl = searchQuery;
            const ytId = (videoUrl.match(/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/) || [])[1];
            if (ytId) videoThumbnail = `https://i.ytimg.com/vi/${ytId}/sddefault.jpg`;
        } else {
            const { videos } = await yts(searchQuery);
            if (!videos || videos.length === 0) {
                await sock.sendMessage(chatId, { text: `❌ *No videos found.*` }, { quoted: message });
                return;
            }
            videoUrl = videos[0].url;
            videoTitle = videos[0].title;
            videoThumbnail = videos[0].thumbnail;
            timestamp = videos[0].timestamp;
        }

        // Send "Downloading" Card
        const cardCaption = makeCard("Fetching Video", [
            ` ${icons.play}  *Title:* ${videoTitle}`,
            ` ${icons.time}  *Duration:* ${timestamp}`,
            "---",
            ` ${icons.down}  _Downloading..._`
        ]);

        await sock.sendMessage(chatId, {
            image: { url: videoThumbnail || 'https://i.imgur.com/3K1d1i3.jpeg' },
            caption: cardCaption
        }, { quoted: message });

        // Download
        let videoData;
        try {
            videoData = await getIzumiVideoByUrl(videoUrl);
        } catch (e1) {
            try {
                videoData = await getOkatsuVideoByUrl(videoUrl);
            } catch (e2) {
                throw new Error("All APIs failed");
            }
        }

        // 🟢 FINAL MESSAGE
        await sock.sendMessage(chatId, {
            video: { url: videoData.download },
            mimetype: 'video/mp4',
            fileName: `${videoData.title || videoTitle || 'video'}.mp4`,
            caption: `*${videoData.title || videoTitle}*\n\n> 🕊 Powered by Septorch`,
            contextInfo: {
                externalAdReply: {
                    title: "🎥 Powered by Septorch",
                    body: "Click to Join Channel",
                    mediaType: 1,
                    thumbnailUrl: videoThumbnail || 'https://i.imgur.com/3K1d1i3.jpeg',
                    // 👇 HARDCODED LINK
                    sourceUrl: 'https://whatsapp.com/channel/0029Vb1ydGk8qIzkvps0nZ04',
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: message });

    } catch (error) {
        console.error('[VIDEO] Command Error:', error?.message || error);
        await sock.sendMessage(chatId, { text: `❌ *Download Failed.*` }, { quoted: message });
    }
}

module.exports = videoCommand;