// ./commands/news.js
const axios = require('axios');
require('dotenv').config();

const NEWS_API_KEY = process.env.NEWS_API_KEY || 'your_newsapi_key';

module.exports = async (sock, chatId, botId) => {
    try {
        const response = await axios.get('https://newsapi.org/v2/top-headlines', {
            params: {
                country: 'ng', // Nigeria
                apiKey: NEWS_API_KEY,
                pageSize: 5
            }
        });

        const articles = response.data.articles;

        if (articles.length === 0) {
            return await sock.sendMessage(chatId, {
                text: '📰 No Nigerian news articles found at the moment.'
            });
        }

        let newsList = '🇳🇬 *Latest Nigerian News*\n\n';

        articles.forEach((article, index) => {
            const title = article.title || 'No title';
            const source = article.source.name || 'Unknown Source';
            const url = article.url || '#';
            newsList += `${index + 1}. *${title}*\n   📰 ${source}\n   🔗 ${url}\n\n`;
        });

        await sock.sendMessage(chatId, { text: newsList });

    } catch (error) {
        console.error('News command error:', error.message);
        if (error.response?.data?.code === 'apiKeyInvalid') {
            await sock.sendMessage(chatId, {
                text: '❌ News API key is invalid or expired. Contact bot owner.'
            });
        } else {
            await sock.sendMessage(chatId, {
                text: '❌ Failed to load Nigerian news. Try again later.'
            });
        }
    }
};