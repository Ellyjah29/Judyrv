const fs = require('fs');
const path = require('path');

function getAnticallPath(botId) {
    if (!botId || typeof botId !== 'string') {
        throw new Error(`Invalid botId: ${botId}. Expected string.`);
    }
    const dataDir = path.join(__dirname, '../data', botId);
    try {
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
    } catch (err) {
        console.error(`❌ Failed to create directory: ${dataDir}`, err);
        return null;
    }
    return path.join(dataDir, 'anticall.json');
}

function readState(botId) {
    const filePath = getAnticallPath(botId);
    if (!filePath) return { enabled: false };

    try {
        if (!fs.existsSync(filePath)) return { enabled: false };
        const raw = fs.readFileSync(filePath, 'utf8');
        const data = JSON.parse(raw || '{}');
        return { enabled: !!data.enabled };
    } catch (error) {
        console.error(`Error reading anticall state for bot ${botId}:`, error);
        return { enabled: false };
    }
}

function writeState(botId, enabled) {
    const filePath = getAnticallPath(botId);
    if (!filePath) return;

    try {
        fs.writeFileSync(filePath, JSON.stringify({ enabled: !!enabled }, null, 2));
    } catch (error) {
        console.error(`Error writing anticall state for bot ${botId}:`, error);
    }
}

async function anticallCommand(sock, chatId, message, args, botId) {
    if (!botId) {
        await sock.sendMessage(chatId, { text: '❌ Bot ID is missing. Cannot manage anticall state.' }, { quoted: message });
        return;
    }

    const state = readState(botId);
    const sub = (args || '').trim().toLowerCase();

    if (!sub || (sub !== 'on' && sub !== 'off' && sub !== 'status')) {
        await sock.sendMessage(chatId, {
            text: `*🛡️ ANTICALL*\n\n.anticall on   — Enable auto-block on incoming calls\n.anticall off  — Disable anticall\n.anticall status — Show current status`,
            quoted: message
        });
        return;
    }

    if (sub === 'status') {
        await sock.sendMessage(chatId, {
            text: `Anticall is currently *${state.enabled ? 'ON ✅' : 'OFF ❌'}* for bot: *${botId}*`,
            quoted: message
        });
        return;
    }

    const enable = sub === 'on';
    writeState(botId, enable);
    await sock.sendMessage(chatId, {
        text: `Anticall is now *${enable ? 'ENABLED 🟢' : 'DISABLED 🔴'}* for bot: *${botId}*`,
        quoted: message
    });
}

module.exports = { anticallCommand, readState };