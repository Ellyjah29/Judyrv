const { handleWelcome } = require('../lib/welcome');

async function welcomeCommand(sock, chatId, message, botId) {
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: 'This command can only be used in groups.' });
        return;
    }

    const text = message.message?.conversation || 
                 message.message?.extendedTextMessage?.text || '';
    const args = text.trim().split(' ').slice(1).join(' ') || '';

    await handleWelcome(sock, chatId, args, botId); // ✅ botId passed
}

module.exports = welcomeCommand;