// commands/tictactoe.js
const TicTacToe = require('../lib/tictactoe');

// Store games per botId
const games = {};

function getBotGames(botId) {
    if (!games[botId]) games[botId] = {};
    return games[botId];
}

// Generate interactive buttons for game state
function getGameButtons(room, isWaiting = false) {
    if (isWaiting) {
        return [
            { buttonId: `ttt_join_${room.id}`, buttonText: { displayText: '✅ Join Game' }, type: 1 },
            { buttonId: `ttt_cancel_${room.id}`, buttonText: { displayText: '❌ Cancel' }, type: 1 }
        ];
    } else {
        return [
            { buttonId: 'surrender', buttonText: { displayText: '🏳️ Surrender' }, type: 1 }
        ];
    }
}

async function tictactoeCommand(sock, chatId, senderId, text, botId) {
    try {
        const botGames = getBotGames(botId);

        // Prevent multiple games per user
        if (Object.values(botGames).find(room =>
            room.id.startsWith('tictactoe') &&
            [room.game.playerX, room.game.playerO].includes(senderId)
        )) {
            await sock.sendMessage(chatId, {
                text: '❌ You are already in a game. Type *surrender* or click the button to quit.'
            });
            return;
        }

        // Look for existing waiting room
        let room = Object.values(botGames).find(r =>
            r.state === 'WAITING'
        );

        if (room) {
            // Join the game
            room.o = chatId;
            room.game.playerO = senderId;
            room.state = 'PLAYING';

            const arr = room.game.render().map(v => ({
                'X': '❎', 'O': '⭕',
                '1': '1️⃣', '2': '2️⃣', '3': '3️⃣',
                '4': '4️⃣', '5': '5️⃣', '6': '6️⃣',
                '7': '7️⃣', '8': '8️⃣', '9': '9️⃣'
            }[v]));

            const str = `
🎮 *TicTacToe Game Started!*

Waiting for @${room.game.currentTurn.split('@')[0]} to play...

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ Player ❎: @${room.game.playerX.split('@')[0]}
▢ Player ⭕: @${room.game.playerO.split('@')[0]}
`;

            await sock.sendMessage(chatId, {
                text: str,
                mentions: [room.game.playerX, room.game.playerO, room.game.currentTurn],
                buttons: getGameButtons(room)
            });

        } else {
            // Create new room
            room = {
                id: 'tictactoe-' + (+new Date),
                x: chatId,
                o: '',
                game: new TicTacToe(senderId, 'o'),
                state: 'WAITING'
            };

            botGames[room.id] = room;

            await sock.sendMessage(chatId, {
                text: `⏳ *Waiting for opponent...*\n\nOthers can join by clicking the button below!`,
                buttons: getGameButtons(room, true)
            });
        }

    } catch (error) {
        console.error(`TicTacToe error (bot ${botId}):`, error);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to start game. Try again.'
        });
    }
}

// Handle button presses and text moves
async function handleTicTacToeMove(sock, chatId, senderId, input, botId) {
    try {
        const botGames = getBotGames(botId);
        const isSurrender = input === 'surrender';
        const isJoin = input.startsWith('ttt_join_');
        const isCancel = input.startsWith('ttt_cancel_');

        // Handle join via button
        if (isJoin) {
            const roomId = input.replace('ttt_join_', '');
            const room = botGames[roomId];
            if (!room || room.state !== 'WAITING') {
                await sock.sendMessage(chatId, { text: '❌ Invalid or expired game.' });
                return;
            }
            if (room.game.playerX === senderId) {
                await sock.sendMessage(chatId, { text: '❌ You cannot join your own game!' });
                return;
            }
            // Reuse the same command logic by calling tictactoeCommand
            await tictactoeCommand(sock, chatId, senderId, '', botId);
            return;
        }

        // Handle cancel (optional)
        if (isCancel) {
            const roomId = input.replace('ttt_cancel_', '');
            const room = botGames[roomId];
            if (room && room.game.playerX === senderId) {
                delete botGames[roomId];
                await sock.sendMessage(chatId, { text: '✅ Game cancelled.' });
            }
            return;
        }

        // Handle move or surrender
        const room = Object.values(botGames).find(r =>
            r.id.startsWith('tictactoe') &&
            [r.game.playerX, r.game.playerO].includes(senderId) &&
            r.state === 'PLAYING'
        );

        if (!room) return;

        if (!isSurrender && !/^[1-9]$/.test(input)) return;

        if (senderId !== room.game.currentTurn && !isSurrender) {
            await sock.sendMessage(chatId, { text: '❌ Not your turn!' });
            return;
        }

        let ok = isSurrender ? true : room.game.turn(
            senderId === room.game.playerO,
            parseInt(input) - 1
        );

        if (!ok && !isSurrender) {
            await sock.sendMessage(chatId, {
                text: '❌ Invalid move! That position is taken.'
            });
            return;
        }

        let winner = room.game.winner;
        let isTie = room.game.turns === 9;

        const arr = room.game.render().map(v => ({
            'X': '❎', 'O': '⭕',
            '1': '1️⃣', '2': '2️⃣', '3': '3️⃣',
            '4': '4️⃣', '5': '5️⃣', '6': '6️⃣',
            '7': '7️⃣', '8': '8️⃣', '9': '9️⃣'
        }[v]));

        if (isSurrender) {
            winner = senderId === room.game.playerX ? room.game.playerO : room.game.playerX;
            await sock.sendMessage(chatId, {
                text: `🏳️ @${senderId.split('@')[0]} surrendered!\n🎉 @${winner.split('@')[0]} wins!`,
                mentions: [senderId, winner]
            });
            delete botGames[room.id];
            return;
        }

        let gameStatus;
        if (winner) {
            gameStatus = `🎉 @${winner.split('@')[0]} wins!`;
        } else if (isTie) {
            gameStatus = `🤝 It's a draw!`;
        } else {
            gameStatus = `🎲 Turn: @${room.game.currentTurn.split('@')[0]}`;
        }

        const str = `
🎮 *TicTacToe*

${gameStatus}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ Player ❎: @${room.game.playerX.split('@')[0]}
▢ Player ⭕: @${room.game.playerO.split('@')[0]}
`;

        const mentions = [room.game.playerX, room.game.playerO];
        if (winner) mentions.push(winner);
        else mentions.push(room.game.currentTurn);

        await sock.sendMessage(room.x, {
            text: str,
            mentions,
            buttons: winner || isTie ? [] : getGameButtons(room)
        });

        if (room.x !== room.o) {
            await sock.sendMessage(room.o, {
                text: str,
                mentions,
                buttons: winner || isTie ? [] : getGameButtons(room)
            });
        }

        if (winner || isTie) {
            delete botGames[room.id];
        }

    } catch (error) {
        console.error(`TicTacToe move error (bot ${botId}):`, error);
    }
}

module.exports = {
    tictactoeCommand,
    handleTicTacToeMove
};