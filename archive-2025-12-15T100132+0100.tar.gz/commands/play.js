const axios = require('axios');
const yts = require('yt-search');

// =========================================
// 🎨 DESIGN & THEME CONFIGURATION
// =========================================
const icons = {
    music : '🎵',   search: '🔎',    time  : '⏱️',
    down  : '⬇️',   check : '✅',    err   : '❌',
    play  : '▶️',   bot   : '🤖'
};

const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.music} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

// =========================================
// 🌐 API HELPERS
// =========================================
const AXIOS_DEFAULTS = {
    timeout: 60000,
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
};

async function tryRequest(getter, attempts = 3) {
    let lastError;
    for (let attempt = 1; attempt <= attempts; attempt++) {
        try { return await getter(); } catch (err) {
            lastError = err;
            if (attempt < attempts) await new Promise(r => setTimeout(r, 1000 * attempt));
        }
    }
    throw lastError;
}

async function getIzumiDownloadByUrl(youtubeUrl) {
    const apiUrl = `https://izumiiiiiiii.dpdns.org/downloader/youtube?url=${encodeURIComponent(youtubeUrl)}&format=mp3`;
    const res = await tryRequest(() => axios.get(apiUrl, AXIOS_DEFAULTS));
    if (res?.data?.result?.download) return res.data.result;
    throw new Error('Izumi returned no download');
}

async function getIzumiDownloadByQuery(query) {
    const apiUrl = `https://izumiiiiiiii.dpdns.org/downloader/youtube-play?query=${encodeURIComponent(query)}`;
    const res = await tryRequest(() => axios.get(apiUrl, AXIOS_DEFAULTS));
    if (res?.data?.result?.download) return res.data.result;
    throw new Error('Izumi search returned no download');
}

async function getOkatsuDownloadByUrl(youtubeUrl) {
    const apiUrl = `https://okatsu-rolezapiiz.vercel.app/downloader/ytmp3?url=${encodeURIComponent(youtubeUrl)}`;
    const res = await tryRequest(() => axios.get(apiUrl, AXIOS_DEFAULTS));
    if (res?.data?.dl) return { download: res.data.dl, title: res.data.title, thumbnail: res.data.thumb };
    throw new Error('Okatsu returned no download');
}

// =========================================
// 🚀 COMMAND HANDLER
// =========================================
async function songCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
        
        if (!text) {
            const usage = makeCard("Song Downloader", [` ${icons.search}  *Missing Song Name*`, "---", " Please provide a title or link."]);
            await sock.sendMessage(chatId, { text: usage }, { quoted: message });
            return;
        }

        // Search Video
        let video;
        if (text.includes('youtube.com') || text.includes('youtu.be')) {
            video = { url: text, title: 'YouTube Link', timestamp: 'Unknown' };
        } else {
            const search = await yts(text);
            if (!search || !search.videos.length) {
                await sock.sendMessage(chatId, { text: `❌ *No results found.*` }, { quoted: message });
                return;
            }
            video = search.videos[0];
        }

        // Send "Downloading" Card
        const cardCaption = makeCard("Fetching Audio", [
            ` ${icons.play}  *Title:* ${video.title}`,
            ` ${icons.time}  *Duration:* ${video.timestamp}`,
            "---",
            ` ${icons.down}  _Downloading..._`
        ]);

        await sock.sendMessage(chatId, {
            image: { url: video.thumbnail || 'https://i.imgur.com/3K1d1i3.jpeg' },
            caption: cardCaption
        }, { quoted: message });

        // Fetch Audio
        let audioData;
        try {
            audioData = await getIzumiDownloadByUrl(video.url);
        } catch (e1) {
            try {
                const query = video.title || text;
                audioData = await getIzumiDownloadByQuery(query);
            } catch (e2) {
                audioData = await getOkatsuDownloadByUrl(video.url);
            }
        }

        // 🟢 FINAL MESSAGE
        await sock.sendMessage(chatId, {
            audio: { url: audioData.download || audioData.dl || audioData.url },
            mimetype: 'audio/mpeg',
            fileName: `${(audioData.title || video.title || 'song')}.mp3`,
            ptt: false,
            contextInfo: {
                externalAdReply: {
                    title: "🎵 Powered by Septorch",
                    body: "Click to Join Channel",
                    mediaType: 1,
                    thumbnailUrl: video.thumbnail || 'https://i.imgur.com/3K1d1i3.jpeg',
                    // 👇 HARDCODED LINK
                    sourceUrl: 'https://whatsapp.com/channel/0029Vb1ydGk8qIzkvps0nZ04', 
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: message });

    } catch (err) {
        console.error('Song command error:', err);
        await sock.sendMessage(chatId, { text: `❌ *Download Failed.*` }, { quoted: message });
    }
}

module.exports = songCommand;