const settings = require('../settings');
const { sendButtons } = require('gifted-btns');
const process = require('process');
const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg'); 

// =========================================
// 🛠️ HELPER: AUTO-RESIZE VIDEO
// =========================================
const resizeVideo = (inputPath, outputPath) => {
    return new Promise((resolve, reject) => {
        console.log("⚙️  Resizing menu video... please wait.");
        ffmpeg(inputPath)
            .size('640x640')            
            .autoPad(true, 'black')     
            .fps(25)
            .duration(10)               
            .noAudio()                  
            .outputOptions('-preset', 'ultrafast')
            .on('end', () => {
                console.log("✅ Video resized successfully!");
                resolve(outputPath);
            })
            .on('error', (err) => {
                console.error("❌ Error resizing video:", err);
                reject(err);
            })
            .save(outputPath);
    });
};

// =========================================
// 🎨 DESIGN & THEME CONFIGURATION
// =========================================
const icons = {
    bot   : '🤖',   menu  : '📂',   cmd    : '⚡',
    arrow : '➔',    star  : '🌟',   gear  : '⚙️',
    warn  : '⚠️',   next  : '➡️',   prev  : '⬅️',
    back  : '🔙',   tip   : '💡'
};

const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    const header = `│  ${icons.bot} *${title.toUpperCase()}*`;
    
    const body = contentLines.map(line => {
        if (line === '---') return divider;
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

// =========================================
// 🗂️ STATIC COMMAND CATEGORIES (BASE)
// =========================================
const baseCategories = {
  general: {
    title: '🧰 General',
    commands: [
      '.help - Show this help menu',
      '.menu - Show interactive menu',
      '.bot [query] - Ask AI',
      '.list - List all commands',
      '.ping - Check bot speed',
      '.alive - Check bot status',
      '.tts <text> - Text to speech',
      '.stt - Reply to a voice note to transcribe it to text',
      '.news - Latest news',
      '.weather <city> - Weather info',
      '.lyrics <song> - Song lyrics',
      '.groupinfo - Group details',
      '.staff - List staff'
    ]
  },
  sports: {
    title: '🏆 Sports',
    commands: [
      '.livescore - Main Score Center',
      '.livescore football - Football scores',
      '.livescore auto <league> on - Auto updates',
      '.livescore basketball - NBA scores',
      '.livescore tennis - Tennis scores',
      '.livescore cricket - Cricket scores'
    ]
  },
  sticker: {
    title: '🎨 Stickers & Reacts',
    commands: [
      '.sticker - Convert media to sticker',
      '.simage - Convert sticker to image',
      '.tgsticker <url> - Telegram stickers',
      '.take <name> - Change sticker metadata',
      '.emojimix - Mix emojis (e.g. 😄+😍)',
      '.attp <text> - Animated text sticker',
      '.nom / .poke / .cry - Anime reactions',
      '.kiss / .pat / .hug - Anime reactions',
      '.wink / .facepalm - Anime reactions',
      '.neko / .waifu / .loli - Random Anime Images'
    ]
  },
  admin: {
    title: '⚙️ Admin',
    commands: [
      '.ban @user - Ban user',
      '.kick @user - Kick user',
      '.promote @user - Make admin',
      '.demote @user - Remove admin',
      '.mute <min> - Mute chat',
      '.unmute - Unmute chat',
      '.delete - Delete message',
      '.tagall - Tag everyone',
      '.antilink on/off - Link protect',
      '.antibadword on/off - Bad word filter',
      '.clear - Clear chat',
      '.resetlink - Reset invite link'
    ]
  },
  owner: {
    title: '👑 Owner',
    commands: [
      '.mode public/private - Bot mode',
      '.autostatus on/off - Status view',
      '.antidelete on/off - Msg protect',
      '.setpp - Set bot PP',
      '.autoreact on/off - Auto react',
      '.autoreply add/list - Auto replies',
      '.fake typing/recording - Fake presence',
      '.switchfake - Toggle fake presence',
      // SCHEDULER
      '.schedule <time> <msg> - Schedule msg',
      '.myschedules - Check queue',
      '.unschedule <id> - Cancel msg',
      '.clearschedule - Clear all',
      // PLUGINS
      '.externalplugin <url> - Install Plugin'
    ]
  },
  utility: {
    title: '🔧 Utility',
    commands: [
      '.ocr - Read image text',
      '.bible <ref> - Read Bible',
      '.urlshort <url> - Shorten link',
      '.upload - File to URL',
      '.notes on/off - AI Notes',
      '.ss / .ssweb <url> - Screenshot site',
      '.trt / .translate - Translate text'
    ]
  },
  ai: {
    title: '🤖 AI Tools',
    commands: [
      '.gpt <text> - ChatGPT',
       '.vision <text> - Analyze an image (Reply to image)',
      '.gemini <text> - Gemini AI',
      '.imagine <idea> - Image Gen',
      '.flux <idea> - Flux Gen'
    ]
  },
  downloads: {
    title: '📥 Downloads',
    commands: [
      '.play <song> - YT Audio',
      '.video <url> - YT Video',
      '.tiktok <url> - TikTok DL',
      '.instagram <url> - Insta DL',
      '.facebook <url> - FB DL',
      '.threads <url> - Threads DL'
    ]
  },
  games: {
    title: '🎲 Games',
    commands: [
      '.ttt @user - Tic-Tac-Toe',
      '.hangman - Guess word',
      '.trivia - Quiz',
      '.mathgame - Math puzzle',
      '.riddle - Solve riddles',
      '.adv - Adventure game'
    ]
  },
  fun: {
    title: '🎮 Fun',
    commands: [
      '.compliment @user - Nice words',
      '.insult @user - Roast user',
      '.ship - Love calculator',
      '.meme - Random meme',
      '.flirt / .shayari - Romantic lines',
      '.goodnight / .roseday - Wishes',
      '.wasted - Wasted effect',
      '.simp / .stupid @user - Rate user'
    ]
  }
};

function paginate(items, perPage = 6) {
  const pages = [];
  for (let i = 0; i < items.length; i += perPage) {
    pages.push(items.slice(i, i + perPage));
  }
  return pages;
}

// =========================================
// 🚀 MAIN MENU HANDLER
// =========================================

async function menuCommand(sock, chatId, command = null, page = 0, senderName = 'User') {
  try {
    const botName = settings.botName || 'SEPTORCH';
    const date = new Date().toLocaleDateString();

    // 🟢 1. DYNAMICALLY MERGE PLUGINS INTO CATEGORIES
    // We create a copy so we don't duplicate items on every run
    const categories = JSON.parse(JSON.stringify(baseCategories));

    if (global.plugins) {
        global.plugins.forEach((plugin) => {
            const cmdName = Array.isArray(plugin.cmd) ? plugin.cmd[0] : plugin.cmd;
            // Match category names (admin, general, etc.)
            let catKey = plugin.category ? plugin.category.toLowerCase() : 'other';
            
            // Handle some common mappings
            if (catKey === 'tools') catKey = 'utility';
            if (catKey === 'game') catKey = 'games';
            if (catKey === 'download') catKey = 'downloads';

            const description = plugin.desc || 'Plugin Command';
            const entry = `.${cmdName} - ${description}`;

            // Add to existing category or create new one
            if (categories[catKey]) {
                // Prevent duplicates
                if (!categories[catKey].commands.some(c => c.startsWith(`.${cmdName}`))) {
                    categories[catKey].commands.push(entry);
                }
            } else {
                categories[catKey] = {
                    title: `🧩 ${catKey.charAt(0).toUpperCase() + catKey.slice(1)}`,
                    commands: [entry]
                };
            }
        });
    }

    // 🟢 2. PREPARE VIDEO
    const rawVideoPath = path.join(__dirname, '../assets/bot_video.mp4'); 
    const resizedVideoPath = path.join(__dirname, '../assets/bot_menu_resized.mp4');
    let finalVideoBuffer = null;

    if (fs.existsSync(resizedVideoPath)) {
        finalVideoBuffer = fs.readFileSync(resizedVideoPath);
    } else if (fs.existsSync(rawVideoPath)) {
        try {
            await sock.sendMessage(chatId, { text: '_🎨 Optimizing menu video..._' });
            await resizeVideo(rawVideoPath, resizedVideoPath);
            finalVideoBuffer = fs.readFileSync(resizedVideoPath);
        } catch (e) {
            console.log("Resize failed, using raw video.");
            finalVideoBuffer = fs.readFileSync(rawVideoPath);
        }
    }

    // 🟢 3. SEND VIDEO FIRST
    if (finalVideoBuffer) {
        await sock.sendMessage(chatId, { 
            video: finalVideoBuffer, 
            gifPlayback: true 
        });
    }

    // 🟢 4. SEND MENU CARD
    if (!command) {
      const menuCard = makeCard(botName, [
          ` ${icons.star}  *Welcome, ${senderName}!*`,
          ` 📅  *Date:* ${date}`,
          ` 📂  *Categories:* ${Object.keys(categories).length}`,
          '---',
          ' Select a category below',
          ' to explore features.',
          '---',
          ` ${icons.tip}  *Tip:* Use *.list* to`,
          ' view all commands quickly.'
      ]);

      // Generate buttons dynamically based on categories
      const buttons = Object.keys(categories).map(catKey => {
          return { id: `.menu ${catKey}`, text: categories[catKey].title };
      });

      await sendButtons(sock, chatId, {
        text: menuCard,
        footer: `v${settings.version || '2.0.0'} • Public Mode`,
        buttons: buttons
      });

    } else {
      // Sub-menu logic
      const key = command.trim().toLowerCase();
      const cat = categories[key];

      if (!cat) return await sock.sendMessage(chatId, { text: '❌ *Category not found.*' });

      const pages = paginate(cat.commands, 8); 
      const pageNum = parseInt(page, 10) || 0;

      if (pageNum >= pages.length || pageNum < 0) return await sock.sendMessage(chatId, { text: '❌ *Invalid Page.*' });

      const currentPage = pages[pageNum];
      
      const cmdList = currentPage.map(cmd => {
          const [trigger, desc] = cmd.split(' - ');
          return ` ${icons.cmd} *${trigger}*` + (desc ? `\n    └ ${desc}` : '');
      });

      const catCard = makeCard(`${cat.title} (${pageNum + 1}/${pages.length})`, cmdList);

      const buttons = [];
      if (pageNum > 0) buttons.push({ id: `.menu ${key} ${pageNum - 1}`, text: `${icons.prev} Previous` });
      if (pageNum < pages.length - 1) buttons.push({ id: `.menu ${key} ${pageNum + 1}`, text: `${icons.next} Next` });
      buttons.push({ id: '.menu', text: `${icons.back} Main Menu` });

      await sendButtons(sock, chatId, {
        text: catCard,
        footer: `${botName} • ${cat.title}`,
        buttons
      });
    }
  } catch (err) {
    console.error('Menu error:', err);
    await sock.sendMessage(chatId, { text: '❌ *Menu Error:* Check console/video path.' });
  }
}

module.exports = {
  menuCommand
};