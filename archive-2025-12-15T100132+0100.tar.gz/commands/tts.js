const { synthesize, languageMap } = require('../lib/gtts-modules');

module.exports = async (sock, chatId, text, botId) => {
    try {
        // 1. Validation
        if (!text) {
            await sock.sendMessage(chatId, { 
                text: '❌ Usage: .tts <text>\nOr for language: .tts <lang>|<text>\nExample: .tts es|Hola amigos' 
            });
            return;
        }

        // 2. Parse Language (Format: "es|Hola world")
        // Default to English ('en')
        let lang = 'en'; 
        let content = text;

        // Check for the separator pipe "|"
        if (text.includes('|')) {
            const parts = text.split('|');
            const potentialLang = parts[0].trim().toLowerCase();
            
            // If the first part is a valid language code (e.g. 'es', 'fr', 'ja')
            if (languageMap[potentialLang]) {
                lang = potentialLang;
                content = parts.slice(1).join('|').trim();
            }
        }

        // 3. Generate Audio Buffer
        const audioBuffer = await synthesize(content, lang);

        // 4. Send Voice Note
        await sock.sendMessage(chatId, { 
            audio: audioBuffer, 
            mimetype: 'audio/mp4', 
            ptt: true // This makes it appear as a Blue Microphone (Voice Note)
        });

    } catch (error) {
        console.error('TTS Command Error:', error);
        await sock.sendMessage(chatId, { text: '❌ Failed to generate audio. Please try again.' });
    }
};