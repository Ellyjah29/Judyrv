const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { writeFile } = require('fs/promises');

/* =========================================
   🎨  DESIGN & THEME CONFIGURATION
   ========================================= */
const prefix = '.';

// Updated, cleaner icon set
const icons = {
    shield : '🛡️',  user: '👤',   time: '🕒',   
    trash  : '🗑️',  chat: '💬',   group: '👥',
    on     : '🟢',  off: '🔴',   warn: '⚠️', 
    err    : '⛔',  info: 'ℹ️',   media: '📷',
    arrow  : '➔',   dot : '◈'
};

// New "Card" Design Function
const makeCard = (title, contentLines) => {
    const borderTop = '╭───────────────────────────╮';
    const borderBtm = '╰───────────────────────────╯';
    const divider   = '├───────────────────────────┤';
    
    // Center the title visually
    const header = `│  ${icons.shield} *${title.toUpperCase()}*`;
    
    // Format body lines
    const body = contentLines.map(line => {
        // If line is a separator, use the divider
        if (line === '---') return divider;
        // Otherwise, pad plain text
        return `│ ${line}`;
    }).join('\n');

    return `${borderTop}\n${header}\n${divider}\n${body}\n${borderBtm}`;
};

const sendCard = (sock, chatId, title, lines, extra = {}) =>
    sock.sendMessage(chatId, { text: makeCard(title, lines), ...extra });

/* =========================================
   🗂️  PER-BOT STATE
   ========================================= */
const messageStore = {}; // { botId: Map }

/* ---------- config helpers ---------- */
const cfgPath = botId => path.join(__dirname, `../data/${botId}/antidelete.json`);
const loadCfg  = botId => {
  try {
    if (!fs.existsSync(cfgPath(botId))) return { enabled: false };
    return JSON.parse(fs.readFileSync(cfgPath(botId)));
  } catch { return { enabled: false }; }
};
const saveCfg = (botId, cfg) =>
  fs.writeFileSync(cfgPath(botId), JSON.stringify(cfg, null, 2));

/* ---------- media temp folder ---------- */
const tmpDir = botId => {
  const dir = path.join(__dirname, `../tmp/${botId}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

/* =========================================
   📜  COMMAND HANDLER
   ========================================= */
async function handleAntideleteCommand(sock, chatId, message, arg, botId) {
  if (!message.key.fromMe)
    return sendCard(sock, chatId, 'ACCESS DENIED', [
      ` ${icons.err}  *Only the Bot Owner can use this.*`
    ]);

  const cfg = loadCfg(botId);

  if (!arg) {
    return sendCard(sock, chatId, 'CONFIGURATION', [
      ` ${icons.info}  *Current Status:* ${cfg.enabled ? '🟢 ACTIVE' : '🔴 DISABLED'}`,
      '---',
      ` ${icons.dot}  *${prefix}antidelete on*`,
      `    ${icons.arrow} Turn Protection ON`,
      '',
      ` ${icons.dot}  *${prefix}antidelete off*`,
      `    ${icons.arrow} Turn Protection OFF`
    ]);
  }

  if (arg === 'on' || arg === 'off') {
    cfg.enabled = arg === 'on';
    saveCfg(botId, cfg);
    const statusText = cfg.enabled ? 'ENABLED' : 'DISABLED';
    const statusIcon = cfg.enabled ? icons.on : icons.off;
    
    return sendCard(sock, chatId, 'SYSTEM UPDATE', [
      ` ${statusIcon}  Antidelete is now *${statusText}*`
    ]);
  }

  return sendCard(sock, chatId, 'ERROR', [
    ` ${icons.warn}  Invalid command usage.`,
    ` Type *${prefix}antidelete* for the menu.`
  ]);
}

/* =========================================
   💾  STORE EVERY INCOMING MESSAGE
   ========================================= */
async function storeMessage(message, botId) {
  const cfg = loadCfg(botId);
  if (!cfg.enabled || !message.key?.id) return;

  try {
    const id      = message.key.id;
    const sender  = message.key.participant || message.key.remoteJid;
    const group   = message.key.remoteJid.endsWith('@g.us') ? message.key.remoteJid : null;

    let content   = '';
    let mediaType = '';
    let mediaPath = '';

    let msg = message.message;

    // 🔍 Handle view-once wrappers
    if (msg?.viewOnceMessage) msg = msg.viewOnceMessage.message;
    else if (msg?.viewOnceMessageV2) msg = msg.viewOnceMessageV2.message;
    else if (msg?.viewOnceMessageV2Extension) msg = msg.viewOnceMessageV2Extension.message;

    if (msg?.conversation) {
      content = msg.conversation;
    } else if (msg?.extendedTextMessage?.text) {
      content = msg.extendedTextMessage.text;
    }

    // ---------- handle all known media ----------
    const mediaMap = {
      imageMessage: 'jpg',
      videoMessage: 'mp4',
      stickerMessage: 'webp',
      audioMessage: 'mp3',
      documentMessage: '',
      contactMessage: 'vcf',
      locationMessage: 'json',
      liveLocationMessage: 'json',
      ptvMessage: 'mp4'
    };

    for (const [key, ext] of Object.entries(mediaMap)) {
      if (msg?.[key]) {
        mediaType = key.replace('Message', '');
        const mediaMsg = msg[key];
        const caption = mediaMsg.caption || '';
        if (caption) content = caption;

        const stream = await downloadContentFromMessage(mediaMsg, mediaType.includes('audio') ? 'audio' : mediaType);
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const buffer = Buffer.concat(chunks);

        let filename = `${id}.${ext || (mediaMsg?.fileName?.split('.').pop() || 'dat')}`;
        mediaPath = path.join(tmpDir(botId), filename);
        await writeFile(mediaPath, buffer);
        break;
      }
    }

    if (!messageStore[botId]) messageStore[botId] = new Map();
    messageStore[botId].set(id, {
      content, mediaType, mediaPath, sender, group,
      timestamp: Date.now()
    });
  } catch (e) {
    console.error(`storeMessage[${botId}]`, e);
  }
}

/* =========================================
   🚨  HANDLE MESSAGE DELETION (The Report)
   ========================================= */
async function handleMessageRevocation(sock, revocation, botId) {
  const cfg = loadCfg(botId);
  if (!cfg.enabled) return;

  try {
    const msgId  = revocation.message.protocolMessage.key.id;
    const by     = revocation.participant || revocation.key.participant || revocation.key.remoteJid;
    const owner  = `${sock.user.id.split(':')[0]}@s.whatsapp.net`;
    if (by.includes(sock.user.id) || by === owner) return;

    const store  = messageStore[botId] || new Map();
    const orig   = store.get(msgId);
    if (!orig) return;

    const [byTag, sendTag] = [by, orig.sender].map(jid => `@${jid.split('@')[0]}`);
    const groupName = orig.group ? (await sock.groupMetadata(orig.group)).subject : '';

    const ts = new Date().toLocaleString('en-US', {
      timeZone: 'Africa/Lagos', hour12: true,
      hour:'2-digit', minute:'2-digit', second:'2-digit',
      day:'2-digit', month:'2-digit', year:'numeric'
    });

    // 🎨 DESIGN: Structured Report Layout
    const lines = [
      ` ${icons.trash}  *DELETION DETECTED*`,
      '---',
      ` ${icons.user}  *Triggered By:*`,
      `    ${byTag}`,
      '',
      ` ${icons.chat}  *Original Sender:*`,
      `    ${sendTag}`,
      '',
      ` ${icons.time}  *Time:* ${ts}`,
      ...(groupName ? [` ${icons.group}  *Group:* ${groupName}`] : []),
      '---',
      orig.content ? `📝 *Message Content:*\n${orig.content}` : ` ${icons.media} *Media File Deleted*`
    ];

    await sendCard(sock, owner, 'SECURITY REPORT', lines, { mentions: [by, orig.sender] });

    /* ----- forward any media type ----- */
    if (orig.mediaType && fs.existsSync(orig.mediaPath)) {
      const opts = { caption: `${icons.shield} *Restored Media* from ${sendTag}`, mentions:[orig.sender] };

      try {
        switch (orig.mediaType) {
          case 'image':
            await sock.sendMessage(owner, { image: { url: orig.mediaPath }, ...opts }); break;
          case 'video':
          case 'ptv':
            await sock.sendMessage(owner, { video: { url: orig.mediaPath }, ...opts }); break;
          case 'sticker':
            await sock.sendMessage(owner, { sticker: { url: orig.mediaPath }, ...opts }); break;
          case 'audio':
            await sock.sendMessage(owner, { audio: { url: orig.mediaPath }, mimetype: 'audio/mpeg', ...opts }); break;
          case 'document':
            await sock.sendMessage(owner, { document: { url: orig.mediaPath }, fileName: path.basename(orig.mediaPath), ...opts }); break;
          case 'contact':
            await sock.sendMessage(owner, { contacts: { displayName: 'Deleted Contact', contacts: [{ vcard: fs.readFileSync(orig.mediaPath, 'utf-8') }] }, ...opts }); break;
          case 'location':
          case 'liveLocation':
            const loc = JSON.parse(fs.readFileSync(orig.mediaPath, 'utf-8'));
            await sock.sendMessage(owner, { location: loc, ...opts }); break;
          default:
            await sendCard(sock, owner, 'MEDIA ERROR', [`${icons.warn} Unsupported media type: ${orig.mediaType}`]);
        }
      } catch (err) {
        await sendCard(sock, owner, 'SYSTEM ERROR', [`${icons.err} Failed to send media: ${err.message}`]);
      }

      fs.unlink(orig.mediaPath, () => {});
    }

    store.delete(msgId);
  } catch (e) {
    console.error(`handleMessageRevocation[${botId}]`, e);
  }
}

/* =========================================
   🌟  EXPORTS
   ========================================= */
module.exports = {
  handleAntideleteCommand,
  storeMessage,
  handleMessageRevocation
};