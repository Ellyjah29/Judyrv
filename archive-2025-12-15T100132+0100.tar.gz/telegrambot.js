const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

// --- Configuration ---
const BOT_TOKEN = process.env.BOT_TOKEN || '8150573168:AAEd5irWgwm4cSNbBIL_XIesTL-g-Ua-9MA';
if (!BOT_TOKEN || BOT_TOKEN === 'REPLACE_WITH_VALID_TOKEN') {
    console.error('❌ TELEGRAM_BOT_TOKEN must be set and valid.');
    process.exit(1);
}
const ADMIN_ID = '7738315673';
const ADMIN_PASSWORD = 'TEAMSEPTORCH';
// --- END Configuration ---

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const RESTART_COOLDOWN = 15 * 60 * 1000;
const settingsPath = path.join(__dirname, 'settings.js');
let settings = {};
const interactedUsersPath = path.join(__dirname, 'interactedUsers.json');
let interactedUsers = new Set();

// --- Utility Functions ---
function loadInteractedUsers() {
    if (fs.existsSync(interactedUsersPath)) {
        try {
            const data = fs.readFileSync(interactedUsersPath, 'utf8');
            const userList = JSON.parse(data);
            interactedUsers = new Set(userList);
        } catch (err) {
            console.error('Failed to load interactedUsers.json:', err);
            interactedUsers = new Set();
        }
    } else {
        interactedUsers = new Set();
    }
}

function saveInteractedUsers() {
    const userList = Array.from(interactedUsers);
    fs.writeFileSync(interactedUsersPath, JSON.stringify(userList, null, 2));
}

function loadSettings() {
    delete require.cache[require.resolve('./settings')];
    settings = require('./settings');
}

function saveSettings() {
    const botsToSave = settings.bots || [];
    const userStatesToSave = settings.userStates || {};
    const blacklistedUsersToSave = settings.blacklistedUsers || [];
    const data = `exports.bots = ${JSON.stringify(botsToSave, null, 2)};
exports.userStates = ${JSON.stringify(userStatesToSave, null, 2)};
exports.blacklistedUsers = ${JSON.stringify(blacklistedUsersToSave, null, 2)};`;
    fs.writeFileSync(settingsPath, data);
    loadSettings();
}

function escapeMarkdown(text) {
    if (typeof text !== 'string') return '';
    return text.replace(/([_*\[\]()~`>#+\-=|{}.!\\])/g, '\\$1');
}

function getBotByAuthKey(inputKey) {
    return settings.bots.find(bot => bot.authKey === inputKey);
}

function getUserBots(chatId) {
    return settings.bots.filter(bot => bot.telegramUserId === chatId);
}

function isExpired(bot) {
    return bot.expiry && new Date(bot.expiry) < new Date();
}

async function notifyExpiringBots() {
    const now = new Date();
    for (const botConfig of settings.bots) {
        if (botConfig.expiry && botConfig.telegramUserId) {
            const expiryDate = new Date(botConfig.expiry);
            const diffTime = expiryDate - now;
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            const chatId = botConfig.telegramUserId;
            if ((diffDays === 3 || diffDays === 1) && diffTime > 0) {
                try {
                    await bot.sendMessage(chatId, `⚠️ Your bot "${botConfig.botName || 'Unnamed Bot'}" will expire in ${diffDays} day(s). Please renew.`);
                } catch (err) {
                    console.error(`Failed to send expiry notice to ${chatId}:`, err.message);
                }
            } else if (diffDays <= 0 && !botConfig.expiredAt) {
                delete botConfig.SESSION_ID;
                botConfig.telegramUserId = null;
                botConfig.expiredAt = botConfig.expiry;
                saveSettings();
            }
        }
    }
}

setInterval(notifyExpiringBots, 1000 * 60 * 60 * 6);

function isAdmin(chatId) {
    return String(chatId) === ADMIN_ID;
}

function isBotRunning(botId) {
    return global.botInstances?.[botId]?.user != null;
}

function mainMenu(isAdminUser = false) {
    const buttons = [
        [{ text: '🔌 Connect Bot', callback_data: 'connect_bot' }],
        [{ text: '🛑 Stop Bot', callback_data: 'stop_bot' }],
        [{ text: '📋 My Bots', callback_data: 'my_bots' }],
        [{ text: '🛒 Buy Authorization Key', url: 'https://t.me/SEPTORCHBOT' }],
        [{ text: '❓ Help', callback_data: 'help' }]
    ];
    if (isAdminUser) {
        buttons.push([{ text: '🛠 Admin Panel', callback_data: 'admin_panel' }]);
    }
    return { reply_markup: { inline_keyboard: buttons } };
}

// --- Initialize ---
loadSettings();
loadInteractedUsers();
console.log('Bot settings and interacted users loaded.');

// --- /start Command ---
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const name = msg.chat.first_name || 'User';
    const escapedName = escapeMarkdown(name);
    const welcomeMessage = `👋 Hi ${escapedName}!
Welcome to SEPTORCH Bot Manager!`;
    if (!interactedUsers.has(String(chatId))) {
        interactedUsers.add(String(chatId));
        saveInteractedUsers();
    }
    await bot.sendMessage(chatId, welcomeMessage, {
        parse_mode: 'Markdown',
        reply_markup: mainMenu(isAdmin(chatId)).reply_markup
    });
    if (settings.userStates[chatId]) {
        delete settings.userStates[chatId];
        saveSettings();
    }
});

// --- Callback Queries ---
bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const data = query.data;
    const name = query.message.chat.first_name || 'User';
    try {
        if (data === 'connect_bot') {
            await bot.editMessageText(`🔑 Send your *Authorization Key* to connect a bot.`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🛒 Buy Now', url: 'https://t.me/SEPTORCHBOT' }],
                        [{ text: '⬅️ Back', callback_data: 'back_to_menu' }]
                    ]
                }
            });
            settings.userStates[chatId] = { step: 'awaiting_auth_key', promptMessageId: messageId };
            saveSettings();
        } else if (data === 'stop_bot') {
            await bot.editMessageText(`🔑 Send your *Authorization Key* to stop your bot.`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🛒 Buy Now', url: 'https://t.me/SEPTORCHBOT' }],
                        [{ text: '⬅️ Back', callback_data: 'back_to_menu' }]
                    ]
                }
            });
            settings.userStates[chatId] = { step: 'awaiting_stop_auth_key', promptMessageId: messageId };
            saveSettings();
        } else if (data === 'my_bots' || data.startsWith('my_bots_page:')) {
            const page = data.startsWith('my_bots_page:') ? parseInt(data.split(':')[1]) : 0;
            const bots = getUserBots(chatId);
            const BOTS_PER_PAGE = 3;
            const totalPages = Math.ceil(bots.length / BOTS_PER_PAGE);
            const start = page * BOTS_PER_PAGE;
            const paginatedBots = bots.slice(start, start + BOTS_PER_PAGE);
            if (bots.length === 0) {
                await bot.editMessageText(`🤖 You are not managing any bots yet.`, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'back_to_menu' }]]
                    }
                });
                return;
            }
            let response = `🤖 *Your Bots* (Page ${page + 1}/${totalPages}):
`;
            let keyboard = [];
            paginatedBots.forEach(b => {
                const status = isExpired(b) ? '❌ Expired' : '✅ Active';
                const escapedBotName = escapeMarkdown(b.botName || 'Unnamed Bot');
                const escapedAuthKey = escapeMarkdown(b.authKey);
                const escapedExpiry = escapeMarkdown(b.expiry || b.createdAt || 'N/A');
                const botId = `bot${settings.bots.indexOf(b) + 1}`;
                const isRunning = isBotRunning(botId);
                response += `${escapedBotName} (${b.themeemoji || ''})
`;
                response += `   Key: \`${escapedAuthKey}\`
`;
                response += `   Status: ${status} ${isRunning ? '🟢' : '🔴'}
`;
                response += `   Expires: ${escapedExpiry}
`;
                let actionRow = [];
                if (isRunning) {
                    actionRow.push({ text: '🛑 Stop', callback_data: `stop_bot_permanent:${b.authKey}` });
                    actionRow.push({ text: '🔄 Reconnect', callback_data: `reconnect_bot:${b.authKey}` });
                } else {
                    actionRow.push({ text: '▶️ Start', callback_data: `start_bot:${b.authKey}` });
                    if (b.SESSION_ID) {
                        actionRow.push({ text: '🔄 Reconnect', callback_data: `reconnect_bot:${b.authKey}` });
                    }
                }
                let manageRow = [
                    { text: '📝 Rename', callback_data: `rename_bot:${b.authKey}` },
                    { text: '📱 Owner', callback_data: `view_owner:${b.authKey}` }
                ];
                if (b.SESSION_ID) {
                    manageRow.push({ text: '🔁 Reset', callback_data: `reset_bot:${b.authKey}` });
                }
                keyboard.push(actionRow, manageRow);
            });
            const navButtons = [];
            if (page > 0) navButtons.push({ text: '⬅️ Prev', callback_data: `my_bots_page:${page - 1}` });
            if (page < totalPages - 1) navButtons.push({ text: '➡️ Next', callback_data: `my_bots_page:${page + 1}` });
            if (navButtons.length > 0) keyboard.push(navButtons);
            keyboard.push([{ text: '⬅️ Back', callback_data: 'back_to_menu' }]);
            await bot.editMessageText(response, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: { inline_keyboard: keyboard }
            });
        } else if (data === 'help') {
            await bot.editMessageText(`Need help?
Use /start to begin or click a button.`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🖇️ Join Channel', url: 'https://whatsapp.com/channel/0029Vb1ydGk8qIzkvps0nZ04' }],
                        [{ text: '📖 How to Use', url: 'https://youtu.be/zWhrpm3Y63Y' }],
                        [{ text: '🔄 How to Reconnect', url: 'https://youtube.com/shorts/nBSYZfnT_Eo' }],
                        [{ text: '⬅️ Back', callback_data: 'back_to_menu' }]
                    ]
                }
            });
        } else if (data === 'admin_panel') {
            await bot.editMessageText(`🔐 *Admin Access Required*
Enter the admin password to continue:`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Cancel', callback_data: 'back_to_menu' }]]
                }
            });
            settings.userStates[chatId] = { step: 'awaiting_admin_password', promptMessageId: messageId };
            saveSettings();
        } else if (data === 'admin_panel_authenticated' && isAdmin(chatId)) {
            await bot.editMessageText(`🛠 *Admin Panel*
👥 Total Users: *${interactedUsers.size}*`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '📛 Expired Bots', callback_data: 'admin_expired' }],
                        [{ text: '✅ Active Bots', callback_data: 'admin_active' }],
                        [{ text: '🎟 Unused Tokens', callback_data: 'admin_unused' }],
                        [{ text: '👥 Manage Users', callback_data: 'admin_users' }],
                        [{ text: '➕ Add Token', callback_data: 'admin_add_token' }],
                        [{ text: '🗑 Remove Token', callback_data: 'admin_remove_token' }],
                        [{ text: '📥 Export Data', callback_data: 'admin_export' }],
                        [{ text: '📤 Export All Users', callback_data: 'admin_export_users' }],
                        [{ text: '📢 Broadcast Message', callback_data: 'admin_broadcast' }],
                        [{ text: '🚫 Blacklist User', callback_data: 'admin_blacklist_user' }],
                        [{ text: '📅 Extend Expiry', callback_data: 'admin_choose_extend' }],
                        [{ text: '✂️ Reduce Expiry', callback_data: 'admin_choose_reduce' }],
                        [{ text: '🔄 Restart All Bots', callback_data: 'admin_restart_all' }],
                        [{ text: '🔄 Reset All Bots', callback_data: 'admin_reset_all_bots' }],
                        [{ text: '⬅️ Back', callback_data: 'back_to_menu' }]
                    ]
                }
            });
        } else if (data === 'admin_expired' && isAdmin(chatId)) {
            const expired = settings.bots.filter(b => isExpired(b));
            let list = expired.length === 0 ? '✅ No expired bots.' : `*❌ Expired Bots:*
` + 
                expired.map((b, i) => {
                    const name = escapeMarkdown(b.botName || 'Unnamed');
                    const key = escapeMarkdown(b.authKey);
                    const exp = escapeMarkdown(b.expiry || b.expiredAt || 'N/A');
                    return `${i + 1}. ${name} - \`${key}\` (Expired: ${exp})`;
                }).join('\n');
            await bot.editMessageText(list, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (data === 'admin_active' && isAdmin(chatId)) {
            const active = settings.bots.filter(b => !isExpired(b) && b.telegramUserId);
            let list = active.length === 0 ? '❌ No active bots.' : `*✅ Active Bots:*
` + 
                active.map((b, i) => {
                    const name = escapeMarkdown(b.botName || 'Unnamed');
                    const key = escapeMarkdown(b.authKey);
                    const exp = escapeMarkdown(b.expiry);
                    return `${i + 1}. ${name} - \`${key}\` (Expires: ${exp})`;
                }).join('\n');
            await bot.editMessageText(list, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (data === 'admin_unused' && isAdmin(chatId)) {
            const unused = settings.bots.filter(b => !b.telegramUserId);
            let list = unused.length === 0 ? '✅ No unused tokens.' : `*🎟 Unused Tokens:*
` + 
                unused.map((b, i) => {
                    const name = escapeMarkdown(b.botName || 'Unnamed');
                    const key = escapeMarkdown(b.authKey);
                    return `${i + 1}. ${name} - \`${key}\``;
                }).join('\n');
            await bot.editMessageText(list, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (data === 'admin_choose_extend' && isAdmin(chatId)) {
            const bots = settings.bots.filter(b => b.expiry);
            const keyboard = bots.map(b => [{
                text: `📅 Extend: ${escapeMarkdown(b.botName || 'Unnamed')} (${escapeMarkdown(b.authKey)})`,
                callback_data: `admin_extend:${b.authKey}`
            }]);
            keyboard.push([{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]);
            await bot.editMessageText(`📅 Select a bot to extend its expiry:`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: { inline_keyboard: keyboard }
            });
        } else if (data === 'admin_choose_reduce' && isAdmin(chatId)) {
            const bots = settings.bots.filter(b => b.expiry);
            const keyboard = bots.map(b => [{
                text: `✂️ Reduce: ${escapeMarkdown(b.botName || 'Unnamed')} (${escapeMarkdown(b.authKey)})`,
                callback_data: `admin_reduce:${b.authKey}`
            }]);
            keyboard.push([{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]);
            await bot.editMessageText(`✂️ Select a bot to reduce its expiry:`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: { inline_keyboard: keyboard }
            });
        } else if (data.startsWith('admin_extend:')) {
            const [_, authKey] = data.split(':');
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Bot not found.' });
                return;
            }
            const expiryDate = new Date(botConfig.expiry || new Date());
            expiryDate.setDate(expiryDate.getDate() + 30);
            botConfig.expiry = expiryDate.toISOString().split('T')[0];
            saveSettings();
            await bot.editMessageText(`✅ Expiry extended to *${botConfig.expiry}* for "${escapeMarkdown(botConfig.botName || 'Unnamed')}"`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_choose_extend' }],
                        [{ text: '🏠 Admin Panel', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data.startsWith('admin_reduce:')) {
            const [_, authKey] = data.split(':');
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Bot not found.' });
                return;
            }
            const expiryDate = new Date(botConfig.expiry || new Date());
            expiryDate.setDate(expiryDate.getDate() - 30);
            botConfig.expiry = expiryDate.toISOString().split('T')[0];
            saveSettings();
            await bot.editMessageText(`✅ Expiry reduced to *${botConfig.expiry}* for "${escapeMarkdown(botConfig.botName || 'Unnamed')}"`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_choose_reduce' }],
                        [{ text: '🏠 Admin Panel', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data === 'admin_users' && isAdmin(chatId)) {
            const users = [...new Set(settings.bots.map(b => b.telegramUserId).filter(Boolean))];
            const msg = users.length === 0 ? '✅ No active users.' : `*👥 Active Users:*
` + 
                users.map((id, i) => `${i + 1}. \`${escapeMarkdown(id)}\``).join('\n');
            await bot.editMessageText(msg, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (data === 'admin_add_token' && isAdmin(chatId)) {
            settings.userStates[chatId] = { step: 'awaiting_new_bot_auth_key' };
            saveSettings();
            await bot.editMessageText(`🔑 Enter the new bot auth key:`, {
                chat_id: chatId,
                message_id: messageId,
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (data === 'admin_remove_token' && isAdmin(chatId)) {
            settings.userStates[chatId] = { step: 'awaiting_remove_bot_auth_key' };
            saveSettings();
            await bot.editMessageText(`🔑 Enter the auth key to remove:`, {
                chat_id: chatId,
                message_id: messageId,
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (data === 'admin_export' && isAdmin(chatId)) {
            const data = { bots: settings.bots, userStates: settings.userStates, blacklistedUsers: settings.blacklistedUsers || [] };
            const file = path.join(__dirname, 'bot_backup.json');
            fs.writeFileSync(file, JSON.stringify(data, null, 2));
            await bot.sendDocument(chatId, file);
            fs.unlinkSync(file);
            await bot.editMessageText(`🛠 *Admin Panel*
👥 Total Users: *${interactedUsers.size}*`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: mainMenu(true).reply_markup
            });
        } else if (data === 'admin_blacklist_user' && isAdmin(chatId)) {
            settings.userStates[chatId] = { step: 'awaiting_blacklist_user' };
            saveSettings();
            await bot.editMessageText(`🆔 Send the Telegram User ID to blacklist:`, {
                chat_id: chatId,
                message_id: messageId,
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (data === 'admin_restart_all' && isAdmin(chatId)) {
            const now = Date.now();
            const last = settings.userStates[chatId]?.adminLastRestart || 0;
            if (now - last < RESTART_COOLDOWN) {
                const wait = Math.ceil((RESTART_COOLDOWN - (now - last)) / 60000);
                await bot.answerCallbackQuery(query.id, { text: `⏳ Wait ${wait} minute(s).` });
                return;
            }
            let count = 0;
            settings.bots.forEach(bot => {
                const id = `bot${settings.bots.indexOf(bot) + 1}`;
                const path = `${__dirname}/session/${id}`;
                if (fs.existsSync(path)) fs.rmSync(path, { recursive: true, force: true });
                delete bot.SESSION_ID;
                bot.telegramUserId = null;
                count++;
            });
            if (!settings.userStates[chatId]) settings.userStates[chatId] = {};
            settings.userStates[chatId].adminLastRestart = now;
            saveSettings();
            await bot.editMessageText(`🔄 *All bots restarted.* (${count} bots)`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (data === 'admin_reset_all_bots' && isAdmin(chatId)) {
            const now = Date.now();
            const last = settings.userStates[chatId]?.adminLastReset || 0;
            if (now - last < RESTART_COOLDOWN) {
                const wait = Math.ceil((RESTART_COOLDOWN - (now - last)) / 60000);
                await bot.answerCallbackQuery(query.id, { text: `⏳ Wait ${wait} minute(s).` });
                return;
            }
            const genKey = () => {
                const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                return Array(16).fill(0).map(() => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
            };
            let count = 0;
            settings.bots.forEach(bot => {
                const id = `bot${settings.bots.indexOf(bot) + 1}`;
                const path = `${__dirname}/session/${id}`;
                if (fs.existsSync(path)) fs.rmSync(path, { recursive: true, force: true });
                bot.authKey = genKey();
                bot.botName = 'New Bot';
                bot.telegramUserId = null;
                bot.SESSION_ID = undefined;
                bot.createdAt = new Date().toISOString();
                count++;
            });
            if (!settings.userStates[chatId]) settings.userStates[chatId] = {};
            settings.userStates[chatId].adminLastReset = now;
            saveSettings();
            await bot.editMessageText(`🔄 *All bots reset successfully.*
✅ ${count} bots updated.`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (data === 'admin_export_users' && isAdmin(chatId)) {
            if (interactedUsers.size === 0) {
                await bot.editMessageText(`❌ No users have interacted with the bot yet.`, {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                    }
                });
                return;
            }
            const file = path.join(__dirname, 'exported_interacted_users.json');
            const list = Array.from(interactedUsers).sort();
            fs.writeFileSync(file, JSON.stringify(list, null, 2));
            await bot.sendDocument(chatId, file, { caption: `📤 *Exported User List*
🔢 Total Users: *${list.length}*` });
            fs.unlinkSync(file);
            await bot.editMessageText(`🛠 *Admin Panel*
👥 Total Users: *${interactedUsers.size}*`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: mainMenu(true).reply_markup
            });
        } else if (data === 'admin_broadcast' && isAdmin(chatId)) {
            await bot.editMessageText(`📤 *Admin Broadcast*
Send the message to broadcast to all /start users.`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '❌ Cancel', callback_data: 'admin_panel_authenticated' }]]
                }
            });
            settings.userStates[chatId] = { step: 'awaiting_broadcast_message', promptMessageId: messageId };
            saveSettings();
        } else if (data.startsWith('rename_bot:')) {
            const authKey = data.split(':')[1];
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                await bot.editMessageText(`🚫 Unauthorized or invalid key.`, {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }],
                            [{ text: '⬅️ Back', callback_data: 'my_bots' }]
                        ]
                    }
                });
                return;
            }
            settings.userStates[chatId] = { step: 'awaiting_bot_name_rename', authKey, promptMessageId: messageId };
            saveSettings();
            await bot.editMessageText(`✏️ Enter the new name for "${escapeMarkdown(botConfig.botName || 'Unnamed')}":`, {
                chat_id: chatId,
                message_id: messageId,
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Cancel', callback_data: 'my_bots' }]]
                }
            });
        } else if (data.startsWith('view_owner:')) {
            const authKey = data.split(':')[1];
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                await bot.editMessageText(`🚫 Unauthorized or invalid key.`, {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }],
                            [{ text: '⬅️ Back', callback_data: 'my_bots' }]
                        ]
                    }
                });
                return;
            }
            const current = botConfig.ownerNumber || 'Not set';
            await bot.editMessageText(`📱 *Owner Number for "${escapeMarkdown(botConfig.botName)}"*
Current: \`${escapeMarkdown(current)}\`
Choose an action:`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '✏️ Change Owner Number', callback_data: `edit_owner:${authKey}` }],
                        [{ text: '⬅️ Back', callback_data: 'my_bots' }]
                    ]
                }
            });
        } else if (data.startsWith('edit_owner:')) {
            const authKey = data.split(':')[1];
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                await bot.editMessageText(`🚫 Unauthorized or invalid key.`, {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }],
                            [{ text: '⬅️ Back', callback_data: 'my_bots' }]
                        ]
                    }
                });
                return;
            }
            settings.userStates[chatId] = { step: 'awaiting_owner_number', authKey, promptMessageId: messageId };
            saveSettings();
            await bot.editMessageText(`📞 Enter the new *owner number* for "${escapeMarkdown(botConfig.botName)}"
📌 Format: 2349011237777`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Cancel', callback_data: 'my_bots' }]]
                }
            });
        } else if (data.startsWith('start_bot:')) {
            const authKey = data.split(':')[1];
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Unauthorized.' });
                return;
            }
            if (!botConfig.SESSION_ID) {
                await bot.editMessageText(`❌ No session found. Please connect first.`, {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                    }
                });
                return;
            }
            const botId = `bot${settings.bots.indexOf(botConfig) + 1}`;
            try {
                await global.startBotById?.(botId);
                await bot.editMessageText(`✅ *"${escapeMarkdown(botConfig.botName)}"* is now online!`, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                    }
                });
            } catch (err) {
                await bot.editMessageText(`❌ Start failed: ${escapeMarkdown(err.message)}`, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                    }
                });
            }
        } else if (data.startsWith('stop_bot_permanent:')) {
            const authKey = data.split(':')[1];
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Unauthorized.' });
                return;
            }
            const botId = `bot${settings.bots.indexOf(botConfig) + 1}`;
            const success = await global.stopBot?.(botId);
            await bot.editMessageText(
                success 
                    ? `📴 "${escapeMarkdown(botConfig.botName)}" stopped. Session preserved.`
                    : `⚠️ Bot was not running.`,
                {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                    }
                }
            );
        } else if (data.startsWith('reconnect_bot:')) {
            const authKey = data.split(':')[1];
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Unauthorized.' });
                return;
            }
            if (!botConfig.SESSION_ID) {
                await bot.editMessageText(`❌ No session to reconnect.`, {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                    }
                });
                return;
            }
            const botId = `bot${settings.bots.indexOf(botConfig) + 1}`;
            try {
                await global.reconnectBot?.(botId);
                await bot.editMessageText(`🔁 "${escapeMarkdown(botConfig.botName)}" reconnected!`, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                    }
                });
            } catch (err) {
                await bot.editMessageText(`❌ Reconnect failed: ${escapeMarkdown(err.message)}`, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                    }
                });
            }
        } else if (data.startsWith('reset_bot:')) {
            const authKey = data.split(':')[1];
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Bot not found.' });
                return;
            }
            if (botConfig.telegramUserId !== chatId && !isAdmin(chatId)) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Unauthorized.' });
                return;
            }
            const now = Date.now();
            const last = settings.userStates[chatId]?.lastRestart || 0;
            if (now - last < RESTART_COOLDOWN) {
                const wait = Math.ceil((RESTART_COOLDOWN - (now - last)) / 60000);
                await bot.answerCallbackQuery(query.id, { text: `⏳ Wait ${wait} minute(s).` });
                return;
            }
            await bot.editMessageText(
                `🧼 *Clean Restart Required*
1️⃣ Open WhatsApp → *Settings → Linked Devices*
2️⃣ Tap *"Log out from all devices"* ⚠️
3️⃣ Wait 10 seconds
4️⃣ Send your new Session ID`,
                {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔗 Generate Session ID', url: 'https://t.me/SEPTORCH_MDBOT/SEPTORCH' }],
                            [{ text: '⬅️ Cancel', callback_data: 'my_bots' }]
                        ]
                    }
                }
            );
            const botId = `bot${settings.bots.indexOf(botConfig) + 1}`;
            const sessionPath = path.join(__dirname, 'session', botId);
            if (fs.existsSync(sessionPath)) {
                fs.rmSync(sessionPath, { recursive: true, force: true });
            }
            delete botConfig.SESSION_ID;
            botConfig.telegramUserId = null;
            settings.userStates[chatId] = {
                step: 'awaiting_session_id',
                authKey,
                lastRestart: now,
                promptMessageId: messageId
            };
            saveSettings();
        } else if (data === 'back_to_menu') {
            const welcomeMessage = `👋 Hi ${escapeMarkdown(name)}!
Welcome to SEPTORCH Bot Manager!`;
            await bot.editMessageText(welcomeMessage, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: mainMenu(isAdmin(chatId)).reply_markup
            });
            if (settings.userStates[chatId]) {
                delete settings.userStates[chatId];
                saveSettings();
            }
        } else {
            await bot.answerCallbackQuery(query.id, { text: 'Action not recognized.' });
        }
    } catch (err) {
        console.error(`Error in callback_query ${data} for ${chatId}:`, err);
        try {
            await bot.sendMessage(chatId, '❌ An error occurred. Please try again.');
        } catch (e) {
            console.error(`Failed to send error message to ${chatId}:`, e);
        }
    } finally {
        if (query.id) {
            try { await bot.answerCallbackQuery(query.id); } catch (e) {}
        }
    }
});

// --- Message Handler ---
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text?.trim();
    const messageId = msg.message_id;
    if (!text || settings.blacklistedUsers?.includes(String(chatId))) return;
    const userState = settings.userStates[chatId];
    if (!userState) return;
    const step = typeof userState === 'object' ? userState.step : userState;
    const promptId = typeof userState === 'object' ? userState.promptMessageId : null;
    try {
        if (step === 'awaiting_admin_password') {
            if (text === ADMIN_PASSWORD) {
                settings.userStates[chatId] = { step: null };
                saveSettings();
                await bot.sendMessage(chatId, '🔓 *Access Granted!*', {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '📁 Open Admin Panel', callback_data: 'admin_panel_authenticated' }]]
                    }
                });
                if (promptId) await bot.editMessageText('🔓 *Access Granted!*', { chat_id: chatId, message_id: promptId, parse_mode: 'Markdown' });
            } else {
                await bot.editMessageText('❌ *Incorrect password.*', {
                    chat_id: chatId,
                    message_id: promptId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔁 Try Again', callback_data: 'admin_panel' }],
                            [{ text: '⬅️ Cancel', callback_data: 'back_to_menu' }]
                        ]
                    }
                });
                delete settings.userStates[chatId];
                saveSettings();
            }
        } else if (step === 'awaiting_broadcast_message') {
            const recipients = [...interactedUsers].filter(id => !settings.blacklistedUsers?.includes(id));
            let success = 0, fail = 0;
            for (const id of recipients) {
                try {
                    await bot.copyMessage(id, chatId, messageId);
                    success++;
                } catch (err) {
                    fail++;
                }
            }
            await bot.editMessageText(`✅ *Broadcast Complete!*
📬 Sent: *${success}*
❌ Failed: *${fail}*`, {
                chat_id: chatId,
                message_id: promptId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '🏠 Admin Panel', callback_data: 'admin_panel_authenticated' }]]
                }
            });
            delete settings.userStates[chatId];
            saveSettings();
        } else if (step === 'awaiting_auth_key') {
            const botConfig = getBotByAuthKey(text);
            if (!botConfig) {
                await bot.editMessageText(`❌ *Invalid or expired Authorization Key*`, {
                    chat_id: chatId,
                    message_id: promptId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Try Again', callback_data: 'connect_bot' }],
                            [{ text: '🛒 Buy Now', url: 'https://t.me/SEPTORCHBOT' }],
                            [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }]
                        ]
                    }
                });
                return;
            }
            if (isExpired(botConfig)) {
                await bot.editMessageText(`⛔ *This key expired on ${botConfig.expiry || 'Unknown'}*. Please renew.`, {
                    chat_id: chatId,
                    message_id: promptId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }],
                            [{ text: '🛒 Buy Now', url: 'https://t.me/SEPTORCHBOT' }],
                            [{ text: '🔄 Try Again', callback_data: 'connect_bot' }]
                        ]
                    }
                });
                return;
            }
            if (botConfig.telegramUserId && botConfig.telegramUserId !== chatId) {
                await bot.editMessageText(`⛔ *This bot is already claimed by another user.*`, {
                    chat_id: chatId,
                    message_id: promptId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }]]
                    }
                });
                return;
            }
            settings.userStates[chatId] = { step: 'awaiting_session_id', authKey: text, promptMessageId: messageId };
            saveSettings();
            await bot.sendMessage(chatId, '📥 Send your Session ID:', {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{
                        text: '🔗 Generate Session ID',
                        url: 'https://t.me/SEPTORCH_MDBOT/SEPTORCH'
                    }]]
                }
            });
        } else if (step === 'awaiting_stop_auth_key') {
            const botConfig = getBotByAuthKey(text);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                await bot.sendMessage(chatId, '🚫 Unauthorized or invalid key.', {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🛒 Buy Now', url: 'https://t.me/SEPTORCHBOT' }],
                            [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }]
                        ]
                    }
                });
                return;
            }
            delete botConfig.SESSION_ID;
            botConfig.telegramUserId = null;
            saveSettings();
            const msg = `⏹️ Bot "${escapeMarkdown(botConfig.botName || 'Unnamed Bot')}" has been stopped successfully.`;
            if (promptId) {
                await bot.editMessageText(msg, {
                    chat_id: chatId,
                    message_id: promptId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'back_to_menu' }]]
                    }
                });
            } else {
                await bot.sendMessage(chatId, msg, mainMenu(isAdmin(chatId)));
            }
            delete settings.userStates[chatId];
            saveSettings();
        } else if (step === 'awaiting_session_id') {
            const botConfig = getBotByAuthKey(userState.authKey);
            if (!botConfig) {
                await bot.sendMessage(chatId, '❌ An error occurred. Please start over.');
                delete settings.userStates[chatId];
                saveSettings();
                return;
            }
            if (!/^\w{6,}#\S+$/.test(text)) {
                return bot.sendMessage(chatId, `❌ *Invalid Session ID format.*
It should look like \`XXXXX#YYYYY\`.`, { parse_mode: 'Markdown' });
            }
            botConfig.SESSION_ID = text;
            botConfig.telegramUserId = chatId;
            if (!botConfig.expiry) {
                const created = new Date();
                botConfig.createdAt = created.toISOString();
                const expiry = new Date(created.getTime() + 30 * 24 * 60 * 60 * 1000);
                botConfig.expiry = expiry.toISOString().split('T')[0];
            }
            if (!botConfig.botName || botConfig.botName === 'New Bot') {
                settings.userStates[chatId] = { step: 'awaiting_bot_name', authKey: userState.authKey, promptMessageId: messageId };
                await bot.sendMessage(chatId, '📝 What name would you like to give this bot?');
            } else {
                delete settings.userStates[chatId];
                const msg = `✅ Bot "${escapeMarkdown(botConfig.botName)}" connected successfully.`;
                if (promptId) {
                    await bot.editMessageText(msg, {
                        chat_id: chatId,
                        message_id: promptId,
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                        }
                    });
                } else {
                    await bot.sendMessage(chatId, msg, mainMenu(isAdmin(chatId)));
                }
            }
            saveSettings();
        } else if (step === 'awaiting_bot_name' || step === 'awaiting_bot_name_rename') {
            const { authKey } = userState;
            const botConfig = getBotByAuthKey(authKey);
            if (botConfig && (botConfig.telegramUserId === chatId || isAdmin(chatId))) {
                const old = botConfig.botName;
                botConfig.botName = text;
                delete settings.userStates[chatId];
                saveSettings();
                const msg = step === 'awaiting_bot_name_rename' 
                    ? `✅ Bot renamed from *${escapeMarkdown(old || 'Unnamed')}* to *${escapeMarkdown(text)}* successfully.`
                    : `🎉 Bot named *${escapeMarkdown(text)}* successfully saved.`;
                if (promptId) {
                    await bot.editMessageText(msg, {
                        chat_id: chatId,
                        message_id: promptId,
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                        }
                    });
                } else {
                    await bot.sendMessage(chatId, msg, mainMenu(isAdmin(chatId)));
                }
            } else {
                await bot.sendMessage(chatId, '❌ An error occurred. Please start over.');
                delete settings.userStates[chatId];
                saveSettings();
            }
        } else if (step === 'awaiting_owner_number') {
            const { authKey } = userState;
            if (!/^\d{10,15}$/.test(text)) {
                return bot.sendMessage(chatId, '❌ Invalid number format. Use digits only (e.g. 2349047943737)');
            }
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                bot.sendMessage(chatId, '🚫 Unauthorized or bot not found.');
                delete settings.userStates[chatId];
                saveSettings();
                return;
            }
            botConfig.ownerNumber = text;
            delete settings.userStates[chatId];
            saveSettings();
            bot.editMessageText(`✅ Owner number updated successfully!
New: \`${escapeMarkdown(text)}\``, {
                chat_id: chatId,
                message_id: promptId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back to My Bots', callback_data: 'my_bots' }]]
                }
            });
            bot.sendMessage(chatId, `🔔 Owner number for *${escapeMarkdown(botConfig.botName)}* has been updated.`, { parse_mode: 'Markdown' });
        } else if (step === 'awaiting_new_bot_auth_key') {
            if (getBotByAuthKey(text)) {
                await bot.sendMessage(chatId, '🚫 This token already exists.');
                return;
            }
            settings.bots.push({
                authKey: text,
                createdAt: new Date().toISOString(),
                botName: 'New Bot',
                telegramUserId: null
            });
            delete settings.userStates[chatId];
            saveSettings();
            await bot.sendMessage(chatId, `✅ Token \`${escapeMarkdown(text)}\` added successfully.`, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (step === 'awaiting_remove_bot_auth_key') {
            const index = settings.bots.findIndex(b => b.authKey === text);
            if (index === -1) {
                await bot.sendMessage(chatId, '🚫 Token not found.');
                return;
            }
            settings.bots.splice(index, 1);
            delete settings.userStates[chatId];
            saveSettings();
            await bot.sendMessage(chatId, `✅ Token \`${escapeMarkdown(text)}\` removed successfully.`, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (step === 'awaiting_blacklist_user') {
            if (!settings.blacklistedUsers) settings.blacklistedUsers = [];
            if (!settings.blacklistedUsers.includes(text)) {
                settings.blacklistedUsers.push(text);
                delete settings.userStates[chatId];
                saveSettings();
                await bot.sendMessage(chatId, `🚫 User \`${escapeMarkdown(text)}\` has been blacklisted.`, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                    }
                });
            } else {
                await bot.sendMessage(chatId, 'ℹ️ User is already blacklisted.', {
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                    }
                });
            }
        }
    } catch (err) {
        console.error(`Error handling message from ${chatId}:`, err);
        try {
            await bot.sendMessage(chatId, '✅ Bot connected successfully.');
        } catch (e) {
            console.error(`Failed to send error message to ${chatId}:`, e);
        }
        delete settings.userStates[chatId];
        saveSettings();
    }
});

console.log('✅ Bot is running with FULL SESSION LIFECYCLE CONTROL!');
module.exports = { bot };
