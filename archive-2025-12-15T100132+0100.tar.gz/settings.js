exports.bots = [
  {
    "authKey": "Septorch",
    "createdAt": "2025-12-03T07:15:51.946Z",
    "botName": "SEPTORCH_BOT",
    "telegramUserId": 7738315673,
    "expiry": "2026-01-02",
    "expiryTimestamp": 1767394799999,
    "ownerNumber": "2349131037140",
    "SESSION_ID": "KMgmwQqL#wQQd0o3J774GLexs1ggUnlyfoK1iXNFvnMathU0EqXI"
  },
  {
    "authKey": "MAYOR",
    "createdAt": "2025-12-09T19:20:14.755Z",
    "botName": "New Bot",
    "telegramUserId": "6160789720"
  },
  {
    "authKey": "septorch",
    "createdAt": "2025-12-11T10:15:42.406Z",
    "botName": "Septorch",
    "telegramUserId": 7738315673,
    "SESSION_ID": "rUxTXIzA#pBXX_VFhR1JQPmcfog4oEPxTUvXJU8NOp0n7yqxwTpI",
    "expiry": "2026-01-10",
    "expiryTimestamp": 1768085999999
  },
  {
    "authKey": "mayor",
    "createdAt": "2025-12-11T08:33:21.220Z",
    "botName": "Mayor",
    "telegramUserId": 6578195381,
    "expiry": "2026-01-10",
    "expiryTimestamp": 1768085999999,
    "SESSION_ID": "fcBA2CJI#cnGA477t8_MNiPkfsVpTwVpzW1eIBf22HJJtEIvjo8Q"
  },
  {
    "authKey": "blaze",
    "createdAt": "2025-12-11T23:11:45.181Z",
    "botName": "Blaze",
    "telegramUserId": 7738315673,
    "expiry": "2026-01-10",
    "expiryTimestamp": 1768085999999,
    "SESSION_ID": "OZRG1K7C#8B09tPTEdPpsGVbh7Hh1osz6_4Vg3hyw9AbCEbditHE"
  },
  {
    "authKey": "darl",
    "createdAt": "2025-12-12T11:31:51.846Z",
    "botName": "Darl",
    "telegramUserId": 7738315673,
    "expiry": "2026-01-11",
    "expiryTimestamp": 1768172399999,
    "SESSION_ID": "bYgATJDI#jUfmy7No6jqjheT6FSlWukt4p3tRsV9U_RZR3cNwqeQ"
  },
  {
    "authKey": "Emmy",
    "createdAt": "2025-12-12T11:39:58.293Z",
    "botName": "Emmy",
    "telegramUserId": 7738315673,
    "expiry": "2026-01-11",
    "expiryTimestamp": 1768172399999,
    "SESSION_ID": "mEoQyDwb#Nn96q5FOSS3gVrZGGAfbvoLeznB5AbMwzHGiGKgPf_Q"
  },
  {
    "authKey": "RAPHSONGS",
    "createdAt": "2025-12-12T17:00:15.306Z",
    "botName": "RAPHSONGS",
    "telegramUserId": 7738315673,
    "expiry": "2026-01-11",
    "expiryTimestamp": 1768172399999,
    "SESSION_ID": "LM42DQaQ#dfl96i635KekdpRTBudNcpK82LFPfkRan9DQbkZOKTw"
  },
  {
    "authKey": "Giveaway 1",
    "createdAt": "2025-12-14T11:17:27.045Z",
    "botName": "Zykra",
    "telegramUserId": 7738315673,
    "SESSION_ID": "nBgnlLRA#WTrB3e6IiiH8hz_XkbXhdf_JTZblhznuyKto9QKU85Q",
    "expiry": "2026-01-13",
    "expiryTimestamp": 1768345199999
  },
  {
    "authKey": "Victorcee",
    "createdAt": "2025-12-14T13:11:33.941Z",
    "botName": "New Bot",
    "telegramUserId": null
  },
  {
    "authKey": "Banx",
    "createdAt": "2025-12-14T15:38:17.833Z",
    "botName": "banx",
    "telegramUserId": null,
    "expiry": "2026-01-13",
    "expiryTimestamp": 1768345199999,
    "ownerNumber": "233536493718"
  }
];
exports.userStates = {
  "7566045774": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8440
  },
  "5159342935": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9121
  },
  "8252318837": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8860
  },
  "5874545127": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9478
  },
  "7962702281": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9615
  },
  "6456700552": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9715
  },
  "7353586099": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9763
  },
  "7128696705": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9241
  },
  "6921893415": {
    "step": "awaiting_session_id",
    "authKey": "Victorcee",
    "promptMessageId": 10594
  },
  "7004652334": {
    "step": "awaiting_session_id",
    "authKey": "Banx",
    "lastRestart": 1765789093115,
    "promptMessageId": 11074
  }
};
exports.blacklistedUsers = [];