/**
 * WhatsApp Bot - Multi-Account Support
 * Fully compatible with Telegram Admin Bot
 * 
 * Copyright (c) 2024 Professor
 */

const fs = require('fs');
const chalk = require('chalk');
const path = require('path');
const { promises: fsp } = fs;
const readline = require('readline');
const axios = require('axios');
const FileType = require('file-type');
const { Boom } = require('@hapi/boom');
const PhoneNumber = require('awesome-phonenumber');
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif');
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, await, sleep, reSize } = require('./lib/myfunc');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  jidDecode,
  proto,
  jidNormalizedUser,
  makeCacheableSignalKeyStore,
  delay
} = require("baileys");
const NodeCache = require("node-cache");
const pino = require("pino");

// Load handlers
const { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('./main');

// Global store for bots
global.botInstances = {};

// Store for messages, contacts, chats
const store = {
  messages: {},
  contacts: {},
  chats: {},
  groupMetadata: async (jid) => {
    return {};
  },
  bind: function (ev) {
    ev.on('messages.upsert', ({ messages }) => {
      messages.forEach(msg => {
        if (msg.key && msg.key.remoteJid) {
          this.messages[msg.key.remoteJid] = this.messages[msg.key.remoteJid] || {};
          this.messages[msg.key.remoteJid][msg.key.id] = msg;
        }
      });
    });
    ev.on('contacts.update', (contacts) => {
      contacts.forEach(contact => {
        if (contact.id) {
          this.contacts[contact.id] = contact;
        }
      });
    });
    ev.on('chats.set', (chats) => {
      this.chats = chats;
    });
  },
  loadMessage: async (jid, id) => {
    return this.messages[jid]?.[id] || null;
  }
};

// Load settings
let settings = require('./settings');

// rmSync added here
const { rmSync } = require('fs');

// Helper to download session from MEGA
async function downloadSession(sessionPath, sessionId) {
  const sessionFile = path.join(sessionPath, 'creds.json');
  if (!fs.existsSync(sessionFile)) {
    if (!sessionId) {
      console.log(chalk.yellow(`⚠️ SESSION_ID not provided for ${sessionPath}`));
      return;
    }
    try {
      console.log(chalk.blue(`📥 Downloading session for ${sessionPath}...`));
      const file = require('megajs').File.fromURL(`https://mega.nz/file/${sessionId}`);
      const data = await new Promise((resolve, reject) => {
        file.download((err, data) => (err ? reject(err) : resolve(data)));
      });
      fs.mkdirSync(sessionPath, { recursive: true });
      fs.writeFileSync(sessionFile, data);
      console.log(chalk.green(`✅ Session downloaded for ${sessionPath}.`));
    } catch (error) {
      console.error(
        chalk.red(`❌ Session download failed for ${sessionPath}:`, error.message)
      );
    }
  }
}

function getExpiryTimestamp(expiryDateStr) {
  const date = new Date(expiryDateStr);
  if (isNaN(date.getTime())) {
    throw new Error(`Invalid expiry date: ${expiryDateStr}`);
  }
  return date.setHours(23, 59, 59, 999); // End of day
}

// Start each bot dynamically
async function startBot(botConfig, botId) {
  const sessionPath = path.join(__dirname, 'session', botId);

  // Set expiry timestamp
  if (botConfig.expiry) {
    botConfig.expiryTimestamp = getExpiryTimestamp(botConfig.expiry);
    console.log(chalk.blue(`🕒 Bot ${botConfig.botName} will expire on: ${botConfig.expiry}`));
  }

  // Download session if needed
  await downloadSession(sessionPath, botConfig.SESSION_ID);

  let { version } = await fetchLatestBaileysVersion();
  const pairingCode = !!botConfig.phoneNumber || process.argv.includes("--pairing-code");
  const useMobile = process.argv.includes("--mobile");
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
  const msgRetryCounterCache = new NodeCache();

  const XeonBotInc = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'fatal' }))
    },
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    getMessage: async key => {
      let jid = jidNormalizedUser(key.remoteJid);
      let msg = await store.loadMessage(jid, key.id);
      return msg?.message || '';
    },
    msgRetryCounterCache,
    defaultQueryTimeoutMs: undefined
  });

  // Set dynamic global values
  global.botname = botConfig.botName;
  global.themeemoji = botConfig.themeemoji || '•';
  global.owner = [botConfig.ownerNumber];

  store.bind(XeonBotInc.ev);

  // Message handler
  XeonBotInc.ev.on('messages.upsert', async chatUpdate => {
    try {
      const mek = chatUpdate.messages[0];
      if (!mek.message) return;
      mek.message =
        Object.keys(mek.message)[0] === 'ephemeralMessage'
          ? mek.message.ephemeralMessage.message
          : mek.message;

      if (mek.key?.remoteJid === 'status@broadcast') {
        await handleStatus(XeonBotInc, chatUpdate, botId);
        return;
      }

      if (!XeonBotInc.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
      if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;

      // Store mapping of sender phone → lid for LID group admin checks
      const senderId = mek.key.participant || mek.key.remoteJid;
      const senderBase = senderId.split(':')[0].split('@')[0];
      const phoneBase = senderId.split('@')[0].replace(/\D/g, '');
      if (!global.botInstances[botId].senderLids) {
        global.botInstances[botId].senderLids = {};
      }
      global.botInstances[botId].senderLids[phoneBase] = senderBase;

      // Check expiry
      if (botConfig.expiryTimestamp && Date.now() > botConfig.expiryTimestamp) {
        const nigeriaExpiry = new Date(botConfig.expiryTimestamp).toLocaleString('en-GB', {
          timeZone: 'Africa/Lagos',
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        });
        console.warn(chalk.yellow(`⏰ Bot ${botConfig.botName} expired on ${nigeriaExpiry}.`));
        if (mek.key.remoteJid && !mek.key.fromMe) {
          await XeonBotInc.sendMessage(mek.key.remoteJid, {
            text: `⏳ This bot expired on ${nigeriaExpiry}. Please contact admin for renewal.`,
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: '120363387922693296@newsletter',
                newsletterName: 'SEPTORCH',
                serverMessageId: -1
              }
            }
          });
        }
        return;
      }

      await handleMessages(XeonBotInc, chatUpdate, true, botId);
    } catch (err) {
      console.error('Error in messages.upsert:', err);
    }
  });

  XeonBotInc.decodeJid = jid => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {};
      return decode.user && decode.server && decode.user + '@' + decode.server || jid;
    } else return jid;
  };

  XeonBotInc.getName = (jid, withoutContact = false) => {
    let id = XeonBotInc.decodeJid(jid);
    withoutContact = XeonBotInc.withoutContact || withoutContact;
    let v;
    if (id.endsWith('@g.us')) {
      return new Promise(async resolve => {
        v = store.contacts[id] || {};
        if (!(v.name || v.subject)) v = await XeonBotInc.groupMetadata(id).catch(() => { });
        resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'));
      });
    } else {
      v = id === '0@s.whatsapp.net' ? { id, name: 'WhatsApp' } :
        id === XeonBotInc.decodeJid(XeonBotInc.user.id) ? XeonBotInc.user :
          (store.contacts[id] || {});
      return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international');
    }
  };

  XeonBotInc.public = true;
  XeonBotInc.serializeM = m => require('./lib/myfunc').smsg(XeonBotInc, m, store);

  // Connection update
  XeonBotInc.ev.on('connection.update', async s => {
    const { connection, lastDisconnect } = s;
    const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;

    if (connection === 'open') {
      console.log(chalk.yellow(`🌿 Connected to => ${JSON.stringify(XeonBotInc.user, null, 2)}`));

      // ✅ Send connection success message to the bot itself (its own number)
        const botNumber = XeonBotInc.user.id.split(':')[0] + '@s.whatsapp.net';
        
        const messageText = `🤖 *${botConfig.botName}* is now online!

📅 *Date:* ${new Date().toLocaleDateString('en-GB')}
⏰ *Time:* ${new Date().toLocaleTimeString('en-GB')}
✅ *Status:* Ready to serve!

*Connected on:* ${botNumber.replace('@s.whatsapp.net', '')}
`;

        try {
            await XeonBotInc.sendMessage(botNumber, {
                text: messageText,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363387922693296@newsletter',
                        newsletterName: 'SEPTORCH',
                        serverMessageId: -1
                    }
                }
            });
            console.log(chalk.green(`✅ Connection message sent to bot itself: ${botNumber}`));
        } catch (err) {
            console.error(chalk.red(`❌ Failed to send connection message to itself:`, err.message));
        }
        
      // Store bot metadata
      if (!global.botInstances[botId]) global.botInstances[botId] = {};
      global.botInstances[botId].phoneJid = XeonBotInc.user.id;
      global.botInstances[botId].lidJid = XeonBotInc.user.lid;
      global.botInstances[botId].senderLids = {};

      // Preload group sender mappings
      try {
        const chats = Object.keys(store.chats).filter(j => j.endsWith('@g.us'));
        for (const groupId of chats) {
          const meta = await XeonBotInc.groupMetadata(groupId).catch(() => null);
          if (meta?.participants) {
            meta.participants.forEach(p => {
              const pure = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
              global.botInstances[botId].senderLids[pure] = pure;
            });
          }
        }
      } catch (err) {
        console.error(chalk.red(`❌ Failed to preload LID mappings for ${botId}:`), err);
      }

      console.log(chalk.magenta('< ================================================== >'));
      console.log(chalk.green(`${global.themeemoji} 🤖 ${global.botname} Connected Successfully! ✅`));
    }

    else if (connection === 'close') {
      console.log(chalk.red(`❌ Connection closed for ${botConfig.botName}. Status: ${statusCode}`));

      if (statusCode === 401 || statusCode === 403) {
        console.warn(chalk.yellow(`🛑 Session ${statusCode === 401 ? 'Unauthorized (401)' : 'Forbidden (403)'} — stopping reconnect.`));
        const sessionPath = path.join(__dirname, 'session', botId);
        try {
          rmSync(sessionPath, { recursive: true, force: true });
          console.log(chalk.gray(`🗑️ Session deleted: ${sessionPath}`));
        } catch (err) {
          console.error(chalk.red(`⚠️ Cleanup failed: ${err.message}`));
        }

        // Mark as logged out
        if (global.botInstances[botId]) {
          global.botInstances[botId].loggedOut = true;
        }

        // Notify owner
        const ownerJid = Array.isArray(botConfig.ownerNumber)
          ? botConfig.ownerNumber[0] + '@s.whatsapp.net'
          : botConfig.ownerNumber + '@s.whatsapp.net';

        try {
          await XeonBotInc.sendMessage(ownerJid, {
            text: `📴 *${botConfig.botName}* session ended.\n\nError: *${statusCode}* - Your bot has been logged out.\n\nAuto-reconnection stopped. Use *restartbot* to reconnect.`,
          });
        } catch (err) {
          console.error("Failed to notify owner about logout");
        }
      }
      else if ([408, 420, 500, 502, 503, 404].includes(statusCode) || !statusCode) {
        console.log(chalk.yellow(`🔁 Retrying ${botConfig.botName} in 5 seconds...`));
        setTimeout(() => startBot(botConfig, botId), 5000);
      }
      else {
        console.warn(chalk.red(`⚠️ Unexpected close code: ${statusCode}. Retrying in 10 seconds...`));
        setTimeout(() => startBot(botConfig, botId), 10000);
      }
    }
  });

  XeonBotInc.ev.on('creds.update', saveCreds);

  XeonBotInc.ev.on('group-participants.update', async update => {
    try {
      const meta = await XeonBotInc.groupMetadata(update.id).catch(() => null);
      if (meta?.participants) {
        if (!global.botInstances[botId].senderLids) {
          global.botInstances[botId].senderLids = {};
        }
        meta.participants.forEach(p => {
          const pure = p.id.split('@')[0].split(':')[0].replace(/\D/g, '');
          global.botInstances[botId].senderLids[pure] = pure;
        });
      }
    } catch (err) {
      console.error(chalk.red(`❌ Failed to update LID map for ${update.id}:`), err);
    }
    await handleGroupParticipantUpdate(XeonBotInc, update, botId);
  });

  XeonBotInc.ev.on('status.update', async status => {
    await handleStatus(XeonBotInc, status, botId);
  });

  // Pairing code logic
  if (pairingCode && !XeonBotInc.authState.creds.registered) {
    if (useMobile) throw new Error('Cannot use pairing code with mobile api');
    let phoneNumber = botConfig.phoneNumber;
    if (!phoneNumber) {
      phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Enter WhatsApp number for ${botConfig.botName} 😍\nFormat: 23481376552730 (without + or spaces): `)));
    }
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (!phoneNumber.startsWith('234')) {
      phoneNumber = '234' + phoneNumber.replace(/^0+/, '');
    }
    setTimeout(async () => {
      try {
        let code = await XeonBotInc.requestPairingCode(phoneNumber);
        code = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log(chalk.black(chalk.bgGreen(`Your Pairing Code : `)), chalk.black(chalk.white(code)));
        console.log(chalk.yellow(`

Please enter this code in your WhatsApp app:

1. Open WhatsApp
2. Go to Settings > Linked Devices
3. Tap "Link a Device"
4. Enter the code shown above`));
      } catch (error) {
        console.error('Error requesting pairing code:', error);
      }
    }, 3000);
  }

  return XeonBotInc;
}

// Question helper
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise(resolve => rl.question(text, resolve));

// Start all bots
async function startAllBots() {
  for (let i = 0; i < settings.bots.length; i++) {
    const botConfig = settings.bots[i];
    const botId = `bot${i + 1}`;
    if (!botConfig.SESSION_ID) {
      console.log(chalk.yellow(`⚠️ Skipping ${botConfig.botName}: SESSION_ID missing.`));
      continue;
    }
    console.log(chalk.cyan(`🚀 Starting bot: ${botConfig.botName} [${botId}]`));
    const sock = await startBot(botConfig, botId);
    if (!global.botInstances) global.botInstances = {};
    global.botInstances[botId] = sock;
    if (i < settings.bots.length - 1) {
      console.log(chalk.yellow('🕒 Waiting 5 seconds before starting next bot...'));
      await delay(5000);
    }
  }
}

// Watch for changes in settings.js
fs.watchFile(path.join(__dirname, 'settings.js'), async (curr, prev) => {
  if (curr.mtime !== prev.mtime) {
    try {
      console.log(chalk.blue('🔄 Reloading settings...'));
      delete require.cache[require.resolve('./settings')];
      const newSettings = require('./settings');

      // Stop removed bots
      for (let i = 0; i < Math.max(settings.bots.length, newSettings.bots.length); i++) {
        const oldBot = settings.bots[i];
        const newBot = newSettings.bots[i];
        const botId = `bot${i + 1}`;
        const oldSession = oldBot ? oldBot.SESSION_ID : null;
        const newSession = newBot ? newBot.SESSION_ID : null;

        if (oldSession && !newSession && oldBot) {
          console.log(chalk.yellow(`🛑 Session ID removed for ${oldBot.botName}, stopping bot...`));
          if (global.botInstances?.[botId]) {
            const sessionPath = path.join(__dirname, 'session', botId);
            (async () => {
              try {
                await global.botInstances[botId].logout();
                rmSync(sessionPath, { recursive: true, force: true });
                console.log(chalk.green(`🗑️ Session folder deleted: ${sessionPath}`));
              } catch (err) {
                console.error(chalk.red(`❌ Failed to clean up session: ${err.message}`));
              }
              delete global.botInstances[botId];
            })();
          }
        }
      }

      // Restart updated bots
      for (let i = 0; i < newSettings.bots.length; i++) {
        const oldBot = settings.bots[i];
        const newBot = newSettings.bots[i];
        const botId = `bot${i + 1}`;
        const oldSession = oldBot ? oldBot.SESSION_ID : null;
        const newSession = newBot ? newBot.SESSION_ID : null;

        const wasLoggedOut = global.botInstances[botId]?.loggedOut;
        if (wasLoggedOut && oldSession === newSession) {
          console.log(chalk.yellow(`⏭️ Skipping restart for ${newBot.botName} — was manually logged out.`));
          continue;
        }

        if (!oldBot || oldSession !== newSession) {
          console.log(chalk.green(`🆕 Starting new/updated bot: ${newBot.botName} [${botId}]`));
          if (global.botInstances?.[botId]) {
            (async () => {
              await global.botInstances[botId].logout().catch(() => {});
              delete global.botInstances[botId];
            })();
          }
          const sock = await startBot(newBot, botId);
          if (!global.botInstances) global.botInstances = {};
          global.botInstances[botId] = sock;
        }
      }

      settings = newSettings;
      console.log(chalk.green('✅ Settings reloaded successfully!'));
    } catch (error) {
      console.error(chalk.red('❌ Error reloading settings:', error.message));
    }
  }
});

// Start all bots
startAllBots().catch(console.error);

// Handle uncaught exceptions
process.on('uncaughtException', err => {
  console.error('Uncaught Exception:', err);
});
process.on('unhandledRejection', err => {
  console.error('Unhandled Rejection:', err);
});

console.log(chalk.greenBright('✅ Multi-account WhatsApp bot started successfully!'));

// Telegram Admin Bot Integration
require('./telegrambot.js');