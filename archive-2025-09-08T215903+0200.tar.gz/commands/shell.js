const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

async function shellCommand(sock, chatId, message, botId) {
    const args = message.trim().split(' ').slice(1).join(' ');
    
    if (!args) {
        return sock.sendMessage(chatId, {
            text: '❌ Please provide a shell command to execute.',
        });
    }

    try {
        const { stdout, stderr } = await execPromise(args);
        
        let output = '';
        if (stdout) output += '✅ Output:\n' + stdout;
        if (stderr) output += '\n⚠️ Error:\n' + stderr;

        if (output.length > 4096) {
            // Send as file if too long
            const tmpFile = require('tmp');
            tmpFile.writeFileSync('/tmp/shell_output.txt', output);
            await sock.sendMessage(chatId, {
                document: fs.readFileSync('/tmp/shell_output.txt'),
                mimetype: 'text/plain',
                fileName: 'shell_output.txt'
            });
        } else {
            await sock.sendMessage(chatId, {
                text: `\`\`\`${output || 'No output'}\`\`\``
            });
        }
    } catch (error) {
        console.error('Error executing shell command:', error);
        await sock.sendMessage(chatId, {
            text: `❌ Failed to execute command: ${error.message}`,
        });
    }
}

module.exports = { shellCommand };