const fs = require('fs');
const path = require('path');
const { channelInfo } = require('../lib/messageConfig');

// Function to get bot-specific banned.json path
function getBotDataPath(botId, filename) {
    if (!botId || typeof botId !== 'string' || !/^[a-zA-Z0-9_-]+$/.test(botId)) {
        throw new Error(`Invalid botId: ${botId}. Must be a valid alphanumeric string.`);
    }
    const dataDir = path.join(__dirname, '..', 'data', botId);
    try {
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
    } catch (err) {
        console.error(`❌ Failed to create directory: ${dataDir}`, err);
        return null;
    }
    const filePath = path.join(dataDir, filename);
    // Initialize default data if file doesn't exist
    const defaults = {
        'banned.json': JSON.stringify([], null, 2)
    };
    if (!fs.existsSync(filePath) && defaults[filename]) {
        try {
            fs.writeFileSync(filePath, defaults[filename]);
        } catch (err) {
            console.error(`❌ Failed to write default file: ${filePath}`, err);
            return null;
        }
    }
    return filePath;
}

async function unbanCommand(sock, chatId, message, botId) {
    let userToUnban;

    // Extract user from mention or reply
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToUnban = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    } else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToUnban = message.message.extendedTextMessage.contextInfo.participant;
    }

    if (!userToUnban) {
        await sock.sendMessage(chatId, {
            text: 'Please mention the user or reply to their message to unban!',
            ...channelInfo
        });
        return;
    }

    // Validate botId
    if (!botId || typeof botId !== 'string') {
        await sock.sendMessage(chatId, {
            text: '❌ Bot ID is missing or invalid.',
            ...channelInfo
        });
        return;
    }

    try {
        const bannedFilePath = getBotDataPath(botId, 'banned.json');
        if (!bannedFilePath) {
            await sock.sendMessage(chatId, {
                text: '❌ Failed to access ban list for this bot.',
                ...channelInfo
            });
            return;
        }

        let bannedUsers;
        try {
            const data = fs.readFileSync(bannedFilePath);
            bannedUsers = JSON.parse(data);
        } catch (err) {
            console.error(`❌ Failed to read or parse banned.json for bot: ${botId}`, err);
            await sock.sendMessage(chatId, {
                text: '❌ Corrupted or unreadable ban list.',
                ...channelInfo
            });
            return;
        }

        const userIndex = bannedUsers.indexOf(userToUnban);
        if (userIndex > -1) {
            bannedUsers.splice(userIndex, 1);
            fs.writeFileSync(bannedFilePath, JSON.stringify(bannedUsers, null, 2));

            await sock.sendMessage(chatId, {
                text: `✅ Successfully unbanned @${userToUnban.split('@')[0]}!`,
                mentions: [userToUnban],
                ...channelInfo
            });
        } else {
            await sock.sendMessage(chatId, {
                text: `⚠️ @${userToUnban.split('@')[0]} is not currently banned.`,
                mentions: [userToUnban],
                ...channelInfo
            });
        }
    } catch (error) {
        console.error('Error in unban command:', error);
        await sock.sendMessage(chatId, {
            text: '❌ An unexpected error occurred while processing the unban request.',
            ...channelInfo
        });
    }
}

module.exports = unbanCommand;