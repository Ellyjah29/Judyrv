const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('baileys');
const { writeFile } = require('fs/promises');

/* =========================================
   🔧  CONSTANTS & SMALL UTILITIES
   ========================================= */
const prefix = '.';

/* prettier-ignore */ const icons = {
  header : '🔰',  on: '✅', off: '🛑', warn: '⚠️', err: '❌',
  info   : 'ℹ️',  save: '💾', del: '🗑️'
};

const box = (title, lines) => [
  `╭━━━[ *${icons.header} ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

const sendBox = (sock, chatId, title, lines, extra = {}) =>
  sock.sendMessage(chatId, { text: box(title, lines), ...extra });

/* =========================================
   🗂️  PER-BOT STATE
   ========================================= */
const messageStore = {}; // { botId: Map }

/* ---------- config helpers ---------- */
const cfgPath = botId => path.join(__dirname, `../data/${botId}/antidelete.json`);
const loadCfg  = botId => {
  try {
    if (!fs.existsSync(cfgPath(botId))) return { enabled: false };
    return JSON.parse(fs.readFileSync(cfgPath(botId)));
  } catch { return { enabled: false }; }
};
const saveCfg = (botId, cfg) =>
  fs.writeFileSync(cfgPath(botId), JSON.stringify(cfg, null, 2));

/* ---------- media temp folder ---------- */
const tmpDir = botId => {
  const dir = path.join(__dirname, `../tmp/${botId}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

/* =========================================
   📜  COMMAND HANDLER
   ========================================= */
async function handleAntideleteCommand(sock, chatId, message, arg, botId) {
  if (!message.key.fromMe)
    return sendBox(sock, chatId, 'Antidelete', [
      `${icons.err}  Only the *bot owner* can use this command.`
    ]);

  const cfg = loadCfg(botId);

  /* no argument ➜ show status */
  if (!arg) {
    return sendBox(sock, chatId, 'Antidelete Setup', [
      `${icons.info}  Current Status : ${cfg.enabled ? 'ON' : 'OFF'}`,
      '',
      `${prefix}antidelete on   – Enable`,
      `${prefix}antidelete off  – Disable`
    ]);
  }

  /* toggle on/off */
  if (arg === 'on' || arg === 'off') {
    cfg.enabled = arg === 'on';
    saveCfg(botId, cfg);
    return sendBox(sock, chatId, 'Antidelete', [
      `${cfg.enabled ? icons.on : icons.off}  Antidelete *${cfg.enabled ? 'enabled' : 'disabled'}*.`
    ]);
  }

  /* invalid arg */
  return sendBox(sock, chatId, 'Antidelete', [
    `${icons.err}  Invalid option. Type *${prefix}antidelete* for help.`
  ]);
}

/* =========================================
   💾  STORE EVERY INCOMING MESSAGE
   ========================================= */
async function storeMessage(message, botId) {
  const cfg = loadCfg(botId);
  if (!cfg.enabled || !message.key?.id) return;

  try {
    const id      = message.key.id;
    const sender  = message.key.participant || message.key.remoteJid;
    const group   = message.key.remoteJid.endsWith('@g.us') ? message.key.remoteJid : null;

    let content   = '';
    let mediaType = '';
    let mediaPath = '';

    /* detect & save content / media */
    if (message.message?.conversation) {
      content = message.message.conversation;
    } else if (message.message?.extendedTextMessage?.text) {
      content = message.message.extendedTextMessage.text;
    } else if (message.message?.imageMessage) {
      mediaType = 'image';
      content   = message.message.imageMessage.caption || '';
      const buf = await downloadContentFromMessage(message.message.imageMessage, 'image');
      mediaPath = path.join(tmpDir(botId), `${id}.jpg`);
      await writeFile(mediaPath, buf);
    } else if (message.message?.stickerMessage) {
      mediaType = 'sticker';
      const buf = await downloadContentFromMessage(message.message.stickerMessage, 'sticker');
      mediaPath = path.join(tmpDir(botId), `${id}.webp`);
      await writeFile(mediaPath, buf);
    } else if (message.message?.videoMessage) {
      mediaType = 'video';
      content   = message.message.videoMessage.caption || '';
      const buf = await downloadContentFromMessage(message.message.videoMessage, 'video');
      mediaPath = path.join(tmpDir(botId), `${id}.mp4`);
      await writeFile(mediaPath, buf);
    }

    if (!messageStore[botId]) messageStore[botId] = new Map();
    messageStore[botId].set(id, {
      content, mediaType, mediaPath, sender, group,
      timestamp: Date.now()
    });
  } catch (e) {
    console.error(`storeMessage[${botId}]`, e);
  }
}

/* =========================================
   🚨  HANDLE MESSAGE DELETION
   ========================================= */
async function handleMessageRevocation(sock, revocation, botId) {
  const cfg = loadCfg(botId);
  if (!cfg.enabled) return;

  try {
    const msgId  = revocation.message.protocolMessage.key.id;
    const by     = revocation.participant || revocation.key.participant || revocation.key.remoteJid;
    const owner  = `${sock.user.id.split(':')[0]}@s.whatsapp.net`;
    if (by.includes(sock.user.id) || by === owner) return;

    const store  = messageStore[botId] || new Map();
    const orig   = store.get(msgId);
    if (!orig) return;

    const [byTag, sendTag] = [by, orig.sender].map(jid => `@${jid.split('@')[0]}`);
    const groupName = orig.group ? (await sock.groupMetadata(orig.group)).subject : '';

    const ts = new Date().toLocaleString('en-US', {
      timeZone: 'Africa/Lagos', hour12: true,
      hour:'2-digit', minute:'2-digit', second:'2-digit',
      day:'2-digit', month:'2-digit', year:'numeric'
    });

    /* ----- build and send report ----- */
    const lines = [
      `${icons.del}  *Deleted By* : ${byTag}`,
      `${icons.info}  *Sender*    : ${sendTag}`,
      `📱  *Number*    : ${orig.sender}`,
      `🕒  *Time*      : ${ts}`,
      ...(groupName ? [`👥  *Group*     : ${groupName}`] : []),
      '',
      orig.content ? `💬  *Deleted Message*:\n${orig.content}` : ''
    ].filter(Boolean);

    await sendBox(sock, owner, 'Antidelete Report', lines, { mentions: [by, orig.sender] });

    /* ----- forward media, if any ----- */
    if (orig.mediaType && fs.existsSync(orig.mediaPath)) {
      const opts = { caption: `*Deleted ${orig.mediaType}* from ${sendTag}`, mentions:[orig.sender] };

      try {
        switch (orig.mediaType) {
          case 'image':   await sock.sendMessage(owner, { image  : { url: orig.mediaPath }, ...opts }); break;
          case 'sticker': await sock.sendMessage(owner, { sticker: { url: orig.mediaPath }, ...opts }); break;
          case 'video':   await sock.sendMessage(owner, { video  : { url: orig.mediaPath }, ...opts }); break;
        }
      } catch (err) {
        await sendBox(sock, owner, 'Antidelete', [`${icons.err}  Error sending media: ${err.message}`]);
      }
      fs.unlink(orig.mediaPath, () => {});
    }

    store.delete(msgId);
  } catch (e) {
    console.error(`handleMessageRevocation[${botId}]`, e);
  }
}

/* =========================================
   🌟  EXPORTS
   ========================================= */
module.exports = {
  handleAntideleteCommand,
  storeMessage,
  handleMessageRevocation
};