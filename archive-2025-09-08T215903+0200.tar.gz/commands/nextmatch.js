const axios = require('axios');
const moment = require('moment-timezone');

async function nextMatchCommand(sock, chatId, message) {
  try {
    await sock.sendPresenceUpdate('composing', chatId);

    const userMessage = message.message?.conversation?.toLowerCase() || message.message?.extendedTextMessage?.text?.toLowerCase() || '';
    const sportMatch = userMessage.match(/\.nextmatch\s+(\w+)/);
    const sport = sportMatch ? sportMatch[1] : 'football';

    const sportMap = {
      football: 'soccer',
      afl: 'afl',
      baseball: 'baseball',
      basketball: 'basketball',
      formula: 'formula-1',
      handball: 'handball',
      hockey: 'hockey',
      mma: 'mma',
      nba: 'nba',
      nfl: 'nfl',
      rugby: 'rugby',
      volleyball: 'volleyball',
    };

    const apiSport = sportMap[sport] || 'soccer';
    if (!sportMap[sport]) {
      await sock.sendMessage(chatId, {
        text: '❌ Unsupported sport. Try: football, basketball, nfl, rugby, baseball, etc.',
      });
      return;
    }

    const apiKey = '0c4c33bfcb5327599859c9efbbd7d5be';
    const apiUrl = `https://v3.football.api-sports.io/fixtures?next=5&sport=${apiSport}`;

    const response = await axios.get(apiUrl, {
      headers: { 'x-apisports-key': apiKey },
    });

    const fixtures = response.data.response || [];

    if (!fixtures.length) {
      await sock.sendMessage(chatId, {
        text: `📅 No upcoming ${sport} matches found. Try again later.`,
      });
      return;
    }

    let responseText = `📅 *Upcoming ${sport.charAt(0).toUpperCase() + sport.slice(1)} Matches:*\n\n`;

    fixtures.forEach((match, index) => {
      const home = match.teams?.home?.name || 'TBD';
      const away = match.teams?.away?.name || 'TBD';
      const league = match.league?.name || '';
      const time = moment(match.fixture.date).tz('Africa/Lagos').format('ddd, MMM D • h:mm A');

      responseText += `${index + 1}. *${league}*\n   ${home} vs ${away}\n   🕒 ${time}\n\n`;
    });

    // Buttons
    const buttons = [
      { buttonId: '.nextmatch football', buttonText: { displayText: '⚽ FOOTBALL' }, type: 1 },
      { buttonId: '.nextmatch basketball', buttonText: { displayText: '🏀 BASKETBALL' }, type: 1 },
      { buttonId: '.nextmatch nfl', buttonText: { displayText: '🏈 NFL' }, type: 1 },
      { buttonId: '.nextmatch rugby', buttonText: { displayText: '🏉 RUGBY' }, type: 1 },
      { buttonId: '.nextmatch baseball', buttonText: { displayText: '⚾ BASEBALL' }, type: 1 }
    ];

    await sock.sendMessage(chatId, {
      text: responseText,
      buttons,
      headerType: 1,
    });

  } catch (error) {
    console.error('Error in nextmatch command:', error.message);
    await sock.sendMessage(chatId, {
      text: '❌ Failed to fetch upcoming matches. Try again later.',
    });
  } finally {
    await sock.sendPresenceUpdate('paused', chatId);
  }
}

module.exports = nextMatchCommand;