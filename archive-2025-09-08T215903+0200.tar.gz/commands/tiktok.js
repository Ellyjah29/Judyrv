const puppeteer = require("puppeteer");

async function tiktokCommand(sock, chatId, message, botId) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        if (!text) {
            return await sock.sendMessage(chatId, {
                text: "❌ Please provide a TikTok link.\nExample: .tiktok https://vm.tiktok.com/xxxx/"
            });
        }

        const url = text.split(" ")[1];
        if (!url) {
            return await sock.sendMessage(chatId, { text: "❌ Please provide a TikTok link." });
        }

        // React to show processing
        await sock.sendMessage(chatId, { react: { text: "🔄", key: message.key } });

        const browser = await puppeteer.launch({
            headless: true,
            args: ["--no-sandbox", "--disable-setuid-sandbox"]
        });

        const page = await browser.newPage();

        // Pretend to be mobile
        await page.setUserAgent(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) " +
            "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile Safari/604.1"
        );

        await page.goto(url, { waitUntil: "networkidle2", timeout: 60000 });

        // Extract TikTok’s embedded JSON state
        const html = await page.content();
        await browser.close();

        const jsonMatch = html.match(/<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)<\/script>/);
        if (!jsonMatch) {
            return await sock.sendMessage(chatId, { text: "❌ Could not fetch TikTok video JSON." });
        }

        const jsonData = JSON.parse(jsonMatch[1]);
        const keys = Object.keys(jsonData);

        let videoUrl = null;
        let musicUrl = null;
        let desc = "";

        for (const key of keys) {
            const entry = jsonData[key];
            if (entry?.aweme?.detail) {
                const detail = entry.aweme.detail;
                if (detail.video?.playAddr?.[0]?.src) {
                    videoUrl = detail.video.playAddr[0].src;
                }
                if (detail.music?.playUrl?.[0]?.src) {
                    musicUrl = detail.music.playUrl[0].src;
                }
                desc = detail.desc || "";
                break;
            }
        }

        if (!videoUrl) {
            return await sock.sendMessage(chatId, { text: "❌ Could not fetch TikTok video. Try again." });
        }

        // Send video
        await sock.sendMessage(chatId, {
            video: { url: videoUrl },
            mimetype: "video/mp4",
            caption: `🎥 Downloaded by SEPTORCH\n\n${desc}`
        }, { quoted: message });

        // Send music if available
        if (musicUrl) {
            await sock.sendMessage(chatId, {
                audio: { url: musicUrl },
                mimetype: "audio/mp4",
                ptt: false,
                fileName: "tiktok_music.mp3"
            }, { quoted: message });
        }

    } catch (error) {
        console.error("TikTok command error:", error);
        await sock.sendMessage(chatId, { text: "❌ Failed to download TikTok video." });
    }
}

module.exports = tiktokCommand;