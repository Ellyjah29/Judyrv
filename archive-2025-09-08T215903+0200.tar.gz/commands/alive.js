const settings = require("../settings");

async function aliveCommand(sock, chatId) {
    try {
        const message = 
`╭━━━[ *🤖 SEPTORCH BOT STATUS* ]━━━╮
┃
┃ 📦 *Version:* ${settings.version}
┃ 📡 *Status:* Online & Responsive
┃ 🌍 *Mode:* Public
┃
┃ ⚙️ *Main Features:*
┃ ├─ ✅ Group Management
┃ ├─ 🚫 Antilink & Spam Control
┃ ├─ 🎮 Fun & Utility Commands
┃ └─ 📈 Channel Growth Tools
┃
┃ 🔖 Type *.menu* to explore all commands
┃
╰━━━━━━━━━━━━━━━━━━━━━━━╯`;

        await sock.sendMessage(chatId, {
            text: message,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363387922693296@newsletter',
                    newsletterName: 'SEPTORCH_BOT MD',
                    serverMessageId: -1
                }
            }
        });
    } catch (error) {
        console.error('Error in alive command:', error);
        await sock.sendMessage(chatId, { text: '✅ SEPTORCH Bot is online and ready!' });
    }
}

module.exports = aliveCommand;