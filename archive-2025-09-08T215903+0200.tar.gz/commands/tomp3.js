import { toAudio } from '../lib/converter.js';

async function toMp3Command(sock, chatId, message, userMessage, botId) {
    const q = message.quoted ? message.quoted : message;
    const mime = (q || q.msg).mimetype || q.mediaType || '';
    
    if (!/video|audio/.test(mime)) {
        return sock.sendMessage(chatId, {
            text: '⚠️ ¿Y el video? Responde a un video o nota de voz para convertir a MP3'
        });
    }

    try {
        await sock.sendMessage(chatId, {
            text: 'Calmaoooo estoy procesando 😎\n\n> Convirtiendo de MP4 a MP3 🔄'
        });

        const media = await q.download();
        if (!media) throw new Error('Failed to download media');

        const audio = await toAudio(media, 'mp4');
        if (!audio.data) throw new Error('Conversion failed: No audio data returned');

        await sock.sendMessage(chatId, {
            audio: audio.data,
            mimetype: 'audio/mpeg',
            contextInfo: {}
        }, {
            quoted: message
        });

    } catch (error) {
        console.error('Error converting to MP3:', error);
        await sock.sendMessage(chatId, {
            text: `⚠️ Tremendo... ¿No sabes usar el comando?\nResponde a un video o nota de voz válido.\n\nError: ${error.message}`
        });
    }
}

export default toMp3Command;