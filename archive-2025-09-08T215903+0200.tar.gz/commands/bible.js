const fetch = require('node-fetch');

// Boxed message formatter
const box = (title, lines) => [
  `╭━━━[ *📖 ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(line => `┃ ${line}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

const sendBox = async (sock, chatId, title, lines, buttons = []) => {
  await sock.sendMessage(chatId, {
    text: box(title, lines),
    buttons,
    footer: '🕊 Powered by Bible API',
  });
};

/**
 * Handle .bible [reference] command
 */
async function bibleCommand(sock, chatId, message, botId) {
  const input = message.trim().split(' ').slice(1).join(' ');
  if (!input) {
    return sendBox(sock, chatId, 'Bible', [
      '❌ Please provide a verse reference.',
      '',
      '📝 Example:',
      '• `.bible John 3:16`',
      '• `.bible John 3:16-18`'
    ]);
  }

  // Check for optional translation argument
  const match = input.match(/(.*?)\s*--trans\s*(\w+)/i);
  const ref = match ? match[1].trim() : input;
  const translation = match ? match[2].trim().toLowerCase() : 'kjv';

  const formattedRef = encodeURIComponent(ref.replace(/\s+/g, ' '));
  const apiUrl = `https://bible-api.com/${formattedRef}?translation=${translation}`;

  try {
    const response = await fetch(apiUrl);
    const data = await response.json();

    if (!data || !data.verses || data.verses.length === 0 || data.error) {
      return sendBox(sock, chatId, 'Bible', [
        `❌ No verse found for: *${ref}*`,
        '📌 Please check your reference.'
      ]);
    }

    const lines = [`*${data.reference}* (${data.translation_id.toUpperCase()})`, ''];

    for (const v of data.verses) {
      lines.push(`📖 ${v.book_name} ${v.chapter}:${v.verse}`);
      lines.push(`   ${v.text.trim()}`);
      lines.push('');
    }

    // Buttons
    const lastVerse = data.verses[data.verses.length - 1];
    const firstVerse = data.verses[0];
    const nextVerse = `${lastVerse.book_name} ${lastVerse.chapter}:${lastVerse.verse + 1}`;
    const prevVerse = `${firstVerse.book_name} ${firstVerse.chapter}:${Math.max(1, firstVerse.verse - 1)}`;
    const nextRange = `${lastVerse.book_name} ${lastVerse.chapter}:${lastVerse.verse + 1}-${lastVerse.verse + 3}`;

    const buttons = [
      { buttonId: `.bible ${prevVerse} --trans ${translation}`, buttonText: { displayText: '⏮️ Previous' }, type: 1 },
      { buttonId: `.bible ${nextVerse} --trans ${translation}`, buttonText: { displayText: '➡️ Next' }, type: 1 },
      { buttonId: `.bible ${nextRange} --trans ${translation}`, buttonText: { displayText: '📜 Next Range' }, type: 1 }
    ];

    // Translation list message
    const translationList = {
      title: '🌐 Select Bible Translation',
      description: 'Choose your preferred Bible version',
      buttonText: '📘 Change Translation',
      listType: 1,
      sections: [
        {
          title: '📖 Available Translations',
          rows: [
            { title: 'King James Version (KJV)', rowId: `.bible ${ref} --trans kjv` },
            { title: 'English Standard Version (ESV)', rowId: `.bible ${ref} --trans esv` },
            { title: 'New International Version (NIV)', rowId: `.bible ${ref} --trans niv` },
            { title: 'World English Bible (WEB)', rowId: `.bible ${ref} --trans web` }
          ]
        }
      ]
    };

    // Send main Bible response with buttons
    await sendBox(sock, chatId, 'Bible', lines, buttons);

    // Then send translation picker
    await sock.sendMessage(chatId, translationList);

  } catch (error) {
    console.error('Bible verse fetch error:', error);
    return sendBox(sock, chatId, 'Bible', [
      '❌ Failed to retrieve Bible verse.',
      '📡 Please try again later.'
    ]);
  }
}

module.exports = { bibleCommand };