const fs = require('fs');
const path = require('path');
const isAdmin = require('../lib/isAdmin');

/* =========================================
   🔧  HELPER: Bot-specific data path
   ========================================= */
function dataPath(botId, filename) {
    if (!botId || typeof botId !== 'string') {
        throw new Error(`Invalid botId: ${botId}`);
    }
    const dir = path.join(__dirname, '..', 'data', botId);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    return path.join(dir, filename);
}

/* =========================================
   ⚠️  WARN COMMAND
   ========================================= */
async function warnCommand(sock, chatId, senderId, mentionedJids, message, botId) {
    // ✅ Add botId parameter

    try {
        // Validate botId
        if (!botId) {
            console.error('warnCommand: Missing botId');
            return;
        }

        // Only works in groups
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, {
                text: 'This command can only be used in groups!'
            });
            return;
        }

        // Check admin status
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId, botId);

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, {
                text: '❌ Error: Please make the bot an admin first to use this command.'
            });
            return;
        }

        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, {
                text: '❌ Error: Only group admins can use the warn command.'
            });
            return;
        }

        // Get user to warn
        let userToWarn;

        if (mentionedJids && mentionedJids.length > 0) {
            userToWarn = mentionedJids[0];
        } else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToWarn = message.message.extendedTextMessage.contextInfo.participant;
        }

        if (!userToWarn) {
            await sock.sendMessage(chatId, {
                text: '❌ Error: Please mention the user or reply to their message to warn!'
            });
            return;
        }

        // Prevent self-warn
        if (userToWarn === senderId) {
            await sock.sendMessage(chatId, {
                text: '⚠️ You cannot warn yourself.',
            });
            return;
        }

        // Add small delay to prevent rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Load warnings (bot-specific)
        const warningsFile = dataPath(botId, 'warnings.json');
        let warnings = {};

        try {
            if (fs.existsSync(warningsFile)) {
                const data = fs.readFileSync(warningsFile, 'utf8');
                warnings = data.trim() ? JSON.parse(data) : {};
            }
        } catch (err) {
            console.warn(`Failed to read warnings for bot ${botId}, starting fresh.`);
            warnings = {};
        }

        // Initialize structure
        if (!warnings[chatId]) warnings[chatId] = {};
        if (!warnings[chatId][userToWarn]) warnings[chatId][userToWarn] = 0;

        warnings[chatId][userToWarn]++;
        const userWarnings = warnings[chatId][userToWarn];

        // Save updated warnings
        fs.writeFileSync(warningsFile, JSON.stringify(warnings, null, 2));

        // Send warning message
        const warningMessage = `*『 WARNING ALERT 』*\n\n` +
            `👤 *Warned User:* @${userToWarn.split('@')[0]}\n` +
            `⚠️ *Warning Count:* ${userWarnings}/3\n` +
            `👑 *Warned By:* @${senderId.split('@')[0]}\n\n` +
            `📅 *Date:* ${new Date().toLocaleString()}`;

        await sock.sendMessage(chatId, {
            text: warningMessage,
            mentions: [userToWarn, senderId]
        });

        // Auto-kick on 3 warnings
        if (userWarnings >= 3) {
            await new Promise(resolve => setTimeout(resolve, 1500)); // Delay before kick

            try {
                await sock.groupParticipantsUpdate(chatId, [userToWarn], 'remove');
                delete warnings[chatId][userToWarn];
                fs.writeFileSync(warningsFile, JSON.stringify(warnings, null, 2));

                const kickMessage = `*『 AUTO-KICK 』*\n\n` +
                    `@${userToWarn.split('@')[0]} has been removed from the group after receiving 3 warnings! ⚠️`;

                await sock.sendMessage(chatId, {
                    text: kickMessage,
                    mentions: [userToWarn]
                });
            } catch (kickError) {
                console.error('Failed to kick user:', kickError);
                await sock.sendMessage(chatId, {
                    text: `❌ Failed to remove @${userToWarn.split('@')[0]} after 3 warnings. Please check bot permissions.`,
                    mentions: [userToWarn]
                });
            }
        }
    } catch (error) {
        console.error('Error in warnCommand:', error);

        // Rate limit handling
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, {
                    text: '❌ Rate limit reached. Please try again in a few seconds.'
                });
            } catch (e) {
                console.error('Could not send rate limit message:', e);
            }
        } else {
            try {
                await sock.sendMessage(chatId, {
                    text: '❌ Failed to warn user. Make sure the bot is admin and has sufficient permissions.'
                });
            } catch (e) {
                console.error('Could not send error message:', e);
            }
        }
    }
}

module.exports = warnCommand;