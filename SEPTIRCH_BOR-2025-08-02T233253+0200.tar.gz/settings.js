exports.bots = [
  {
    "botName": "New Bot",
    "themeemoji": "🦄",
    "ownerNumber": "2349047943737",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "HrpuXA7ye7ND4U35",
    "telegramUserId": null,
    "expiryTimestamp": 1753786696977,
    "createdAt": "2025-08-02T21:27:36.661Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🤖",
    "ownerNumber": "2349047943737",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "BEz8KN94hgQd8ZEq",
    "telegramUserId": null,
    "expiryTimestamp": 1753810236437,
    "createdAt": "2025-08-02T21:27:36.678Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "⚡",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "KD08JslW0990KfJt",
    "telegramUserId": null,
    "expiryTimestamp": 1751324399000,
    "createdAt": "2025-08-02T21:27:36.813Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "⚡",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "BSVMaKBpxTCwam23",
    "telegramUserId": null,
    "expiryTimestamp": 1752188399000,
    "createdAt": "2025-08-02T21:27:37.277Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "👑",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "3mcHOwEBAhdmKo07",
    "telegramUserId": null,
    "expiryTimestamp": 1752361199000,
    "createdAt": "2025-08-02T21:27:37.277Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🎯",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "DvYTwKp3Snr0qWwu",
    "telegramUserId": null,
    "expiryTimestamp": 1752361199000,
    "createdAt": "2025-08-02T21:27:37.725Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "💫",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "DrjhTjlqRn5jy9z3",
    "telegramUserId": null,
    "expiryTimestamp": 1753788399409,
    "createdAt": "2025-08-02T21:27:37.904Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🌟",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "uoosmdiKZDNwtY7F",
    "telegramUserId": null,
    "expiryTimestamp": 1754175599000,
    "createdAt": "2025-08-02T21:27:38.470Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🔥",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "8qleyX244yeq13x3",
    "telegramUserId": null,
    "expiryTimestamp": 1753796135547,
    "createdAt": "2025-08-02T21:27:38.719Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🛡️",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "vZtxcwd9Ny8WQXwU",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:38.724Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🚀",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "S8lGweeQMT75XaVm",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:38.813Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "⚙️",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "QlsYFh3E4vSXLoS1",
    "telegramUserId": null,
    "expiryTimestamp": 1753869068620,
    "createdAt": "2025-08-02T21:27:39.277Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "💎",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "QlBlYKtN1ikxtH2T",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:39.588Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "BMs9CFI810SsCAFP",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:39.588Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "ISFFtwxC61timiHV",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:39.747Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "iYlfYd0wH5xUdswb",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:39.748Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "cJ66rY1QqOhs4yq5",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:39.750Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "atQdEFmA9GRmfiC7",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:39.750Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "ertOldGX0Us11Kby",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:39.751Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "clIHKyyV9cpE78bu",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-02T21:27:39.808Z"
  }
];
exports.userStates = {
  "1691883937": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7949
  },
  "1872222884": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8797
  },
  "1984959557": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3602
  },
  "2046598405": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8170
  },
  "8135871264": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7828
  },
  "6834525619": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7904
  },
  "6178610094": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8106
  },
  "6582804562": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8122
  },
  "7179979536": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "lastRestart": 1753722572914,
    "promptMessageId": 8165
  },
  "7569969378": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8197
  },
  "5603889826": {
    "step": "awaiting_session_id",
    "authKey": "lNNXjvoQoMHUEFMz",
    "promptMessageId": 8265
  },
  "5613886154": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8335
  },
  "8454766080": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8372
  },
  "6936711750": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8386
  },
  "7013483934": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8411
  },
  "6318304090": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8454
  },
  "7698997438": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7584
  },
  "7561987171": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8338
  },
  "7262422290": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8504
  },
  "6952558480": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8547
  },
  "7417554225": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8706
  },
  "7614436302": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8713
  },
  "6334060350": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8730
  },
  "6817161756": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8783
  },
  "7567588756": {
    "step": "awaiting_session_id",
    "authKey": "ENQQwj0TUy2pbIpY",
    "promptMessageId": 8799
  },
  "7705270175": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8039
  },
  "7738315673": {
    "step": null,
    "adminLastReset": 1754170056581,
    "adminLastRestart": 1754170104506
  }
};
exports.blacklistedUsers = [];