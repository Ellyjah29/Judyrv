const { channelInfo } = require('../lib/messageConfig');

async function clearCommand(sock, chatId, botId) {
    try {
        // Notify user
        const notice = await sock.sendMessage(chatId, {
            text: '🧹 Clearing recent bot messages...',
            ...channelInfo
        });

        // Fetch recent messages
        const messages = await sock.loadMessages(chatId, 50); // load last 50 msgs

        let deletedCount = 0;
        for (const msg of messages.messages.reverse()) {
            const fromBot = msg.key.fromMe || msg.key.participant === botId;
            const idToDelete = msg.key.id;

            if (fromBot && idToDelete) {
                await sock.sendMessage(chatId, { delete: msg.key });
                deletedCount++;
                if (deletedCount >= 10) break; // Limit to 10
            }
        }

        // Delete notification too
        await sock.sendMessage(chatId, { delete: notice.key });

    } catch (err) {
        console.error('Error in clearCommand:', err);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to clear messages!',
            ...channelInfo
        });
    }
}

module.exports = { clearCommand };