const axios = require('axios');

module.exports = async function livescoreCommand(sock, chatId, message, botId) {
  try {
    await sock.sendPresenceUpdate('composing', chatId);

    const text =
      message.message?.conversation?.toLowerCase() ||
      message.message?.extendedTextMessage?.text?.toLowerCase() ||
      message.message?.buttonsResponseMessage?.selectedButtonId?.toLowerCase() ||
      '';

    const sportMatch = text.match(/\.livescore\s+(\w+)/);
    const sport = sportMatch ? sportMatch[1] : null;

    if (!sport) {
      await sock.sendMessage(chatId, {
        text: '*🎮 Select a sport to view live scores:*',
        buttons: [
          { buttonId: '.livescore football', buttonText: { displayText: '⚽ Football' }, type: 1 },
          { buttonId: '.livescore basketball', buttonText: { displayText: '🏀 Basketball' }, type: 1 },
          { buttonId: '.livescore baseball', buttonText: { displayText: '⚾ Baseball' }, type: 1 },
          { buttonId: '.livescore nfl', buttonText: { displayText: '🏈 NFL' }, type: 1 },
          { buttonId: '.livescore rugby', buttonText: { displayText: '🏉 Rugby' }, type: 1 }
        ],
        headerType: 1
      });
      return;
    }

    const sportMap = {
      football: 'soccer',
      afl: 'afl',
      baseball: 'baseball',
      basketball: 'basketball',
      formula: 'formula-1',
      handball: 'handball',
      hockey: 'hockey',
      mma: 'mma',
      nba: 'nba',
      nfl: 'nfl',
      rugby: 'rugby',
      volleyball: 'volleyball',
    };

    const apiSport = sportMap[sport];

    if (!apiSport) {
      await sock.sendMessage(chatId, {
        text: '❌ Unsupported sport.\n\n✅ Try: football, basketball, baseball, nfl, rugby, etc.',
      });
      return;
    }

    const apiKey = '0c4c33bfcb5327599859c9efbbd7d5be'; // Replace with your key
    const apiUrl = `https://v3.football.api-sports.io/${apiSport === 'soccer' ? 'livescore' : `${apiSport}/livescore`}`;

    const response = await axios.get(apiUrl, {
      headers: { 'x-apisports-key': apiKey },
    });

    const matches = response.data.response || [];

    if (!matches.length) {
      await sock.sendMessage(chatId, {
        text: `📭 No live ${sport} matches now.`,
      });
      return;
    }

    let responseText = `🏟️ *Live ${sport.charAt(0).toUpperCase() + sport.slice(1)} Scores*\n\n`;

    matches.slice(0, 5).forEach((match, i) => {
      const home = match.teams?.home?.name || 'Home';
      const away = match.teams?.away?.name || 'Away';
      const score = `${match.goals?.home ?? 0} - ${match.goals?.away ?? 0}`;
      const status = match.fixture?.status?.short || 'LIVE';
      const league = match.league?.name || 'Unknown League';

      responseText += `${i + 1}. *${league}*\n`;
      responseText += `   ${home} vs ${away}\n`;
      responseText += `   Score: ${score} (${status})\n\n`;
    });

    await sock.sendMessage(chatId, { text: responseText });

  } catch (error) {
    console.error('LiveScore Error:', error.message);
    if (error.response?.status === 429) {
      await sock.sendMessage(chatId, {
        text: '⏳ Too many requests. Please wait or upgrade your API plan.',
      });
    } else if (error.response?.status === 401) {
      await sock.sendMessage(chatId, {
        text: '❌ Invalid API key. Please check your key in the code.',
      });
    } else {
      await sock.sendMessage(chatId, {
        text: '⚠️ Error fetching scores. Try again later.',
      });
    }
  } finally {
    await sock.sendPresenceUpdate('paused', chatId);
  }
};