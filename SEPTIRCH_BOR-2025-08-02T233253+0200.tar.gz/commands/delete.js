const isAdmin = require('../lib/isAdmin');
const { channelInfo } = require('../lib/messageConfig');

async function deleteCommand(sock, chatId, message, senderId) {
    try {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            return await sock.sendMessage(chatId, {
                text: '⚠️ *I need to be an admin to delete messages!*',
                ...channelInfo
            });
        }

        if (!isSenderAdmin) {
            return await sock.sendMessage(chatId, {
                text: '❌ *Only group admins can use the .delete command!*',
                ...channelInfo
            });
        }

        const contextInfo = message.message?.extendedTextMessage?.contextInfo;

        if (!contextInfo?.stanzaId || !contextInfo?.participant) {
            return await sock.sendMessage(chatId, {
                text: '🧾 *Please reply to a message you want to delete!*',
                ...channelInfo
            });
        }

        await sock.sendMessage(chatId, {
            delete: {
                remoteJid: chatId,
                fromMe: false,
                id: contextInfo.stanzaId,
                participant: contextInfo.participant
            }
        });

        console.log(`🗑️ Deleted message by ${contextInfo.participant} in ${chatId}`);
        
    } catch (error) {
        console.error('❌ Error in deleteCommand:', error);
        await sock.sendMessage(chatId, {
            text: '⚠️ *Something went wrong while deleting the message.*',
            ...channelInfo
        });
    }
}

module.exports = deleteCommand;