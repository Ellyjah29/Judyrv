async function githubCommand(sock, chatId) {
    const repoInfo = `*🤖 SEPTORCH_BOT MD*

*📂 CREATORS:*
THIS BOT IS CREATED BY SEPTORCH  FOR USERS TO GAIN THE BEST EXPERIENCE ON WHATSAPP MAKING WHATSAPP MORE  SPECIAL THANKS TO MR_UNIQUE_HACKER AND WhiskeySockets
Baileys IF YOU LIKE THE BOT PLEASE JOIN THE CHANNEL BELOW 

*📢 Official Channel:*
https://whatsapp.com/channel/0029Vb1ydGk8qIzkvps0nZ04

*📢 SEND BUGS OR WHAT YOU WLL LIKE US TO ADD HERE:*
https://ngl.link/septorch


_Join the channel if you like the bot!_`;

    try {
        await sock.sendMessage(chatId, {
            text: repoInfo,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363387922693296@newsletter',
                    newsletterName: 'SEPTORCH_BOT MD',
                    serverMessageId: -1
                }
            }
        });
    } catch (error) {
        console.error('Error in github command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Error fetching repository information.' 
        });
    }
}

module.exports = githubCommand; 