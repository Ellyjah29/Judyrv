const { isAdmin }  = require('../lib/isAdmin');
const { channelInfo } = require('../lib/messageConfig');

/* ── Box-style formatter ─────────────────────────────────── */
const box = (title, lines) => [
  `╔═══『 ⚠️  ${title.toUpperCase()}  ⚠️ 』═══╗`,
  ...lines.map(l => `║ ${l}`),
  '╚════════════════════════════╝'
].join('\n');

/* ── MANUAL .demote COMMAND ──────────────────────────────── */
async function demoteCommand(sock, chatId, mentionedJids, message) {
  try {
    /* group-only check */
    if (!chatId.endsWith('@g.us'))
      return sock.sendMessage(chatId, { text: '⛔ Group chat only!', ...channelInfo });

    /* admin rights */
    const { isSenderAdmin, isBotAdmin } =
      await isAdmin(sock, chatId, message.key.participant || message.key.remoteJid);

    if (!isBotAdmin)
      return sock.sendMessage(chatId, { text: '🛑 Bot needs *admin* rights.', ...channelInfo });
    if (!isSenderAdmin)
      return sock.sendMessage(chatId, { text: '❌ Only *group admins* can demote.', ...channelInfo });

    /* target(s) */
    let targets =
      mentionedJids?.length
        ? mentionedJids
        : message.message?.extendedTextMessage?.contextInfo?.participant
          ? [message.message.extendedTextMessage.contextInfo.participant]
          : [];

    if (!targets.length)
      return sock.sendMessage(chatId, {
        text: '⚠️ Mention or reply to the user you want to demote.',
        ...channelInfo
      });

    /* demote */
    await sock.groupParticipantsUpdate(chatId, targets, 'demote');

    /* craft banner */
    const executor = message.key.participant || message.key.remoteJid;
    const names    = targets.map(jid => `• @${jid.split('@')[0]}`);
    const dateStr  = new Date().toLocaleString();

    const banner = box('GROUP DEMOTION', [
      '👤 Demoted:',
      ...names,
      '',
      `👑 By: @${executor.split('@')[0]}`,
      `📅 Date: ${dateStr}`,
      '',
      '⬇️ Rank removed. Please respect new hierarchy.'
    ]);

    await sock.sendMessage(chatId, {
      text: banner,
      mentions: [...targets, executor],
      ...channelInfo
    });

  } catch (e) {
    console.error('demoteCommand error:', e);
    await sock.sendMessage(chatId, {
      text: '❌ Failed to demote user(s). Check bot permissions.',
      ...channelInfo
    });
  }
}

/* ── AUTO DEMOTION EVENT ─────────────────────────────────── */
async function handleDemotionEvent(sock, groupId, participants, author) {
  try {
    const names = participants.map(jid => `• @${jid.split('@')[0]}`);
    const executorTag = author ? `@${author.split('@')[0]}` : 'System';
    const mentionList = author ? [...participants, author] : participants;
    const banner = box('GROUP DEMOTION', [
      '👤 Demoted:',
      ...names,
      '',
      `👑 By: ${executorTag}`,
      `📅 Date: ${new Date().toLocaleString()}`,
      '',
      '⬇️ Rank removed. Please follow new chain of command.'
    ]);

    await sock.sendMessage(groupId, {
      text: banner,
      mentions: mentionList,
      ...channelInfo
    });

  } catch (e) {
    console.error('handleDemotionEvent error:', e);
  }
}

module.exports = { demoteCommand, handleDemotionEvent };