// commands/tictactoe.js
const TicTacToe = require('../lib/tictactoe');

const allGames = {}; // games[botId] = { gameId: room }

function getGameStore(botId) {
    if (!allGames[botId]) allGames[botId] = {};
    return allGames[botId];
}

function scheduleAutoEnd(gameStore, roomId, sock, chatId, players) {
    if (gameStore[roomId].timeout) clearTimeout(gameStore[roomId].timeout);
    gameStore[roomId].timeout = setTimeout(async () => {
        delete gameStore[roomId];
        await sock.sendMessage(chatId, {
            text: `⌛ Game ended due to inactivity.`,
            mentions: players
        });
    }, 5 * 60 * 1000); // 5 minutes
}

async function tictactoeCommand(sock, chatId, senderId, text) {
    try {
        const botId = sock.user.id;
        const gameStore = getGameStore(botId);

        if (Object.values(gameStore).find(room =>
            [room.game.playerX, room.game.playerO].includes(senderId)
        )) {
            await sock.sendMessage(chatId, {
                text: '❌ You are already in a game. Type *surrender* to quit.'
            });
            return;
        }

        let room = Object.values(gameStore).find(r =>
            r.state === 'WAITING' &&
            (text ? r.name === text : true)
        );

        if (room) {
            room.o = chatId;
            room.game.playerO = senderId;
            room.state = 'PLAYING';

            const arr = room.game.render().map(v => ({
                'X': '❎', 'O': '⭕',
                '1': '1️⃣', '2': '2️⃣', '3': '3️⃣',
                '4': '4️⃣', '5': '5️⃣', '6': '6️⃣',
                '7': '7️⃣', '8': '8️⃣', '9': '9️⃣',
            }[v]));

            const str = `
🎮 *TicTacToe Started!*

Waiting for @${room.game.currentTurn.split('@')[0]} to play...

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ Type number (1-9) to play
▢ Type *surrender* to quit
▢ Room ID: ${room.id}
`;

            await sock.sendMessage(chatId, {
                text: str,
                mentions: [room.game.playerX, room.game.playerO]
            });

            scheduleAutoEnd(gameStore, room.id, sock, chatId, [room.game.playerX, room.game.playerO]);

        } else {
            const id = 'ttt-' + Date.now();
            room = {
                id,
                x: chatId,
                o: '',
                game: new TicTacToe(senderId),
                state: 'WAITING'
            };
            if (text) room.name = text;
            gameStore[id] = room;

            await sock.sendMessage(chatId, {
                text: `⏳ Waiting for opponent...\nType *.ttt ${text || ''}* to join!`
            });

            scheduleAutoEnd(gameStore, id, sock, chatId, [senderId]);
        }
    } catch (err) {
        console.error('TicTacToe error:', err);
    }
}

async function handleTicTacToeMove(sock, chatId, senderId, text) {
    try {
        const botId = sock.user.id;
        const gameStore = getGameStore(botId);

        const room = Object.values(gameStore).find(room =>
            [room.game.playerX, room.game.playerO].includes(senderId) &&
            room.state === 'PLAYING'
        );
        if (!room) return;

        const isSurrender = /^surrender$/i.test(text);
        if (!isSurrender && !/^[1-9]$/.test(text)) return;

        if (senderId !== room.game.currentTurn && !isSurrender) {
            await sock.sendMessage(chatId, { text: '❌ Not your turn!' });
            return;
        }

        let validMove = isSurrender || room.game.turn(senderId === room.game.playerO, parseInt(text) - 1);

        if (!validMove && !isSurrender) {
            await sock.sendMessage(chatId, {
                text: '❌ Invalid move! Position already taken.'
            });
            return;
        }

        const arr = room.game.render().map(v => ({
            'X': '❎', 'O': '⭕',
            '1': '1️⃣', '2': '2️⃣', '3': '3️⃣',
            '4': '4️⃣', '5': '5️⃣', '6': '6️⃣',
            '7': '7️⃣', '8': '8️⃣', '9': '9️⃣',
        }[v]));

        let winner = room.game.winner;
        let tie = room.game.turns === 9;

        if (isSurrender) {
            winner = senderId === room.game.playerX ? room.game.playerO : room.game.playerX;
            await sock.sendMessage(chatId, {
                text: `🏳️ @${senderId.split('@')[0]} surrendered!\n🎉 @${winner.split('@')[0]} wins!`,
                mentions: [senderId, winner]
            });
            delete gameStore[room.id];
            return;
        }

        const gameText = `
🎮 *TicTacToe Game*

${winner ? `🎉 @${winner.split('@')[0]} wins!` : tie ? '🤝 Draw!' : `🎲 Turn: @${room.game.currentTurn.split('@')[0]}`}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ ❎: @${room.game.playerX.split('@')[0]}
▢ ⭕: @${room.game.playerO.split('@')[0]}
${!winner && !tie ? '\n▢ Send number (1-9) or type *surrender*' : ''}
`;

        const mentions = [room.game.playerX, room.game.playerO, ...(winner ? [winner] : [])];

        await sock.sendMessage(room.x, {
            text: gameText,
            mentions
        });
        if (room.x !== room.o) {
            await sock.sendMessage(room.o, {
                text: gameText,
                mentions
            });
        }

        if (winner || tie) {
            delete gameStore[room.id];
        } else {
            scheduleAutoEnd(gameStore, room.id, sock, chatId, [room.game.playerX, room.game.playerO]);
        }
    } catch (err) {
        console.error('TicTacToe move error:', err);
    }
}

module.exports = {
    tictactoeCommand,
    handleTicTacToeMove
};