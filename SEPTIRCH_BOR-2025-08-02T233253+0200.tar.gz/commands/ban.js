const fs   = require('fs');
const path = require('path');

/* =========================================
   🔧  HELPERS & CONSTANTS
   ========================================= */
const icons = { header: '🚫', ok: '✅', err: '❌', warn: '⚠️' };

const box = (title, lines) => [
  `╭━━━[ *${icons.header} ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

const sendBox = (sock, chatId, title, lines, extra = {}) =>
  sock.sendMessage(chatId, { text: box(title, lines), ...extra });

/* ---------- bot-scoped data path ---------- */
const dataPath = (botId, file) => {
  const dir = path.join(__dirname, '..', 'data', botId);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, file);
};

/* =========================================
   🚫  BAN COMMAND
   ========================================= */
async function banCommand(sock, chatId, message, botId) {
  /* ---------------------------------
     1️⃣  Identify target user
     --------------------------------- */
  let target =
    message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ||
    message.message?.extendedTextMessage?.contextInfo?.participant;

  if (!target) {
    return sendBox(sock, chatId, 'Ban', [
      `${icons.warn}  Please *mention* the user or *reply* to their message to ban.`
    ]);
  }

  /* ---------------------------------
     2️⃣  Load / update banned list
     --------------------------------- */
  const file = dataPath(botId, 'banned.json');
  let banned = [];
  try {
    if (fs.existsSync(file)) banned = JSON.parse(fs.readFileSync(file));
  } catch { /* ignore malformed file – start fresh */ }

  if (banned.includes(target)) {
    return sendBox(sock, chatId, 'Ban', [
      `${icons.warn}  @${target.split('@')[0]} is *already banned*.`
    ], { mentions: [target] });
  }

  banned.push(target);
  try {
    fs.writeFileSync(file, JSON.stringify(banned, null, 2));
    return sendBox(sock, chatId, 'Ban', [
      `${icons.ok}  Successfully *banned* @${target.split('@')[0]}.`
    ], { mentions: [target] });
  } catch (e) {
    console.error(`banCommand[${botId}]`, e);
    return sendBox(sock, chatId, 'Ban', [
      `${icons.err}  Failed to ban user.`
    ]);
  }
}

module.exports = banCommand;