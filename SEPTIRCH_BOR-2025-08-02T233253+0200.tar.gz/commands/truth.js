// commands/truth.js

const { channelInfo } = require('../lib/messageConfig');

// 🔍 List of truths
const truths = [
    "What is the most embarrassing moment of your life?",
    "Have you ever cheated on a test?",
    "What's a secret you've never told anyone?",
    "Who is your crush right now?",
    "If you could switch lives with someone for a day, who would it be?",
    "Have you ever lied to your best friend?",
    "What’s the worst thing you’ve ever done at work or school?",
    "Have you ever stolen something?",
    "What’s your biggest fear?",
    "Have you ever had a one-night stand?",
    "What’s the weirdest dream you’ve ever had?",
    "Have you ever been caught doing something you shouldn’t?",
    "What’s the most expensive thing you’ve broken accidentally?",
    "Do you still have feelings for an ex?",
    "What’s the most childish thing you’re still afraid of?",
    "Have you ever peed in a pool or bath?",
    "Have you ever lied about your age?",
    "What’s something you love but are really bad at?",
    "Have you ever faked being sick to skip something?",
    "Would you date someone much older than you?",
    "What’s something you’ve never told your parents?",
    "Have you ever kissed someone just to get something from them?",
    "What’s your guilty pleasure?",
    "Have you ever used a fake ID?",
    "What’s the most illegal thing you’ve ever done?",
    "Would you rather lose all your memories or all your money?",
    "Have you ever ghosted someone?",
    "What’s the most awkward date you’ve been on?",
    "Have you ever cried over a movie?",
    "What’s the longest you’ve gone without showering?",
    "Have you ever lied to get out of a party?",
    "Have you ever fallen for someone you weren’t supposed to?",
    "What’s something you wish people knew about you?",
    "Would you keep a found wallet or return it?",
    "Have you ever made fun of someone behind their back?",
    "Have you ever regretted a tattoo?",
    "Have you ever talked to yourself in front of a mirror?",
    "What’s the most childish thing you still do?",
    "Have you ever pretended to like a gift you hated?",
    "What’s the most embarrassing song on your playlist?",
    "Have you ever forgotten someone’s name immediately after meeting them?",
    "What’s the dumbest thing you’ve ever bought?",
    "Have you ever eaten food off the floor and lied about it?",
    "What’s the most useless talent you have?",
    "Have you ever said 'I love you' when you didn’t mean it?",
    "Would you break up with someone just because of a text message?",
    "What’s the most immature thing you’ve ever done?",
    "Have you ever cried during a Zoom call?",
    "Would you delete social media if no one else used it?"
];

// 🧾 Styled box message
function formatTruthBox(usernameTag, truthText) {
    return [
        '╭━━━━━━[💬 *TRUTH TIME* 💬]━━━━━━╮',
        `┃ ${usernameTag}, answer honestly!`,
        '┃',
        ...truthText.split('\n').map(line => `┃ ${line}`),
        '╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯'
    ].join('\n');
}

// 📤 Truth command handler
async function sendTruth(sock, chatId, senderId) {
    try {
        const randomIndex = Math.floor(Math.random() * truths.length);
        const selectedTruth = truths[randomIndex];
        const userTag = `@${senderId.split('@')[0]}`;

        const boxMessage = formatTruthBox(userTag, selectedTruth);

        await sock.sendMessage(chatId, {
            text: boxMessage,
            mentions: [senderId],
            ...channelInfo
        });
    } catch (error) {
        console.error('❌ Error sending truth:', error);
        await sock.sendMessage(chatId, {
            text: 'Something went wrong while sending the truth. Try again!'
        });
    }
}

module.exports = { sendTruth };