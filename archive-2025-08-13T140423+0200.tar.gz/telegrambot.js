const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

// --- Configuration ---
const BOT_TOKEN = process.env.BOT_TOKEN || '7511907925:AAHk1dUDKcgHQ7cn3k7zw_UwiBcxQJLmr0U'; // Use environment variable
if (!BOT_TOKEN || BOT_TOKEN === 'REPLACE_WITH_VALID_TOKEN') {
    console.error('❌ TELEGRAM_BOT_TOKEN must be set and valid.');
    process.exit(1);
}
// --- REPLACE THIS WITH YOUR ACTUAL ADMIN ID ---
const ADMIN_ID = '7738315673'; // e.g., '7738315673'
// --- Admin Password ---
const ADMIN_PASSWORD = 'TEAMSEPTORCH'; // 🔒 Password to access admin panel
// --- END Configuration ---
const bot = new TelegramBot(BOT_TOKEN, { polling: true });

// Cooldown for restarts and resets (15 minutes)
const RESTART_COOLDOWN = 15 * 60 * 1000;

// Settings file path
const settingsPath = path.join(__dirname, 'settings.js');
let settings = {};

// Load settings dynamically
function loadSettings() {
    delete require.cache[require.resolve('./settings')];
    settings = require('./settings');
}

// Save settings to file
function saveSettings() {
    const botsToSave = settings.bots || [];
    const userStatesToSave = settings.userStates || {};
    const blacklistedUsersToSave = settings.blacklistedUsers || [];
    const data = `exports.bots = ${JSON.stringify(botsToSave, null, 2)};
exports.userStates = ${JSON.stringify(userStatesToSave, null, 2)};
exports.blacklistedUsers = ${JSON.stringify(blacklistedUsersToSave, null, 2)};`;
    fs.writeFileSync(settingsPath, data);
    loadSettings(); // Reload after saving
}

// Find bot by authKey
function getBotByAuthKey(inputKey) {
    return settings.bots.find(bot => bot.authKey === inputKey);
}

// Get bots owned by user
function getUserBots(chatId) {
    return settings.bots.filter(bot => bot.telegramUserId === chatId);
}

// Check if bot expired
function isExpired(bot) {
    return bot.expiry && new Date(bot.expiry) < new Date();
}

// Notify expiring bots every 6 hours
async function notifyExpiringBots() {
    const now = new Date();
    for (const botConfig of settings.bots) {
        if (botConfig.expiry && botConfig.telegramUserId) {
            const expiryDate = new Date(botConfig.expiry);
            const diffTime = expiryDate - now;
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            const chatId = botConfig.telegramUserId;
            if ((diffDays === 3 || diffDays === 1) && diffTime > 0) {
                try {
                    await bot.sendMessage(chatId, `⚠️ Your bot "${botConfig.botName || 'Unnamed Bot'}" will expire in ${diffDays} day(s). Please renew to continue uninterrupted.`);
                } catch (err) {
                    console.error(`Failed to send expiry notice to ${chatId}:`, err.message);
                }
            } else if (diffDays <= 0 && !botConfig.expiredAt) {
                console.log(`Bot ${botConfig.authKey} for user ${chatId} has expired.`);
                delete botConfig.SESSION_ID;
                botConfig.telegramUserId = null;
                botConfig.expiredAt = botConfig.expiry;
                saveSettings();
            }
        }
    }
}
setInterval(notifyExpiringBots, 1000 * 60 * 60 * 6); // Check every 6 hours

// Admin check
function isAdmin(chatId) {
    return String(chatId) === ADMIN_ID;
}

// --- Main menu buttons ---
function mainMenu(isAdminUser = false) {
    const buttons = [
        [{ text: '🔌 Connect Bot', callback_data: 'connect_bot' }],
        [{ text: '🛑 Stop Bot', callback_data: 'stop_bot' }],
        [{ text: '📋 My Bots', callback_data: 'my_bots' }],
        [{ text: '❓ Help', callback_data: 'help' }]
    ];
    if (isAdminUser) {
        buttons.push([{ text: '🛠 Admin Panel', callback_data: 'admin_panel' }]);
    }
    return { reply_markup: { inline_keyboard: buttons } };
}

loadSettings();
console.log('Bot settings loaded.');

// --- Start command ---
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const name = msg.chat.first_name || 'User';
    if (settings.blacklistedUsers?.includes(String(chatId))) {
        return bot.sendMessage(chatId, '❌ You have been banned from using this service.');
    }
    const welcomeMessage = `👋 Hi ${name}!\nWelcome to SEPTORCH Bot Manager!`;
    bot.sendMessage(chatId, welcomeMessage, {
        parse_mode: 'Markdown',
        ...mainMenu(isAdmin(chatId))
    }).catch(err => console.error(`Error sending start message to ${chatId}:`, err));
});

// --- Callback handler for button clicks ---
bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const data = query.data;
    const name = query.message.chat.first_name || 'User';

    try {
        // --- User Menu Callbacks ---
        if (data === 'connect_bot') {
            await bot.editMessageText('🔑 Send your *Authorization Key* to connect a bot.', {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'back_to_menu' }]
                    ]
                }
            });
            settings.userStates[chatId] = { step: 'awaiting_auth_key', promptMessageId: messageId };
            saveSettings();
        } else if (data === 'stop_bot') {
            await bot.editMessageText('🔑 Send your *Authorization Key* to stop your bot.', {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'back_to_menu' }]
                    ]
                }
            });
            settings.userStates[chatId] = { step: 'awaiting_stop_auth_key', promptMessageId: messageId };
            saveSettings();
        } else if (data === 'my_bots') {
            const bots = getUserBots(chatId);
            let response = '';
            let keyboard = [];
            if (bots.length === 0) {
                response = '🤖 You are not managing any bots yet.';
                keyboard = [[{ text: '⬅️ Back', callback_data: 'back_to_menu' }]];
            } else {
                response = '🤖 *Your Bots:*\n';
                bots.forEach((b, i) => {
                    const status = isExpired(b) ? '❌ Expired' : '✅ Active';
                    response += `${i + 1}. ${b.botName || 'Unnamed Bot'} (${b.themeemoji || ''})\n`;
                    response += `   Access Key: \`${b.authKey}\`\n`;
                    response += `   Status: ${status}\n`;
                    response += `   Expires: ${b.expiry || b.createdAt || 'N/A'}\n`;
                    keyboard.push([
                        { text: `📝 Rename`, callback_data: `rename_bot:${b.authKey}` },
                        { text: `🔄 Restart`, callback_data: `restart_bot:${b.authKey}` }
                    ]);
                });
                keyboard.push([{ text: '⬅️ Back', callback_data: 'back_to_menu' }]);
            }
            await bot.editMessageText(response, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: { inline_keyboard: keyboard }
            });
        } else if (data === 'help') {
            await bot.editMessageText('Need help?\nUse /start to begin or click a button.', {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }],
                        [{ text: '⬅️ Back', callback_data: 'back_to_menu' }]
                    ]
                }
            });
        }

        // --- Admin Panel Access (Password Protected) ---
        else if (data === 'admin_panel') {
            await bot.editMessageText('🔐 *Admin Access Required*\n\nEnter the admin password to continue:', {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Cancel', callback_data: 'back_to_menu' }]
                    ]
                }
            });
            settings.userStates[chatId] = { step: 'awaiting_admin_password', promptMessageId: messageId };
            saveSettings();
        }

        // --- Real Admin Panel (Only shown after correct password) ---
        else if (data === 'admin_panel_authenticated' && isAdmin(chatId)) {
            await bot.editMessageText('🛠 *Admin Panel* — Manage bots globally:', {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '📛 Expired Bots', callback_data: 'admin_expired' }],
                        [{ text: '✅ Active Bots', callback_data: 'admin_active' }],
                        [{ text: '🎟 Unused Tokens', callback_data: 'admin_unused' }],
                        [{ text: '👥 Manage Users', callback_data: 'admin_users' }],
                        [{ text: '➕ Add Token', callback_data: 'admin_add_token' }],
                        [{ text: '🗑 Remove Token', callback_data: 'admin_remove_token' }],
                        [{ text: '📥 Export Data', callback_data: 'admin_export' }],
                        [{ text: '🚫 Blacklist User', callback_data: 'admin_blacklist_user' }],
                        [{ text: '📅 Extend Expiry', callback_data: 'admin_choose_extend' }],
                        [{ text: '✂️ Reduce Expiry', callback_data: 'admin_choose_reduce' }],
                        [{ text: '🔄 Restart All Bots', callback_data: 'admin_restart_all' }],
                        [{ text: '🔄 Reset All Bots (New Keys)', callback_data: 'admin_reset_all_bots' }],
                        [{ text: '⬅️ Back', callback_data: 'back_to_menu' }]
                    ]
                }
            });
        }

        // --- Admin Panel Sub-menus ---
        else if (data === 'admin_expired' && isAdmin(chatId)) {
            const expired = settings.bots.filter(b => isExpired(b));
            let list = '*❌ Expired Bots:*\n';
            if (expired.length === 0) {
                list = '✅ No expired bots.';
            } else {
                expired.forEach((b, i) => list += `${i + 1}. ${b.botName || 'Unnamed'} - \`${b.authKey}\` (Expired: ${b.expiry || b.expiredAt || 'N/A'})\n`);
            }
            await bot.editMessageText(list, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data === 'admin_active' && isAdmin(chatId)) {
            const active = settings.bots.filter(b => !isExpired(b) && b.telegramUserId);
            let list = '*✅ Active Bots:*\n';
            if (active.length === 0) {
                list = '❌ No active bots.';
            } else {
                active.forEach((b, i) => list += `${i + 1}. ${b.botName || 'Unnamed'} - \`${b.authKey}\` (Expires: ${b.expiry})\n`);
            }
            await bot.editMessageText(list, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data === 'admin_unused' && isAdmin(chatId)) {
            const unused = settings.bots.filter(b => !b.telegramUserId);
            let list = '*🎟 Unused Tokens:*\n';
            if (unused.length === 0) {
                list = '✅ No unused tokens.';
            } else {
                unused.forEach((b, i) => list += `${i + 1}. ${b.botName || 'Unnamed'} - \`${b.authKey}\`\n`);
            }
            await bot.editMessageText(list, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data === 'admin_choose_extend' && isAdmin(chatId)) {
            const bots = settings.bots.filter(b => b.expiry);
            const keyboard = bots.map(botItem => [{
                text: `📅 Extend: ${botItem.botName || 'Unnamed'} (${botItem.authKey})`,
                callback_data: `admin_extend:${botItem.authKey}`
            }]);
            keyboard.push([{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]);
            await bot.editMessageText('📅 Select a bot to *extend* its expiry:', {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: { inline_keyboard: keyboard }
            });
        } else if (data === 'admin_choose_reduce' && isAdmin(chatId)) {
            const bots = settings.bots.filter(b => b.expiry);
            const keyboard = bots.map(botItem => [{
                text: `✂️ Reduce: ${botItem.botName || 'Unnamed'} (${botItem.authKey})`,
                callback_data: `admin_reduce:${botItem.authKey}`
            }]);
            keyboard.push([{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]);
            await bot.editMessageText('✂️ Select a bot to *reduce* its expiry:', {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: { inline_keyboard: keyboard }
            });
        } else if (data.startsWith('admin_extend:')) {
            const parts = data.split(':');
            const authKey = parts[1];
            const daysToAdd = parseInt(parts[2]) || 30;
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Bot not found.' });
                return;
            }
            const expiryDate = new Date(botConfig.expiry || new Date());
            expiryDate.setDate(expiryDate.getDate() + daysToAdd);
            botConfig.expiry = expiryDate.toISOString().split('T')[0];
            saveSettings();
            await bot.editMessageText(`✅ Expiry extended by ${daysToAdd} day(s) to *${botConfig.expiry}* for bot "${botConfig.botName || 'Unnamed'}"`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back to Extend List', callback_data: 'admin_choose_extend' }],
                        [{ text: '🏠 Admin Panel', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data.startsWith('admin_reduce:')) {
            const parts = data.split(':');
            const authKey = parts[1];
            const daysToSubtract = parseInt(parts[2]) || 30;
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Bot not found.' });
                return;
            }
            const expiryDate = new Date(botConfig.expiry || new Date());
            expiryDate.setDate(expiryDate.getDate() - daysToSubtract);
            botConfig.expiry = expiryDate.toISOString().split('T')[0];
            saveSettings();
            await bot.editMessageText(`✅ Expiry reduced by ${daysToSubtract} day(s) to *${botConfig.expiry}* for bot "${botConfig.botName || 'Unnamed'}"`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back to Reduce List', callback_data: 'admin_choose_reduce' }],
                        [{ text: '🏠 Admin Panel', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data === 'admin_users' && isAdmin(chatId)) {
            const activeUsers = [...new Set(settings.bots.map(b => b.telegramUserId).filter(Boolean))];
            let msg = '*👥 Active Users:*\n';
            if (activeUsers.length === 0) {
                msg = '✅ No active users.';
            } else {
                activeUsers.forEach((id, i) => {
                    msg += `${i + 1}. \`${id}\`\n`;
                });
            }
            await bot.editMessageText(msg, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data === 'admin_add_token' && isAdmin(chatId)) {
            settings.userStates[chatId] = { step: 'awaiting_new_bot_auth_key' };
            saveSettings();
            await bot.editMessageText('🔑 Enter the new bot auth key:', {
                chat_id: chatId,
                message_id: messageId,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data === 'admin_remove_token' && isAdmin(chatId)) {
            settings.userStates[chatId] = { step: 'awaiting_remove_bot_auth_key' };
            saveSettings();
            await bot.editMessageText('🔑 Enter the auth key to remove:', {
                chat_id: chatId,
                message_id: messageId,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data === 'admin_export' && isAdmin(chatId)) {
            const exportData = {
                bots: settings.bots,
                userStates: settings.userStates,
                blacklistedUsers: settings.blacklistedUsers || []
            };
            const filePath = path.join(__dirname, 'bot_backup.json');
            fs.writeFileSync(filePath, JSON.stringify(exportData, null, 2));
            await bot.sendDocument(chatId, filePath);
            await bot.editMessageText('🛠 *Admin Panel* — Manage bots globally:', {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: mainMenu(true).reply_markup
            });
        } else if (data === 'admin_blacklist_user' && isAdmin(chatId)) {
            settings.userStates[chatId] = { step: 'awaiting_blacklist_user' };
            saveSettings();
            await bot.editMessageText('🆔 Send the Telegram User ID to blacklist:', {
                chat_id: chatId,
                message_id: messageId,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        } else if (data === 'admin_restart_all' && isAdmin(chatId)) {
            const now = Date.now();
            const lastRestart = settings.userStates[chatId]?.adminLastRestart || 0;
            if (now - lastRestart < RESTART_COOLDOWN) {
                const timeLeft = Math.ceil((RESTART_COOLDOWN - (now - lastRestart)) / 60000);
                await bot.answerCallbackQuery(query.id, { text: `⏳ Please wait ${timeLeft} minute(s) before restarting all bots again.` });
                return;
            }
            let restartedCount = 0;
            settings.bots.forEach(botConfig => {
                const botId = `bot${settings.bots.indexOf(botConfig) + 1}`;
                const sessionPath = path.join(__dirname, 'session', botId);
                if (fs.existsSync(sessionPath)) {
                    fs.rmSync(sessionPath, { recursive: true, force: true });
                }
                delete botConfig.SESSION_ID;
                botConfig.telegramUserId = null;
                restartedCount++;
            });
            if (!settings.userStates[chatId]) settings.userStates[chatId] = {};
            settings.userStates[chatId].adminLastRestart = now;
            saveSettings();
            await bot.editMessageText(`🔄 *All bots have been restarted successfully.* (${restartedCount} bots affected)`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        }

        // --- NEW: Reset All Bots ---
        else if (data === 'admin_reset_all_bots' && isAdmin(chatId)) {
            const now = Date.now();
            const lastReset = settings.userStates[chatId]?.adminLastReset || 0;
            if (now - lastReset < RESTART_COOLDOWN) {
                const timeLeft = Math.ceil((RESTART_COOLDOWN - (now - lastReset)) / 60000);
                await bot.answerCallbackQuery(query.id, { 
                    text: `⏳ Please wait ${timeLeft} minute(s) before resetting all bots again.` 
                });
                return;
            }

            const generateAuthKey = () => {
                const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                let key = '';
                for (let i = 0; i < 16; i++) {
                    key += chars.charAt(Math.floor(Math.random() * chars.length));
                }
                return key;
            };

            let resetCount = 0;
            const resetReport = [];
            const notifiedUsers = new Set();

            settings.bots.forEach(botConfig => {
                const oldOwner = botConfig.telegramUserId;
                const oldName = botConfig.botName || 'Unnamed Bot';

                if (oldOwner && !notifiedUsers.has(oldOwner)) {
                    try {
                        bot.sendMessage(oldOwner, `⚠️ *Your bot has been reset by the admin.*\n\n🔹 Bot: *${oldName}*\n🔑 Your previous access key is no longer valid.\n\nPlease contact the admin for a new key.`, {
                            parse_mode: 'Markdown'
                        }).catch(err => console.error(`Failed to notify user ${oldOwner}:`, err));
                    } catch (err) {
                        console.error(`Notification failed for user ${oldOwner}:`, err);
                    }
                    notifiedUsers.add(oldOwner);
                }

                const botId = `bot${settings.bots.indexOf(botConfig) + 1}`;
                const sessionPath = path.join(__dirname, 'session', botId);
                if (fs.existsSync(sessionPath)) {
                    fs.rmSync(sessionPath, { recursive: true, force: true });
                }

                const newAuthKey = generateAuthKey();

                Object.assign(botConfig, {
                    authKey: newAuthKey,
                    botName: 'New Bot',
                    telegramUserId: null,
                    SESSION_ID: undefined,
                    createdAt: new Date().toISOString()
                });

                resetReport.push({
                    botName: botConfig.botName,
                    authKey: newAuthKey
                });

                resetCount++;
            });

            if (!settings.userStates[chatId]) settings.userStates[chatId] = {};
            settings.userStates[chatId].adminLastReset = now;
            saveSettings();

            const exportFilePath = path.join(__dirname, 'new_authkeys_export.txt');
            let exportContent = `🔐 NEW AUTH KEYS - Generated: ${new Date().toISOString()}\n`;
            exportContent += `🔁 Total Bots Reset: ${resetCount}\n\n`;
            resetReport.forEach((item, i) => {
                exportContent += `${i + 1}. ${item.botName} → ${item.authKey}\n`;
            });
            fs.writeFileSync(exportFilePath, exportContent);

            await bot.editMessageText(`🔄 *Resetting all bots...*`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown'
            });

            await bot.sendDocument(chatId, exportFilePath).catch(() => {
                bot.sendMessage(chatId, '📄 Key list could not be sent, but reset was successful.');
            });

            fs.unlinkSync(exportFilePath);

            await bot.editMessageText(`🔄 *All bots have been reset successfully.*\n✅ ${resetCount} bots updated.\n📩 Previous owners were notified.\n📎 New key list sent above.`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]
                    ]
                }
            });
        }

        // --- My Bots Sub-menu Callbacks ---
        else if (data.startsWith('rename_bot:')) {
            const authKey = data.split(':')[1];
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                await bot.editMessageText('🚫 Unauthorized or invalid key.', {
                    chat_id: chatId,
                    message_id: messageId,
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }],
                            [{ text: '⬅️ Back', callback_data: 'my_bots' }]
                        ]
                    }
                });
                return;
            }
            settings.userStates[chatId] = { step: 'awaiting_bot_name_rename', authKey, promptMessageId: messageId };
            saveSettings();
            await bot.editMessageText(`✏️ Enter the new name for your bot "${botConfig.botName || 'Unnamed'}":`, {
                chat_id: chatId,
                message_id: messageId,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Cancel', callback_data: 'my_bots' }]
                    ]
                }
            });
        } else if (data.startsWith('restart_bot:')) {
            const authKey = data.split(':')[1];
            const botConfig = getBotByAuthKey(authKey);
            if (!botConfig) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Bot not found.' });
                return;
            }
            if (botConfig.telegramUserId !== chatId && !isAdmin(chatId)) {
                await bot.answerCallbackQuery(query.id, { text: '🚫 Unauthorized.' });
                return;
            }
            const now = Date.now();
            const lastRestart = settings.userStates[chatId]?.lastRestart || 0;
            if (now - lastRestart < RESTART_COOLDOWN) {
                const timeLeft = Math.ceil((RESTART_COOLDOWN - (now - lastRestart)) / 60000);
                await bot.answerCallbackQuery(query.id, { text: `⏳ Please wait ${timeLeft} minute(s) before restarting again.` });
                return;
            }
            const botId = `bot${settings.bots.indexOf(botConfig) + 1}`;
            const sessionPath = path.join(__dirname, 'session', botId);
            if (fs.existsSync(sessionPath)) {
                fs.rmSync(sessionPath, { recursive: true, force: true });
            }
            delete botConfig.SESSION_ID;
            botConfig.telegramUserId = null;
            settings.userStates[chatId] = {
                step: 'awaiting_session_id',
                authKey,
                lastRestart: now,
                promptMessageId: messageId
            };
            saveSettings();
            await bot.editMessageText(`🔄 *Restarting bot "${botConfig.botName || 'Unnamed Bot'}"...*\nSend your Session ID to reconnect or generate one below:`, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔗 Generate Session ID', url: 'https://web-pair-qr-tze1.onrender.com/' }],
                        [{ text: '⬅️ Cancel', callback_data: 'my_bots' }]
                    ]
                }
            });
        }

        // --- Navigation Callbacks ---
        else if (data === 'back_to_menu') {
            const welcomeMessage = `👋 Hi ${name}!\nWelcome to SEPTORCH Bot Manager!`;
            await bot.editMessageText(welcomeMessage, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: mainMenu(isAdmin(chatId)).reply_markup
            });
            if (settings.userStates[chatId]) {
                delete settings.userStates[chatId];
                saveSettings();
            }
        } else {
            await bot.answerCallbackQuery(query.id, { text: 'Action not recognized or not implemented yet.' });
        }
    } catch (err) {
        console.error(`Error handling callback_query ${data} for ${chatId}:`, err);
        try {
            await bot.sendMessage(chatId, '❌ An error occurred while processing your request. Please try again.');
        } catch (sendErr) {
            console.error(`Failed to send error message to ${chatId}:`, sendErr);
        }
    } finally {
        if (!query.id) return;
        try {
            await bot.answerCallbackQuery(query.id);
        } catch (answerErr) {}
    }
});

// --- Message handler for user text input ---
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text?.trim();
    const messageId = msg.message_id;
    if (!text) return;
    if (settings.blacklistedUsers?.includes(String(chatId))) return;
    const userStateObj = settings.userStates[chatId];
    if (!userStateObj) return;
    const userStateStep = typeof userStateObj === 'object' ? userStateObj.step : userStateObj;
    const promptMessageId = typeof userStateObj === 'object' ? userStateObj.promptMessageId : null;

    try {
        // --- Handle Admin Password Input ---
        if (userStateStep === 'awaiting_admin_password') {
            if (text === ADMIN_PASSWORD) {
                settings.userStates[chatId] = { step: null };
                saveSettings();
                await bot.sendMessage(chatId, '🔓 *Access Granted!* Welcome to the Admin Panel.', {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '📁 Open Admin Panel', callback_data: 'admin_panel_authenticated' }
                        ]]
                    }
                });
                try {
                    await bot.editMessageText('🔓 *Access Granted!*', {
                        chat_id: chatId,
                        message_id: promptMessageId,
                        parse_mode: 'Markdown'
                    });
                } catch (err) {
                    console.error('Could not edit password prompt:', err);
                }
            } else {
                await bot.editMessageText('❌ *Incorrect password.*\n\nTry again or cancel:', {
                    chat_id: chatId,
                    message_id: promptMessageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔁 Try Again', callback_data: 'admin_panel' }],
                            [{ text: '⬅️ Cancel', callback_data: 'back_to_menu' }]
                        ]
                    }
                });
                delete settings.userStates[chatId];
                saveSettings();
            }
            return;
        }

        // --- Handle Authorization Key Input ---
        if (userStateStep === 'awaiting_auth_key') {
            const botConfig = getBotByAuthKey(text);
            if (!botConfig) {
                await bot.editMessageText(`❌ *Invalid or expired Authorization Key*\nPlease try again or contact the admin.`, {
                    chat_id: chatId,
                    message_id: promptMessageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Try Again', callback_data: 'connect_bot' }],
                            [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }]
                        ]
                    }
                });
                return;
            }
            if (isExpired(botConfig)) {
                await bot.editMessageText(`⛔ *This key expired on ${botConfig.expiry || botConfig.expiredAt || 'Unknown'}*. Please renew.`, {
                    chat_id: chatId,
                    message_id: promptMessageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }],
                            [{ text: '🔄 Try Again', callback_data: 'connect_bot' }]
                        ]
                    }
                });
                return;
            }
            if (botConfig.telegramUserId && botConfig.telegramUserId !== chatId) {
                await bot.editMessageText(`⛔ *This bot is already claimed by another user.*`, {
                    chat_id: chatId,
                    message_id: promptMessageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }]]
                    }
                });
                return;
            }
            settings.userStates[chatId] = { step: 'awaiting_session_id', authKey: text, promptMessageId: messageId };
            saveSettings();
            await bot.sendMessage(chatId, '📥 Send your Session ID, or click below to generate one:', {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{
                        text: '🔗 Generate Session ID',
                        url: 'https://web-pair-qr-tze1.onrender.com/'
                    }]]
                }
            });
        } else if (userStateStep === 'awaiting_stop_auth_key') {
            const botConfig = getBotByAuthKey(text);
            if (!botConfig || (botConfig.telegramUserId !== chatId && !isAdmin(chatId))) {
                await bot.sendMessage(chatId, '🚫 Unauthorized or invalid key.', {
                    reply_markup: {
                        inline_keyboard: [[{ text: '📩 Contact Admin @Septorch29', url: 'https://t.me/Septorch29' }]]
                    }
                });
                return;
            }
            delete botConfig.SESSION_ID;
            botConfig.telegramUserId = null;
            saveSettings();
            if (promptMessageId) {
                await bot.editMessageText(`⏹️ Bot "${botConfig.botName || 'Unnamed Bot'}" has been stopped successfully.`, {
                    chat_id: chatId,
                    message_id: promptMessageId,
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'back_to_menu' }]]
                    }
                });
            } else {
                await bot.sendMessage(chatId, `⏹️ Bot "${botConfig.botName || 'Unnamed Bot'}" has been stopped successfully.`, {
                    reply_markup: mainMenu(isAdmin(chatId))
                });
            }
            delete settings.userStates[chatId];
            saveSettings();
        } else if (userStateStep === 'awaiting_session_id') {
            const botConfig = getBotByAuthKey(userStateObj.authKey);
            if (!botConfig) {
                await bot.sendMessage(chatId, '❌ An error occurred. Please start over.');
                delete settings.userStates[chatId];
                saveSettings();
                return;
            }
            if (!/^\w{6,}#\S+$/.test(text)) {
                return bot.sendMessage(chatId, `❌ *Invalid Session ID format.*\nIt should look like \`XXXXX#YYYYY\`.`, { parse_mode: 'Markdown' });
            }
            botConfig.SESSION_ID = text;
            botConfig.telegramUserId = chatId;
            if (!botConfig.expiry && !botConfig.expiredAt) {
                const createdDate = new Date();
                botConfig.createdAt = createdDate.toISOString();
                const expiryDate = new Date(createdDate.getTime() + 30 * 24 * 60 * 60 * 1000);
                botConfig.expiry = expiryDate.toISOString().split('T')[0];
            }
            if (!botConfig.botName || botConfig.botName === 'New Bot' || botConfig.botName === '') {
                settings.userStates[chatId] = { step: 'awaiting_bot_name', authKey: userStateObj.authKey, promptMessageId: messageId };
                await bot.sendMessage(chatId, '📝 What name would you like to give this bot?');
            } else {
                delete settings.userStates[chatId];
                if (promptMessageId) {
                    await bot.editMessageText(`✅ Bot "${botConfig.botName}" connected successfully.`, {
                        chat_id: chatId,
                        message_id: promptMessageId,
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                        }
                    });
                } else {
                    await bot.sendMessage(chatId, `✅ Bot "${botConfig.botName}" connected successfully.`, mainMenu(isAdmin(chatId)));
                }
            }
            saveSettings();
        } else if (userStateStep === 'awaiting_bot_name' || userStateStep === 'awaiting_bot_name_rename') {
            const { authKey } = userStateObj;
            const botConfig = getBotByAuthKey(authKey);
            if (botConfig && (botConfig.telegramUserId === chatId || isAdmin(chatId))) {
                const oldName = botConfig.botName;
                botConfig.botName = text;
                delete settings.userStates[chatId];
                saveSettings();
                let successMessage = `🎉 Bot named *${text}* successfully saved.`;
                if (userStateStep === 'awaiting_bot_name_rename') {
                    successMessage = `✅ Bot renamed from *${oldName || 'Unnamed'}* to *${text}* successfully.`;
                }
                if (promptMessageId) {
                    await bot.editMessageText(successMessage, {
                        chat_id: chatId,
                        message_id: promptMessageId,
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'my_bots' }]]
                        }
                    });
                } else {
                    await bot.sendMessage(chatId, successMessage, mainMenu(isAdmin(chatId)));
                }
            } else {
                await bot.sendMessage(chatId, '❌ An error occurred. Please start over.');
                delete settings.userStates[chatId];
                saveSettings();
            }
        } else if (userStateStep === 'awaiting_new_bot_auth_key') {
            const newAuthKey = text;
            if (getBotByAuthKey(newAuthKey)) {
                await bot.sendMessage(chatId, '🚫 This token already exists.');
                return;
            }
            settings.bots.push({
                authKey: newAuthKey,
                createdAt: new Date().toISOString(),
                botName: 'New Bot',
                telegramUserId: null
            });
            delete settings.userStates[chatId];
            saveSettings();
            await bot.sendMessage(chatId, `✅ Token \`${newAuthKey}\` added successfully.`, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (userStateStep === 'awaiting_remove_bot_auth_key') {
            const authKey = text;
            const index = settings.bots.findIndex(b => b.authKey === authKey);
            if (index === -1) {
                await bot.sendMessage(chatId, '🚫 Token not found.');
                return;
            }
            settings.bots.splice(index, 1);
            delete settings.userStates[chatId];
            saveSettings();
            await bot.sendMessage(chatId, `✅ Token \`${authKey}\` removed successfully.`, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                }
            });
        } else if (userStateStep === 'awaiting_blacklist_user') {
            const userIdToBlacklist = text.trim();
            if (!settings.blacklistedUsers) settings.blacklistedUsers = [];
            if (!settings.blacklistedUsers.includes(userIdToBlacklist)) {
                settings.blacklistedUsers.push(userIdToBlacklist);
                delete settings.userStates[chatId];
                saveSettings();
                await bot.sendMessage(chatId, `🚫 User \`${userIdToBlacklist}\` has been blacklisted.`, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                    }
                });
            } else {
                await bot.sendMessage(chatId, 'ℹ️ User is already blacklisted.', {
                    reply_markup: {
                        inline_keyboard: [[{ text: '⬅️ Back', callback_data: 'admin_panel_authenticated' }]]
                    }
                });
            }
        }
    } catch (err) {
        console.error(`Error handling message from ${chatId}:`, err);
        try {
            await bot.sendMessage(chatId, '✅ Bot connected successfully.');
        } catch (sendErr) {
            console.error(`Failed to send error message to ${chatId}:`, sendErr);
        }
        delete settings.userStates[chatId];
        saveSettings();
    }
});

console.log('Bot is running...');