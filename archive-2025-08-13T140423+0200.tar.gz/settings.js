exports.bots = [
  {
    "botName": "SEPTORCH",
    "themeemoji": "🦄",
    "ownerNumber": "2349047943737",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "NxPl4437xQHoiwyR",
    "telegramUserId": 7738315673,
    "expiryTimestamp": 1753786696977,
    "createdAt": "2025-08-12T07:06:07.641Z",
    "SESSION_ID": "OYQn3BgD#3GCxm499h2x8Nh83eg4LViptEE1HfNMTw9IaEGPUKak"
  },
  {
    "botName": "🦇 vampire 🦇",
    "themeemoji": "🤖",
    "ownerNumber": "2349047943737",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "UUoJkppJeOSYGVai",
    "telegramUserId": 7738315673,
    "expiryTimestamp": 1753810236437,
    "createdAt": "2025-08-12T07:06:09.157Z",
    "SESSION_ID": "SQQXDbQQ#-tj3WAVEY2m0CZ75gSkswJpNb2dGaC65flI0fP3FrTs"
  },
  {
    "botName": "New Bot",
    "themeemoji": "⚡",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "GLUNVtfnjSBYgzeJ",
    "telegramUserId": null,
    "expiryTimestamp": 1751324399000,
    "createdAt": "2025-08-12T07:06:09.337Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "⚡",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "ITlChqiyXJlYX5rz",
    "telegramUserId": null,
    "expiryTimestamp": 1752188399000,
    "createdAt": "2025-08-12T07:06:10.383Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "👑",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "XcVHnlyTs3mosnSc",
    "telegramUserId": null,
    "expiryTimestamp": 1752361199000,
    "createdAt": "2025-08-12T07:06:10.439Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🎯",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "k9B8Vgu7Dxrcn7C5",
    "telegramUserId": null,
    "expiryTimestamp": 1752361199000,
    "createdAt": "2025-08-12T07:06:11.168Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "💫",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "ch8cfiOd5Zsd4UZj",
    "telegramUserId": null,
    "expiryTimestamp": 1753788399409,
    "createdAt": "2025-08-12T07:06:11.202Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🌟",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "HHP84pWH99b8sxNv",
    "telegramUserId": null,
    "expiryTimestamp": 1754175599000,
    "createdAt": "2025-08-12T07:06:11.895Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🔥",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "AjU1F6sx1uXOBzED",
    "telegramUserId": null,
    "expiryTimestamp": 1753796135547,
    "createdAt": "2025-08-12T07:06:11.912Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🛡️",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "xiffoCExdNwktpw6",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:12.078Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "🚀",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "gdq2Fft8xS9Dz0ix",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:12.082Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "⚙️",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-20",
    "authKey": "2BJ2ymoTx0Me7PQP",
    "telegramUserId": null,
    "expiryTimestamp": 1753869068620,
    "createdAt": "2025-08-12T07:06:12.103Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "💎",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "VObPVDi8zT8zKdYq",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:12.136Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "2JIiyb5YBie0Jyjv",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:12.727Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "eMIeA4UXjrAgZuQs",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:12.753Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "Ct8aFY7nuLD7rcbp",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:14.027Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "DNLCQobvjcmXtNYV",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:14.032Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "7SMvScq5Z7oHDS4r",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:14.033Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "DIu3E4bggerCEDII",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:14.147Z"
  },
  {
    "botName": "New Bot",
    "themeemoji": "",
    "ownerNumber": "",
    "phoneNumber": "",
    "expiry": "2025-08-21",
    "authKey": "10dixpKtir23SAoI",
    "telegramUserId": null,
    "expiryTimestamp": null,
    "createdAt": "2025-08-12T07:06:15.391Z"
  }
];
exports.userStates = {
  "1208243019": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9603
  },
  "1691883937": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7949
  },
  "1974108270": {
    "step": "awaiting_session_id",
    "authKey": "7MgMCN9SUwNJSUA1",
    "promptMessageId": 9067
  },
  "1984959557": {
    "step": "awaiting_auth_key",
    "promptMessageId": 3602
  },
  "2046598405": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8170
  },
  "8135871264": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7828
  },
  "6834525619": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7904
  },
  "6178610094": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "promptMessageId": 8106
  },
  "6582804562": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8122
  },
  "7179979536": {
    "step": "awaiting_session_id",
    "authKey": "HLT31Q98O3LBzXzy",
    "lastRestart": 1753722572914,
    "promptMessageId": 8165
  },
  "7569969378": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8197
  },
  "5603889826": {
    "step": "awaiting_session_id",
    "authKey": "lNNXjvoQoMHUEFMz",
    "promptMessageId": 8265
  },
  "5613886154": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8335
  },
  "8454766080": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8372
  },
  "7013483934": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8411
  },
  "6318304090": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8454
  },
  "7698997438": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7584
  },
  "7561987171": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8338
  },
  "7262422290": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8504
  },
  "6952558480": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8547
  },
  "7417554225": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8706
  },
  "7705270175": {
    "step": "awaiting_auth_key",
    "promptMessageId": 8039
  },
  "6533592280": {
    "step": "awaiting_auth_key",
    "promptMessageId": 7348
  },
  "7489934782": {
    "step": "awaiting_session_id",
    "authKey": "jNIabtkeCERNjf6f",
    "promptMessageId": 8922
  },
  "7651849479": {
    "step": "awaiting_session_id",
    "authKey": "h9xCz2VdscUlRWt4",
    "promptMessageId": 8942
  },
  "6446529359": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9117
  },
  "7995698204": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9319
  },
  "8230335047": {
    "step": "awaiting_session_id",
    "authKey": "TKfoNBe71Z3OnTJY",
    "promptMessageId": 9332
  },
  "7543401844": {
    "step": "awaiting_session_id",
    "authKey": "TKfoNBe71Z3OnTJY",
    "promptMessageId": 9330
  },
  "7640425412": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9374
  },
  "6936711750": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9422
  },
  "7210517032": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9518
  },
  "5920552777": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9520
  },
  "7567588756": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9545
  },
  "7705529700": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9573
  },
  "5445162970": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9578
  },
  "6468630089": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9584
  },
  "7405226005": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9599
  },
  "5032528012": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9607
  },
  "6743991616": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9617
  },
  "7856086567": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9637
  },
  "7685257379": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9655
  },
  "7490089479": {
    "step": "awaiting_auth_key",
    "promptMessageId": 6790
  },
  "6914462600": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9660
  },
  "7467159978": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9297
  },
  "7169588332": {
    "step": "awaiting_auth_key",
    "promptMessageId": 5879
  },
  "7821198502": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9810
  },
  "5292926296": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9813
  },
  "6777244790": {
    "step": "awaiting_auth_key",
    "promptMessageId": 9822
  }
};
exports.blacklistedUsers = [];