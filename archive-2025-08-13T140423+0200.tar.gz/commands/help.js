const settings = require('../settings');
const fs = require('fs');
const path = require('path');

// Stylish category formatter
function formatCategory(title, commands) {
    const list = commands.map(cmd => `🔥 ${cmd}`).join('\n');
    return `
╭─⟓ *${title || 'Commands'}* ⟓─╮
${list}
╰──────────────────────╰`;
}

async function helpCommand(sock, chatId, channelLink, botId) {
    const header = `
╭───[ 🤖 *${settings.botName || 'SEPTORCH_BOT'}* ]───╮
│ 📆 Version: *${settings.version || '1.0.0'}*
│ 👑 Developer: *${settings.botOwner || 'SEPTORCH'}*
╰──────────────────╰

📌 Type any command below to use it!
💬 For support, join our channel or send feedback.`;

    const sections = [
        // ——— GENERAL ———
        formatCategory('General', [
            ".help - Show this help menu",
            ".menu - Show this help menu",
            ".bot - Show this help menu",
            ".list - Show this help menu",
            ".ping - Check bot response time",
            ".alive - Verify if bot is active",
            ".tts <text> - Convert text to speech",
            ".joke - Get a random joke",
            ".quote - Get quote of the day",
            ".fact - Get a fun fact",
            ".weather <city> - Weather info",
            ".news - Latest news",
            ".attp <text> - Animated text sticker",
            ".lyrics <song> - Song lyrics",
            ".8ball <question> - Magic 8-ball answer",
            ".groupinfo - Group details",
            ".infogp - Group details",
            ".infogrupo - Group details",
            ".staff - Admins list",
            ".admins - Admins list",
            ".listadmin - Admins list",
            ".🫣 - View once media",
            ".vv2 - View once media",
            ".vv - View once media",
            ".pair <query> - Link WhatsApp and get session ID",
            ".rent <query> - Link WhatsApp and get session ID",
            ".trt <lang> <text> - Translate text",
            ".translate <lang> <text> - Translate text",
            ".ss <url> - Take screenshot of website",
            ".ssweb <url> - Take screenshot of website",
            ".screenshot <url> - Take screenshot of website"
        ]),

        // ——— ADMIN ———
        formatCategory('Admin', [
            ".ban @user - Ban user from group",
            ".unban @user - Unban user",
            ".kick @user - Remove member",
            ".promote @user - Promote admin",
            ".demote @user - Demote admin",
            ".mute <minutes> - Mute group",
            ".unmute - Unmute group",
            ".delete - Delete bot message",
            ".del - Delete bot message",
            ".warnings - List all warnings",
            ".warn @user - Warn member",
            ".antilink on - Enable antilink",
            ".antilink off - Disable antilink",
            ".antibadword on - Enable bad word filter",
            ".antibadword off - Disable bad word filter",
            ".clear - Clear chat history",
            ".tagall - Tag all members",
            ".🔊 <msg> - Tag all members",
            ".chatbot on - Chat AI toggle",
            ".chatbot off - Chat AI toggle",
            ".resetlink - Reset group invite link"
        ]),

        // ——— OWNER ———
        formatCategory('Owner', [
            ".mode public - Set bot in public mode",
            ".mode private - Set bot in private mode",
            ".autostatus on - Auto status reply on",
            ".autostatus off - Auto status reply off",
            ".clearsession - Clear session data",
            ".antidelete on - Prevent deleted messages",
            ".antidelete off - Allow deleted messages",
            ".cleartmp - Clear temporary files",
            ".setpp - Set bot profile picture",
            ".autoreact on - Auto reactions on",
            ".autoreact off - Auto reactions off",
            ".areact on - Auto reactions on",
            ".areact off - Auto reactions off",
            ".autoreply add <trigger> <response> - Add auto reply",
            ".autoreply remove <trigger> - Remove auto reply",
            ".autoreply list - List all auto replies",
            ".fake typing - Fake typing presence",
            ".fake recording - Fake recording presence",
            ".switchfake - Toggle fake presence mode"
        ]),

        // ——— UTILITY ———
        formatCategory('Utility', [
            ".ocr - Extract text from image",
            ".bible <verse> - Bible verses",
            ".getprofile - Show user profile",
            ".profile - Show user profile",
            ".welcome on - Enable welcome message",
            ".welcome off - Disable welcome message",
            ".goodbye on - Enable goodbye message",
            ".goodbye off - Disable goodbye message",
            ".urlshort <url> - Shorten URLs",
            ".short <url> - Shorten URLs",
            ".upload - Upload file",
            ".autoStatus on - Auto status update on",
            ".autoStatus off - Auto status update off",
            ".notes on - Toggle AI note mode",
            ".notes off - Toggle AI note mode"
        ]),

        // ——— STICKERS & IMAGES ———
        formatCategory('Stickers & Images', [
            ".blur - Blur effect on image",
            ".simage - Convert sticker to image",
            ".sticker - Convert media to sticker",
            ".tgsticker <url> - Telegram sticker",
            ".stickertelegram <url> - Telegram sticker",
            ".meme - Send random meme",
            ".take <name> - Sticker metadata",
            ".emojimix 😄+😍 - Mix emojis"
        ]),

        // ——— AI TOOLS ———
        formatCategory('AI Tools', [
            ".gpt <prompt> - Use AI assistant",
            ".gemini <prompt> - Use AI assistant",
            ".imagine <idea> - Generate images",
            ".dalle <idea> - Generate images",
            ".flux <idea> - Generate images"
        ]),

        // ——— FUN ZONE ———
        formatCategory('Fun Zone', [
            ".compliment @user - Give compliment",
            ".insult @user - Insult someone",
            ".flirt - Flirt with someone",
            ".shayari - Romantic Hindi poetry",
            ".goodnight - Night wishes",
            ".roseday - Rose day greetings",
            ".character <name> - Character sticker",
            ".wasted - Wasted effect on DP",
            ".ship - Relationship calculator",
            ".simp @user - Simp reaction",
            ".stupid @user - It's so stupid!",
            ".itssostupid @user - It's so stupid!",
            ".iss @user - It's so stupid!"
        ]),

        // ——— GAMES ———
        formatCategory('Games', [
            ".tictactoe @user - Start game",
            ".ttt @user - Start game",
            ".move <1-9> - Make move",
            ".surrender - Surrender game",
            ".hangman - Play hangman",
            ".guess <letter> - Guess letter",
            ".trivia - Start trivia",
            ".answer <ans> - Answer trivia",
            ".riddle - Solve riddles",
            ".mathgame - Math puzzle game",
            ".mates - Math puzzle game",
            ".matemáticas - Math puzzle game"
        ]),

        // ——— DOWNLOADS ———
        formatCategory('Downloads', [
            ".play <name> - Download music",
            ".song <name> - Download music",
            ".ytmp3 <song> - Download music",
            ".spotify <song> - Spotify downloader",
            ".music <song> - Spotify downloader",
            ".instagram <link> - Instagram downloader",
            ".facebook <link> - Facebook downloader",
            ".tiktok <url> - TikTok downloader",
            ".tt <url> - TikTok downloader",
            ".threads <url> - Threads video/audio DL",
            ".thread <url> - Threads video/audio DL",
            ".threaddl <url> - Threads video/audio DL",
            ".video <url> - Video downloader",
            ".qvideo <url> - HIGH QUALITY Video downloader",
            ".ytmp4 <url> - Video downloader",
            ".yt2mp4 <url> - HIGH QUALITY Video downloader"
        ]),

        // ——— MEDIA TOOLS ———
        formatCategory('Media Tools', [
            ".toMp3 - Convert media to audio",
            ".toaudio - Convert media to audio",
            ".viewonce - Send view-once media",
            ".viewonce2 - Alternative view-once",
            ".vv - Send view-once media",
            ".vv2 - Alternative view-once",
            ".🫣 - Alternative view-once"
        ]),

        // ——— EXTRA FEATURES ———
        formatCategory('Extra Features', [
            ".topmembers - Top message contributors",
            ".notes <query> - Save chat notes",
            ".summary - Summarize chat",
            ".topics - List saved topics",
            ".github - Source code link",
            ".sc - Source code link",
            ".repo - Source code link",
            ".owner - Bot owner info"
        ]),

        // ——— TEXT MAKER FONTS ———
        formatCategory('Text Maker (Fonts)', [
            ".metallic <text>",
            ".ice <text>",
            ".snow <text>",
            ".impressive <text>",
            ".matrix <text>",
            ".light <text>",
            ".neon <text>",
            ".devil <text>",
            ".purple <text>",
            ".thunder <text>",
            ".leaves <text>",
            ".1917 <text>",
            ".arena <text>",
            ".hacker <text>",
            ".sand <text>",
            ".blackpink <text>",
            ".glitch <text>",
            ".fire <text>"
        ]),

        // ——— CREDITS ———
        formatCategory('Credits', [
            ".owner - Show bot owner info",
            ".credits - Credits info",
            ".channel - Join official channel"
        ])
    ];

    const helpMessage = `${header}\n\n${sections.join('\n\n')}\n\n💡 *Tips:*
- Use .menu anytime to reopen this menu
- Use commands by replying to media where needed
- Some commands require group context/admin rights
- Owner commands are exclusive to the bot owner`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');

        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363387922693296@newsletter',
                        newsletterName: 'SEPTORCH',
                        serverMessageId: -1
                    }
                }
            });
        } else {
            await sock.sendMessage(chatId, {
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363387922693296@newsletter',
                        newsletterName: 'SEPTORCH',
                        serverMessageId: -1
                    }
                }
            });
        }
    } catch (err) {
        console.error('Error in help command:', err);
        await sock.sendMessage(chatId, { text: '*⚠️ Failed to load help menu. Try again later.*' });
    }
}

module.exports = helpCommand;