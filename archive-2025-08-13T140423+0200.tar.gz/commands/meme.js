const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');

// Register the custom font
registerFont(path.join(__dirname, '../assets/fonts/Lobster-Regular.ttf'), { family: 'Lobster' });

const memeCaptions = [
  "They put am, you cry.\nThey commot am,\nyou put am back.",
  "Heartbreak dey pain keh?\nHave u plug your phone overnight\nMake e no charge 😂",
  "When Superman fly you say 'He is a Hero',\nBut when grandma fly you say 'She is a witch'",
  "From “I love your voice” to “kindly type”\nSo na like this my time take expire 😂",
  "Where can I find those families that say:\n'Take this $2m and leave our daughter' 😭",
  "But you don’t look broke”\nNa until I tie rag for neck? 😔",
  "I like nonchalant guys\nNow they’ve replied your 45 mins VN with “OK” 😭",
  "For me to enter relationship\nI'd rather enter problem 😂",
  "Once bitten?\nBetter bite the werey back 😤",
  "Women: men get audacity with money\nMen: una get audacity with zero balance 😤😂",
  "Cherish the time with me o\nI fit go UK anytime ✈️",
  "No vex say we no dey talk again\nNa pride hold the two of us 😅",
  "I dey fight for my life\nOne person dey vex say I no text am 🙄",
  "Una go just wake up drip quote like say sense dey una head 😒",
  "NET WORTH:\nGBESE 💸",
  "You fit still get evidence\nI go still deny am 😌😂",
  '"hey stranger" 👋\nAn ashawo is about to destroy your relationship 😂',
  "Neighbor: Una too dey make noise o!\nMe: I never come back from work yet Jacks 😅",
  "Abii make I born make dem dey dash my pikin money? 😂",
  "Some people get memes pass their money 💀",
  "Hit chest 3x\nSay: I must leave this country 😭",
  "If you sabi pamper person text me Abeg 🥺",
  "Everything you heard about me is true\nYes I be bad person 🥲",
  "Law student?\nAbeg attend class — I no wan go jail bcos of you 😂",
  "First: I'm tired.\nSecond: Make person run me 100k\nPut am for Opay abeg 😭",
  "Na God get final say\nMake I go sleep small 😴",
  "Gender 1: why you stop texting?\nGender 2: I want my kids to be fine 😔",
  "Giver show receiver update\nReceiver say he no get time 😤",
  "Me sef go meet person wey go show me love,\nBut for now I go soak garri 💔",
  "E shock you? E shock me too! 😲",
  "Who dey breet? Na me dey breet! 😎",
  "No gree for anybody this year o! 💪",
  "Your landlord dey knock door\nYour account balance dey laugh you 😂",
  "Na me be the 'Odogwu' you dey find! 🔥",
  "You dey wait for alert\nBut na 'Low Battery' you dey see 😭",
  "Japa don turn Japa-nonsense! ✈️😩",
  "Fuel don cost, NEPA don bill\nMy pocket say 'Omo Oba' 😪",
  "You dey chop life\nBut your bank account dey chop you 😅",
  "I tell am say I no get money\nShe say 'Use data call me' 😂",
  "Person wey dey owe me\nDey post 'God when?' 😒",
  "Na only you waka come?\nNo, I bring poverty join body 😭",
  "Your babe dey call you stingy\nBut your account balance na stingier 😔",
  "Wahala no dey finish\nBut garri no dey ever finish! 🥣",
  "You say you no go love again\nNext week you don dey toast 😍😂",
  "When you see 'Transaction Failed'\nBut you don already dey plan dinner 😭",
  "Na who get money dey find true love\nMe wey dey trek dey find transport 😅",
  "Omo, this life no balance o\nEven my garri no level! 😩",
  "You dey find better babe?\nCheck your account balance first 😏",
  "I say I no dey do again\nBut na lie, I dey do am small small 😅",
  "Bros, you get shishi?\nNo, but I get vibes! 😎",
  "Na so so 'God abeg' we dey pray\nBut God say 'Work hard' 🙏😭",
  "Your babe dey post 'Single and Happy'\nBut she dey your DM by 2am 😍",
  "Dollar don reach 2000\nMy salary still dey 2002 😪",
  "You dey form posh\nBut your account dey speak pidgin 😅",
  "I no dey jealous o\nBut how you take buy iPhone 16? 😒",
  "No be say I no get money\nNa just say the money no get me 😔",
  "You dey wait for bae\nBae dey wait for bank alert 😭",
  "Na me go open boutique\nBut for now, I dey patch my trouser 🪡",
  "You say my head no correct\nBut my bank account no correct pass 😅",
  "I dey hustle for better life\nBut life dey hustle me back 😩",
  "Your pastor say 'Sow seed'\nMy account say 'No land' 🌱😭",
  "Na who dey enjoy dey call am love\nMe I dey call am billing 😤",
  "You dey plan wedding\nBut your savings dey plan funeral ⚰️",
  "I no dey broke o\nNa just temporary brokenness 😅",
  "You say you get standards\nBut you dey trek under rain 😔",
  "Na me be the vibe\nBut NEPA cut my light 😩",
  "You dey find sugar daddy\nBut na sugarcane daddy you go see 😅",
  "I dey pray for money\nBut na data I dey get 😒",
  "Your babe dey call you king\nBut your pocket dey call you pauper 😭",
  "No be my fault o\nNa economy dey fault me 😪",
  "You dey talk about loyalty\nBut your babe dey greet her ex 😏",
  "I no dey give up\nBut my bank account don surrender 🏳️",
  "You say you dey hustle\nBut na sleep you dey hustle pass 😴",
  "Na me go buy Benz o\nBut for now, I dey jump bus 🚍",
  "You dey call me bro\nBut your sister dey call me boo 😍",
  "No be say I no sabi love\nNa money I no sabi 😔",
  "Your tailor dey promise tomorrow\nBut tomorrow don turn next month 😅",
  "I dey plan big things\nBut my pocket dey plan small small 😭",
  "You dey find true love\nBut na true billing you go find 💸",
  "Na me go build house o\nBut for now, I dey dodge landlord 😅",
  "You say I no get sense\nBut my sense don commot with fuel price 😩",
  "I no dey lazy o\nNa opportunity dey lazy me 😔",
  "You dey call am groove\nBut na garri I dey groove with 🥣",
  "No be say I no fine\nNa my wallet no fine 😭",
  "You dey wait for miracle\nBut na mistake you go get 😅",
  "I dey find better job\nBut job dey find better person 😔",
  "Your babe dey form hard to get\nBut her phone dey form hard to charge 😭",
  "Na me go shine this year\nBut NEPA say no light 😩",
  "You dey talk about goals\nBut na goalkeeper I be for now ⚽",
  "I no dey fear anybody\nBut my landlord dey fear me 😅",
  "You say you dey vex\nBut my account dey vex pass 😤",
  "Na me go make am big\nBut for now, I dey make am small 😔",
  "You dey find peace of mind\nBut na piece of garri you go see 🥣",
  "I no dey dull o\nNa my pocket dey dull me 😭",
  "You dey call am love\nBut na data she dey love 😅",
  "Na me go relocate o\nBut my savings no gree relocate 😩",
  "You dey talk about vibes\nBut na hunger dey give me vibes 😔",
  "I no dey stingy o\nNa my money dey stingy me 😅",
  "You dey plan vacation\nBut na village you go visit 😭",
  "Na me go buy jet o\nBut for now, I dey trek 😪",
  "Exam don start, meme no dey my head again.",
  "I feel so sigma and awnn..\nThey no sabi the meaning of sigma oh.",
  "You're not hard to love..\nYou're just 17.",
  "Today is such a lovely day, right guys?",
  "Wetin remain for my account na my name.",
  "If it's money laundering, involve me please.",
  "All these because of one degree?",
  "Don't let this weather allow you to text the wrong person..\nDrop your phone and sleep.",
  "If you have not eaten by this time, why?",
  "I never dey mood for like 14 years now.",
  "Cause of death: data subscription.",
  "Y'all be acting like you don't know book.",
  "If you're afraid of posting a certain status because people will judge you,\nforward it to me.",
  "God did it again..\nWe're all awake this morning.",
  "Mi o get ara mi",
  "Rain dey fall now, your boyfriend no wear hoodie..\nNa when sun dey shine, he go wear hoodie and socks.",
  "Thought I was reading pdf..\nhow did I get to this app again?",
  "I wish I had 2k.",
  "It's the weekend.",
  "Happy birthday.\nSorry, I mean happy Sunday 💐",
  "Guys, I'm thinking of going into music.",
  "Don't grow up, it's a trap.",
  "I go soon craze..",
  "My belle go think say I hate am.",
  "You don ask AI for sub before?",
  '"liked your story"-- how bout you like me instead?',
  "Get like 6 babes.\nOgun fit kill 4.",
  "To cut the story short, I have spent my school fees.",
  "Make we do quick start war.",
  "So, I no go chop sleep bai.",
  "We go again today, even though I no wan go.",
  "Please if you're coming into my life, hold money.",
  "Aren't you old enough to be lying that you're single?",
  "If you never enter school yet, no enter.",
  "Stay humble, just be doing bad.",
  '"I\'ve got a lot of pdf to cover" don use duvet cover body.',
  "I like you and your babe, I fit join the relationship?",
  "If you sent me money today, drop account number.",
  "I just wanna hug someone and stay there..\nI'm so tired.",
  "Just dey watch oh, weekend go finish in 2 minutes.",
  "I go thief oh.",
  "Good morning guys, don't tolerate nonsense today.",
  "Sometimes it's not ego, it's self respect.",
  "I feel so tired and awwwwwwn.",
  "I say make I think outside the box today, I nearly craze.",
  "Guys, it's the last Sunday in the month of June!",
  "To dey understand some of una, person need to dey watch Nat Geo Wild",
  "'You look happier'\nThank you, I've been eating 3 times a day.",
  "Everyday is a 'Thank you, Lord' day.",
  "Use sense text me, I never chop today.",
  "Just because the deodorant said 48hrs doesn't mean you should challenge it.",
  "If you go bill another person while I dey here,\nme and you go get serious issue.",
  "It's the month of July.\nThe seventh month of the year.\nBlessings all through this month for us all.",
  "Today is not my birthday but more life to me.",
  "Appreciate life, some just left few hours ago.",
  "Financially, me sef no be my type.",
  "Don't bill me..\nI don't want to lose you.",
  "Is Joy still coming?",
  "As I gentle, naso I take wicked.",
  "If I send your papa, make I bend.",
  "Just because you haven't found the right person,\ndoesn't mean you will.",
  "Dear God, bless the unblessed and keep the blessed blessed.",
  "If you fit feed fine boy, dm.",
  "Tough times don't last..\nSince January??",
  "Fuck!! Erosion don carry my babe.",
  "Thank God it's Friday.",
  "I need like 5 babes.",
  "The little I have done finish.",
  "Who send me come this planet?",
  "God, help me.",
  "It's going to get so much better.",
  "Na who first read go first forget.",
  "You're hungry ke?\nI thought you ATE and left no crumbs?",
  "Music is actually the best thing to exist after food and sleep.",
  "Must tomorrow be Monday?",
  "Chances of running mad this week is very high.",
  "Imagine make person dey sad because say he wan read.",
  "Omoh, first class students get four heads.",
  "Breathe if I'm your favorite.",
  "Na only when I wan pee I dey remember say I get preek.",
  "What if you lose the things that makes you look down on others?",
  "I love people who understand that even if we don't talk, we're good.",
  "To see me go hard..\nI no get clothes.",
  "Omoh × 100",
  "Fuck, I don spend tomorrow money.",
  "God will punish boring texters.",
  "Even on bad terms, loyalty should not change.",
  "Let me fix myself first so I can show you the best version of me.",
  "Are you okay with the weather or my bike man should come and carry you?",
  "Na only memory loss fit save you from your problem.",
  "If you send me 5k now, I fit give you serious girlfriend.\nFine fine girls full my hand o!",
  "How me wey no happy wan make you happy?\nYou no dey think?",
  "If you don chop today, I tap from your grace.",
  "I'm at a point in life where I'm just at a point.",
  "So nobody fit dey work make I dey chop?",
  "God, please don't let sleep ruin my life.",
  "Any plug here wey dey withdraw Subway surf coin?",
  "We don't have it all but there's so much to be grateful for.",
  "God removed my rib to create you, I no complain.\nNow, comot your cloth make I see wetin God create, e turn wahala.",
  "Easy buy wan lock my phone.",
  "Life taught you many lessons but you forgot all of them.",
  "I refuse to be unhappy in this one life that I'm living.",
  "Give me peace of money, I get mind.",
  "Chelsea fans don sacrifice Buhari.",
  "Weekend con dey like view once.",
  "God have mercy upon us all.",
  "Make person no craze before consistency starts to pay.",
  "You don cry reach limit before?",
  "So, no food vender needs model?",
  "right heart, wrong generation.",
  "Kano na long distance relationship but London na true love?\nThief.",
  "Good evening guys.\nWahala dey.",
  "If you're gonna talk bad about me, invite me..\nI'll tell you more bad things.",
  "It's fine. Jesus wept too..\nAbi you strong pass oyigiyigi?",
  "Don't be scared.\nI've woken up to drink water..\nI'm not studying.",
  "Don't forget you're alive for a reason..",
  "Later, I go use vn tell una wetin sup for today's exam.",
  "Craving cake and ice cream but if I see fufu and egusi,\nwho am I to say no?",
  "I dey top 10 poorest youth.",
  "'Have a nice day'\nDon't tell me what to do.",
  "Passing away seems easier than passing my uni degree.",
  "Anytime I want to stfu, I always have one more thing to say.",
  "Them never do frame for me before but them don frame me.",
  "Una many wey love go disgrace",
  "The secret is prayer. The reason is God.\nThe plan is obedience. The result is favour.",
  "My phone dey hot, but my pocket cold! 😭",
  "Na who get light dey watch Netflix o! 🔋",
  "You dey form big boy with empty wallet? 😂",
  "Fuel price don turn me to marathon runner! 🏃",
  "I pray for data, God send me love letter! 😅",
  "Your babe dey call you baby, but na poverty dey raise you! 😔",
  "Na only garri fit settle this matter! 🥣",
  "Landlord knock, I open with prayer! 🙏",
  "I dey hustle, but na sleep dey win! 😴",
  "Your ex dey post flex, but I dey flex garri! 💪",
  "NEPA bill don finish my destiny! 💡",
  "You say you get sense, but your account no gree! 😒",
  "I need visa, but passport dey laugh me! ✈️",
  "Na so so 'I go make it' we dey sing! 🎶",
  "Your pastor dey bless, my pocket dey curse! 😩",
  "I dey plan trip, but trek don plan me! 🚶",
  "Babe say she need love, I say I need airtime! 📱",
  "Na who get money dey form lover boy! 💸",
  "My shoe dey cry, but I dey dance! 💃",
  "You dey wait for alert, I dey wait for grace! 🙌",
  "Fuel don cost, my bike don retire! ⛽",
  "I tell am say I dey fine, but hunger dey laugh! 😂",
  "Your friend dey ball, I dey dodge ball! ⚽",
  "Na only God fit decode this economy! 🤔",
  "I dey save, but my hand dey spend! 💰",
  "You dey form slay queen with borrowed wig! 👑",
  "My data finish, my hope finish join! 📴",
  "Na who get generator dey shine! 💡",
  "I dey pray for breakthrough, na breakdown I dey get! 😭",
  "Your babe dey form hard, but her phone soft! 📱",
  "I need money, not motivational quote! 💬",
  "Na so so traffic, my life don jam! 🚗",
  "You dey flex iPhone, I dey flex torchlight! 🔦",
  "My landlord dey form boss, I dey form tenant! 🏠",
  "I dey fast, but food dey fast me! 🍽️",
  "Your crush dey online, my credit offline! 😅",
  "Na who get data dey update status! 📲",
  "I dey beg God, but NEPA dey beg me! 💡",
  "You say you get swag, but na rag you wear! 😄",
  "My account balance na emergency number! 📞",
  "I dey plan wedding, but ring don rust! 💍",
  "Na who get fuel dey move forward! ⛽",
  "Your babe dey call you king, I dey call her queen of stress! 👑",
  "I dey hustle for abroad, but visa dey abroad me! ✈️",
  "Na so so promise, my pocket empty! 😔",
  "You dey form rich, but na rent you owe! 😂",
  "My phone dey ring, but na debt dey call! 📱",
  "I dey pray for light, NEPA pray for me! 💡",
  "Your friend dey travel, I dey travel in dream! 😴",
  "Na who get shishi dey talk sense! 💰",
  "I dey save for house, landlord save my rent! 🏡",
  "You dey form lover, but na hunger dey love you! 😅",
  "My data plan don expire, my life plan too! 📴",
  "Na so so stress, my head don scatter! 🤯",
  "You dey flex car, I dey flex leg work! 🚶",
  "I dey beg for food, my pride dey beg too! 🍲",
  "Your babe dey form fine, but na filter dey fine! 📸",
  "Na who get network dey chat! 📶",
  "I dey plan big, but my pocket plan small! 😭",
  "You say you get game, but na shame you get! 😂",
  "My phone dey low, my spirit low pass! 📱",
  "Na who get money dey find peace! ✌️",
  "I dey dodge bill, bill dey dodge me! 💸",
  "Your friend dey ball, I dey hold ball! ⚽",
  "Na so so prayer, my problem still dey! 🙏",
  "You dey form boss, but na loss you dey! 😄",
  "My account dey sleep, I dey wake am! 💤",
  "I dey fast for blessing, hunger dey fast me! 🍽️",
  "Your babe dey call you boo, I dey call her debt! 📞",
  "Na who get light dey cook! 💡",
  "I dey plan trip, my leg plan stay! 🚶",
  "You dey flex shoe, I dey flex sole! 👟",
  "My data finish, my joy finish join! 📴",
  "Na so so hustle, my body don tire! 😩",
  "You say you get vibe, but na tribe you get! 😂",
  "I dey pray for car, trek dey answer! 🚗",
  "Your friend dey shine, I dey shine torch! 🔦",
  "Na who get money dey form hero! 💪",
  "I dey save for future, past dey spend! ⏳",
  "You dey form love, but na love scam! 😅",
  "My phone dey die, my hope dey die too! 📱",
  "Na so so bill, my peace don run! 💸",
  "You dey flex watch, I dey watch time! ⏰",
  "I dey beg for data, network beg me! 📶",
  "Your babe dey form queen, I dey form pauper! 👑",
  "Na who get fuel dey flex! ⛽",
  "I dey plan party, garri dey plan me! 🥣",
  "You say you get style, but na file you get! 😂",
  "My account dey cry, I dey laugh am! 😭",
  "Na so so stress, my head don block! 🤯",
  "You dey form rich, but na stitch you need! 🧵",
  "Abeg if person wan swallow pride, which soup he go use?",
  "Your future doctors are using chatgpt to pass their exams.You better start eating healthy.",
  "I dey pray for light, darkness dey pray back! 💡"
];

async function memeCommand(sock, chatId) {
  try {
    const memePath = path.join(__dirname, '../assets/meme.jpg'); // Clown image
    const image = await loadImage(memePath);

    const canvas = createCanvas(image.width, image.height);
    const ctx = canvas.getContext('2d');

    // Apply blur filter to the clown image
    ctx.filter = 'blur(5px)'; // 5px blur radius, adjustable
    ctx.drawImage(image, 0, 0, image.width, image.height);
    ctx.filter = 'none'; // Reset filter for text rendering

    const randomMeme = memeCaptions[Math.floor(Math.random() * memeCaptions.length)];
    const lines = splitTextToLines(randomMeme, 15);

    const fontSize = Math.floor(image.height * 0.07); // Increased for readability
    ctx.font = `bold ${fontSize}px "Lobster"`;
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.95)'; // Solid white with high opacity
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)'; // Strong black outline
    ctx.lineWidth = 4; // Thicker outline for contrast
    ctx.shadowColor = 'rgba(0, 0, 0, 0.5)'; // Subtle shadow
    ctx.shadowBlur = 4;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;

    const centerX = image.width / 2;
    const totalHeight = lines.length * fontSize * 1.5; // Increased line spacing
    const startY = (image.height - totalHeight) / 2 + fontSize; // Centered vertically

    lines.forEach((line, i) => {
      const y = startY + i * fontSize * 1.5;
      ctx.strokeText(line, centerX, y); // Outline first
      ctx.fillText(line, centerX, y);   // Fill with white
    });

    const buffer = canvas.toBuffer('image/jpeg');

    await sock.sendMessage(chatId, {
      image: buffer,
      caption: '💙 meme by *SEPTORCH_BOT*'
    });

  } catch (error) {
    console.error('❌ Error generating meme:', error);
    await sock.sendMessage(chatId, {
      text: '❌ Failed to send your custom meme. Try again later.'
    });
  }
}

// Helper: Split text into lines with max `maxChars` per line
function splitTextToLines(text, maxChars) {
  const words = text.split(/\s+/);
  const lines = [];
  let current = '';

  for (const word of words) {
    if ((current + word).length > maxChars) {
      lines.push(current.trim());
      current = word + ' ';
    } else {
      current += word + ' ';
    }
  }

  if (current.trim()) lines.push(current.trim());
  return lines;
}

module.exports = memeCommand;