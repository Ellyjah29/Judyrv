const { setAntilink, getAntilink, removeAntilink } = require('../lib/index');
const isAdmin = require('../lib/isAdmin');

const prefix = '.';

/* prettier-ignore */ const icons = {
    header:  '🛡️',   on:      '✅',   off:     '🛑',
    set:     '⚙️',   warn:    '⚠️',   kick:    '🚫',
    delete:  '🗑️',   error:   '❌',   info:    'ℹ️'
};

/* ========== helpers ========== */
const box = (title, lines) => [
  `╭━━━[ *${icons.header} ${title.toUpperCase()}* ]━━━╮`,
  ...lines.map(l => `┃ ${l}`),
  '╰━━━━━━━━━━━━━━━━━━━━━━╯'
].join('\n');

const send = (sock, chatId, title, lines) =>
  sock.sendMessage(chatId, { text: box(title, lines) });

/* ========== command handler ========== */
async function handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, botId) {
  try {
    if (!isSenderAdmin) {
      return send(sock, chatId, 'Admins Only', [
        `${icons.error}  This command is restricted to *group admins*.`
      ]);
    }

    const args   = userMessage.slice(9).trim().toLowerCase().split(/\s+/);
    const action = args[0];

    if (!action) {
      return send(sock, chatId, 'Antilink Setup', [
        `${icons.info}  Usage:`,
        `${prefix}antilink on`,
        `${prefix}antilink off`,
        `${prefix}antilink set <delete|kick|warn>`,
        `${prefix}antilink get`
      ]);
    }

    switch (action) {
      /* ---- turn on ---- */
      case 'on': {
        const cfg = await getAntilink(chatId, botId);
        if (cfg?.enabled) {
          return send(sock, chatId, 'Antilink', [
            `${icons.info}  Antilink is *already ON*.`
          ]);
        }
        const ok = await setAntilink(chatId, 'on', 'delete', botId);
        return send(sock, chatId, 'Antilink', [
          ok ? `${icons.on}  Antilink has been *enabled*.`
             : `${icons.error}  Failed to enable Antilink.`
        ]);
      }

      /* ---- turn off ---- */
      case 'off': {
        await removeAntilink(chatId, botId);
        return send(sock, chatId, 'Antilink', [
          `${icons.off}  Antilink has been *disabled*.`
        ]);
      }

      /* ---- set action ---- */
      case 'set': {
        const option = args[1];
        if (!['delete', 'kick', 'warn'].includes(option)) {
          return send(sock, chatId, 'Antilink', [
            `${icons.error}  Invalid option. Use *delete*, *kick*, or *warn*.`
          ]);
        }
        const ok = await setAntilink(chatId, 'on', option, botId);
        return send(sock, chatId, 'Antilink', [
          ok ? `${icons.set}  Action set to *${option}*.`
             : `${icons.error}  Failed to update action.`
        ]);
      }

      /* ---- get status ---- */
      case 'get': {
        const cfg = await getAntilink(chatId, botId) || {};
        return send(sock, chatId, 'Antilink Status', [
          `Status : ${cfg.enabled ? 'ON' : 'OFF'}`,
          `Action : ${cfg.action || '—'}`
        ]);
      }

      /* ---- fallback ---- */
      default:
        return send(sock, chatId, 'Antilink', [
          `${icons.error}  Unknown sub-command. Type *${prefix}antilink* for help.`
        ]);
    }
  } catch (err) {
    console.error(`Antilink error [${botId}]`, err);
    await send(sock, chatId, 'Antilink', [
      `${icons.error}  An unexpected error occurred.`
    ]);
  }
}

/* ========== link detection ========== */
async function handleLinkDetection(sock, chatId, message, userMessage, senderId, botId) {
  const cfg = await getAntilink(chatId, botId);
  if (!cfg?.enabled) return;

  const linkRx = {
    whatsappGroup  : /chat\.whatsapp\.com\/[A-Za-z0-9]{20,}/,
    whatsappChannel: /wa\.me\/channel\/[A-Za-z0-9]{20,}/,
    telegram       : /t\.me\/[A-Za-z0-9_]+/,
    allLinks       : /https?:\/\/\S+/
  };

  const matched =
    (cfg.type === 'whatsappGroup'   && linkRx.whatsappGroup.test(userMessage))   ||
    (cfg.type === 'whatsappChannel' && linkRx.whatsappChannel.test(userMessage)) ||
    (cfg.type === 'telegram'        && linkRx.telegram.test(userMessage))        ||
    (cfg.type === 'allLinks'        && linkRx.allLinks.test(userMessage));

  if (!matched) return;

  /* ---- delete the offending message ---- */
  try {
    await sock.sendMessage(chatId, {
      delete: {
        remoteJid: chatId,
        fromMe: false,
        id: message.key.id,
        participant: message.key.participant || senderId
      }
    });
  } catch (e) {
    console.error(`[${botId}] delete failed`, e);
  }

  /* ---- enforce chosen action ---- */
  const mentions = [senderId];
  const nameTag  = `@${senderId.split('@')[0]}`;

  switch (cfg.action) {
    case 'warn':
      await send(sock, chatId, 'Antilink Warning', [
        `${icons.warn}  ${nameTag}, posting links is not allowed.`
      ], mentions);
      break;

    case 'kick':
      try {
        await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
        await send(sock, chatId, 'Antilink Kick', [
          `${icons.kick}  ${nameTag} was removed for posting a link.`
        ], mentions);
      } catch (e) {
        console.error(`[${botId}] kick failed`, e);
        await send(sock, chatId, 'Antilink', [
          `${icons.error}  Could not kick user — is the bot an admin?`
        ]);
      }
      break;

    default: // delete
      await send(sock, chatId, 'Antilink', [
        `${icons.delete}  A link was removed.`
      ]);
  }
}

module.exports = { handleAntilinkCommand, handleLinkDetection };