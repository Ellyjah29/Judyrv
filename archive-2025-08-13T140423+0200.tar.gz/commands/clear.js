const { channelInfo } = require('../lib/messageConfig');

async function clearCommand(sock, chatId, senderId, botId) {
    try {
        // Use your robust isAdmin system
        const { isSenderAdmin, isBotAdmin } = await require('../lib/isAdmin')(sock, chatId, senderId, botId);

        if (!isBotAdmin) {
            return await sock.sendMessage(chatId, {
                text: '❌ I need to be an admin to delete messages.',
                ...channelInfo
            });
        }

        if (!isSenderAdmin) {
            return await sock.sendMessage(chatId, {
                text: '❌ Only group admins can use the clear command.',
                ...channelInfo
            });
        }

        const notice = await sock.sendMessage(chatId, {
            text: '🧹 Clearing recent messages...',
            ...channelInfo
        });

        // Fetch messages
        const messages = await sock.fetchMessages(chatId, { limit: 50 });
        if (!messages?.length) return;

        let deletedCount = 0;
        for (const msg of messages) {
            if (!msg.key?.id || deletedCount >= 10) continue;

            // ✅ MOST RELIABLE: Use fromMe flag for self-messages
            // For bot's own messages, fromMe is true
            if (msg.key.fromMe) {
                try {
                    await sock.sendMessage(chatId, {
                        delete: {
                            remoteJid: chatId,
                            fromMe: true,
                            id: msg.key.id,
                            participant: msg.key.participant
                        }
                    });
                    deletedCount++;
                } catch (err) {
                    console.warn(`Failed to delete own msg ${msg.key.id}:`, err);
                }
            }
        }

        // Delete notice
        try {
            await sock.sendMessage(chatId, {
                delete: {
                    remoteJid: chatId,
                    fromMe: true,
                    id: notice.key.id,
                    participant: notice.key.participant
                }
            });
        } catch (err) {
            console.warn('Failed to delete notice:', err);
        }

        if (deletedCount > 0) {
            await sock.sendMessage(chatId, {
                text: `✅ Cleared ${deletedCount} message(s).`,
                ...channelInfo
            });
        }

    } catch (err) {
        console.error('Error in clearCommand:', err);
        await sock.sendMessage(chatId, {
            text: '❌ Failed to clear messages.',
            ...channelInfo
        });
    }
}

module.exports = clearCommand;