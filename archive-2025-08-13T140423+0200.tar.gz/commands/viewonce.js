// commands/viewonce.js

const { downloadContentFromMessage } = require('baileys');
const fs = require('fs');
const path = require('path');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363387922693296@newsletter',
            newsletterName: 'SEPTORCH',
            serverMessageId: -1
        }
    }
};

async function viewOnceCommand(sock, chatId, message) {
    try {
        const ctx = message.message?.extendedTextMessage?.contextInfo;
        const quoted = ctx?.quotedMessage || message.message?.viewOnceMessage?.message;
        const mediaMessage = quoted?.imageMessage || quoted?.videoMessage;

        if (!mediaMessage) {
            await sock.sendMessage(chatId, {
                text: '❌ Please *reply* to a view once image or video!',
                ...channelInfo
            });
            return;
        }

        const isImage = !!quoted.imageMessage || !!quoted?.viewOnceMessage?.message?.imageMessage;
        const isVideo = !!quoted.videoMessage || !!quoted?.viewOnceMessage?.message?.videoMessage;

        const caption = mediaMessage.caption ? `\n*📝 Caption:* ${mediaMessage.caption}` : '';
        const title = '*💀 SEPTORCH Anti ViewOnce 💀*';
        const typeLabel = isImage ? '*📸 Image*' : '*📹 Video*';

        if (isImage) {
            try {
                console.log('📥 Downloading view once image...');
                const stream = await downloadContentFromMessage(mediaMessage, 'image');
                let buffer = Buffer.from([]);

                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                await sock.sendMessage(chatId, {
                    image: buffer,
                    caption: `${title}\n\n*Type:* ${typeLabel}${caption}`,
                    ...channelInfo
                });

                console.log('✅ View once image sent.');
            } catch (err) {
                console.error('❌ Image download error:', err);
                await sock.sendMessage(chatId, {
                    text: '❌ Failed to process image!\n' + err.message,
                    ...channelInfo
                });
            }
            return;
        }

        if (isVideo) {
            try {
                console.log('📥 Downloading view once video...');
                const tempDir = path.join(__dirname, '../temp');
                if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);

                const tempPath = path.join(tempDir, `vo_${Date.now()}.mp4`);
                const stream = await downloadContentFromMessage(mediaMessage, 'video');
                const writer = fs.createWriteStream(tempPath);

                for await (const chunk of stream) {
                    writer.write(chunk);
                }
                writer.end();

                await new Promise(resolve => writer.on('finish', resolve));

                await sock.sendMessage(chatId, {
                    video: fs.readFileSync(tempPath),
                    caption: `${title}\n\n*Type:* ${typeLabel}${caption}`,
                    ...channelInfo
                });

                fs.unlinkSync(tempPath);
                console.log('✅ View once video sent.');
            } catch (err) {
                console.error('❌ Video processing error:', err);
                await sock.sendMessage(chatId, {
                    text: '❌ Failed to process video!\n' + err.message,
                    ...channelInfo
                });
            }
            return;
        }

        await sock.sendMessage(chatId, {
            text: '❌ Unsupported media or not a view once message.',
            ...channelInfo
        });

    } catch (error) {
        console.error('❌ Unexpected error in viewOnceCommand:', error);
        await sock.sendMessage(chatId, {
            text: '❌ Unexpected error!\n' + error.message,
            ...channelInfo
        });
    }
}

module.exports = viewOnceCommand;